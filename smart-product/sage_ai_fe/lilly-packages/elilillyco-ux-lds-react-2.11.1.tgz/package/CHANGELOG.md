# CHANGELOG

_**For the `Version 2` Enterprise Lilly Design System React Package**_

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.11.1](https://github.com/EliLillyCo/ux-lds/releases/tag/v2.11.1)

> 20 Aug 2025

## Changed

- Added node 24 to supported engines

## [2.11.0](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.11.0)

> 12 Aug 2025

### Changed

- **Accordion**
  - Now uses CSS Grid to handle the expand animation - this fixes an issue rendering dynamic content
  - `open` prop is now only needed on the LdsAccordion.Header component

### Fixed

- **Dropdown** - Added a new prop `arrowNavigation` to allow the dropdown to be used with arrow navigation. This prop will set the `aria-haspopup` and `role` attributes appropriately for accessibility.
- **Tabs** - Fixed an issue where the mobile tabs were not using the correct a11y attributes and roles.
- **Datepicker** - Fixed a bug where the LdsDatepicker renders duplicate id for calendar Year input

## [2.10.4](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.10.4)

> 16 July 2025

### Added

- **Right-to-left (RTL) Language support**
  - RTL support added for components.
  - RTL Global toolbar added for storybook.
  - RTL Demo example page added for Form components.

### Fixed

- **Dropdown** - Add built-in auto-close support. When an item is selected, the dropdown will close and focus will return to the dropdown button for accessibility. This behavior can be disabled with the `keepOpenOnSelect` prop.
- **Loading Spinner** - Passed `backgroundColor`, `iconColor`, and `spinnerColor` Storybook args to story component template so that they work as expected.
- **Step Indicator** - Fixed a bug where the component would throw an error if it was rendered before the `indicatorRef` was set. Added null checks before using `indicatorRef.current`.
- **Progress Indicator** - Added missing ref
- **Product Jump Menu** - Added missing ref
- **Header** - Added missing props to type definitions
- **Search** - Added missing props to type definitions
  - updated `searchOnBtnClick` documentation
  - clear button now works when `searchTerm` is `null` or uncontrolled
- **Pagination** - Added missing props to type definitions

## [2.10.3](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.10.3)

> 02 June 2025

### Fixed

- **Sticky Component** - Implemented the `initScrollPadding` utility in `src/components/LdsSticky/scrollPadding.js` to dynamically adjust `scroll-padding-top` based on the height of the sticky element. This prevents focused elements from being hidden behind the sticky element when navigating with the keyboard.

### Chores

- Moved heroku auth deps into an npm workspace.

## [2.10.2](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.10.2) [#497](https://github.com/EliLillyCo/ux-lds-react/pull/497)

> 05 May 2025

### Added

- **Figma Code Connect** - Created the integration config files for the following components:
  - Figure Caption
  - Tabs
  - Text Field
  - Toast
  - Tooltip
  - Video List Player, Videos List
  - Video List Player, Chapterized Video

### Changed

- **Pagination** - Enhancment to add edge detection so that the dropdown feature can open "up" when at the bottom of the screen.
- **Tooltip** - Enhancement to allow tooltips to be bound to interactive elements such as links or buttons. This makes it so that it can be triggered on hover and not block click/touch events.

### Fixed

- **Chat History** - Bug fix for long text truncation in history list items; also includes a general improvement refactor to the React component.
- **Header** - A11y bug fixes for keyboard interaction to trap focus in mobile menu when it is opened, and until the user chooses to close the menu. When menu is closed, focus the Open Menu button.
- **Icon** - A11y fix for when the icon is decorative; the `<svg>` should not have a `role` attribute when the `aria-hidden` attribute is set to `true` and the `<title>` is unnecessary and should not render

### Chores

- **Icon** - Rewrite of the Icon documentation, primarily to improve the coverage of its accessibility features
- Base LDS dependency updated to require version `2.10.2`

## [2.10.1](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.10.1) [#489](https://github.com/EliLillyCo/ux-lds-react/pull/489)

> 04 April 2025

### Added

- **Figma Code Connect** - Created the integration config files for the following components:
  - Blockquote
  - Date Picker
  - Link
  - Link List
  - Loading Spinner
  - Modal
  - Progress Indicator
  - Select
  - Step Indicator
  - Textarea
  - Video Player

### Changed

- **Chat Modal** - Refactored to use Chat Interface components

### Fixed

- **Image Slider** - A11y QAT revision to include titles to the dots, added `aria-selected` to currently selected dot and adjusted the fullscreen toggle button's labels to match its current toggle state. Added string props for all user facing text.
- **Loading Button** - A11y QAT revision to revise how accessible names are defined for each loading state, fixed icon titles not being configurable and fixed some accessible names being announced multiple times in storybook demos
- **Loading Spinner** - A11y QAT revision to improve color contrast ratio for the Verzenio-brand themed Loading Spinner theming demo example
- **Side Nav (Product)** - Resolved a bug where the logo was not maintaining the same height between collapsed and expanded states
- **Step Indicator** - A11y QAT revision to the DOM pattern to include a screen reader only label to convey when a step is complete
- **Tabs** - Resolved an issue with how the tab stories were rendering in the MDX docs page and resolved a bug that caused the active tab to be focused on page load

### Chores

- **Checkbox** - Updated the Storybook documentation to add more usage examples including making it easier to modify a single instance of a checkbox via a default story for testing. Also updated the `TypeScript `definition and added `PropTypes` validation to the component.
- Base LDS dependency updated to require version `2.10.1`

## [2.10.0](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.10.0) #[476](https://github.com/EliLillyCo/ux-lds-react/pull/476)

> 20 March 2025

### Added

- **Chat History** - new component for displaying chat history items in a sidebar
- **Radio Buttons** - added a property 'autoColumns' to toggle auto layout radio buttons into columns based on horizontal space

### Changed

- **Checkbox and Radio** - Updated CSS classes so that checkbox and radio were no longer sharing CSS classes in case they diverge later on.
- **Numeric Slider** V2 Redesign, includes a major component refactor and documentation rewrite.

### Fixed

- **Image Comparison Slider** - Fix control icon vertical alignment issue
- **Image Slider** - Adjusted control titles to match aria-label value

### Chores

- **Typography** - Update theme token documentation to align with Base typography theme updates.
- Base LDS dependency updated to require version `2.10.0`

## [2.9.1 - HOTFIX](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.9.1) #[468](https://github.com/EliLillyCo/ux-lds-react/pull/468)

> 03 March 2025

### Fixed

- A CSS import from Base LDS wasn't using the `.css` filename extension as `@import './trailing-action/_index'`; this has been updated to be `@import './trailing-action/_index.css'` to correct potential compilation errors in dependent projects.

### Chores

- Base LDS dependency updated to require version `2.9.1`

## [2.9.0](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.9.0) #[465](https://github.com/EliLillyCo/ux-lds-react/pull/465)

> 25 February 2025

### Changed

- **Toast** - V2 redesign

### Fixed

- **Image Slider** - QAT revision to address an issue where the slider controls can overlay the caption content
- **TextField, TextArea** - Resolved a breaking change in release `v2.8.0` caused by the removal of the `error` and `errorMessage` props in these components.

### Removed

- Defunct LDS 1.x `index.css` theme file removed, added a note to the Storybook quick start installation guide

### Chores

- Base LDS dependency updated to require version `2.9.0`

## [2.8.0](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.8.0) [#457](https://github.com/EliLillyCo/ux-lds-react/pull/457)

> 10 February 2025

### Added

- **Drawer (Product)** - New Component for web app products to add a kind of content overlay that slides in from any edge of the screen
- **Side Navigation (Product)** - New Component for web app products to add a functional side menu

### Fixed

- **Jump Menu (Product)** - QAT revisions to right positioning, desktop focus and hover states, accessibility interactions

### Chores

- Form Input Fields - Global usability updates for form fields and minor usage documentation update/refactor

## [2.7.0](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.7.0) [#452](https://github.com/EliLillyCo/ux-lds-react/pull/452)

> 31 January 2025

### Added
- **Chat Interface** - New product application feature

### Changed

- **Button Group** - V2 redesign
- **Textarea** - V2 redesign
- **Progress Indicator** - V2 redesign

### Fixed

- **Jump Menu (Web)** - Accessibility AQT CSS updates
- **Pagination** - missing loop key attribute error

### Removed

### Chores

- **Chat Modal** - SB docs moved to `Components > Modals > Chat Modal`
- **Modal** - Minor docs revisions
- **Modal Interstitials** - Minor docs revisions
- **Table** - Docs updated to refine limitation definitions
- Added release notes documentation
- Updated the EDAT GitHub Workflow configs per recent revisions to the enterprise CI/CD integration

## [2.6.0](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.6.0) [#441](https://github.com/EliLillyCo/ux-lds-react/pull/441)

> 13 January 2025

### Added

- **Product Jump Menu** - React version of Mobile Product Jump Menu component created
- **YouTube Player** - utility component to provide parity with the Kaltura implementation and promote consistency

### Changed

- **Video List Player** - some minor refactoring to improve documentation and functionality

### Fixed

- **Table** - Accessibility issues with Storybook examples

### Chores

- **Video Player** - YouTube usage docuementation rewritten to include the new YouTube Player utility component
- **Video List Player** - full rewrite of the storybook documentation, including verification that both the YouTube and Kaltura utility components function properly in the context of the list player configurations via story demo reimplementation.

## [2.5.2 - HOTFIX](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.5.2) [#435](https://github.com/EliLillyCo/ux-lds-react/pull/435)

> 18 Decemeber 2024

### Changed

- **Footer** - Adjusted v1 cookie button label to be "Cookie Settings" and removed the Language Select usage for legal compliance

### Fixed

- **Footer** - Refactored the React compoonent so that all the sub-components are individaul files and are imported and registered correctly in the base component. This resolves react import/export console errors and standardizes the component implementation with our other components.

## [2.5.1 - HOTFIX](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.5.1) [#433](https://github.com/EliLillyCo/ux-lds-react/pull/433)

> 13 December 2024

### Changed

- Incremental update to match `ux-lds` version 2.5.1 footer privacy link font size

## [2.5.0](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.5.0) - [#432](https://github.com/EliLillyCo/ux-lds-react/pull/432)

> 12 December 2024

### Added

- **Lilly Logo** - New logo with tagline variants and the "L" monogram logo
- **Tooltip** - New functionality to use buttons or custom elements as the tooltip trigger.

### Changed

- **Lilly Logo** - V2 redesign includes a major refactor and re-implementation to handle rendering multiple logo image options
- **Link** - V2 redesign
- **Link List** - V2 redesign
- **Radio Button** - minor component implementation update; SB documentation rewrite
- **Radio Button Group** - minor component implementation update; SB documentation rewrite
- **Option Selector** - V2 redesign

### Fixed

- **Tooltip** - Top / Bottom automatic edge detection

### Removed

- Moved Side Nav styles into ux-lds

### Chores

- Reorganized the Storybook components navigation menu to reflect the current state of the LDS Enterprise Portal component navigation menu

## [2.4.1 - HOTFIX](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.4.1) [#430](https://github.com/EliLillyCo/ux-lds-react/pull/430)

> 11 December 2024

### Changed

- **Footer** - Major legal issue remediation
  - Restore the LDS 1.0 footer implementation and make available
  - Temporarily deprecate the LDS 2.0 footer implementation

## [2.4.0](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.4.0) - [#413](https://github.com/EliLillyCo/ux-lds-react/pull/413)

> 20 November 2024

### Changed

- **Loading Button** - V2 redesign
- **Loading Spinner** - V2 redesign
- **Select** - Component logic refactor to improve applying option reference id's during the flattening parse and allow for ARIA labels on selectable options. Includes documentation rewrite.
- **ValidationError** - Documentation rewrite in anticipation for the LDS 2.0 refactor of form validation states

### Fixed

- **Header** - Mega menu now closes when clicking on the backdrop
- **Side Nav** - Contact lilly & language selector display in mobile
- **Validation Error** - Addresed an incorrect HTML markup pattern
- Revised Storybook documentation for various component pattern examples that include MLRO critical content to both show the correct U.S. English values where possible and add disclaimers that implementation teams need to ensure such content is validated by MLRO before release to production.

### Removed

- **Select** - CSS removed; it was migrated into the `ux-lds` base package
- **Button** - Removed stories for deprecated button style options

## [2.3.3](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.3.3) - [#404](https://github.com/EliLillyCo/ux-lds-react/pull/404)

> 11 November 2024

### Changed

- **Image Slider** - V2 Refactor; includes adding validated props for styling options with optional number indicator.
- **Checkbox & Radio Button** - Labels in story examples are now editable with storybook args for stress testing
- **Validation Error** - Icon now "hangs" to the left of the text in its own wrapper. Error text will never show underneath the icon
- **Step Indicator** - V2 rework

### Fixed

- **Blockquote** - Citation will be aligned to quote text when using a side positioned author photo

## [2.3.2 - HOTFIX](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.3.2) - [#401](https://github.com/EliLillyCo/ux-lds-react/pull/401)

> 29 October 2023

### Fixed

- **Header** - Fixed issues where menu items were not clickable in safari due to the way code handled nav focus.

## [2.3.1](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.3.1) - [#394](https://github.com/EliLillyCo/ux-lds-react/pull/394)

> 22 October 2024

### Changed

- **Accordion** - Refactored the component to have its sub-components in separate files

### Fixed

- **Accordion** - Re-wrote the header sub-component logic primarily to refine and bugfix some funk in the transition animations

### Removed

- **Accordion** - No longer uses the `iconOpenName` prop; when necessary the logicl open-state icon that corresponds to a closed state icon will be set automatically. Simplifying configuration and forcing adherance to LDS Design spec.

## [2.3.0](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.3.0) - [#391](https://github.com/EliLillyCo/ux-lds-react/pull/391)

> 11 October 2024

### Added

- **ISI** - prop `expanded` to programmatically manage the detached presentation state
  - Also created a Vite demo example to show how to use this prop to expand the ISI using a URL query parameter

### Changed

- **Accordion** - prop `open` can now programmatically manage the presentation state
  - Also created a Vite demo example to show how to use this prop to open an Accordion using a URL query parameter
- **Blockquote** - V2 refactor; includes adding validated props for styling options and props for specific content portions.
- **Tabs** - light refactor and documentation updates to include additional usage for the `activeTab` prop using a URL query parameter
- **Tooltip** - V2 refactor; includes adding validated props for styling options.

### Fixed

- **Accordion**
  - Uses validated props `stateClass`, `densityClass` and `radiusClass` to set the available variant classes respectively, as opposed to setting them via the non-validated `className` prop.
  - Uses React REFs instead of JS document selectors where applicable
- **Contact Lilly** - adjustment for horizontal overflow in utility menu
- **Header** - mobile nav panel correctly computes its height based on the height of the top bar (which can vary depending on custom logo sizes)
- **Select** - dropdown was broken in release `2.1.0` and was unable to open
- **Language Select** - adjustment for horizontal overflow in utility menu


## [2.2.0](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.2.0) - [#377](https://github.com/EliLillyCo/ux-lds-react/pull/377)

> 26 September 2024

### Added

- **Datepicker** - now accepts `error` prop to set error styling and aria-invalid on the text field

### Changed

- **Color Documentation** - updated to new requirements from changes in base package
- **Datepicker** - no longer allows letters to be typed into the input
- **Table** - React implementation refactor/optimization
- **Video List Player** - usage documentation updated; primarily the Kaltura variants should be using the `LdsKalturaPlayer` utility component

### Fixed

- **Accordion** - caret-type state icons now animate upon opening or closing
- **Video Player** - Kaltura React logic in the `useAddKalturaScript` hook to prevent inadvertantly causing multiple load attempts of a video embed script on initialization and re-renders.

## [2.1.0](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.1.0) - [#357](https://github.com/EliLillyCo/ux-lds-react/pull/357)

> 11 September 2024

### Added

- **Utility Menu**
  - new authentication/SSO UX component now available for both the Header and SideNav components
  - new `LdsUtilityMenuDropdown` component for the utility nav
- **Video Player** - New `LdsKalturaPlayer` utility component to standardize the embed of Kaltura Videos into an `LdsVideoPlayer` for most typical use cases

### Changed

- **Utility Menu** - styling adjustments to account for the new authentication/SSO feature
- **Video Player** - revised and refactored the Storybook documentation in toto, including adding new documentation for:
  - The `LdsKalturaPlayer` utility component
  - The `useAddKalturaScript` utility React hook
  - The `timeToSeconds` utility function
- **Interactive Card** - major refactor to align with the figma design requirements and standardize functional implementation
- **Contact Lilly** - now shows a headset icon by default for consistency and for responsive performance; can be disabled via props

### Fixed

- **Dropdown** - added edge check in `LdsDropdown` component to open drop down menus in proper direction
- **Interactive Card** - radius options are now tied to the global themeable tokens
- **Accordion** - adjusted the header markup to include a span pattern so that the content does not overlap with the state icon
- **Header** - added missing `hoverOpen` prop for flyout menu to the Storybook documentation table

## [2.0.0](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v2.0.0) - [#339](https://github.com/EliLillyCo/ux-lds-react/pull/339)

> 14 August 2024

_React LDS Major Version №2 involves a complete redesign of almost all our components_

### Added

- **Button** - Click animations
- **Cookie Consent Modal** - NEW Component
- **Divider** - NEW Component (replaces old LdsHorizontalRule)
- **Header** - redesigned with new "Utility Menu" feature
- **Icon** - included more Phosphor icons to the "official" LDS subset library
- **Side Nav** - redesigned with new "Utility Menu" feature
- **Typography Documentation**
  - New storybook documentation
  - New Vite app examples
- General Code Package Features:
  - Typescript support

### Changed

- **Checkbox**
  - New styling
  - Group now uses `mixed` prop instead of `intermediate` prop
- **Tabs** - Display mobile tabs on desktop if they would overflow/wrap
- **Footer** - v2 redesign/refactor
- **Half-Billboard** - Marked as "Deprecated" for v2 launch
- **Hero** - v2 redesing/refactor
  - Merged half-billboard component function into this component
- **Icon** - implementation refactored to use a CSS `mask-image` encoding feature
- **ISI** - v2 redesign/refactor
- **Lilly Logo** - v2 redesign/refactor
- **Language Select** - v2 redesign/refactor
- **Contact Lilly** - v2 redesign/refactor
- **Language Selector** - v2 redesign/refactor
  - options structure changed to a radio group for accessibility
- **Typography** - v2 redesign/refactor
- **Modal** - v2 redesign/refactor
  - Removed `useLdsModal` hook
  - Added react context provider `LdsModalProvider` to manage multiple modals on an app
  - Removed `useLdsHCPModal` hook and added new `LdsHcpModal` component
  - Imporoved stacked and queued modals behavior
- General Chores:
  - Vite app major refactor of page directory structure and app pages

### Fixed

- **Button** - ripple effect breaking `.lds-link` style buttons
- **Footer** - global links breaking when none or less than 1 child
- **Header** - Mega Menu links `target="null"` if no target specified
- **Language Select**
  - was using different names for the hidden input and the radio buttons in the dropdown.
  - now using `onchange` event to set the radio value instead of `onclick`
- **Lilly Logo** - missing feature to edit the SVG's title prop added
- **Pagination** - imporoper page jumping interaction
- **Step Indicator** - added resize observer to watch the component's own width for resize to display the correct responsive mode
- **Switch** - correctly handles as a controlled input if needed

### Removed

- **Accordion** - removed use of web component
- **Horizontal Rule** - superseded by Divider
- **Numeric Slider** - removed use of web component

# Major Version 1 Changes
> Version 2 was forked from Version 1 at release `1.2.0`; see the `CHANGELOG` file on the `main-v1` branch for subsequent Version 1 release notes.

## [1.2.0](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v1.2.0) - [#218](https://github.com/EliLillyCo/ux-lds-react/pull/218)

> 29 January 2024

### Added

- **Alert** - CSS Transition added while closing alert and Adding/triggering Alert example story added.
- **Checkbox Group** - select all functionality
- **Header**
  - Major refactor
  - The global "exo" menu can now have custom content inserted before or after the menu items.
- **ISI** - design tokens added to Storybook
- **Language Select** - now stores a cookie with the users language preference.
- **Progress Indicator** - initial development
- **Radio Group** - `error`, `errorMessage`, and `required` fields to set accessibility attributes
- **Side Nav** - new `flexContent` property for page layout construction
- **Text Field** and **Textarea** - now automatically set `aria-required` when required is set on the component
- Documentation Chores:
  - Layout - new layout classes to set up page layouts.
  - Document `{...rest}` property usage

### Changed

- **Date Picker**
  - year text input changed to `type="text" inputMode="numeric" pattern="[0-9]*"` for a better accessibility pattern
  - 8px margin added between calendar popup and main input
  - Today button added to calendar popup
- **Header** - Major refactor:
  - Updated the menu rendering components so that any menu items can render an additional icon with and that icons can be positioned before or after the text label.
  - Exposed hardcoded text labels so that they can be customized or translated.
  - Rewrote the header usage documentation.
- **Switch**
  - updated to remove state text labels
  - Rewrote the usage documentation

### Fixed

- **Checkbox Group** - accessibility configurations and documentation
- **Date Picker** - year input keydown no longer allows non-numeric characters

## [1.1.2](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v1.1.2) - [#192](https://github.com/EliLillyCo/ux-lds-react/pull/192)

> 14 December 2023

### Added

- **Alert** - now has an optional onClose prop that will trigger after an alert is dismissed.
- **Icons** - included numerous additionl Phosphor icons:
  - Android Logos, Apple Logos, Arrow Clockwise, Arrow Counter-Clockwise, Arrows Clockwise, Arrows Counter-Clockwise, Caret Up-Down, Facebook Logo, Figma Logo, Github Logo, Instagram Logo, Kaltura Play, Linkedin Square Logo, Mac Command, Microsoft Excel Logo, Microsoft Outlook Logo, Microsoft Teams Logo, Microsoft Word Logo, Pinterest Logo, Reddit Logos, Sign In, Sign Out, Slack Logo, Snapchat Logo, Soundcloud Logo, Tiktok Logo, Windows Logo, X (Social) Logo, Youtube Logo

### Changed

- **Date Picker** - The `onChange` event that fires when the input is typed into now returns the actual value that is set on the date picker. Previously there was a mismatch between the value getting set as the actual date value and the value returned. This now matches how the value is returned to the `onChange` event when selecting a date via the calendar.
- **Half-Billboard** - `ImageColumn` and `ContentColumn` props now accept the `className` prop to apply custom classes.
- **Link List** - The `LdsLinkList.SubHeader` component has been deprecated. The new `subHeader` prop on the main component should be used instead. `LdsLinkList.SubHeader` will be removed in LDS V2. This change has been added to improve the accessibility of the Link List

### Fixed

- **Date Picker** - calendar pop up no longer causes scroll at 320px - 340px mobile screens.
- **Footer** - primary links auto column flow option now available to be set by prop
- **Link List** - A11y issue resolved by adding `role="list"` to the `ul`
- **Table** - now sets `aria-labelledby` on the table referencing the `caption`
- **Tabs** - A11y issue resolved by updating the `role` attribute of the main `div`
- **Toast**
  - `autoDismiss` function now works correctly
  - no longer tries to reference document outside of a `useEffect`
  - inline toast action button color
  - `clearAllToasts` function is now actually a function

## [1.1.1](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v1.1.1) - [#180](https://github.com/EliLillyCo/ux-lds-react/pull/180)

> 1 December 2023

### Changed

- **Lilly Logo** component no longer uses web component from ux-lds
- **Loading Spinner** refactored to remove base web component

### Fixed

- **Footer** - original migration did not include the custom override slot option from the Vue version, this feature has been added along with updated documentation.
- **Video player** - loading logic
- **Date Picker** - page no longer scrolls when calendar is open and arrow keys are used to navigate the calendar

## [1.1.0](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v1.1.0) - [#171](https://github.com/EliLillyCo/ux-lds-react/pull/171)

> 17 November 2023

### Added

- **Card** - footer feature
- **Text Field** and **Textarea** - now have a built-in error message

### Fixed

- **Date Picker** - adjusted the selected date hover color for accessibility
- **Side Nav** - updates if menu updates
- **Tabs** - tab ids can now be strings or numbers

### Changed

- **Back-to-Top** component now appears after scrolling 100px (configurable)
- **Figure Caption** - content now accepts string or HTML node
- **Modal** - close icon button
- General Chores:
  - All components now accept custom classname and rest properties

### Removed

- **Alert** - removed use of web component
- **Header** - default props (deprecated React feature)
- General Chores:
  - Replaced the old `<lds-icon>` web component with the `<LdsIcon>` React component in several places

## [1.0.0](https://github.com/EliLillyCo/ux-lds-react/releases/tag/v1.0.0) - [#149](https://github.com/EliLillyCo/ux-lds-react/pull/149)

> 16 October 2023

### Initial Product Release
