import { useState } from 'react';

import { getCookie, deleteCookie, setCookie } from '../util/cookies.js';
import isClientEnvironment from '../util/isClientEnvironment.js';

const scrollOverlayCookie = 'lds_tableScrollOverlays';
const disabledCookieValue = 'disabled';

/**
 * A custom hook for managing table scroll overlays with a neecssary functional cookie.
 *
 * @param {number} dismissExpirationDays - The number of days until the scroll overlays dismiss cookie expires; default is a zero-day "session cookie"
 */
export default function useLdsTableScrollOverlays(dismissExpirationDays = 0) {
  const initTableScrollOverlayStatus = () => {
    if (!isClientEnvironment()) {
      return undefined;
    }
    const overlayStatus = getCookie(scrollOverlayCookie);
    if (overlayStatus !== disabledCookieValue) return 'enabled';
    return disabledCookieValue;
  };

  const [tableScrollOverlayStatus, setTableScrollOverlayStatus] = useState(initTableScrollOverlayStatus());

  const disableTableScrollOverlays = () => {
    let persistence = dismissExpirationDays;
    // Cookie persistence should not be less than zero days (negative numbers unexpectedly delete the cookie)
    // Nor more than 365 days (1 year) for legal/regulatory compliance reasons
    if (persistence < 0) {
      // eslint-disable-next-line no-console
      console.warn(`LDS TABLE >>> The useLdsTableScrollOverlays function was called with an invalid dismissExpirationDays value of '${persistence}' days which would unexpectedly delete the cookie.\nThe function will fallback to an effective value of 0 (zero).\nPlease set a value of either 0 (zero) for a session cookie (default) or within 1-365 days`);
      persistence = 0;
    }
    if (persistence > 365) {
      // eslint-disable-next-line no-console
      console.warn(`LDS TABLE >>> The useLdsTableScrollOverlays function was called with an invalid dismissExpirationDays value of '${persistence}' days which exceeds the legal/regulatory maximum of 365 days (1 year).\nThe function will fallback to an effective value of 365 days.\nPlease set a value of either 0 (zero) for a session cookie (default) or within 1-365 days`);
      persistence = 365;
    }

    setCookie(scrollOverlayCookie, disabledCookieValue, dismissExpirationDays);
    setTableScrollOverlayStatus(disabledCookieValue);
  };

  const getTableScrollOverlaysStatus = () => {
    try {
      let status = getCookie(scrollOverlayCookie);
      if (!status || (status === '')) status = null;
      setTableScrollOverlayStatus(status);
      return status;
    } catch (ex) {
      // eslint-disable-next-line no-console
      console.error('LDS TABLE >>> An unexpected exception occured when calling getTableScrollOverlaysStatus, if this error persists please submit a bug report to the LDS team. Exception:', ex.message);
      return null;
    }
  };

  const resetTableScrollOverlays = () => {
    deleteCookie(scrollOverlayCookie);
    setTableScrollOverlayStatus(null);
  };

  return {
    tableScrollOverlayStatus,
    initTableScrollOverlayStatus,
    disableTableScrollOverlays,
    getTableScrollOverlaysStatus,
    resetTableScrollOverlays,
  };
}
