import useWindowSize from './useWindowSize.js';

export default function useIsMobile(mobileBreakpoint = 768) {
  const { width } = useWindowSize();
  return width < mobileBreakpoint;
}

// ? How to use
// const isMobile = useIsMobile(pixelBreakpoint);
