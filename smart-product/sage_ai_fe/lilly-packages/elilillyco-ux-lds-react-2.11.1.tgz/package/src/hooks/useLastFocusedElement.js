import { useRef, useEffect } from 'react';
// hook accepts a selector to exclude from focus tracking
export default function useLastFocusedElement(excludedSelector) {
  const lastFocusedElementRef = useRef(null);

  useEffect(() => {
    function handleFocusIn(event) {
      const target = event.target;
      if (!target.closest(excludedSelector)) {
        lastFocusedElementRef.current = target;
      }
    }

    function handleFocusOut(event) {
      const target = event.relatedTarget;
      if (!target || !target.closest(excludedSelector)) {
        lastFocusedElementRef.current = null;
      }
    }

    document.addEventListener('focusin', handleFocusIn);
    document.addEventListener('focusout', handleFocusOut);

    return () => {
      document.removeEventListener('focusin', handleFocusIn);
      document.removeEventListener('focusout', handleFocusOut);
    };
  }, [excludedSelector]);

  return lastFocusedElementRef;
}
