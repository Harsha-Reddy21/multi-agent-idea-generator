import { useState } from 'react';

import { getCookie, deleteCookie, setCookie } from '../util/cookies.js';
import isClientEnvironment from '../util/isClientEnvironment.js';
/**
 * A custom hook for managing cookie consent status.
 *
 * @param {string} cookieName - The name of the cookie to use for storing the consent status.
 * @param {number} acceptExpirationDays - The number of days until the "accept" cookie expires.
 * @param {number} declineExpirationDays - The number of days until the "decline" cookie expires.
 * @returns {object} An object with functions for managing cookie consent status.
 */
export default function useLdsCookieConsent(cookieName, acceptExpirationDays, declineExpirationDays) {
  const initCookie = () => {
    if (!isClientEnvironment()) {
      return '';
    }
    return getCookie(cookieName);
  };

  const [cookieConsentStatus, setCookieConsentStatus] = useState(initCookie());

  const acceptCookies = () => {
    setCookieConsentStatus('enabled');
    setCookie(cookieName, 'enabled', acceptExpirationDays);
  };

  const declineCookies = () => {
    setCookie(cookieName, 'disabled', declineExpirationDays);
    setCookieConsentStatus('disabled');
  };

  const resetCookieConsent = () => {
    deleteCookie(cookieName);
    setCookieConsentStatus(null);
  };

  return {
    acceptCookies,
    cookieConsentStatus,
    declineCookies,
    initCookie,
    resetCookieConsent,
  };
}
