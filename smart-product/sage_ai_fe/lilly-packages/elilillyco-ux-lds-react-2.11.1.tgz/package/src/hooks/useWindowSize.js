import { useState, useEffect } from 'react';

export default function useWindowSize() {
  const [size, setSize] = useState({
    width: null,
    height: null,
  });

  /* can not use "useLayoutEffect" here due to potential SSR
    If any rendering issues arise we can consider doing something like this

    // use-isomorphic-layout-effect.js
    import { useLayoutEffect, useEffect } from 'react';
    const useIsomorphicLayoutEffect =
      typeof window !== 'undefined' ? useLayoutEffect : useEffect;
    export default useIsomorphicLayoutEffect;

    https://gist.github.com/gaearon/e7d97cdf38a2907924ea12e4ebdf3c85
  */
  useEffect(() => {
    const handleResize = () => {
      setSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return size;
}

// ? How to use
// const { width, height } = useWindowSize();
