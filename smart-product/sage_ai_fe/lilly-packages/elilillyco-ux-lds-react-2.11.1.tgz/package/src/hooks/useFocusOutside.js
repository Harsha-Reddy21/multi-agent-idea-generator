import useOutsideEvent from './useOutsideEvent.js';
export default function useFocusOutside(callback) {
  // returns ref for the element we want to detect focus outside of
  return useOutsideEvent(callback, 'focusin');
}
// ? How to use
// const ref = useFocusOutside(() => {
//    Your custom logic here
// });
