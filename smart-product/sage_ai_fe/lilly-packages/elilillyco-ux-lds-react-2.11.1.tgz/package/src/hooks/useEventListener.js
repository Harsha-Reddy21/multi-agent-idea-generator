import { useEffect, useRef } from 'react';

export default function useEventListener(target, eventNames, handler, options) {
  // Create a ref that stores the handler
  const savedHandler = useRef();

  // Update ref.current value if handler changes
  useEffect(() => {
    savedHandler.current = handler;
  }, [handler]);

  useEffect(() => {
    const targetElement = target.current ?? target;
    if (!targetElement?.addEventListener) return;
    const eventListener = (event) => savedHandler.current(event);
    // Convert eventNames to an array if it's not
    const normalizedEventNames = Array.isArray(eventNames)
      ? eventNames
      : [eventNames];
    // Add event listeners for each eventName
    normalizedEventNames.forEach((eventName) => {
      targetElement.addEventListener(eventName, eventListener, options);
    });
    // Return a cleanup function that removes the event listeners when the component is unmounted
    // eslint-disable-next-line consistent-return
    return () => {
      normalizedEventNames.forEach((eventName) => {
        targetElement.removeEventListener(eventName, eventListener);
      });
    };
  }, [eventNames, target, options]);
}

// ? How to use
// useEventListener(ref, 'click', handlerFunction);
// or
// useEventListener(ref, ['click', 'touchstart'], handlerFunction);
// or
// useEventListener(ref, ['click', 'touchstart'], handlerFunction, { passive: true });
