import { useEffect, useState } from 'react';

export default function usePrefersReducedMotion() {
  const [hasReducedMotion, setHasReducedMotion] = useState(false);

  useEffect(() => {
    setHasReducedMotion(
      window.matchMedia('(prefers-reduced-motion: reduce)') === true || window.matchMedia('(prefers-reduced-motion: reduce)').matches === true
    );
  }, []);

  return hasReducedMotion;
}

// ? How to use
// const prefersReducedMotion = usePrefersReducedMotion();
