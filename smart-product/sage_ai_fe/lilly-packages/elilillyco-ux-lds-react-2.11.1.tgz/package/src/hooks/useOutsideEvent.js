import { useRef, useEffect } from 'react';
import useEventListener from './useEventListener.js';
import isClientEnvironment from '../util/isClientEnvironment.js';
// hook to detect clicks outside of a component

// TODO: THIS HOOK NEEDS TO BE PROPERLY FIXED FOR SSR
/* eslint-disable */
export default function useOutsideEvent(callback, events) {
  // check if we're in a client environment and return null if not
  if (!isClientEnvironment()) {
    return null;
  }
  // Ref for the element that we want to detect clicks outside of
  const ref = useRef(null);
  // Ref for the callback passed to the hook - to avoid creating a new callback on every render
  const callbackRef = useRef(callback);
  // Update the current callback if it changes
  useEffect(() => {
    callbackRef.current = callback;
  }, [callback]);
  // Using useEventListener to manage the event listeners
  useEventListener(document, events, handler);
  // Event handler for the click and touchstart events
  function handler(e) {
    const element = ref.current;
    // Check if the element exists and the click was outside of the element
    if (element && !element.contains(e.target)) {
      // If the click was outside, invoke the callback with the event
      callbackRef.current(e);
      e.stopPropagation();
    }
  }

  // Return the ref to be used by the consumer of this hook
  return ref;
}
/* eslint-enable */

// ? How to use
// const ref = useClickOutside(() => {
//    Your custom logic here
// });
