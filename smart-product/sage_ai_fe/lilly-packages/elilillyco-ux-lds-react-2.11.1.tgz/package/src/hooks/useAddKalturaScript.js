import { useEffect, useRef, useState } from 'react';
import timeToSeconds from '../util/timeToSeconds.js';

// Constants
const SCRIPT_ID_BASE = 'lds-kaltura-player-script';
const SCRIPT_SRC_BASE = 'https://cdnapisec.kaltura.com/p/';

// For more information on the Kaltura Player API, see:
// https://developer.kaltura.com/player/web/getting-started-web
export default function useAddKalturaScript({
  videoId,
  partnerId,
  uiConfId,
  targetDiv,
  chromeless = false,
  autoplay = false,
  plugins = {
    'playkit-js-info': {},
  },
  startTime = 0,
}) {
  const SCRIPT_ID = `${SCRIPT_ID_BASE}_${videoId}`;
  const [hasError, setHasError] = useState({
    errorDetected: false,
    errorMessage: '',
  });

  const [kalturaPlayer, setKalturaPlayer] = useState(null);

  const scriptLoaded = useRef(false);

  useEffect(() => {
    const newScript = createNewScript(partnerId, uiConfId, SCRIPT_ID);

    const handleError = (event) => {
      const error = event.payload;
      const errorMessage = error.data.data.message || 'Error loading Kaltura player';
      setHasError({ errorDetected: true, errorMessage });
    };

    if (!scriptLoaded.current) {
      try {
        // Generate the player script
        newScript.onload = () => {
          setKalturaPlayer(
            initKalturaPlayer({
              videoId,
              partnerId,
              uiConfId,
              targetDiv,
              chromeless,
              setHasError,
              autoplay,
              startTime,
              plugins,
            })
          );
        };
        // Add the script to the document head
        document.head.appendChild(newScript);
        // Update the ref var that the script has been loaded, else it will be loaded on re-renders
        // That throws a console error that some end-users believe is blocking other scripts
        scriptLoaded.current = true;
      } catch (ex) {
        // DEBUG
        // eslint-disable-next-line no-console
        console.error(`LDS Error: unexpected exception in useAddKalturaScript while embedding video '${videoId}.\nException:`, ex.message);
      }
    }
    // Cleanup function to remove event listener
    return () => {
      if (kalturaPlayer) {
        kalturaPlayer.removeEventListener(
          kalturaPlayer.Event.ERROR,
          handleError
        );

        /* Removing the script from the document head causes re-render issues */
        /* TODO: Verify that this can be removed or refactor as necessary */

        // // Remove the embed script
        // document.head.removeChild(newScript);
        // // Update the ref var that the embed script is no longer loaded
        // // This is important to handle videos that may not initially be visible (such as in a modal)
        // // Which will need to load the script if the component is re-rendered to be visible.
        // scriptLoaded.current = false;
      }
    };
  }, [videoId, partnerId, uiConfId, targetDiv, SCRIPT_ID, chromeless, autoplay, startTime, plugins, kalturaPlayer]);

  const seekToPositionKaltura = (time, autoplay = true) => {
    const seconds = timeToSeconds(time);
    if (!kalturaPlayer) return;

    kalturaPlayer.currentTime = seconds;
    if (!autoplay === true) {
      kalturaPlayer.pause();
    } else {
      kalturaPlayer.play();
    }
  };

  return { hasError, seekToPositionKaltura, kalturaPlayer };
}

function createNewScript(partnerId, uiConfId, scriptId) {
  const newScript = document.createElement('script');
  newScript.setAttribute('id', scriptId);
  newScript.setAttribute('src', generateScriptSrc(partnerId, uiConfId));
  return newScript;
}

function generateScriptSrc(partnerId, uiConfId) {
  return `${SCRIPT_SRC_BASE}${partnerId}/embedPlaykitJs/uiconf_id/${uiConfId}`;
}

function initKalturaPlayer({
  videoId,
  partnerId,
  uiConfId,
  targetDiv,
  chromeless,
  setHasError,
  autoplay = false,
  plugins = {
    'playkit-js-info': {},
  },
  startTime = 0,
}) {
  const videoPlayer = getVideoElement(targetDiv);

  if (chromeless) {
    videoPlayer.classList.add('chromeless');
  }

  const kalturaPlayer = setupKalturaPlayer({
    targetDiv,
    partnerId,
    uiConfId,
    autoplay,
    plugins,
    startTime: timeToSeconds(startTime),
  });
  kalturaPlayer.loadMedia({ entryId: videoId });
  kalturaPlayer.addEventListener(kalturaPlayer.Event.ERROR, (event) => {
    const error = event.payload;

    const errorMessage = error.data.data.message
      ? `${error.data.data.message}. Check the console for more details.`
      : 'Error loading Kaltura player. Check the console for more details.';

    setHasError({ errorDetected: true, errorMessage });
  });
  return kalturaPlayer;
}

function getVideoElement(targetDiv) {
  return document.getElementById(targetDiv);
}

function setupKalturaPlayer({
  targetDiv,
  partnerId,
  uiConfId,
  autoplay,
  plugins,
  startTime,
}) {
  // eslint-disable-next-line no-undef
  return KalturaPlayer.setup({
    targetId: targetDiv,
    provider: {
      partnerId,
      uiConfId,
    },
    playback: {
      autoplay,
    },
    plugins: plugins,
    sources: {
      startTime,
    },
  });
}
