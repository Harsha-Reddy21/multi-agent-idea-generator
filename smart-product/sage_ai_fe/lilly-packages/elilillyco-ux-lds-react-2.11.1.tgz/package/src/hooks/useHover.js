import { useRef } from 'react';
import useEventStateToggle from './useEventStateToggle.js';

export default function useHover() {
  const ref = useRef(null);
  const [hovering, manualSetHover] = useEventStateToggle(
    ref,
    'mouseenter',
    'mouseleave'
  );
  return [ref, hovering, manualSetHover];
}

// ? How to use
// manualSetHover is a function that can be used to manually set the state in
// case we need to imperatively change the state without waiting for an event to
// fire
// const [ref, hovering, manualSetHover] = useHover();
