import { useRef } from 'react';
import useEventStateToggle from './useEventStateToggle.js';

export default function useFocus() {
  const ref = useRef(null);
  const [focused, manualSetFocused] = useEventStateToggle(
    ref,
    ['focus'],
    ['blur']
  );
  return [ref, focused, manualSetFocused];
}

// ? How to use
// manualSetFocused is a function that can be used to manually set the state in
// case we need to imperatively change the state without waiting for an event to
// fire
// const [ref, focused, manualSetFocused] = useFocus();
