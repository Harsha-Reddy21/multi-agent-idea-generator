import { useRef, useEffect } from 'react';

/*
  This function is used to detect clicking away from an element and trigger a callback function.
  Commonly used for things like clicking away from a dropdown or a modal to close them.

  @param {function} callback - The function to be called when a click outside the element is detected
  @param {array} ignoreSelectors - An array of selectors to ignore when clicking outside the element. Clicking on these elements will not trigger the callback function. Commonly used for things like a button that opens a dropdown, so clicking on the button does not close the dropdown automatically
  @param {array} includeSelectors - An array of selectors to include as a trigger for the callback. Used for elements that should trigger a callback even if they are a child of the element (not an outside click)
*/
export default function useClickOutside(callback, ignoreSelectors = [], includeSelectors = []) {
  const ref = useRef(null);

  useEffect(() => {
    const handleClickOutside = (e) => {
      // check to trigger callback from specific elements that are not an outside click
      try {
        if (includeSelectors && includeSelectors.length) {
          includeSelectors.forEach((selector) => {
            if (e.target.matches(selector)) {
              callback();
            }
          });
        }
      } catch (err) {
        console.error('Error in useClickOutside with includeSelectors:', err); // eslint-disable-line
      }

      if (ignoreSelectors && ignoreSelectors.length) {
        for (let i = 0; i < ignoreSelectors.length; i += 1) {
          if (e.target.closest(ignoreSelectors[i])) return;
        }
      }

      if (ref.current && !ref.current.contains(e.target)) callback();
    };

    document.addEventListener('click', handleClickOutside);

    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [callback, ignoreSelectors]);

  return ref;
}

// ? How to use
// const ref = useClickOutside(() => {
//    Your custom logic here
// });
//
// return <div ref={ref}>...</div>;
