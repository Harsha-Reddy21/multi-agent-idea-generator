import { useState, useCallback } from 'react';

/*
  This hook is used to help measure the size of dom nodes that may change size or have dynamic content.
  For example this is used in the side nav to add an empty content placeholder underneath the sticky content so page content is not hidden.

  USAGE:

  const [rect, measuredRef] = useResizeObserver();

  useEffect(() => {
    console.log('new div height is:', rect.height);
  }, rect);

  return (
    <div ref={measuredRef}>
      The element whose size we want to measure
    </div>
  )
*/

export default function useResizeObserver() {
  const [rect, setRect] = useState(null);

  const measuredRef = useCallback((node) => {
    if (node === null) return;

    const resizeObserver = new ResizeObserver((entries) => {
      if (!entries || !entries[0]) return;
      setRect(entries[0].contentRect);
    });
    resizeObserver.observe(node);
  }, []);

  return [rect, measuredRef];
}
