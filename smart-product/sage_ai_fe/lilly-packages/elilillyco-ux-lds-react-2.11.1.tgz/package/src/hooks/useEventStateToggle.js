import { useState, useCallback } from 'react';
import useEventListener from './useEventListener.js';

export default function useEventStateToggle(
  ref,
  trueEvents = [],
  falseEvents = []
) {
  const [state, setState] = useState(false);

  const setTrue = useCallback(() => {
    setState(true);
  }, []);

  const setFalse = useCallback(() => {
    setState(false);
  }, []);

  const manualSetState = useCallback((newState) => {
    setState(newState);
  }, []);

  // Using the new useEventListener for both true and false events
  useEventListener(ref, trueEvents, setTrue);
  useEventListener(ref, falseEvents, setFalse);

  return [state, manualSetState];
}

// ? How to use
// manualOverrideSetter is a function that can be used to manually set the state
// in case we need to imperatively change the state without waiting for an event to fire
// const [currentStateBoolean, manualOverrideSetter] = useEventStateToggle(ref, ['mouseenter'], ['mouseleave']);
