/* eslint-disable no-param-reassign */
import { useMemo } from 'react';

export default function useMergeRefs(...refs) {
  // The hook returns a memoized callback function that is the result of merging all provided refs
  // useMemo ensures that the same merged ref function is returned between renders unless `refs` change
  // eslint-disable-next-line react-hooks/exhaustive-deps
  return useMemo(() => mergeRefs(...refs), refs);
}

// Return a new ref callback function that will call all provided ref callbacks
function mergeRefs(...refs) {
  return (node) => {
    refs.forEach((ref) => {
      assignRef(ref, node);
    });
  };
}

function assignRef(ref, value) {
  // Utility function to assign a value to a ref
  if (ref == null) return;

  // If the ref is a function, call it with the value
  // see https://react.dev/reference/react-dom/components/common#ref-callback
  if (typeof ref === 'function') {
    ref(value);
    return;
  }

  // try to set the current property of the ref object to the value or throw an error
  try {
    ref.current = value;
  } catch (error) {
    // eslint-disable-next-line no-console
    console.error('Cannot assign value to ref', error);
    throw new Error(`Cannot assign value '${value}' to ref '${ref}'`);
  }
}

// ? How to use
// const ref = useMergeRefs(ref1, ref2, ref3);
// or
// const ref = useMergeRefs(ref1, ref2, ref3, (node) => {
//   Your custom logic here
// });
