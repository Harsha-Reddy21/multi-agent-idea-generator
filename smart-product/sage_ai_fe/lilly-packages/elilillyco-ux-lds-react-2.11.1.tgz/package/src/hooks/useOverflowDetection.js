/**
 * A custom React hook that detects whether content overflows its container horizontally.
 * The hook uses ResizeObserver to automatically detect changes in the element's dimensions.
 *
 * @param {React.RefObject} elementRef - A React ref object pointing to the DOM element to check for overflow
 * @returns {boolean} isOverflown - Returns true if the element's content overflows horizontally, false otherwise
 *
 * @example
 * const elementRef = useRef(null);
 * const isOverflowing = useOverflowDetection(elementRef);
 *
 * return (
 *   <div ref={elementRef} className={isOverflowing ? 'overflow' : ''}>
 *     Content that might overflow
 *   </div>
 * );
 */
import { useState, useEffect, useCallback } from 'react';

function useOverflowDetection(elementRef) {
  const [isOverflown, setIsOverflown] = useState(false);

  const checkOverflow = useCallback(element => {
    if (!element) return false;
    return element.scrollWidth > element.clientWidth;
  }, []);

  useEffect(() => {
    if (elementRef.current) {
      setIsOverflown(checkOverflow(elementRef.current));

      // Optional: add resize observer for dynamic content
      const resizeObserver = new ResizeObserver(() => {
        setIsOverflown(checkOverflow(elementRef.current));
      });

      resizeObserver.observe(elementRef.current);
      return () => resizeObserver.disconnect();
    }
    return undefined; // Explicit return for when elementRef.current is falsy
  }, [checkOverflow, elementRef]);

  return isOverflown;
}

export default useOverflowDetection;
