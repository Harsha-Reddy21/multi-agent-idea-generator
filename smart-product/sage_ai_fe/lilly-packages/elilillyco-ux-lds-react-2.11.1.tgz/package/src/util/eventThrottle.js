export default function eventThrottle(func, limit, ...args) {
  let timeout;
  let lastRan;
  return () => {
    if (!lastRan) {
      func.apply(this, args);
      lastRan = Date.now();
    } else {
      clearTimeout(timeout);
      const next = limit - (Date.now() - lastRan);
      if (next < 0) {
        func.apply(this, args);
        lastRan = Date.now();
      } else {
        timeout = setTimeout(() => {
          if ((Date.now() - lastRan) >= limit) {
            func.apply(this, args);
            lastRan = Date.now();
          }
        }, next);
      }
    }
  };
}
