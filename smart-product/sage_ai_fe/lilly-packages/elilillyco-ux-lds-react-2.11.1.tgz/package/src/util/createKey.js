import nodeCrypto from 'crypto';

const createKey = () => {
  /*
    THIS SHOULD NOT BE USED FOR GENERATING KEYS ON AN ELEMENT MAP

     if you iterate over complex components - generating key on the fly will cause forced mount/unmount for component and all children
     keys should come from data.

     Also be careful using this in an SSR environment. Keys may differ if called twice during server render and client render
  */

  // self.crypto.randomUUID() is only available in secure context (HTTPS).
  // Use nodeCrypto for unit tests.
  if (typeof window !== 'undefined' && typeof self.crypto.randomUUID === 'function') {
    return self.crypto.randomUUID();
  }
  return nodeCrypto.randomUUID();
};

export default createKey;
