/**
 * Write a message to the console
 *
 * @param {string} message the console message to write
 * @param {level} level optionally define what type of console message, either 'log', 'warn' or 'error'; default is 'log'
 * @param {boolean} useValue whether to output a value; default is false
 * @param {value} value optionally provide a value to print as its type (unmolested); default is undefined
 */
export const consoleWriter = (
  message,
  level = 'log',
  useValue = false,
  value = undefined
) => {
  /* eslint-disable no-console, indent */
  try {
    switch (level.toLowerCase()) {
      case 'e':
      case 'err':
      case 'error':
        if (useValue) {
          console.error(message, value);
        } else {
          console.error(message);
        }
        break;
      case 'w':
      case 'warn':
      case 'warning':
        if (useValue) {
          console.warn(message, value);
        } else {
          console.warn(message);
        }
        break;
      case 'i':
      case 'log':
      case 'info':
      default:
        if (useValue) {
          console.log(message, value);
        } else {
          console.log(message);
        }
    }
  } catch (ex) {
    throw new Error(`ux-lds - JavaScript utilities => consoleWriter(message: ${message}, level: ${level}, useValue: ${useValue}, value: ${value}): Encountered an unexpected exception:`, ex.message);
  }
  /* eslint-enable no-console, indent */
};
