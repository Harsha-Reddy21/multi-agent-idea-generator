import getFocusableElements from './getFocusableElements.js';

export default function handleTabAway(e, ref, callback) {
  const focusableElements = getFocusableElements(ref.current);
  const focusableLength = focusableElements.length - 1;

  const isShift = e.shiftKey;
  const isTabKey = e.key === 'Tab';

  // Trying to shift tab away from first focusable element
  if (e.target === focusableElements[0] && isShift && isTabKey) {
    callback('first');
  }

  // Trying to tab away from last focusable element
  if (e.target === focusableElements[focusableLength] && !isShift && isTabKey) {
    callback('last');
  }
}

/*
  ? How to use
  Consider a dropdown list that you want to close when the user tabs away from it.
  The example below will close the dropdown when the user tabs or shift tabs away from the first or last focusable item in the dropdown

  const handleKeyDown = (e) => {
    const callback = () => setIsOpen(false);
    return handleTabAway(e, dropdownRef, callback);
  };

  return (
    <div
      ref={dropdownRef}
      onKeyDown={handleKeyDown}
    >
      <button></button>
      <button></button>
      <button></button>
    </div>
  )
*/
