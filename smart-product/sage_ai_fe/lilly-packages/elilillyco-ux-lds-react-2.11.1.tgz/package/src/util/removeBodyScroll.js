const removeBodyScroll = () => {
  // Prevents the body from scrolling underneath the modal when it opens.
  const htmlTag = document.documentElement;
  const pagePosition = htmlTag.scrollTop || window.pageYOffset;

  htmlTag.style.top = `-${pagePosition}px`;
  htmlTag.setAttribute('data-modal-active', 'true');
  htmlTag.setAttribute('data-modal-position', pagePosition);
};

export default removeBodyScroll;
