/**
 * Returns an elements offset top relative to the entire document.
 *
 * @param {Element} element Element to get offset of.
 * @returns {Number}
 */
export default function offsetTopDocument(element) {
  let headerOffset = 0;

  const ldsSticky = document.querySelector('div.lds-sticky');
  if (ldsSticky) {
    headerOffset = ldsSticky.offsetHeight;
  }
  return element.getBoundingClientRect().top
    + (document.documentElement.scrollTop || window.scrollY) - headerOffset;
}
