const isRTL = (elementRef) => {
  // If no elementRef is provided, return false
  if (!elementRef) {
    // eslint-disable-next-line no-console
    console.error('LDS ERROR [Usage]: isRTL function requires an elementRef parameter which must be a valid ref to a Component DOM element');
    return false;
  }
  if (elementRef.current) {
    const isRTL = !!elementRef.current.closest('[dir="rtl"]');
    return isRTL;
  }
  return false;
};

export default isRTL;
