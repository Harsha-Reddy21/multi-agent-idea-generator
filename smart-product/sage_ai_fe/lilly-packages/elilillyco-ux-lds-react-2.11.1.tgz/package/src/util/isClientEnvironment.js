export default function isClientEnvironment() {
  return typeof window !== 'undefined' || typeof document !== 'undefined';
}
