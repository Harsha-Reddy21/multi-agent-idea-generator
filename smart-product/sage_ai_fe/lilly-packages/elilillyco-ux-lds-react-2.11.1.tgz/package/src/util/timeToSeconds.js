const timeToSeconds = (timeString = '0:00:00') => {
  // if timeString is already a number, return it
  if (typeof timeString === 'number') {
    if (Number.isNaN(timeString)) {
      return 0;
    }
    return timeString;
  }

  // if timeString is a string that can be converted to a number, return it
  if (!isNaN(Number(timeString))) {
    return Number(timeString);
  }

  const timeParts = timeString.split(':').map(Number);

  if (timeParts.length === 2) {
    const [minutes, seconds] = timeParts;
    return minutes * 60 + seconds;
  }

  if (timeParts.length === 3) {
    const [hours, minutes, seconds] = timeParts;
    return hours * 3600 + minutes * 60 + seconds;
  }

  return 0; // Fallback for invalid formats
};

export default timeToSeconds;
