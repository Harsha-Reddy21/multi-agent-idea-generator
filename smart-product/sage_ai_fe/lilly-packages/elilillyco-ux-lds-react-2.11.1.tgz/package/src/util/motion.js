export const duration = {
  short: 200,
  medium: 400,
  long: 600,
};

export const timingFunction = {
  standard: 'cubic-bezier(0.4, 0, 0.2, 1)',
  bounce: 'cubic-bezier(0.4, 0, 0.2, 1.1)',
  linear: 'cubic-bezier(0, 0, 1, 1)',
};
