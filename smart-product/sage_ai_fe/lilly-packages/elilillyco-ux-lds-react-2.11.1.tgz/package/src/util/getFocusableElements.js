// Attempts to get any focusable elements within the parent element passed in.
// Note that this will not work for anything inside of a shadow dom.
export default function getFocusableElements(element) {
  if (!element) {
    // eslint-disable-next-line no-console
    console.error('LDS ERROR [Usage]: getFocusableElements function requires an element parameter of type HTMLElement which must be a valid DOM element');
    return [];
  }

  try {
    const elements = element.querySelectorAll(`
      a[href]:not([disabled]):not([tabindex="-1"]):not([inert] *),
      button:not([disabled]):not([tabindex="-1"]):not([inert] *),
      textarea:not([disabled]):not([tabindex="-1"]):not([inert] *),
      input:not([disabled]):not([type="hidden"]):not([tabindex="-1"]):not([inert] *),
      select:not([disabled]):not([tabindex="-1"]):not([inert] *),
      .lds-focusable:not([inert] *),
      [tabindex]:not([tabindex="-1"]):not([inert] *),
      iframe:not([tabindex="-1"]):not([inert] *),
      [contentEditable=true]:not([tabindex="-1"]):not([inert] *)`);

    return Array.from(elements).filter((el) => el.offsetHeight > 0);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error(`LDS ERROR [Unexpected Failure]: Failed to getFocusableElements: ${err.message}`, `\n>>> in element ${element}`);
    return [];
  }
}
