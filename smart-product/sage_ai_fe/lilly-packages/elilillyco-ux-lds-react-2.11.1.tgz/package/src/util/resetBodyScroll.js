const resetBodyScroll = () => {
  // When closing a modal allow the body to scroll again
  // and reset the scroll position to where it was when the modal was opened.
  const htmlTag = document.documentElement;
  const pagePosition = htmlTag.getAttribute('data-modal-position'); // scroll position is set when modal opened

  htmlTag.setAttribute('data-modal-active', 'false');
  htmlTag.style.top = null;
  window.scrollTo(0, pagePosition);

  htmlTag.removeAttribute('data-modal-position');
};
export default resetBodyScroll;
