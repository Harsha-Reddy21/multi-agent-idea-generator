import { forwardRef } from 'react';
import cn from 'classnames';

export default forwardRef(function tableVisualCaption({
  id,
  className,
  children,
  ...rest
}, ref) {
  return (
    <div
      id={id}
      className={cn(
        'lds-table-caption-container',
        className
      )}
      aria-hidden="true"
      ref={ref}
      {...rest}
    >
      <p className="lds-table-caption">
        {children}
      </p>
    </div>
  );
});
