import { useEffect, useRef, useState } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import {
  tableElementIds,
  getTableElementById
} from './util.js';
import useLdsTableTableScrollOverlays from '../../hooks/useLdsTableScrollOverlays.js';

/* Private Sub-Components */
import VisualCaption from './private/VisualCaption.jsx';
import ScrollOverlay from './private/ScrollOverlay.jsx';
import TopScrollBar from './private/TopScrollbar.jsx';

/* Public Sub-Components */
import RowTh from './public/RowHeaderCell.jsx';

// JSDoc type definitions
/**
 * @typedef LdsTableProps
 * @property {string} id - Required Component `id`; must be unique for each table.
 * @property {React.ReactNode} children - Required React child slot object; must be valid innerHTML markup to be injected into the '<table>' element's context.
 * @property {string} [styleClass] - Optionally apply a specific LDS table style variant class or leave undefined for the default style. Currently 'discrete-cells' is the only available variant.
 * @property {string} [frozenColumnClass] - Optionally apply a specific LDS table frozen column class to the table component container '<div>' or leave undefined. Freezes the first table head <th> cell in a row. Available options are 'frozen-first-col' to freeze the first column in all rows, 'frozen-first-col-body' only freezes the first column in the table body <tbody> context, the second column can likewise be frozen with either 'frozen-second-col' or 'frozen-second-col-body' respectively.
 * @property {string} [frozenColumnShadowClass] - Optionally apply a specific LDS table frozen column shadow class to the table component container '<div>' or leave undefined. Changes the style of the drop shadow on frozen row heading cells. Normally undefined. Currently only one variant class is available 'frozen-col-shadow-25' which increases the shadow opacity to 25% (default is 12%).
 * @property {string} [className] - Optional custom user-defined CSS class(es) for the table component <div> wrapper element, will be appended to the list of any other component classes
 * @property {string} [caption] - Required table caption content object; can be a plain string or text or a React fragment of valid inline JSX/HTML markup to be injected into a paragraph '<p>' element context; it is also rendered into a visually hidden <table> <caption> element for assistive technology.
 * @property {string} [visualCaptionClass] - Optional string of additional class names to add to the visual caption container '<div>' element.
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [visualCaptionAttributes] - Optional additional properties object to pass generic HTML attributes onto the visual caption container '<div>' element.
 * @property {boolean} [hideVisualCaption] - Whether to optionally hide the caption content visually; default is 'false'; when true the visual caption will not be rendered and the caption content will only be announced by screen readers from the <table> <caption> element.
 * @property {boolean} [scrollOverlayLabel] - Optional custom user-defined text content to be displayed on the scroll overlay; replaces the default text; must be inline JSX/HTML content to be injected into a '<span>' element within a '<button>' element.
 * @property {string} [scrollOverlayClass] - Optional string of additional class names to add to the scroll overlay container '<button>' element.
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [scrollOverlayAttributes] - Optional additional properties object to pass generic HTML attributes onto the scroll overlay container '<button>' element.
 * @property {boolean} [disableScrollOverlay] - Whether to optionally disable the scroll overlay feature; default is 'false'; when true the scroll overlay markup will not be rendered and any JS functions will be disabled for the component instance.
 * @property {boolean} [disableTopScrollbar] - Whether to optionally disable the top scrollbar feature; default is 'false'; when true the scroll overlay markup will not be rendered and any JS functions will be disabled for the component instance.
 * @property {boolean} [disableScrollShadows] - Whether to optionally disable the scroll direction indicator shadows feature; default is 'false'; when true the scroll shadows markup will not be rendered and any JS functions will be disabled for the component instance.
 * @property {string} [tableClass] - Optional custom user-defined CSS class(es) for the table <table> element, will be appended to the list of any other component classes
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [tableAttributes] - An additional properties object to pass generic HTML attributes onto the table <table> element
 */
/**
 * LdsTable component
 * @param {LdsTableProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
function LdsTable({
  id,
  children,
  styleClass,
  frozenColumnClass,
  frozenColumnShadowClass,
  className,
  caption,
  visualCaptionClass,
  visualCaptionAttributes,
  hideVisualCaption = false,
  scrollOverlayLabel = 'Swipe left or right to view all data.',
  scrollOverlayClass,
  scrollOverlayAttributes,
  disableScrollOverlay = false,
  disableTopScrollbar = false,
  disableScrollShadows = false,
  tableClass,
  tableAttributes,
  ...rest
}) {
  const ids = tableElementIds(id);

  const tableContainerRef = useRef(null);

  const {
    disableTableScrollOverlays,
    getTableScrollOverlaysStatus,
  } = useLdsTableTableScrollOverlays();

  const [tableScrollFeaturesAllAreDisabled, setTableScrollFeaturesAllAreDisabled] = useState(disableScrollOverlay && disableTopScrollbar && disableScrollShadows);

  /**
   * Table scroll overlay button onClick event handler
   *
   * Hides the scroll overlays on ALL LDS tables on the current page
   * Then sets a cookie indicating the user has dismissed the overlay so it does not show again on
   * any other page or if the current one is refreshed or reloaded.
   */
  const dismissTableScrollOverlays = () => {
    try {
      // Hide the overlays on every table found on the current page
      const tables = document.querySelectorAll('.lds-table-container');
      tables.forEach((table) => {
        table.classList.remove('scroll-overlay');
      });
      // Disable the overlays on the entire site by setting a cookie
      // By default the cookie is a session cookie unless the invocation of useLdsTableScrollOverlays
      // sets a different persistence duration.
      disableTableScrollOverlays();
    } catch (ex) {
      // DEBUG
      // // eslint-disable-next-line no-console
      // console.error(`LDS TABLE >>> An unexpected error occured attempting to dismiss table scroll overlays while interacting with table '${ids.tableContainer}'.\n>>> Exception: ${ex.message}\n>>> Please submit a bug report to the LDS team if this error persists.`);
    }
  };

  useEffect(() => {
    setTableScrollFeaturesAllAreDisabled(disableScrollOverlay && disableTopScrollbar && disableScrollShadows);

    /**
     * Update the scroll overlay's visible state based on UI conditions
     * @param {boolean} isScrollable - Whether the table is able to be scrolled
     * @param {boolean} isNotScrolled - Whether the table, if scrollable, has not been scrolled
     *
     * This should be invoked on all applicable events (Page Load, Table Scroll, Table Width Resize)
     */
    const updateScrollOverlayState = (isScrollable, isNotScrolled) => {
      // Abort if this is called and scroll overlays are disabled
      if (disableScrollOverlay) return;

      try {
        // Check the Scroll Overlays cookie status, and if they have been dismissed by the end-user, always hide the overlay(s)
        if (getTableScrollOverlaysStatus() === 'disabled') {
          tableContainerRef.current.classList.remove('scroll-overlay');
          return;
        }

        // If and only if the table is scrollable and has not been scrolled; show the overlay
        // Implicitly the overlay should hide if the table is scrolled
        if (isScrollable && isNotScrolled) {
          tableContainerRef.current.classList.add('scroll-overlay');
          return;
        }

        // Otherwise, hide the overlay
        tableContainerRef.current.classList.remove('scroll-overlay');
      } catch (ex) {
        // DEBUG
        // console.error(`LDS TABLE >>> An unexpected error occured in funciton updateScrollOverlayState attempting to add or remove classes from the root container of table '${ids.tableContainer}'.\n>>> Exception: ${ex.message}\n>>> Please submit a bug report to the LDS team if this error persists.`);
      }
    };

    /**
     * Toggle the scroll shadows visible state
     * @param {boolean} enableLeft - Whether the left scroll shadow should be visible
     * @param {boolean} enableRight - Whether the right scroll shadow should be visible
     */
    const toggleScrollShadows = (enableLeft, enableRight) => {
      // Abort if this is called and scroll shadows are disabled
      if (disableScrollShadows) return;

      try {
        const shadowLeft = getTableElementById(tableContainerRef.current, ids.tableScrollShadowLeft);
        const shadowRight = getTableElementById(tableContainerRef.current, ids.tableScrollShadowRight);

        if (enableLeft) shadowLeft.style.display = 'block';
        if (!enableLeft) shadowLeft.style.display = 'none';

        if (enableRight) shadowRight.style.display = 'block';
        if (!enableRight) shadowRight.style.display = 'none';
      } catch (ex) {
        // DEBUG
        // console.error(`LDS TABLE >>> An unexpected error occured in funciton toggleScrollShadows attempting to toggle the scroll shadows for table '${ids.tableContainer}'.\n>>> Exception: ${ex.message}\n>>> Please submit a bug report to the LDS team if this error persists.`);
      }
    };

    /**
     * Update the scroll shadows visible states based on UI conditions
     * @param {boolean} isScrollable - Whether the table is able to be scrolled
     * @param {boolean} isNotScrolled - Whether the table, if scrollable, has not been scrolled (is at "hard left")
     * @param {boolean} isScrolled - Whether the table, if scrollable, has been scrolled to an intermediate position
     * @param {boolean} isScrolledToEnd - Whether the table, if scrollable, has been scrolled to its end (is at "hard right")
     *
     * This should be invoked on all applicable events (Page Load, Table Scroll, Table Width Resize)
     */
    const updateScrollShadowsState = (isScrollable, isNotScrolled, isScrolled, isScrolledToEnd) => {
      // Abort if this is called and scroll shadows are disabled
      if (disableScrollShadows) return;

      // Table is not scrollable, disable shadows
      if (!isScrollable) {
        toggleScrollShadows(false, false);
        return;
      }

      // Table is scrollable but not scrolled (at hard left); show only the right shadow
      if (isNotScrolled) {
        toggleScrollShadows(false, true);
        return;
      }

      // Table is scrolled to some intermediate point, show both shadows
      if (isScrolled) {
        toggleScrollShadows(true, true);
        return;
      }

      // Table is scrolled to the end (at hard right), show only the left shadow
      if (isScrolledToEnd) {
        toggleScrollShadows(true, false);
        return;
      }

      // Fallback; show no shadows if none of the explicit conditions above are detected.
      toggleScrollShadows(false, false);
      // DEBUG
      // console.warn(`LDS TABLE >>> WARNING: Scroll shadows for table '${ids.tableContainer}' were unexpectedly hidden; please submit a bug report to the LDS team if this warning persists.`);
    };

    /**
     * Set the dimensions of the top scrollbar elements
     * @param {boolean} isScrollable - whether the table is currently scrollable
     * @param {number} tableWidth - the current numeric width of the <table> element in pixels
     * @param {number} tableScrollbarHeight - the computed height of the table's scrollbar; it is browser specific
     *
     * This should be invoked on all applicable events (Page Load, Table Width Resize)
     */
    const setTopScrollbarDimensions = (isScrollable) => {
      // Abort if this is called and the top scrollbar is disabled
      if (disableTopScrollbar) return;

      try {
        const table = getTableElementById(tableContainerRef.current, ids.tableTable);
        const tableScrollBox = getTableElementById(tableContainerRef.current, ids.tableScrollBox);
        const topScrollbar = getTableElementById(tableContainerRef.current, ids.tableTopScrollbar);
        const topScrollbarFill = getTableElementById(tableContainerRef.current, ids.tableTopScrollbarFill);

        const tableWidth = table.clientWidth;
        const tableScrollbarHeight = (tableScrollBox.offsetHeight - tableScrollBox.clientHeight);

        // Set the top scroll bar container to be the computed height of a scroll bar in the current browser
        if ((tableScrollbarHeight <= 0) || !isScrollable) {
          // If it doesn't have a height that can be computed, don't display the top scrollbar
          topScrollbar.style.display = 'none';
          topScrollbar.style.height = '0';
        } else {
          // If it does have a height, display it
          topScrollbar.style.display = 'block';
          // Needs to be at least 1 pixel TALLER than the scroll bar height for the element to be visible in some browsers
          topScrollbar.style.height = `${tableScrollbarHeight + 1}px`;
        }

        // Set the top scroll bar container fill element to be the width of the table
        // This makes the top scroll bar identical in width to the bottom scroll bar in the table scroll container
        if (tableWidth <= 0) {
          topScrollbarFill.style.width = '0';
        } else {
          topScrollbarFill.style.width = `${tableWidth}px`;
        }
      } catch (ex) {
        // DEBUG
        // console.error(`LDS TABLE >>> An unexpected error occured in function setTopScrollbarDimensions attempting to set the dimensions of the top scrollbar for table '${ids.tableContainer}'.\n>>> Exception: ${ex.message}\n>>> Please submit a bug report to the LDS team if this error persists.`);
      }
    };

    /**
     * Updates all the table scroll features when necessary
     *
     * Should be called
     *   - once on page load for initialization
     *   - any time the table is scrolled
     *   - any time the table is resized (width changes)
     */
    const updateTableScrollFeatures = (isScrollable, isNotScrolled, isScrolled, isScrolledToEnd) => {
      try {
        // When no scroll features are enabled, remove flag classes (if set) and abort early.
        if (tableScrollFeaturesAllAreDisabled) {
          tableContainerRef.current.classList.remove('scroll-overlay');
          tableContainerRef.current.classList.remove('scrollable');
          return;
        }

        // Set a class to flag whether the table is scrollable
        if (isScrollable) {
          tableContainerRef.current.classList.add('scrollable');
        } else {
          tableContainerRef.current.classList.remove('scrollable');
        }

        updateScrollOverlayState(isScrollable, isNotScrolled);
        updateScrollShadowsState(isScrollable, isNotScrolled, isScrolled, isScrolledToEnd);
      } catch (ex) {
        // DEBUG
        // console.error(`LDS TABLE >>> An unexpected error occured in function updateTableScrollFeatures.\n>>> Exception: ${ex.message}\n>>> Please submit a bug report to the LDS team if this error persists.`);
      }
    };

    /**
     * Initialize, add or remove a scroll event listener on the Table's scroll box container element
     *
     * Should be called
     *   - once on page load for initializaiton
     *   - any time the table is resized (width changes)
     */
    const setTableScrollBoxScrollListener = () => {
      try {
        const tableScrollBox = getTableElementById(tableContainerRef.current, ids.tableScrollBox);
        const iniScrollOffset = (tableScrollBox.scrollWidth - tableScrollBox.clientWidth);
        const iniIsScrollable = (iniScrollOffset > 0);
        const iniScrollLeft = (tableScrollBox.scrollLeft);
        const iniIsNotScrolled = (iniScrollLeft === 0);
        const iniIsScrolled = ((iniScrollLeft > 0) && (iniScrollLeft < iniScrollOffset));
        const iniIsScrolledToEnd = (iniScrollLeft >= iniScrollOffset);
        // Baseline the scroll features whether initializing or updating
        updateTableScrollFeatures(iniIsScrollable, iniIsNotScrolled, iniIsScrolled, iniIsScrolledToEnd);

        // Remove the any matching scroll listeners by default
        try {
          tableScrollBox.removeEventListener('scroll');
        } catch {
          // Suppress exceptions; do nothing if the event listener cannot be removed because it doesn't exist
        }

        let topScrollbar = null;
        if (!disableTopScrollbar) topScrollbar = getTableElementById(tableContainerRef.current, ids.tableTopScrollbar);

        if (iniIsScrollable && !tableScrollFeaturesAllAreDisabled) {
          tableScrollBox.addEventListener('scroll', () => {
            // Without latency, smoothly update the top scrollbar scrollLeft position with the scroll box scrollLeft position
            if (!disableTopScrollbar && topScrollbar) topScrollbar.scrollLeft = tableScrollBox.scrollLeft;

            // With latentcy
            setTimeout(() => {
              const curScrollOffset = (tableScrollBox.scrollWidth - tableScrollBox.clientWidth);
              const curScrollLeft = (tableScrollBox.scrollLeft);
              const curIsNotScrolled = (curScrollLeft === 0);
              const curIsScrolled = ((curScrollLeft > 0) && (curScrollLeft < curScrollOffset));
              const curIsScrolledToEnd = (curScrollLeft >= curScrollOffset);
              // Constantly update scroll features when the table is scrolled
              updateTableScrollFeatures(true, curIsNotScrolled, curIsScrolled, curIsScrolledToEnd);
            }, 100);
          });
        }
      } catch (ex) {
        // DEBUG
        // console.error(`LDS TABLE >>> An unexpected error occured in function setTableScrollBoxScrollListener.\n>>> Exception: ${ex.message}\n>>> Please submit a bug report to the LDS team if this error persists.`);
      }
    };

    /**
     * Initialize, add or remove a scroll event listener on the Table's optional top scrollbar element
     *
     * Should be called
     *   - once on page load for initialization
     *   - any time the table is resized (width changes)
     */
    const setTopScrollbarScrollListener = () => {
      if (disableTopScrollbar) return;

      try {
        const tableScrollBox = getTableElementById(tableContainerRef.current, ids.tableScrollBox);
        const topScrollbar = getTableElementById(tableContainerRef.current, ids.tableTopScrollbar);

        // Remove the any matching scroll listeners by default
        try {
          if (topScrollbar) topScrollbar.removeEventListener('scroll');
        } catch {
          // Suppress exceptions; do nothing if the event listener cannot be removed because it doesn't exist
        }

        const scrollOffset = (tableScrollBox.scrollWidth - tableScrollBox.clientWidth);
        const isScrollable = (scrollOffset > 0);

        if (!tableScrollFeaturesAllAreDisabled || (isScrollable && !disableTopScrollbar && topScrollbar)) {
          topScrollbar.addEventListener('scroll', () => {
            // Without latency, smoothly update the scroll box scrollLeft position with the top scrollbar scrollLeft position
            tableScrollBox.scrollLeft = topScrollbar.scrollLeft;
          });
        }
      } catch (ex) {
        // DEBUG
        // console.error(`LDS TABLE >>> An unexpected error occured in function setTopScrollbarScrollListener.\n>>> Exception: ${ex.message}\n>>> Please submit a bug report to the LDS team if this error persists.`);
      }
    };

    // ** Initialize scrollable features on load **
    const iniTableScrollBox = getTableElementById(tableContainerRef.current, ids.tableScrollBox);
    const iniScrollOffset = (iniTableScrollBox.scrollWidth - iniTableScrollBox.clientWidth);
    const iniIsScrollable = (iniScrollOffset > 0);
    setTopScrollbarDimensions(iniIsScrollable);
    setTopScrollbarScrollListener();
    setTableScrollBoxScrollListener();

    const resizeObserver = new ResizeObserver(() => {
      // Update scrollable features on table resize
      const curTableScrollBox = getTableElementById(tableContainerRef.current, ids.tableScrollBox);
      const curScrollOffset = (curTableScrollBox.scrollWidth - curTableScrollBox.clientWidth);
      const curIsScrollable = (curScrollOffset > 0);
      setTopScrollbarDimensions(curIsScrollable);
      setTopScrollbarScrollListener();
      setTableScrollBoxScrollListener();
    });

    resizeObserver.observe(iniTableScrollBox);

    return () => {
      try {
        const tableScrollBox = getTableElementById(tableContainerRef.current, ids.tableScrollBox);
        tableScrollBox.removeEventListener('scroll');
      } catch { /* GNDN: The tableScrollBox may not have an event listener */ }

      try {
        // eslint-disable-next-line react-hooks/exhaustive-deps
        const topScrollbar = getTableElementById(tableContainerRef.current, ids.tableTopScrollbar);
        topScrollbar.removeEventListener('scroll');
      } catch { /* GNDN: The topScrollbar may not have an event listener and it may not exist in DOM */ }

      resizeObserver.unobserve(iniTableScrollBox);
    };
  }, [
    disableScrollOverlay,
    disableScrollShadows,
    disableTopScrollbar,
    ids.tableContainer,
    ids.tableScrollBox,
    ids.tableScrollShadowLeft,
    ids.tableScrollShadowRight,
    ids.tableTable,
    ids.tableTopScrollbar,
    ids.tableTopScrollbarFill,
    tableScrollFeaturesAllAreDisabled,
    getTableScrollOverlaysStatus,
  ]);

  return (
    <>
      <div
        id={ids.tableContainer}
        ref={tableContainerRef}
        className={cn(
          'lds-table-container',
          styleClass,
          frozenColumnClass,
          frozenColumnShadowClass,
          className
        )}
        {...rest}
      >
        {!hideVisualCaption && <VisualCaption
          id={ids.tableVisualCaption}
          className={visualCaptionClass}
          {...visualCaptionAttributes}
        >
          {caption}
        </VisualCaption>}

        <div id={ids.tableWrapper} className="lds-table-wrapper">

          {!disableScrollOverlay && <ScrollOverlay
            id={ids.tableScrollOverlay}
            className={scrollOverlayClass}
            onClick={dismissTableScrollOverlays}
            label={scrollOverlayLabel}
            {...scrollOverlayAttributes}
          />}

          {!disableTopScrollbar && <TopScrollBar
            id={ids.tableTopScrollbar}
            fillId={ids.tableTopScrollbarFill}
          />}

          {!disableScrollShadows && <div
            id={ids.tableScrollShadowLeft}
            className="lds-table-scroll-shadow-left"
            style={{ display: 'none' }}>
          </div>}

          <div
            id={ids.tableScrollBox}
            className="lds-table-scroll-box"
            tabIndex="0"
            role="group"
            aria-labelledby={ids.tableCaption}
          >
            <table
              id={ids.tableTable}
              className={cn(
                'lds-table',
                tableClass
              )}
              aria-labelledby={ids.tableCaption}
              {...tableAttributes}
            >
              <caption id={ids.tableCaption}>
                {caption}
              </caption>
              {children}
            </table>
          </div>

          {!disableScrollShadows && <div
            id={ids.tableScrollShadowRight}
            className="lds-table-scroll-shadow-right"
            style={{ display: 'none' }}>
          </div>}
        </div>
      </div>
    </>
  );
}
LdsTable.propTypes = {
  id: PropTypes.string.isRequired,
  caption: PropTypes.any.isRequired,
  children: PropTypes.any.isRequired,
  styleClass: PropTypes.oneOf([
    'discrete-cells',
  ]),
  frozenColumnClass: PropTypes.oneOf([
    'frozen-first-col',
    'frozen-first-col-body',
    'frozen-second-col',
    'frozen-second-col-body',
  ]),
  frozenColumnShadowClass: PropTypes.oneOf([
    'frozen-col-shadow-25',
  ]),
  className: PropTypes.string,
  visualCaptionClass: PropTypes.string,
  visualCaptionAttributes: PropTypes.any,
  hideVisualCaption: PropTypes.bool,
  scrollOverlayLabel: PropTypes.any,
  scrollOverlayClass: PropTypes.string,
  scrollOverlayAttributes: PropTypes.any,
  disableScrollOverlay: PropTypes.bool,
  disableTopScrollbar: PropTypes.bool,
  disableScrollShadows: PropTypes.bool,
  tableClass: PropTypes.string,
  tableAttributes: PropTypes.any,
};

/* Register Public Sub-components */
LdsTable.thRow = RowTh;

export default LdsTable;
