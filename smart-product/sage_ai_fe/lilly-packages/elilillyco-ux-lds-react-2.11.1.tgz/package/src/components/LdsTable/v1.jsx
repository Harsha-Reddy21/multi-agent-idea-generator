import PropTypes from 'prop-types';
import cn from 'classnames';

// JSDoc type definitions
/**
 * @typedef LdsTableProps
 * @property {string} id - Required Component `id`.
 * @property {string} caption - Text value of the `<caption>` element to display above or below the table
 * @property {React.ReactNode} children - React child slot object
 * @property {boolean} [striped] - Apply an alternating background color to the table rows
 * @property {boolean} [flat] - Apply flat table style
 * @property {string} [layoutClass] - Apply a specific LDS table layout class. One of 'layout-auto' or 'layout-fixed'
 * @property {string} [captionSide] - Where the caption element will be placed relative to the table. One of 'top' or 'bottom'
 * @property {string} [captionClass] - Optional custom user-defined CSS class(es) for the table caption element, will be appended to the list of any other component classes
 * @property {object} [captionStyle] - Customize the style attribute of the caption element
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [captionAttributes] - An additional properties object to pass generic HTML attributes onto the table caption element
 * @property {string} [tableClass] - Optional custom user-defined CSS class(es) for the table element, will be appended to the list of any other component classes
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [tableAttributes] - An additional properties object to pass generic HTML attributes onto the table element
 * @property {string} [className] - Optional custom user-defined CSS class(es) for the table component wrapper element, will be appended to the list of any other component classes
 */
/**
 * LdsTable component
 * @param {LdsTableProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsTable({
  id,
  caption,
  children,
  striped = false,
  flat = false,
  layoutClass = '',
  captionSide = 'top',
  captionClass = 'h3',
  captionStyle = {},
  captionAttributes,
  tableClass,
  tableAttributes,
  className,
  ...rest
}) {
  const TableCaption = () => {
    return (
      <p
        className={cn(
          'lds-table-caption',
          captionClass
        )}
        style={captionStyle}
        id={`${id}-caption`}
        {...captionAttributes}
      >
        {caption}
      </p>
    );
  };

  return (
    <>
      {caption && captionSide === 'top' && <TableCaption />}
      <div
        className={cn(
          'lds-table-wrapper',
          className
        )}
        tabIndex="0"
        role="group"
        aria-labelledby={`${id}-caption`}
        {...rest}
      >
        <table
          id={id}
          role="table"
          className={cn(
            'lds-table',
            layoutClass,
            {
              striped,
              flat,
            },
            tableClass
          )}
          aria-labelledby={`${id}-caption`}
          {...tableAttributes}
        >
          {children}
        </table>
      </div>
      {caption && captionSide === 'bottom' && <TableCaption />}
    </>
  );
}

LdsTable.propTypes = {
  id: PropTypes.string.isRequired,
  captionSide: PropTypes.oneOf(['top', 'bottom']),
  captionClass: PropTypes.string,
  layoutClass: PropTypes.oneOf(['layout-auto', 'layout-fixed']),
  flat: PropTypes.bool,
  striped: PropTypes.bool,
};
