export const tableElementIds = (base) => {
  return {
    tableContainer: base,
    tableVisualCaption: `${base}_visual-caption`,
    tableWrapper: `${base}_wrapper`,
    tableScrollOverlay: `${base}_scroll-overlay`,
    tableTopScrollbar: `${base}_top-scroll-bar`,
    tableTopScrollbarFill: `${base}_top-scroll-bar-fill`,
    tableScrollShadowLeft: `${base}_scroll-shadow-left`,
    tableScrollShadowRight: `${base}_scroll-shadow-right`,
    tableScrollBox: `${base}_scroll-box`,
    tableTable: `${base}_table`,
    tableCaption: `${base}_table-caption`,
  };
};

export const getTableElementById = (currentTableContainerRef, elementId) => {
  if (currentTableContainerRef) {
    try {
      const element = currentTableContainerRef.querySelector(`#${elementId}`);
      if (!element) {
        // DEBUG
        // // eslint-disable-next-line no-console
        // console.error(`LDS TABLE >>> [×] Element ID '${elementId}' NOT found, TABLE may not function correctly, document.getElementById returned:`, element);
        return null;
      }

      // DEBUG -- Enable to make sure you're getting the DOM element you think you are; Disable in production
      // console.log(`ISI >>> [√] Element ID '${elementId}' found:`, element);

      return element;
    } catch (ex) {
      // DEBUG
      // // eslint-disable-next-line no-console
      // console.error(`LDS TABLE >>> A fatal exception occurred attempting to get the Element ID '${elementId}': ${ex.message}`);
      return null;
    }
  }

  return null;
};
