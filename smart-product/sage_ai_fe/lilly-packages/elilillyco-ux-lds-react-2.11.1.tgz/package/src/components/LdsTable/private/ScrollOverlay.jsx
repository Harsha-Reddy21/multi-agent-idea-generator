import { forwardRef } from 'react';
import cn from 'classnames';

export default forwardRef(function TableScrollOverlay({
  id,
  onClick,
  label = 'Swipe left or right to view all data.',
  className,
  ...rest
}, ref) {
  return (
    <button
      id={id}
      className={cn(
        'lds-table-scroll-overlay',
        className
      )}
      onClick={onClick}
      aria-hidden="true"
      tabIndex="-1"
      ref={ref}
      {...rest}
    >
      <span className="lds-table-scroll-overlay-container">
        <span className="lds-table-swipe-notice">
          <svg className="lds-table-scroll-overlay-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 37 26" fill="none">
            <path d="M1 5H10" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M5 1L1 5L5 9" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M12.9995 25L9.33453 18.75C9.00823 18.1761 8.92218 17.4964 9.09515 16.8593C9.26812 16.2222 9.68607 15.6794 10.2578 15.3493C10.8295 15.0192 11.5086 14.9287 12.1468 15.0974C12.7851 15.2661 13.3306 15.6805 13.6645 16.25L15.9995 20V6.5C15.9995 5.83696 16.2629 5.20107 16.7318 4.73223C17.2006 4.26339 17.8365 4 18.4995 4C19.1626 4 19.7985 4.26339 20.2673 4.73223C20.7361 5.20107 20.9995 5.83696 20.9995 6.5V13.5C20.9995 12.837 21.2629 12.2011 21.7318 11.7322C22.2006 11.2634 22.8365 11 23.4995 11C24.1626 11 24.7985 11.2634 25.2673 11.7322C25.7361 12.2011 25.9995 12.837 25.9995 13.5V15.5C25.9995 14.837 26.2629 14.2011 26.7318 13.7322C27.2006 13.2634 27.8365 13 28.4995 13C29.1626 13 29.7985 13.2634 30.2673 13.7322C30.7361 14.2011 30.9995 14.837 30.9995 15.5V20C30.9995 23 29.9995 25 29.9995 25" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M32 1L36 5L32 9" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M27 5H36" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span className="lds-table-scroll-overlay-text">
            {label}
          </span>
        </span>
      </span>
    </button>
  );
});
