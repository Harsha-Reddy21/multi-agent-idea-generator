import { forwardRef } from 'react';

export default forwardRef(function TableScrollOverlay({
  id,
  fillId,
}, ref) {
  return (
    <div
      id={id}
      className="lds-table-top-scroll-bar"
      ref={ref}
    >
      <div id={fillId} className="lds-table-top-scroll-bar-filler"></div>
    </div>
  );
});
