import PropTypes from 'prop-types';
import cn from 'classnames';

// JSDoc type definitions
/**
 * @typedef LdsTableRowHeaderCellProps
 * @property {React.ReactNode} children - Required React child slot object; must be valid innerHTML markup to be injected into a '<span>' element within a '<th>'.
 * @property {string} [className] - Optional custom user-defined CSS class(es) for the <th> wrapper element, will be appended to the list of any other component classes
 */
/**
 * LdsTableRowHeaderCell component
 * @param {LdsTableRowHeaderCellProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function RowTh({ children, className, ...rest }) {
  return (
    <th
      className={cn(
        'row-heading-cell',
        className
      )}
      {...rest}
    >
      <span className="row-heading-cell-inner">
        {children}
      </span>
    </th>
  );
}

RowTh.propTypes = {
  children: PropTypes.any.isRequired,
  className: PropTypes.string,
};
