import {
  forwardRef, useRef, useEffect, useState
} from 'react';
import PropTypes from 'prop-types';
import Horizontal from './horizontalProgressIndicator.jsx';
import Circle from './circleProgressIndicator.jsx';

import {
  getValidProgress,
  getValidAriaLabel,
  getValidAriaValueMax,
  getValidAriaValueMin
} from './progressIndicator.helpers.js';

// JSDoc type definitions
/**
 * @typedef LdsProgressIndicatorProps
 * @property {number} [progress] - The percent the process has completed as a number from 0 (zero) to 100, inclusive. The input must be a number and not be less than zero or greater than 100.
 * @property {string} [size] -A t-shirt size string value used to scale the overall size of the component. xsmall, small, medium, and large.
 * @property {string} [ariaLabel] - A String value which sets the "aria-label" attribute; it must contain a value
 * @property {number} [ariaValueMax] - A String value which indicates the maximum value of the progress indicator; it must contain a value
 * @property {number} [ariaValueMin] - A String value which indicates the minimum value of the progress indicator; it must contain a value
 * @property {string} [errorMessage] - An optional string value which describes an error, when set to a truthy value the indicates the progress indicator is in the error state, this defaults to undefined.
 * @property {string} [helperText] - An optional string value which when set to a truthy value will set helper text describing the state of the process.
 * @property {boolean} [horizontalShape] - An optional boolean value which determines the shape of the progress indicator, defaults to false (circle shape).
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 */
const LdsProgressIndicator = forwardRef(
  /**
   * LdsProgressIndicator component
   * @param {LdsProgressIndicatorProps & React.InputHTMLAttributes<HTMLInputElement>} props
   * @param {React.Ref} ref - forwarded ref to the indicator DOM node
   * @returns {React.JSX.Element}
   */
  function LdsProgressIndicator(
    {
      progress = 0,
      size = 'small',
      ariaLabel = 'Processing',
      ariaValueMax = 100,
      ariaValueMin = 0,
      className,
      helperText,
      errorMessage,
      horizontalShape = false,
    },
    ref
  ) {
    const helperTextRef = useRef(null);

    const [diameter, setDiameter] = useState(0);
    const [boxHeight, setBoxHeight] = useState(0);
    const [boxWidth, setBoxWidth] = useState(0);
    const [helperTextWrap, setHelperTextWrap] = useState(false);
    // Validate prop values
    let vProgress = getValidProgress(progress);
    const vAriaLabel = getValidAriaLabel(ariaLabel);
    let vAriaValueMax = getValidAriaValueMax(ariaValueMax);
    let vAriaValueMin = getValidAriaValueMin(ariaValueMin);
    let progressText = `${vProgress}%`;

    // Check that the max/min values are logical
    if ((vAriaValueMin > vAriaValueMax) || (vAriaValueMax < vAriaValueMin)) {
      // eslint-disable-next-line no-console
      console.warn(`
    LDS Warning: A Progress Indicator has illogical ariaValueMin or ariaValueMax values set. Min must be less than max; max must be less than min. To avoid an illogical condition, the default of min = 0 and max = 100 will be used.
    Input ariaValueMin: ${ariaValueMin}
    Input ariaValueMax: ${ariaValueMax}
    Please fix the illogical min/max values above when customizing these ARIA attributes to resolve this warning.
    `);
      vAriaValueMin = 0;
      vAriaValueMax = 100;
    }
    let ariaValueNow = errorMessage ? undefined : vProgress;
    // Use an internal ref if no ref is provided
    const internalRef = useRef(null);
    const indicatorRef = ref || internalRef;

    useEffect(() => {
      if (!horizontalShape && indicatorRef && typeof indicatorRef !== 'function' && indicatorRef.current) {
        setDiameter(indicatorRef.current.offsetWidth);
      } else if (horizontalShape && indicatorRef && typeof indicatorRef !== 'function' && indicatorRef.current) {
        setBoxWidth(indicatorRef.current.offsetWidth);
        setBoxHeight(indicatorRef.current.offsetHeight);
      }
      if ((helperText || errorMessage) && helperTextRef.current && !horizontalShape) {
        setHelperTextWrap(helperTextRef.current.offsetHeight > 34);
      }
    }, [horizontalShape, helperText, errorMessage, size, indicatorRef]);

    const sharedProps = {
      size,
      className,
      errorMessage,
      helperText,
      ariaLabel: vAriaLabel,
      ariaValueMin: vAriaValueMin,
      ariaValueMax: vAriaValueMax,
      ariaValueNow,
      indicatorRef,
      progressText,
      progress: vProgress,
    };

    if (horizontalShape) {
      return (
        <Horizontal
          {...sharedProps}
          boxHeight={boxHeight}
          boxWidth={boxWidth}
        />
      );
    }
    return (
      <Circle
        {...sharedProps}
        diameter={diameter}
        helperTextWrap={helperTextWrap}
        helperTextRef={helperTextRef}
      />
    );
  }
);

LdsProgressIndicator.propTypes = {
  progress: PropTypes.number,
  size: PropTypes.string,
  ariaLabel: PropTypes.string,
  ariaValueMax: PropTypes.number,
  ariaValueMin: PropTypes.number,
  className: PropTypes.string,
  helperText: PropTypes.string,
  errorMessage: PropTypes.string,
  horizontalShape: PropTypes.bool,
};

export default LdsProgressIndicator;
