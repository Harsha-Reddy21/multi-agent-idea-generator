import cn from 'classnames';
import LdsIcon from '../LdsIcon/index.jsx';
import isRTL from '../../util/isRTL.js';

export default function Horizontal({
  size,
  className,
  errorMessage,
  helperText,
  ariaLabel,
  ariaValueMin,
  ariaValueMax,
  ariaValueNow,
  boxHeight,
  boxWidth,
  indicatorRef,
  progressText,
  progress,
}) {
  let currProgressText = progressText;
  let currProgress = progress;
  const isRtl = isRTL(indicatorRef);
  if (errorMessage) {
    currProgressText = '';
    currProgress = 0;
  }
  let horizontalStroke = 0;
  if (boxHeight === 42) {
    horizontalStroke = 8;
  } else if (boxHeight > 42 && boxHeight < 52) {
    horizontalStroke = (0.4 * (boxHeight)) - 8.8; // Evenly space values 8-12 exclusive, ratio mismatches a bit
  } else {
    horizontalStroke = (0.5 * (boxHeight)) - 14; // linear relation with the rest of the values
  }

  let lineLocation = boxHeight - horizontalStroke + (horizontalStroke / 4); // Set the location vertically of the line within the viewbox
  let halfStrokeWidth = horizontalStroke / 2;

  // Get line stroke dash offset
  let lineStrokeDashOffset = (boxWidth - ((currProgress / 100) * boxWidth));
  if (isRtl) {
    lineStrokeDashOffset *= -1;
  }
  let horizontalFontSize = horizontalStroke + 8;
  let horizontalSubLabelSize = (horizontalFontSize / 2) + 4;

  let strokeDasharray = `${boxWidth} ${boxWidth}`;
  let viewBoxHorizontal = `0 0 ${boxWidth} ${boxHeight}`;
  const widthWithRoundedCap = boxWidth - halfStrokeWidth; // Subtract some width ot the line so the rounded ends don't get cut off
  return (
    <div
      role="progressbar"
      className={cn(
        'lds-progress-indicator-horizontal',
        className,
        errorMessage ? 'error' : '',
        {
          'size-xs': size === 'xsmall',
          'size-sm': size === 'small',
          'size-md': size === 'medium',
          'size-lg': size === 'large',
        }
      )}
      aria-label={ariaLabel}
      aria-valuemin={ariaValueMin}
      aria-valuemax={ariaValueMax}
      aria-valuenow={ariaValueNow}
      ref={indicatorRef}
    >
      <div className="lds-progress-indicator-text-container">
        <span
          className="lds-progress-indicator-text-horizontal"
          style={{ fontSize: `${horizontalFontSize}px` }}
        >
          {currProgressText}
        </span>
        {(helperText && !errorMessage) && <span
          className="lds-progress-indicator-helper-text-horizontal"
          style={{ fontSize: `${horizontalSubLabelSize}px` }}
        >{helperText}
        </span>}
        {(errorMessage && !isRtl) && <span
          className="lds-progress-indicator-helper-text-horizontal"
          style={{ fontSize: `${horizontalSubLabelSize}px` }}
        >
          <LdsIcon name="warning-circle-fill" inline role="img" aria-hidden="true"></LdsIcon>
          {errorMessage}
        </span>}
        {(errorMessage && isRtl) && <span
          className="lds-progress-indicator-helper-text-horizontal"
          style={{ fontSize: `${horizontalSubLabelSize}px` }}
        >
          {errorMessage}
          <LdsIcon name="warning-circle-fill" inline role="img" aria-hidden="true"></LdsIcon>
        </span>}
      </div>
      <svg
        className="lds-progress-indicator-svg"
        viewBox={viewBoxHorizontal}
      >
        <line
          className="lds-progress-indicator-horizontal-base"
          strokeLinecap="round"
          strokeWidth={horizontalStroke}
          y1={lineLocation}
          y2={lineLocation}
          x1={halfStrokeWidth}
          x2={widthWithRoundedCap}
        />
        <line
          className="lds-progress-indicator-horizontal-progress"
          strokeLinecap="round"
          strokeWidth={horizontalStroke}
          y1={lineLocation}
          y2={lineLocation}
          x1={halfStrokeWidth}
          x2={widthWithRoundedCap}
          strokeDasharray={strokeDasharray}
          strokeDashoffset={lineStrokeDashOffset}
        />
      </svg>

    </div>
  );
}
