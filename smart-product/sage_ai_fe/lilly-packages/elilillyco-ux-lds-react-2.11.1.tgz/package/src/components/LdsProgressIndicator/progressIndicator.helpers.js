const MINIMUM_VALUE = 0;
const MAXIMUM_VALUE = 100;

export const getValidProgress = (propProgress) => {
  if (propProgress == null) {
    // eslint-disable-next-line no-console
    console.error('\nLDS Error: A Progress Indicator progress prop was not provided or was set to null/undefined.\nIt will default to a progress value of 0.\nPlease set a valid numeric progress value between 0 and 100 to clear this error.\n');
    return MINIMUM_VALUE;
  }

  if (typeof propProgress !== 'number' || isNaN(propProgress)) {
    // eslint-disable-next-line no-console
    console.error(`\nLDS Error: A Progress Indicator progress prop was set to a non-numeric value: ${propProgress}.\nIt will default to a progress value of 0.\nPlease set a valid numeric progress value between 0 and 100 to clear this error.\n`);
    return MINIMUM_VALUE;
  }

  const warn = propProgress < MINIMUM_VALUE || propProgress > MAXIMUM_VALUE;
  const progress = Math.max(MINIMUM_VALUE, Math.min(MAXIMUM_VALUE, propProgress));

  if (warn) {
    // eslint-disable-next-line no-console
    console.warn(`\nLDS Warning: A Progress Indicator progress percentage value was set to ${propProgress}% which is invalid.\nThe progress percent will be overridden to the ${propProgress < MINIMUM_VALUE ? 'minimum' : 'maximum'} of ${progress}.\nTo correctly customize the value, please set it between ${MINIMUM_VALUE}-${MAXIMUM_VALUE} inclusive to clear this warning.\n`);
  }

  return progress;
};

export const getValidAriaLabel = (propAriaLabel) => {
  // Fail fast if falsey
  if (!propAriaLabel) {
    // eslint-disable-next-line no-console
    console.error('\n    LDS Error: A Progress Indicator ariaLabel prop was set to a falsey value.\n    It will default to a value of \'Progress\'.\n    Please set a valid string value to clear this error.\n    ');
    return 'Progress';
  }
  return propAriaLabel;
};

export const getValidAriaValueMin = (propAriaValueMin) => {
  if (propAriaValueMin == null) {
    // eslint-disable-next-line no-console
    console.error('\nLDS Error: A Progress Indicator ariaValueMin prop was not provided or was set to a falsey value.\nIt will default to a value of 0.\nPlease set a valid numeric value between 0 and 100 to clear this error.\n');
    return MINIMUM_VALUE;
  }

  if (typeof propAriaValueMin !== 'number' || isNaN(propAriaValueMin)) {
    // eslint-disable-next-line no-console
    console.error(`\nLDS Error: A Progress Indicator ariaValueMin prop was set to a non-numeric value: ${propAriaValueMin}.\nIt will default to a value of 0.\nPlease set a valid numeric value between 0 and 100 to clear this error.\n`);
    return MINIMUM_VALUE;
  }

  const warn = propAriaValueMin < MINIMUM_VALUE || propAriaValueMin > MAXIMUM_VALUE;
  const ariaValueMin = Math.max(MINIMUM_VALUE, Math.min(MAXIMUM_VALUE, propAriaValueMin));

  if (warn) {
    // eslint-disable-next-line no-console
    console.warn(`\nLDS Warning: A Progress Indicator has the ariaValueMin value set out of range; the value was either greater than ${MAXIMUM_VALUE} or less than ${MINIMUM_VALUE} (zero).\ninput ariaValueMin: ${propAriaValueMin}\nThe ariaValueMin will be rendered as: ${ariaValueMin}\nTo correctly customize the value, please set it between ${MINIMUM_VALUE}-${MAXIMUM_VALUE} inclusive to clear this warning.\n`);
  }

  return ariaValueMin;
};

export const getValidAriaValueMax = (propAriaValueMax) => {
  if (propAriaValueMax == null) {
    // eslint-disable-next-line no-console
    console.error('\nLDS Error: A Progress Indicator ariaValueMax prop was not provided or was set to a falsey value.\nIt will default to a value of 100.\nPlease set a valid numeric value between 0 and 100 to clear this error.\n');
    return MAXIMUM_VALUE;
  }

  if (typeof propAriaValueMax !== 'number' || isNaN(propAriaValueMax)) {
    // eslint-disable-next-line no-console
    console.error(`\nLDS Error: A Progress Indicator ariaValueMax prop was set to a non-numeric value: ${propAriaValueMax}.\nIt will default to a value of 100.\nPlease set a valid numeric value between 0 and 100 to clear this error.\n`);
    return MAXIMUM_VALUE;
  }

  const warn = propAriaValueMax < MINIMUM_VALUE || propAriaValueMax > MAXIMUM_VALUE;
  const ariaValueMax = Math.max(MINIMUM_VALUE, Math.min(MAXIMUM_VALUE, propAriaValueMax));

  if (warn) {
    // eslint-disable-next-line no-console
    console.warn(`\nLDS Warning: A Progress Indicator has the ariaValueMax value set out of range; the value was either greater than ${MAXIMUM_VALUE} or less than ${MINIMUM_VALUE} (zero).\ninput ariaValueMax: ${propAriaValueMax}\nThe ariaValueMax will be rendered as: ${ariaValueMax}\nTo correctly customize the value, please set it between ${MINIMUM_VALUE}-${MAXIMUM_VALUE} inclusive to clear this warning.\n`);
  }

  return ariaValueMax;
};
