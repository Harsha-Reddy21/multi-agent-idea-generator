import cn from 'classnames';
import LdsIcon from '../LdsIcon/index.jsx';
import isRTL from '../../util/isRTL.js';

export default function Circle({
  errorMessage,
  className,
  size,
  ariaLabel,
  ariaValueMin,
  ariaValueMax,
  ariaValueNow,
  indicatorRef,
  progress,
  progressText,
  diameter,
  helperTextWrap,
  helperText,
  helperTextRef,
}) {
  // Compute circle dimensions from size
  let viewBoxCircle = `0 0 ${diameter} ${diameter}`;
  const radius = diameter / 2;
  const stroke = diameter / 16;
  const innerStroke = stroke / 2;
  const normalizedRadius = radius - stroke;
  const circumference = normalizedRadius * 2 * Math.PI;
  const isRtl = isRTL(indicatorRef);
  let strokeDashOffset = 0;

  // There is a linear relation between diameter and font size, use y=mx+b where x is the diameter in pixels and y is the font size
  // M is the change in y divided by the change in x, of one pair of coordinates, lets use xsmall as coordinate 1 and small as coordinate 2
  let x1 = 96;
  let y1 = 16;
  let x2 = 128;
  let y2 = 20;
  let m = (y2 - y1) / (x2 - x1);
  // B is the value when y, or font would be zero --> 4 for this design
  let b = 4;
  let fontSize = (m * diameter) + b;
  let subLabelFontSize = (diameter / 16) + 6;
  let subLabelLineHeight = subLabelFontSize + 6;
  let shiftHelperText = '';
  if (helperTextWrap) {
    shiftHelperText = 'calc(-50% - 24px)';
  } else {
    shiftHelperText = 'calc(-50% - 10px)';
  }

  let currProgressText = progressText;
  let currProgress = progress;
  if (errorMessage) {
    currProgressText = '---';
    currProgress = 0;
  }
  strokeDashOffset = circumference - ((currProgress / 100) * circumference);
  if (isRtl) {
    strokeDashOffset *= -1;
  }
  return (
    <div
      role="progressbar"
      className={cn(
        'lds-progress-indicator',
        className,
        errorMessage ? 'error' : '',
        {
          'size-xs': size === 'xsmall',
          'size-sm': size === 'small',
          'size-md': size === 'medium',
          'size-lg': size === 'large',
        }
      )}
      aria-label={ariaLabel}
      aria-valuemin={ariaValueMin}
      aria-valuemax={ariaValueMax}
      aria-valuenow={ariaValueNow}
      ref={indicatorRef}
    >
      <span
        className="lds-progress-indicator-text"
        style={{ fontSize: `${fontSize}px` }}
      >
        {currProgressText}
      </span>
      <svg
        className="lds-progress-indicator-svg"
        height={diameter}
        width={diameter}
        viewBox={viewBoxCircle}
      >
        <circle
          className="lds-progress-indicator-circle-base"
          r={normalizedRadius}
          cx={radius}
          cy={radius}
          strokeWidth={innerStroke}
        />
        <circle
          className="lds-progress-indicator-circle-progress"
          r={normalizedRadius}
          cx={radius}
          cy={radius}
          style={{ strokeDashoffset: `${strokeDashOffset}` }}
          strokeDasharray={`${circumference} ${circumference}`}
          strokeWidth={stroke}
          strokeLinecap="round"
        />
      </svg>
      {(helperText && !errorMessage) && <span
        className="lds-progress-indicator-helper-text"
        style={{ fontSize: `${subLabelFontSize}px`, lineHeight: `${subLabelLineHeight}px`, left: shiftHelperText }}
        ref={helperTextRef}
      >{helperText}
      </span>}
      {(errorMessage && isRtl) && <span
        className="lds-progress-indicator-helper-text"
        style={{ fontSize: `${subLabelFontSize}px`, lineHeight: `${subLabelLineHeight}px`, left: shiftHelperText }}
        ref={helperTextRef}
      >
        {errorMessage}
        <LdsIcon name="warning-circle-fill" inline role="img" aria-hidden="true"></LdsIcon>
      </span>}
      {(errorMessage && !isRtl) && <span
        className="lds-progress-indicator-helper-text"
        style={{ fontSize: `${subLabelFontSize}px`, lineHeight: `${subLabelLineHeight}px`, left: shiftHelperText }}
        ref={helperTextRef}
      >
        <LdsIcon name="warning-circle-fill" inline role="img" aria-hidden="true"></LdsIcon>
        {errorMessage}
      </span>}
    </div>
  );
}
