import PropTypes from 'prop-types';
import cn from 'classnames';

import ImageComparisonSliderTitle from './ImageComparisonSliderTitle.jsx';
import ImageComparisonSliderImages from './ImageComparisonSliderImages.jsx';
import ImageComparisonSliderCaption from './ImageComparisonSliderCaption.jsx';

// JSDoc type definitions
/**
 * @typedef LdsImageComparisonSliderProps
 * @property {string} id - ID to assign to Image Comparison Slider. Required for Image Slider to work.
 * @property {{src: string, alt?: string, title?: string}} image1 - An object which defines first image with valid src, alt & title. src is required for image comparison slider to work.
 * @property {{src: string, alt?: string, title?: string}} image2 - An object which defines second image with valid src, alt & title. src is required for image comparison slider to work.
 * @property {string} [caption] - Caption text for Image Comparison Slider
 * @property {string} [controlBtnAriaLabel] - ARIA-LABEL text for control button of Image Comparison Slider
 * @property {string} [hiddenControlBtnText] - Screen reader only text for control button of Image Comparison Slider for Accessibility
 * @property {string} [className] - Optional custom user-defined CSS class(es) to add to the component root container element; will be appended to the list of any other component classes
 */
/**
 * LdsImageComparisonSlider component
 * @param {LdsImageComparisonSliderProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsImageComparisonSlider({
  caption,
  controlBtnAriaLabel = 'Move left or right to compare images',
  hiddenControlBtnText = 'Move by clicking and dragging or using your arrow keys to see the difference between the two images',
  id,
  image1,
  image2,
  className,
  ...rest
}) {
  return (
    <div
      className={cn(
        'lds-image-comparison-slider',
        className
      )}
      {...rest}
    >
      <ImageComparisonSliderTitle
        id={id}
        imgTitle1={image1?.title}
        imgTitle2={image2?.title}
      />
      <ImageComparisonSliderImages
        controlBtnAriaLabel={controlBtnAriaLabel}
        hiddenControlBtnText={hiddenControlBtnText}
        id={id}
        image1={image1}
        image2={image2}
      />
      <ImageComparisonSliderCaption
        id={id}
        caption={caption}
      />
    </div>
  );
}

LdsImageComparisonSlider.propTypes = {
  caption: PropTypes.string,
  controlBtnAriaLabel: PropTypes.string,
  hiddenControlBtnText: PropTypes.string,
  id: PropTypes.string.isRequired,
  image1: PropTypes.shape({
    src: PropTypes.string.isRequired,
    alt: PropTypes.string,
    title: PropTypes.string,
  }),
  image2: PropTypes.shape({
    src: PropTypes.string.isRequired,
    alt: PropTypes.string,
    title: PropTypes.string,
  }),
};
