import { useRef } from 'react';

import LdsIcon from '../LdsIcon/index.jsx';

export default function ImageComparisonSliderImages({
  controlBtnAriaLabel,
  hiddenControlBtnText,
  id,
  image1,
  image2,
}) {
  const sliderRef = useRef(null);
  const controlRef = useRef(null);
  const leftImgRef = useRef(null);

  const buffer = 22; // buffer size should be half of the .lds-image-comparison-slider-control width

  let controllerPos = undefined;
  let dragging = false;
  let moving = false;

  const getCalcControllerPos = () => {
    return controllerPos ? `calc(${controllerPos}% - (1.5rem - 2px))` : null;
  };

  const setControllerPos = () => {
    controlRef.current.style.left = getCalcControllerPos();
    leftImgRef.current.style.width = controllerPos ? `${controllerPos}%` : null;
  };

  const sliderWidth = () => {
    return sliderRef.current.getBoundingClientRect().width;
  };

  const percentOfWidth = (number) => {
    return (number / sliderWidth()) * 100;
  };

  const determineControlPosition = (cursorPos) => {
    const sliderBoundary = sliderRef.current.getBoundingClientRect();
    const leftStop = sliderBoundary.left + buffer;
    const rightStop = sliderBoundary.right - buffer;
    if (cursorPos < leftStop) {
      controllerPos = percentOfWidth(buffer);
    } else if (cursorPos > rightStop) {
      controllerPos = percentOfWidth(rightStop - sliderBoundary.left);
    } else {
      const finalPos = cursorPos - sliderBoundary.left;
      controllerPos = finalPos && finalPos > 0
        ? percentOfWidth(finalPos)
        : (1 / sliderWidth()) * 100;
    }
    setControllerPos();
  };

  const beginDrag = () => { dragging = true; };

  const endDrag = () => { dragging = false; };

  const drag = (e) => {
    if (dragging) {
      const cursorPos = e.clientX;
      determineControlPosition(cursorPos);
    }
  };

  const dragTouch = (e) => {
    if (dragging) {
      const cursorPos = e.touches[0].clientX;
      determineControlPosition(cursorPos);
    }
  };

  const keyUpLeft = () => {
    let posTracker = controllerPos;
    const increment = percentOfWidth(3);
    const target = percentOfWidth(buffer);

    if (controllerPos > target) {
      moving = true;

      for (let i = 0; i < 10; i += 1) {
        if ((posTracker - increment) < target) {
          moving = false;
          controllerPos = target;
        }
        controllerPos -= increment;

        if (i === 9) moving = false;
        posTracker -= increment;
      }
    }
  };

  const keyUpRight = () => {
    let posTracker = controllerPos;
    const increment = percentOfWidth(3);
    const target = percentOfWidth(sliderWidth() - buffer);

    if (controllerPos < target) {
      moving = true;

      for (let i = 0; i < 10; i += 1) {
        if ((posTracker + increment) > target) {
          moving = false;
          controllerPos = target;
        }
        controllerPos += increment;

        if (i === 9) moving = false;
        posTracker += increment;
      }
    }
  };

  const handleKeyUp = (e) => {
    if (moving) return;
    if (!controllerPos) controllerPos = 50;
    if (e.code === 'ArrowRight') {
      keyUpRight();
    } else if (e.code === 'ArrowLeft') {
      keyUpLeft();
    }
    setControllerPos();
  };

  return (
    <div
      className="lds-image-comparison-slider-buffer"
      onMouseLeave={endDrag}
      onMouseUp={endDrag}
    >
      <div
        aria-roledescription="image comparison tool"
        aria-labelledby={`${id}ImageComparisonSliderCaption`}
        className="lds-image-comparison-slider-images"
        role="region"
        ref={sliderRef}
        onMouseMove={drag}
        onMouseLeave={endDrag}
        onTouchMove={dragTouch}
        onTouchEnd={endDrag}
      >
        <div
          className="lds-image-comparison-slider-control"
          ref={controlRef}
        >
          <div className="lds-image-comparison-slider-control-bar-top"></div>
          <div className="lds-image-comparison-slider-control-bar-bottom"></div>
          <button
            className="lds-button-base lds-image-comparison-slider-control-button"
            aria-label={controlBtnAriaLabel}
            onMouseDown={beginDrag}
            onTouchStart={beginDrag}
            onKeyUp={handleKeyUp}
          >
            <span className="sr-only">{hiddenControlBtnText}</span>
            <LdsIcon className="lds-image-comparison-slider-control-icon-left" name="CaretLeft" decorative inline />
            <LdsIcon className="lds-image-comparison-slider-control-icon-right" name="CaretRight" decorative inline />
          </button>
        </div>
        <div
          className="lds-image-comparison-slider-left"
          ref={leftImgRef}
        >
          <img src={image1.src} alt={image1?.alt || 'leftImage'} aria-describedby={`${id}LeftLabel`} />
        </div>
        <div className="lds-image-comparison-slider-right">
          <img src={image2.src} alt={image2?.alt || 'rightImage'} aria-describedby={`${id}RightLabel`} />
        </div>
      </div>
    </div>
  );
}
