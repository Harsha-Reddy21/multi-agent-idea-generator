export default function ImageComparisonSliderCaption({ id, caption }) {
  if (caption === undefined || caption === null) {
    return '';
  }
  return (
    <div className="lds-image-comparison-slider-caption ta-center">
      <p id={`${id}ImageComparisonSliderCaption`}>
        { caption }
      </p>
    </div>
  );
}
