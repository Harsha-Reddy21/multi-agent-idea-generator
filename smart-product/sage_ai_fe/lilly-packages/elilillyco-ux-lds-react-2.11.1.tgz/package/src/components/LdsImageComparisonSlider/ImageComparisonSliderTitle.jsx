export default function ImageComparisonSliderTitle({
  id,
  imgTitle1,
  imgTitle2,
}) {
  if (!imgTitle1 && !imgTitle2) {
    return '';
  }
  return (
    <div className="lds-image-comparison-slider-titles">
      <div className="row">
        <div className="col-6">
          <p className="lds-image-comparison-slider-title-left h4" id={`${id}LeftLabel`}>
            { imgTitle1 }
          </p>
        </div>
        <div className="col-6">
          <p className="lds-image-comparison-slider-title-right h4" id={`${id}RightLabel`}>
            { imgTitle2 }
          </p>
        </div>
      </div>
    </div>
  );
}
