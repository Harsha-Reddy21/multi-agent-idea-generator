import { forwardRef, useEffect, useState } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsLink from '../LdsLink/index.jsx';
import LdsValidationMessage from '../LdsValidationMessage/index.jsx';

// JSDoc type definitions
/**
 * @typedef LdsTextFieldProps
 * @property {string} id - HTML `id` attribute value of the input element
 * @property {string} name - HTML `name` attribute value of the input element
 * @property {string} label - Label to display above the text field
 * @property {string} [labelClassName] - Optional custom user-defined CSS class(es) for the label element, will be appended to the list of any other component classes
 * @property {string} [ariaDescribedBy] - Custom ARIA described by attribute value for the input
 * @property {string} [counterHiddenLabel] - Value of the non-visiblee counter label text which will be used by assistive technologies
 * @property {string} [counterText] - Value of the counter element
 * @property {boolean} [disabled] - Sets the text input to disabled state
 * @property {string} [state] - Optional string value for the text field state: Accepts: success, warning, error.
 * @property {string} [stateMessage] - Optional state message to display below text field when state is available.
 * @property {Object} [labelLink] - Optional label link related link props to pass to the LdsLink component.
 * @property {number} [maxLength] - The maximum number of characters that can be entered into the field.
 * @property {function} [onChange] - Callback function to execute when the textfield value changes
 * @property {string} [hint] - Hint text to display below the text field label
 * @property {string} [radiusClass] - Optional; set one of the border radius size classes for the component; valid values are 'radius-sm', 'radius-md', or leave undefined to use default
 * @property {string} [className] - Optional custom user-defined CSS class(es) for the input element, will be appended to the list of any other component classes
 * @property {boolean} [required] - Property to mark the input as required. Automatically sets aria-required
 */
const LdsTextField = forwardRef(
  /**
   * LdsTextField component
   * @param {LdsTextFieldProps & React.InputHTMLAttributes<HTMLInputElement>} props
   * @returns {React.JSX.Element}
   */
  function LdsTextField({
    id,
    name,
    label,
    ariaDescribedBy = '',
    counterHiddenLabel,
    counterText,
    disabled = false,
    labelClassName,
    state = '',
    stateMessage,
    hint,
    labelLink,
    maxLength,
    onChange,
    radiusClass,
    className,
    required,
    error = false,
    errorMessage,
    ...rest
  }, ref) {
    const [charCount, setCharCount] = useState(0);
    const [describedBy, setDescribedBy] = useState(ariaDescribedBy);
    const hintId = `${id}-hint`;
    const stateId = `${id}-textfield-${state}`;

    // TODO: Deprecated props. Remove in future LDS version
    if (error) {
      // eslint-disable-next-line
      console.warn('ux-lds-react: LdsTextField: The `error` prop is deprecated and will be removed in a future version. Migrate to `state` prop instead.');
    }
    if (errorMessage) {
      // eslint-disable-next-line
      console.warn('ux-lds-react: LdsTextField: The `errorMessage` prop is deprecated and will be removed in a future version. Migrate to `stateMessage` prop instead.');
    }

    const componentState = error ? 'error' : state;
    const componentStateMessage = errorMessage || stateMessage;

    useEffect(() => {
      let desc = ariaDescribedBy;
      if (hint) desc += ` ${hintId}`;
      if (maxLength) {
        desc += `${id}-char-count ${ariaDescribedBy}`;
      }
      if (componentState.length > 0 && componentStateMessage) desc += ` ${stateId}`;
      setDescribedBy(desc.trim());
    }, [hint, hintId, ariaDescribedBy, maxLength, componentState, componentStateMessage, stateId, id]);

    const CharacterCount = () => {
      if (!maxLength) return '';

      return (
        <>
          <span
            id={`${id}-char-count`}
            className="sr-only"
          >
            {counterHiddenLabel || `${maxLength} character limit`}
          </span>
          <span
            role="status"
            aria-live="polite"
            className={cn(
              'lds-form-character-count',
              {
                disabled: disabled,
                [`${componentState}`]: componentState,
              }
            )}
          >
            {counterText ? (charCount + '\u00A0' + counterText) : (charCount + `/${maxLength}`)}
          </span>
        </>
      );
    };

    const handleChange = (e) => {
      setCharCount(e.target.value.length);
      if (onChange) onChange(e);
    };

    return (
      <div
        className={cn(
          'lds-text-field-wrapper',
          radiusClass,
          className
        )}
      >
      <label
        htmlFor={id}
        className={cn(
          'lds-form-label',
          { disabled },
          labelClassName
        )}
      >
        {label}
      </label>
      {
        hint
        && <div aria-hidden="true">
            <span className="lds-form-hint" id={hintId}>
              {hint}
            </span>
          </div>
      }
        <input
          id={id}
          className={cn(
            'lds-text-field',
            {
              disabled,
              [`${componentState}`]: componentState,
            },
            className
          )}
          type="text"
          name={name}
          maxLength={maxLength}
          onChange={handleChange}
          aria-describedby={describedBy}
          aria-invalid={componentState === 'error' ? true : null}
          disabled={disabled}
          ref={ref}
          required={required}
          aria-required={required ? true : null}
          {...rest}
        />
       {
          (componentState || maxLength || labelLink) && (
            <div className="lds-form-panel">
              {(componentState || labelLink) && (
                <div className="lds-form-section-start">
                  {
                    componentState.length > 0 && componentStateMessage
                    && <LdsValidationMessage id={stateId} state={componentState}>
                        {componentStateMessage}
                      </LdsValidationMessage>
                  }
                  {
                    labelLink
                    && <div className="lds-form-label-link">
                        <LdsLink {...labelLink}>{labelLink.text}</LdsLink>
                      </div>
                  }
                </div>
              )}
            <CharacterCount />
          </div>
          )
        }
      </div>
    );
  }
);

LdsTextField.propTypes = {
  id: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  label: PropTypes.string.isRequired,
  labelLink: PropTypes.object,
  disabled: PropTypes.bool,
  hint: PropTypes.string,
  required: PropTypes.bool,
  state: PropTypes.string,
  className: PropTypes.string,
  radiusClass: PropTypes.oneOf(['radius-sm', 'radius-md', undefined]),
  maxLength: PropTypes.any,
};

export default LdsTextField;
