import { useEffect, useRef } from 'react';
import cn from 'classnames';
import { initScrollPadding } from './scrollPadding.js';

// JSDoc type definitions
/**
 * @typedef LdsStickyProps
 * @property {React.ReactNode} [children] - React child slot object
 * @property {object} [style] - Optional custom user-defined CSS styles for the component
 * @property {number} [top] - The top position of the sticky element
 * @property {string} [className] - Optional custom user-defined CSS class(es) for the component, will be appended to the list of any other component classes
 */
/**
 * LdsSticky component
 * @param {LdsStickyProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsSticky({
  children,
  style = {},
  top = 0,
  className,
  ...rest
}) {
  const stickyRef = useRef(null);

  useEffect(() => {
    if (!stickyRef.current) return undefined;

    // Use the imported function with the ref
    const cleanup = initScrollPadding(stickyRef.current);

    return typeof cleanup === 'function' ? cleanup : undefined;
  }, []);

  return (
    <div
      ref={stickyRef}
      className={cn(
        'lds-sticky',
        className
      )}
      style={{
        top,
        position: 'sticky',
        zIndex: 100,
        ...style,
      }}
      {...rest}
    >
      {children}
    </div>
  );
}
