/**
 * Initializes scroll padding based on a sticky element's height
 * @param {HTMLElement} stickyElement - The sticky element to base padding on
 * @returns {Function|undefined} Cleanup function to remove observers and styles
 */
export function initScrollPadding(stickyElement) {
  // Early return for non-browser environments
  if (typeof document === 'undefined' || !stickyElement) {
    return undefined;
  }

  // get the header reference
  const header = stickyElement;

  // Check browser support for :has selector once
  const hasSupport = 'CSS' in window && CSS.supports?.('selector(:has(*))');

  // Calculate extra padding based on outline styles
  let extraPadding = 0;
  try {
    // Look for an existing .lds-link element inside main
    const mainElement = document.querySelector('main');
    const linkElement = mainElement?.querySelector('.lds-link');

    if (linkElement) {
      // Get the computed styles from the existing element
      const computedStyle = getComputedStyle(linkElement);
      const outlineOffset = parseFloat(computedStyle.outlineOffset) || 0;
      const outlineWidth = parseFloat(computedStyle.outlineWidth) || 0;

      // Calculate the total extra padding
      extraPadding = Math.abs(outlineOffset) + outlineWidth;
    }
  } catch (error) {
    // eslint-disable-next-line no-console
    console.warn('Could not calculate outline padding for sticky element:', error);
  }

  // create a style node and get its stylesheet reference
  const style = document.head.appendChild(document.createElement('style'));
  const stylesheet = style.sheet;

  // function: apply scroll padding from header height
  const applyScrollPadding = () => {
    try {
      // delete any existing rule from the stylesheet
      while (stylesheet.cssRules.length) {
        stylesheet.deleteRule(0);
      }

      // get the header height, and add the extra padding for outlines
      const height = header.offsetHeight + extraPadding;

      // create a new rule for scroll padding with appropriate fallback
      if (hasSupport) {
        stylesheet.insertRule(`html:has(main *:focus) { scroll-padding-top:${height}px }`);
      } else {
        stylesheet.insertRule(`html { scroll-padding-top:${height}px }`);
      }

      // handle focused elements
      const focused = document.activeElement || document.body;
      if (focused !== document.body && !header.contains(focused)) {
        if (focused.getBoundingClientRect().top < height) {
          focused.scrollIntoView({ behavior: 'smooth' });
        }
      }
    } catch (error) {
      console.warn('Error applying scroll padding:', error);
    }
  };

  // Debounce resize events for better performance
  let debounceTimeout;
  const debouncedApplyScrollPadding = () => {
    clearTimeout(debounceTimeout);
    debounceTimeout = setTimeout(applyScrollPadding, 10);
  };

  // define a resize observer to monitor the size of the header
  const observer = new ResizeObserver(debouncedApplyScrollPadding);

  // enable resize monitor and apply scroll-padding immediately
  observer.observe(header);
  applyScrollPadding();

  // Return cleanup function
  return () => {
    clearTimeout(debounceTimeout);
    observer.disconnect();
    style.remove();
  };
}

/**
 * Auto-initializes scroll padding when the DOM is loaded
 * @param {string|HTMLElement} target - A CSS selector string or an HTMLElement for the sticky element
 * @returns {Function|undefined} Function to remove the event listener
 */
export function autoInitScrollPadding(target) {
  if (typeof window === 'undefined') return undefined;

  const handler = () => {
    const stickyElement = typeof target === 'string' ? document.querySelector(target) : target;
    if (stickyElement) {
      initScrollPadding(stickyElement);
    } else {
      console.warn('autoInitScrollPadding: Target element not found.');
    }
  };
  window.addEventListener('DOMContentLoaded', handler);

  // Return cleanup function
  return () => window.removeEventListener('DOMContentLoaded', handler);
}
