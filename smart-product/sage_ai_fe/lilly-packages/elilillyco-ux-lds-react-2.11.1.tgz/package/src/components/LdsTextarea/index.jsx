import { forwardRef, useEffect, useState } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsLink from '../LdsLink/index.jsx';
import LdsValidationMessage from '../LdsValidationMessage/index.jsx';

// JSDoc type definitions
/**
 * @typedef LdsTextareaProps
 * @property {string} id - HTML textarea element ID
 * @property {string} name - HTML textarea element name
 * @property {string} label - Text content for the form field label
 * @property {string} [ariaDescribedBy] - Value to add to the textarea element ARIA Described By attribute
 * @property {string} [counterHiddenLabel] - Value of the non-visiblee counter label text which will be used by assistive technologies
 * @property {string} [counterText] - Value of the counter element
 * @property {boolean} [disabled] - Whether the form field is in the disabled state
 * @property {string} [state] - Optional string value for the text area state: Accepts: success, warning, error.
 * @property {string} [stateMessage] - Optional state message to display below text area when state is available.
 * @property {Object} [labelLink] - Optional label link related link props to pass to the LdsLink component.
 * @property {number} [maxLength] - The maximum number of characters that can be entered into the field
 * @property {function} [onChange] - Callback function to execute when the textarea value changes
 * @property {string} [hint] - Hint text to display below the text area label
 * @property {string} [radiusClass] - Optional; set one of the border radius size classes for the component; valid values are 'radius-sm', 'radius-md', or leave undefined to use default
 * @property {string} [className] - Optional custom user-defined CSS class(es) for the table component wrapper element, will be appended to the list of any other component classes
 * @property {boolean} [required] - Property to mark the input as required. Automatically sets aria-required
 */
const LdsTextarea = forwardRef(
  /**
   * LdsTextarea component
   * @param {LdsTextareaProps & React.InputHTMLAttributes<HTMLInputElement>} props
   * @returns {React.JSX.Element} LdsTextarea component
   */
  function LdsTextarea({
    id,
    name,
    label,
    ariaDescribedBy = '',
    counterHiddenLabel,
    counterText,
    disabled = false,
    state = '',
    stateMessage,
    hint,
    labelLink,
    maxLength,
    onChange,
    radiusClass,
    className,
    required,
    error = false,
    errorMessage,
    ...rest
  }, ref) {
    const [charCount, setCharCount] = useState(0);
    const [describedBy, setDescribedBy] = useState(ariaDescribedBy);
    const hintId = `${id}-hint`;
    const stateId = `${id}-textarea-${state}`;

    // TODO: Deprecated props. Remove in future LDS version
    if (error) {
      // eslint-disable-next-line
      console.warn('ux-lds-react: LdsTextArea: The `error` prop is deprecated and will be removed in a future version. Migrate to `state` prop instead.');
    }
    if (errorMessage) {
      // eslint-disable-next-line
      console.warn('ux-lds-react: LdsTextArea: The `errorMessage` prop is deprecated and will be removed in a future version. Migrate to `stateMessage` prop instead.');
    }

    const componentState = error ? 'error' : state;
    const componentStateMessage = errorMessage || stateMessage;

    useEffect(() => {
      let descStr = ariaDescribedBy;
      if (hint) descStr += ` ${hintId}`;
      if (maxLength) {
        descStr += `${id}-char-count ${ariaDescribedBy}`;
      }
      if (componentState.length > 0 && componentStateMessage) descStr += ` ${stateId}`;
      setDescribedBy(descStr.trim());
    }, [hint, hintId, ariaDescribedBy, maxLength, componentState, componentStateMessage, stateId, id]);

    const CharacterCount = () => {
      if (!maxLength) return '';

      return (
        <>
          <span
            id={`${id}-char-count`}
            className="sr-only"
          >
            {counterHiddenLabel || `${maxLength} character limit`}
          </span>
          <span
            role="status"
            aria-live="polite"
            className={cn(
              'lds-form-character-count',
              {
                disabled: disabled,
                [`${componentState}`]: componentState,
              }
            )}
          >
            {counterText ? (charCount + '\u00A0' + counterText) : (charCount + `/${maxLength}`)}
          </span>
        </>
      );
    };

    const handleChange = (e) => {
      setCharCount(e.target.value.length);
      if (onChange) onChange(e);
    };

    return (
      <div
        className={cn(
          'lds-textarea-wrapper',
          radiusClass,
          className
        )}
      >
        <label
          htmlFor={id}
          className={cn(
            'lds-form-label',
            'lds-textarea-label',
            {
              disabled: disabled,
            }
          )}
        >
          {label}
        </label>
        {
          hint
          && <div className="lds-form-panel">
              <span
                className="lds-form-hint lds-textarea-helper-text"
                id={hintId}
              >
                {hint}
              </span>
            </div>
        }
        <textarea
          id={id}
          name={name}
          disabled={disabled}
          onChange={handleChange}
          maxLength={maxLength}
          aria-invalid={componentState === 'error' ? true : null}
          aria-describedby={describedBy}
          className={cn(
            'lds-textarea',
            {
              disabled: disabled,
              [`${componentState}`]: componentState,
            }
          )}
          required={required}
          aria-required={required ? true : null}
          {...rest}
          ref={ref}
        />
        {
          (componentState || maxLength || labelLink) && (
            <div className="lds-form-panel">
              {(componentState || labelLink) && (
                <div className="lds-form-section-start">
                  {
                    componentState.length > 0 && componentStateMessage
                    && <LdsValidationMessage id={stateId} state={componentState}>
                        {componentStateMessage}
                      </LdsValidationMessage>
                  }
                  {
                    labelLink
                    && <div className="lds-form-label-link">
                        <LdsLink {...labelLink}>{labelLink.text}</LdsLink>
                      </div>
                  }
                </div>
              )}
            <CharacterCount />
          </div>
          )
        }
      </div>
    );
  }
);

LdsTextarea.prototype = {
  id: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  label: PropTypes.string.isRequired,
  labelLink: PropTypes.object,
  disabled: PropTypes.bool,
  state: PropTypes.string,
  className: PropTypes.string,
  radiusClass: PropTypes.oneOf(['radius-sm', 'radius-md', undefined]),
  maxLength: PropTypes.any,
  required: PropTypes.bool,
};

export default LdsTextarea;
