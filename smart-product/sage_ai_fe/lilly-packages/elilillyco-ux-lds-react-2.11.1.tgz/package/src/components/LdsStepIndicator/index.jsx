import {
  useState,
  useEffect,
  useRef
} from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsIcon from '../LdsIcon/index.jsx';

// JSDoc type definitions
/**
 * @typedef LdsStepIndicatorProps
 * @property {string[]} steps - An array of labels to be used for each step. Minimum of 3 steps. Maximum of 7 steps.
 * @property {number} [activeIndex] - The initialized index position of the Step Indicator. Default is initial index i.e. 0
 * @property {string} [completeLabel] - The label text used for the "complete" state. Default is "Complete!"
 * @property {string} [stepCompleteLabel] - A screen reader only label text used to mark a completed step. Defaults to the same value as completeLabel
 * @property {string} [ofLabel] - The component's ARIA label attribute is dynamically set to a value of "Step [current_step] of [total_steps]", use this property to change the value of the substring "of"
 * @property {string} [nextLabel] - In condensed mode the component will display the next upcoming step. This label is used to set a value of "Next: [step]"
 * @property {string} [stepLabel] - The component's ARIA label attribute is dynamically set to a value of "Step [current_step] of [total_steps]", use this property to change the value of the substring "step"
 * @property {boolean} [forceCondensedMode] - The component can be forced to render in condensed by setting this property value to "true". Condensed mode is automatically determined by the width of the component by default.
 * @property {boolean} [showStepNumbers] - Component will automatically show the step number in the step label ("1. Step label 1", "2. Step label 2") vs ("Step label 1", "Step label 2"). Default is "true"
 * @property {boolean} [showNextStep] - In condensed mode will show the next upcoming step.
 */
/**
 * LdsStepIndicator component
 * @param {LdsStepIndicatorProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
function LdsStepIndicator({
  steps,
  activeIndex = 0,
  completeLabel = 'Complete!',
  stepCompleteLabel = completeLabel,
  ofLabel = 'of',
  nextLabel = 'Next',
  stepLabel = 'Step',
  forceCondensedMode = false,
  showStepNumbers = true,
  showNextStep = true,
  className,
  ...rest
}) {
  const indicatorRef = useRef(null);
  const initializedRef = useRef(false);

  // Responsive display mode state handler
  const [condensed, setCondensed] = useState(forceCondensedMode);

  const stepCount = steps.length;
  const allCompleted = activeIndex === stepCount;

  // create a text label for the current active step
  // because the "complete" state is 1 greater than possible steps we have to adjust
  const activeStepLabel = activeIndex >= stepCount ? stepCount : activeIndex + 1;

  /*
    Min and max recommended by design are 3 and 7.
    Show a warning but not forcing a hard requirement on this.
  */
  if (stepCount < 3) {
    // eslint-disable-next-line
    console.warn('ux-lds-react LdsStepIndicator: Minimum of 3 steps required');
  }

  if (stepCount > 7) {
    // eslint-disable-next-line
    console.warn('ux-lds-react LdsStepIndicator: Maximum of 7 steps required');
  }

  /**
   * CHECK WIDTH WATCHER EFFECT
   *
   * This effect initially checks the width of the component and sets the correct responsive
   * display mode.
   *
   * Using a ResizeObserver, it is watched for anytime its own width changes to see if it needs to
   * update the responsive display mode. It is necessary to do this by watching the component's
   * width for cases where the component may be in an initially hidden container which may have
   * no width. When its container's visibility state changes it may resize and need to update the
   * responsive display mode. (i.e. when used in a modal or a tab panel)
   */
  useEffect(() => {
    /* This function determines if the "large" mode can be displayed by computing the number of
     * steps times the width of the pills to get a minimum width for the current step indicator.

     * If the current width of the indicator is not wide enough to show all the steps in the
     * "large" mode it switches to the "condensed" mode.

     * This will happen as necessary
     * The condensed mode is not specifically for "mobile" display nor is the "large"
     * mode specifically for "desktop" display.
     */
    const checkWidth = () => {
      if (forceCondensedMode) {
        setCondensed(true);
      } else {
        const minPillWidth = 144; // 144px is min width of a pill in large mode
        const totalPillWidth = minPillWidth * stepCount;

        const pillPadding = 8; // 8px flex gap between pills
        const totalPadding = (stepCount - 1) * pillPadding;

        const minimumContainerWidth = totalPillWidth + totalPadding;

        if (indicatorRef.current) {
          const indicatorWidth = indicatorRef.current.getBoundingClientRect().width;
          setCondensed(minimumContainerWidth > indicatorWidth);
        }
      }
    };

    // Initialize the step indicator width, do this only once
    if (!initializedRef.current) {
      checkWidth();
      initializedRef.current = true;
    }

    // If the indicator ITSELF resizes for any reason run the width check
    const resizeObserver = new ResizeObserver(() => {
      checkWidth();
    });
    if (indicatorRef.current) {
      resizeObserver.observe(indicatorRef.current);
    }

    return () => {
      resizeObserver.disconnect();
    };
  }, [forceCondensedMode, stepCount]);

  return (
    <div
      role="region"
      ref={indicatorRef}
      className={cn(
        'lds-step-indicator',
        {
          condensed,
          'all-completed': allCompleted,
        },
        className
      )}
      aria-live="polite"
      aria-label={`${stepLabel} ${activeStepLabel} ${ofLabel} ${stepCount}`}
      {...rest}
    >
      <div className="list-wrapper">
        <div className="step-count">
          <span
            className="sr-only"
          >
            {`${stepLabel}`}
          </span>
          <span>{activeStepLabel}</span>
          <span className="of-text">{ofLabel}</span>
          <span>{stepCount}</span>
        </div>
        <ol
          className="step-list"
          role="list"
        >
          {
            steps.map((step, index) => (
              <li
                key={`step-indicator-dots-${index}`}
                className={cn(
                  'step-list-item',
                  {
                    active: index === activeIndex,
                    complete: index < activeIndex,
                  }
                )}
                aria-current={(index === activeIndex) ? `${stepLabel}` : null}
              >
                <div className="step-pill"></div>
                <span className="step-label">
                  {/* divs to create "Hanging punctuation" */}
                  {showStepNumbers && <div>{index + 1}.&nbsp;</div>}
                  <div>
                    <span
                      className="sr-only step-complete-label"
                      aria-hidden={index >= activeIndex}
                    >
                      {stepCompleteLabel}
                    </span>
                    {step}
                  </div>
                </span>

                {/* Complete label will display under last step when all steps are complete */}
                {
                  index === stepCount - 1 && allCompleted && (
                    <span className="complete-label">
                      <LdsIcon
                        name="check"
                      />
                      {completeLabel}
                    </span>
                  )
                }
              </li>
            ))
          }
        </ol>
      </div>

      {/* Show completed label in condensed mode */}
      {
        activeIndex === stepCount && (
          <div className="condensed-complete-label">
            <LdsIcon
              name="check"
            />
            {completeLabel}
          </div>
        )
      }

      {/* Show current label in condensed mode if we are not completed */}
      {
        activeIndex < stepCount && (
          <div className="condensed-label">
            {steps[activeIndex]}
          </div>
        )
      }

      {/* Show next step in condensed mode if we are not on the final step */}
      {
        showNextStep && (activeIndex < stepCount - 1) && (
          <div className="condensed-next-label">
            {nextLabel}: {steps[activeIndex + 1]}
          </div>
        )
      }
    </div>
  );
}

export default LdsStepIndicator;

LdsStepIndicator.propTypes = {
  steps: PropTypes.arrayOf(PropTypes.string).isRequired,
  completeLabel: PropTypes.string,
  ofLabel: PropTypes.string,
  nextLabel: PropTypes.string,
  forceCondensedMode: PropTypes.bool,
  showStepNumbers: PropTypes.bool,
};
