import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsIcon from '../LdsIcon/index.jsx';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsBlockquoteProps
 * @property {string|React.ReactNode} [children] - HTML content handled by the React component's `children` property
 * @property {string|React.ReactNode} [authorName] - HTML content for the author name
 * @property {string|React.ReactNode} [authorName] - HTML content for the author name
 * @property {string|React.ReactNode} [authorPhoto] - src for author photo
 * @property {string} [authorPhotoAlt] - Alt for author photo
 * @property {string} [authorPhotoPosition] - Position of author photo. top, left, or right
 * @property {string} [citeAlignment] - Alignment of cite element. align-left, align-right, or align-center
 * @property {string} [densityClass] - Density of blockquote. small, medium, or large
 * @property {boolean} [fullWidth] - Sets blockquote to full width mode. Will expand to fill its container
 * @property {string} [quoteAlignment] - Alignment of quote. align-left, align-right, or align-center
 * @property {string} [quoteIconPosition] - Position of quote icon. top or side.
 * @property {boolean} [showQuoteIcon] - Shows the quote icon
 * @property {string} [styleClass] - Style of blockquote to use. bordered left, bordered right, bordered left right, bordered-bg left, bordered-bg right, or bordered-bg left right
 * @property {string|React.ReactNode} [supplement] - Supplement text content
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 */
/**
 * LdsBlockquote component
 * @param {LdsBlockquoteProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsBlockquote component
 */
function LdsBlockquote({
  children,
  authorName = '',
  authorPhoto,
  authorPhotoAlt = '',
  authorPhotoPosition = 'top',
  citeAlignment = '',
  densityClass = 'large',
  fullWidth = false,
  quoteAlignment = '',
  quoteIconPosition = 'top',
  showQuoteIcon = false,
  styleClass = '',
  supplement = '',
  className = '',
  ...rest
}) {
  return (
    <blockquote
      className={cn(
        'lds-blockquote',
        densityClass,
        styleClass,
        {
          'full-width': fullWidth,
        },
        className
      )}
      {...rest}
    >
      <div
        className={cn(
          'blockquote-wrapper',
          {
            'side-photo': authorPhoto && ['left', 'right'].includes(authorPhotoPosition),
          }
        )}
      >
        { authorPhoto && authorPhotoPosition === 'top'
          && <img src={authorPhoto} className="author-photo" alt={authorPhotoAlt} />
        }
        { showQuoteIcon && quoteIconPosition === 'top'
          && <LdsIcon name="quotes-fill" className="quote-icon" decorative />
        }
        <div
          className={cn(
            'lds-blockquote-content',
            quoteAlignment
          )}
        >
          { authorPhoto && authorPhotoPosition === 'left'
            && <img src={authorPhoto} className="author-photo" alt={authorPhotoAlt} />
          }
          <div>
            { showQuoteIcon && quoteIconPosition === 'side'
              && <sup>
                <svg className="lds-icon quotes-fill quote-icon-inline" aria-hidden="true"></svg>
              </sup>
            }
            {children}
          </div>
          { authorPhoto && authorPhotoPosition === 'right'
            && <img src={authorPhoto} className="author-photo" alt={authorPhotoAlt} />
          }
        </div>
        <cite
          className={cn(
            citeAlignment
          )}
        >
          <strong className="lds-blockquote-author">
            {authorName}
          </strong>
          <span className="lds-blockquote-supplement">
            {supplement}
          </span>
        </cite>
      </div>
    </blockquote>
  );
}

/* eslint-disable */
LdsBlockquote.propTypes = {
  authorName: PropTypes.string.isRequired,
  authorPhotoAlt: function (props, propName, componentName) {
    if (props.authorPhoto && !props[propName]) {
      return new Error(`Invalid prop ${propName} supplied to ${componentName}. ${propName} is required when using an authorPhoto`);
    }
  },
  authorPhotoPosition: PropTypes.oneOf(['top', 'left', 'right']),
  citeAlignment: PropTypes.oneOf(['align-left', 'align-right', 'align-center']),
  densityClass: PropTypes.oneOf(['small', 'medium', 'large']),
  fullWidth: PropTypes.bool,
  quoteAlignment: PropTypes.oneOf(['align-left', 'align-right', 'align-center']),
  quoteIconPosition: PropTypes.oneOf(['top', 'side']),
  showQuoteIcon: PropTypes.bool,
  styleClass: PropTypes.oneOf([
    'bordered left',
    'bordered right',
    'bordered left right',
    'bordered-bg left',
    'bordered-bg right',
    'bordered-bg left right',
  ]),
};
/* eslint-enable */

export default LdsBlockquote;
