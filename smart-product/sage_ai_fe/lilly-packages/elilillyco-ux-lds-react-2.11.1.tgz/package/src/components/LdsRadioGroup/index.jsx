import { forwardRef, useId } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsValidationError from '../LdsValidationError/index.jsx';

// JSDoc type definitions
/**
 * @typedef LdsRadioGroupProps
 * @property {string|object} label - Required; content to display in the radio button group\'s fieldset legend element as a label; can be either a string or a React fragment (object) of inline-type only HTML or JSX markup.
 * @property {React.ReactNode} children - Required; React child slot object; must contain at least one (but typically two or more) LDS Radio Button <LdsRadio> components only
 * @property {boolean} [required] - Optional; flag the radio button group as a required field for validation; sets the aria-required attribute on the <fieldset> element
 * @property {string} [srRequiredText] - Optional; use to modify the visually hidden accessible text that will be added for screen readers to radio button group label when the field is required; the default is "(this field is required)"
 * @property {boolean} [error] - Optional; Sets the radio group to be in an error state which should be based on a custom validation method; sets aria-invalid on the radio group.
 * @property {string|object} [errorMessage] - Optional; the validation error message content to display when the radio button group is in the error state; only shows when the error prop is set to true; can be either a string or a react fragment (object) of inline-type only HTML or JSX markup.
 * @property {boolean} [indent] - Optional; indents the radio buttons underneath the group label such that they appear more like a list
 * @property {string} [densityClass] - Optional; adjusts the spacing density padding between radio buttons in the group; accepts one of: 'small' or 'medium'
 * @property {string} [className] - Optional; custom user-defined CSS class(es) for the root <fieldset> element, will be appended to the list of any other component classes
 * @property {boolean} [autoColumns] - Optional; automatically evenly distribute the radio buttons in columns to fill the width of the parent container.
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Optional, define any additional non-prop attributes to be rendered on the component's root <fieldset> element.
 */
const LdsRadioGroup = forwardRef(
  /**
  * LdsRadioGroup component
  * @param {LdsRadioGroupProps & React.InputHTMLAttributes<HTMLInputElement>} props
  * @returns {React.JSX.Element}
  */
  function LdsRadioGroup({
    label,
    children,
    required,
    // TODO for next component update:
    //  1) This prop name is obtuse; use something a little more obvious and link to the required state option e.g. requiredA11yLabel
    srRequiredText = '(this field is required)',
    error = false,
    errorMessage,
    indent = false,
    densityClass = 'small',
    className,
    autoColumns = false,
    ...rest
  }, ref) {
    const errorId = useId();

    return (
    <fieldset
      className={cn(
        'lds-radio-group',
        {
          'auto-columns': autoColumns,
          indent,
          error,
        },
        densityClass,
        className
      )}
      ref={ref}
      role="radiogroup"
      aria-required={required || null}
      aria-describedby={error && errorMessage ? errorId : null}
      aria-invalid={error || null}
      {...rest}
    >
      <legend>
        {label}
        {required && <span className="sr-only">{srRequiredText}</span>}
      </legend>
      {
        error && errorMessage
        && <LdsValidationError id={errorId}>{errorMessage}</LdsValidationError>
      }
      {children}
    </fieldset>
    );
  }
);

LdsRadioGroup.propTypes = {
  label: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.object,
  ]).isRequired,
  children: PropTypes.node.isRequired,
  required: PropTypes.bool,
  srRequiredText: PropTypes.string,
  error: PropTypes.bool,
  errorMessage: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.object,
  ]),
  indent: PropTypes.bool,
  densityClass: PropTypes.oneOf(['small', 'medium']),
  className: PropTypes.string,
  rest: PropTypes.any,
};

export default LdsRadioGroup;
