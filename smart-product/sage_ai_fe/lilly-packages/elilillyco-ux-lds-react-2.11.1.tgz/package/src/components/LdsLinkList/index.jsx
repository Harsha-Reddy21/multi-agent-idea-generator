import PropTypes from 'prop-types';
import cn from 'classnames';

// JSDoc type definitions
/**
 * @typedef LdsLinkListProps
 * @property {string} [className] - The class name of the link list.
 * @property {React.ReactNode} [children] - The children of the link list.
 * @property {boolean} [ordered] - By default the links are unordered. If ordered(numbered) links should be used instead, set this to `true`
 * @property {string} [styleClass] - Optional; Set a string value for the style classes; valid values are 'unstyled', 'bordered left', 'bordered right' and 'horizontal'.
 * @property {string} [subHeader] - The subheader of the link list.
 * @property {string} [subHeaderClassName] - The class name of the subheader.
 * @property {Object} [subHeaderProps] - The props of the subheader.
 */
/**
 * LdsLinkList component
 * @param {LdsLinkListProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
function LdsLinkList({
  className,
  children,
  ordered = false,
  styleClass = '',
  subHeader,
  subHeaderClassName,
  subHeaderProps = {},
  ...rest
}) {
  let subHeaderId;
  if (subHeader) {
    subHeaderId = `${subHeader.toLowerCase().replace(/ /g, '-')}-${Math.floor(
      Math.random() * 10000
    )}`;
  }

  const ListSubHeader = () => {
    if (!subHeader) return '';

    return (
      <li
        className={cn(
          'lds-link-list-subheader-item',
          subHeaderClassName
        )}
        {...subHeaderProps}
      >
        <span
          id={subHeaderId}
          className="lds-link-list-subheader"
        >
          {subHeader}
        </span>
      </li>
    );
  };

  if (ordered) {
    return (
      <ol
        className={cn(
          'lds-link-list',
          styleClass,
          className
        )}
        aria-describedby={subHeader ? subHeaderId : undefined}
        role="list"
        {...rest}
      >
        <ListSubHeader />
        {children}
      </ol>
    );
  }

  return (
    <ul
      className={cn(
        'lds-link-list',
        styleClass,
        className
      )}
      aria-describedby={subHeader ? subHeaderId : undefined}
      role="list"
      {...rest}
    >
      <ListSubHeader />
      {children}
    </ul>
  );
}

// JSDoc type definitions
/**
 * @typedef LdsLinkListItemProps
 * @property {string} [className] - The class name of the link list item.
 * @property {React.ReactNode} [children] - The children of the link list item.
 */
/**
 * LdsLinkList.Item component
 * @param {LdsLinkListItemProps} props
 * @returns {React.JSX.Element}
 */
LdsLinkList.Item = function LdsLinkListItem({
  className,
  children,
  ...rest
}) {
  return (
    <li
      className={cn(
        'lds-link-list-item',
        className
      )}
      {...rest}
    >
      {children}
    </li>
  );
};

// Prop Types
LdsLinkList.propTypes = {
  className: PropTypes.string,
  children: PropTypes.node,
  ordered: PropTypes.bool,
  styleClass: PropTypes.string,
  subHeader: PropTypes.string,
  subHeaderClassName: PropTypes.string,
  subHeaderProps: PropTypes.Object,
};
LdsLinkList.Item.propTypes = {
  className: PropTypes.string,
  children: PropTypes.node,
};

export default LdsLinkList;
