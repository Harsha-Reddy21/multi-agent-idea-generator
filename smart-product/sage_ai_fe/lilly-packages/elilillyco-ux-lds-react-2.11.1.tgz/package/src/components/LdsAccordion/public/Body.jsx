import PropTypes from 'prop-types';
import cn from 'classnames';
import { useEffect, useRef, useState } from 'react';

/**
 * @typedef LdsAccordionBodyProps
 * @property {string} accordionId - ID to assign to accordion. Required for accordion to work.
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {Array.<React.ReactNode>|React.ReactNode} [children] - Optional children
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Optional, define any additional non-prop attributes to be rendered on the component's root container element.
*/
/**
 * LdsAccordion.Body sub component
 * @param {LdsAccordionBodyProps} props
 * @returns {React.JSX.Element} - LdsAccordionBody component
 */
export default function Body({
  accordionId,
  className,
  children,
  ...rest
}) {
  const [transitionEnd, setTransitionEnd] = useState(false);
  const bodyRef = useRef(null);

  useEffect(() => {
    const bodyElement = bodyRef.current;

    const handleTransitionEnd = () => {
      const accordionHeader = bodyElement.previousElementSibling;
      if (!accordionHeader) return;

      const isOpen = accordionHeader.classList.contains('open');
      setTransitionEnd(isOpen);
    };

    bodyElement.addEventListener('transitionend', handleTransitionEnd);

    return () => {
      bodyElement.removeEventListener('transitionend', handleTransitionEnd);
    };
  }, []);

  return (
    <div
      id={`${accordionId}_body`}
      ref={bodyRef}
      className={cn(
        'lds-accordion-body',
        {
          'transition-end': transitionEnd,
        },
        className
      )}
      role="region"
      aria-labelledby={`${accordionId}_header`}
      {...rest}
    >
      <div className="accordion-inner-expandable">
        <div
          id={`${accordionId}_body-panel`}
          className="lds-accordion-panel"
        >
          {children}
        </div>
      </div>
    </div>
  );
}

Body.propTypes = {
  accordionId: PropTypes.string.isRequired,
  className: PropTypes.string,
  children: PropTypes.any,
  rest: PropTypes.any,
};
