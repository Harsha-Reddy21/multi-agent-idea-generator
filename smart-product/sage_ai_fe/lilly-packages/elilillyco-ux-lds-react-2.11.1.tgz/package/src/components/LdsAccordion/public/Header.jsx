import {
  useEffect,
  useState
} from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import LdsIcon from '../../LdsIcon/index.jsx';

const iconNamesSet = {
  'caret-down': 'caret-down',
  'caret-down-fill': 'caret-down-fill',
  'caret-circle-down': 'caret-circle-down',
  'caret-circle-down-fill': 'caret-circle-down-fill',
  plus: 'minus',
  'plus-circle': 'minus-circle',
  'plus-circle-fill': 'minus-circle-fill',
};

/**
 * @typedef LdsAccordionHeaderProps
 * @property {string} accordionId - ID to assign to accordion. Required for accordion to work.
 * @property {boolean} [open] - When this attribute is present, the accordion will be in the open expanded state. This attribute takes no value but acts as boolean "true" when present.
 * @property {string} iconClosedName - Valid Icon value for the icon used when accordion is close/collapse.
 * @property {string} iconClosedLabel - Label or action for the icon used when accordion is close/collapse.
 * @property {string} iconOpenLabel - Label or action text value for the icon used when accordion is open/expand.
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {Array.<React.ReactNode>|React.ReactNode} [children] - Optional children
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Optional, define any additional non-prop attributes to be rendered on the component's root container element.
*/
/**
 * LdsAccordion.Header sub component
 * @param {LdsAccordionHeaderProps} props
 * @returns {React.JSX.Element} - LdsAccordionHeader component
 */
export default function Header({
  accordionId,
  open,
  children,
  iconClosedName = 'caret-down',
  iconClosedLabel = 'expand accordion',
  iconOpenLabel = 'collapse accordion',
  className,
  ...rest
}) {
  const [iconName, setIconName] = useState(iconClosedName);
  const [isOpen, setIsOpen] = useState(open);

  useEffect(() => {
    setIsOpen(open);
  }, [open]);

  useEffect(() => {
    if (isOpen) {
      setIconName(iconNamesSet[iconClosedName]);
    } else {
      setIconName(iconClosedName);
    }
  }, [isOpen, iconClosedName]);

  return (
    <div
      id={`${accordionId}_header`}
      className={cn(
        'lds-accordion-header',
        { open: isOpen },
        className
      )}
      {...rest}
    >
      <div
        id={`${accordionId}_toggle`}
        className={'lds-accordion-toggle'}
      >
        <button
          id={`${accordionId}_toggle-button`}
          className="lds-button-clear-style toggle-btn"
          onClick={() => setIsOpen(!isOpen)}
          aria-controls={`${accordionId}_body`}
        >
        <span className="lds-accordion-header-text">
          {children}
          </span>
          <LdsIcon
            id={`${accordionId}_toggle-icon`}
            className="lds-accordion-toggle-icon"
            label={`${isOpen ? iconOpenLabel : iconClosedLabel}`}
            name={iconName}
          />
        </button>
      </div>
    </div>
  );
}

Header.propTypes = {
  accordionId: PropTypes.string.isRequired,
  children: PropTypes.any,
  open: PropTypes.bool,
  iconClosedName: PropTypes.oneOf(Object.keys(iconNamesSet)),
  iconClosedLabel: PropTypes.string,
  iconOpenLabel: PropTypes.string,
  className: PropTypes.string,
  rest: PropTypes.any,
};
