// MARK: Imports
import PropTypes from 'prop-types';
import cn from 'classnames';

/* Public Sub-Components */
import Header from './public/Header.jsx';
import Body from './public/Body.jsx';

// MARK: Component Def

// JSDoc comments to supply typescript compiler with the necessary types
/**
 * @typedef LdsAccordionProps
 * @property {string} accordionId - ID to assign to accordion. Required for accordion to work.
 * @property {Array.<React.ReactNode>|React.ReactNode} [children] - Inner child accordion content nodes, must be well-formed instances of the LdsAccordion.Header and LdsAccordion.Body sub-components.
 * @property {boolean} [open] - When this attribute is present, the accordion will be in the open expanded state. This attribute takes no value but acts as boolean "true" when present.
 * @property {string} [styleClass] - Set a string value for one of the variant component style classes; valid values are 'outlined', 'solid', 'image-background' or leave undefined for the default style
 * @property {string} [densityClass] - Optional; set one of the density size classes for the component; valid values are 'xsmall', 'small' or leave undefined for the default small density
 * @property {string} [radiusClass] - Optional; set one of the border radius size classes for the component; valid values are 'radius-sm', 'radius-md', 'radus-lg' or leave undefined to use the theme radius default
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Optional, define any additional non-prop attributes to be rendered on the component's root container element.
 */

/**
 * LdsAccordion component
 * @param {LdsAccordionProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsAccordion component
 */
function LdsAccordion({
  accordionId,
  children,
  styleClass,
  densityClass,
  radiusClass,
  className,
  ...rest
}) {
  // MARK: Component Render
  return (
    <div
      id={accordionId}
      className={cn(
        'lds-accordion',
        styleClass,
        densityClass,
        radiusClass,
        className
      )}
      {...rest}
    >
      {children}
    </div>
  );
}

// MARK: Prop Type Check
LdsAccordion.propTypes = {
  accordionId: PropTypes.string.isRequired,
  children: PropTypes.any,
  open: PropTypes.bool,
  styleClass: PropTypes.oneOf(['outlined', 'solid', undefined]),
  densityClass: PropTypes.oneOf(['xsmall', 'small', undefined]),
  radiusClass: PropTypes.oneOf(['no-radius', 'radius-xs', 'radius-sm', 'radius-md', 'radius-lg', undefined]),
  className: PropTypes.string,
  rest: PropTypes.any,
};

// MARK: Exports

/* Register Public Sub-components */
LdsAccordion.Header = Header;
LdsAccordion.Body = Body;

/* Export Component */
export default LdsAccordion;
