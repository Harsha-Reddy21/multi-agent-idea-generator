const validToggleIconsClosed = [
  'caret-down',
  'caret-down-fill',
  'caret-circle-down',
  'caret-circle-down-fill',
  'plus',
  'plus-circle',
  'plus-circle-fill',
];

const validToggleIconsOpen = [
  'minus',
  'minus-circle',
  'minus-circle-fill',
  null,
  undefined,
];

const allValidToggleIcons = validToggleIconsClosed.concat(validToggleIconsOpen);

export {
  validToggleIconsClosed,
  validToggleIconsOpen,
  allValidToggleIcons
};
