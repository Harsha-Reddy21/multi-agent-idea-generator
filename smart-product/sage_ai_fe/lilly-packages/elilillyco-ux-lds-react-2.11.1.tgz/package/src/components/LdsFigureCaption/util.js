export const validButtonIconOptions = [
  'CaretCircleUpFill',
  'CaretUp',
  'CaretUpFill',
  'MinusCircle',
  'MinusCircleFill',
  'Minus',
];

export const validButtonTextAlignmentOptions = [
  'left',
  'center',
  'right',
];

export const validContentMaxHeightOptions = [
  'small',
  'medium',
  'large',
];

export const validRadiusSizeOptions = [
  'small',
  'medium',
  'large',
];

export const isSwapIcon = (collapsedIcon) => {
  switch (collapsedIcon) {
    case 'Minus':
    case 'MinusCircle':
    case 'MinusCircleFill':
      return true;
    default:
      return false;
  }
};

export const getSwapIconName = (collapsedIcon) => {
  switch (collapsedIcon) {
    case 'Minus':
      return 'Plus';
    case 'MinusCircle':
      return 'PlusCircle';
    case 'MinusCircleFill':
      return 'PlusCircleFill';
    default:
      return collapsedIcon;
  }
};

export const getMaxHeightValue = (maxHeightOption, maxHeightOverride) => {
  // No Max Height unless explicitly set
  let maxHeightValue = 'none';

  // If a Max Height option is selected set the correct pixel value
  if (maxHeightOption) {
    switch (maxHeightOption.toLowerCase()) {
      case 'small':
        maxHeightValue = '232px';
        break;
      case 'medium':
        maxHeightValue = '472px';
        break;
      case 'large':
        maxHeightValue = '712px';
        break;
      default:
        break;
    }
  }

  // If a Max Height override value is provided
  if (maxHeightOverride && maxHeightOverride > 0) {
    // Set the user defined max height
    maxHeightValue = `${maxHeightOverride}px`;

    // However, don't allow it to be completely unusable
    if (maxHeightOverride < 32) {
      maxHeightValue = '32px';
    }
  }

  return maxHeightValue;
};
