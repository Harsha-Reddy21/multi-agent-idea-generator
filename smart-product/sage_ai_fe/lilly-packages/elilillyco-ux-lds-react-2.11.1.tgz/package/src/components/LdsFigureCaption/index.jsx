import { useState } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

// Private Sub-Components
import LdsIcon from '../LdsIcon/index.jsx';

// Component Utilities
import * as Utils from './util.js';

// Hooks and Global Utility Functions
import usePrefersReducedMotion from '../../hooks/usePrefersReducedMotion.js';
import createRipple from '../../util/createRipple.js';

// Component Utilities

// JSDoc comments to supply typescript compiler with the necessary types
/**
 * @typedef FigureCaptionProps
 * @property {string} [ariaLabel] - The ARIA label value for the HTML figure element. Must be set for accessibility compliance; if not explicitly then a default value is used
 * @property {string} [buttonIcon] - Name of icon to show when the description is collapsed. Can be `CaretCircleUpFill`, `CaretUp`, `CaretUpFill`, `MinusCircle`, `MinusCircleFill`, `Minus`
 * @property {string} [buttonId] - The ID for the button that toggles the description.
 * @property {string} [buttonTextAlign] - Button text alignment. Can be `left`, `center`, or `right`
 * @property {React.ReactNode} children - The media to display in the figure. Passed as a child of the component.
 * @property {string} [className] - Optional custom user-defined CSS class(es) for the root figure container element, will be appended to the list of any other component classes.
 * @property {string} [contentMaxHeight] - The maximum height of the description.
 * @property {number} [contentMaxHeightOverride] - Pixel height of the description
 * @property {string} [hideDescriptionText] - Text to display in the hide description button
 * @property {boolean} [initExpanded] - If true expands the figure caption by default. Only applies when noCollapse is false.
 * @property {boolean} [noCollapse] - If true, removes the button and panel to display the text directly below the figure. The text is by default centered.
 * @property {string} [radiusSize] - Size of the border radius, selected from either `small`, `medium`, or `large`
 * @property {string} [showDescriptionText] - Text to display in the show description button
 * @property {string|React.ReactNode} [textContent] - Text to show in the description. Can be any valid HTML. Accepts a string or HTML.
 */
/**
 * FigureCaption component
 * @param {FigureCaptionProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - FigureCaption component
 */
export default function FigureCaption({
  ariaLabel = 'Figure with description',
  buttonIcon = 'CaretCircleUpFill',
  buttonId,
  buttonTextAlign = 'left',
  children,
  className,
  contentMaxHeight,
  contentMaxHeightOverride,
  hideDescriptionText = 'Close description',
  initExpanded = false,
  noCollapse = false,
  radiusSize = 'medium',
  showDescriptionText = 'Open description',
  textContent,
  ...rest
}) {
  const [transcriptOpen, setTranscriptOpen] = useState(initExpanded);
  const prefersReducedMotion = usePrefersReducedMotion();

  const isSwapIcon = Utils.isSwapIcon(buttonIcon);

  const swappedIconName = Utils.getSwapIconName(buttonIcon);

  const maxHeight = Utils.getMaxHeightValue(contentMaxHeight, contentMaxHeightOverride);

  const handleClick = (event) => {
    // If the user prefers reduced motion don't create the ripple effect
    if (!prefersReducedMotion) {
      createRipple(event);
    }
    setTranscriptOpen(!transcriptOpen);
  };

  return (
    <figure
      aria-label={ariaLabel}
      className={cn(
        'lds-figure-caption',
        `radius-${radiusSize}`,
        {
          collapsed: !transcriptOpen && !noCollapse,
        },
        className
      )}
      {...rest}
    >
      {children}
      {!noCollapse
        && <button
          id={buttonId}
          type="button"
          className={cn(
            'lds-button-base',
            'lds-figure-caption-toggle',
            `align-${buttonTextAlign}`
          )}
          onClick={(e) => handleClick(e)}
        >
          {transcriptOpen ? hideDescriptionText : showDescriptionText }
          <LdsIcon
            className={cn(
              'lds-figure-caption-toggle-icon',
              {
                'icon-swap': isSwapIcon,
              }
            )}
            name={(isSwapIcon && !transcriptOpen) ? swappedIconName : buttonIcon}
            decorative
          />
        </button>
      }
      <figcaption>
        <div className="lds-figure-caption-text-wrapper">
          <div className="lds-figure-caption-text">
            <div className="lds-figure-caption-text-scroll" style={{ maxHeight: maxHeight }}>
              {textContent}
            </div>
          </div>
        </div>
      </figcaption>
    </figure>
  );
}

FigureCaption.propTypes = {
  ariaLabel: PropTypes.string,
  buttonIcon: PropTypes.PropTypes.oneOf(Utils.validButtonIconOptions),
  buttonId: PropTypes.string,
  buttonTextAlign: PropTypes.PropTypes.oneOf(Utils.validButtonTextAlignmentOptions),
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
  contentMaxHeight: PropTypes.oneOf(Utils.validContentMaxHeightOptions),
  contentMaxHeightOverride: PropTypes.number,
  hideDescriptionText: PropTypes.string,
  initExpanded: PropTypes.bool,
  noCollapse: PropTypes.bool,
  radiusSize: PropTypes.PropTypes.oneOf(Utils.validRadiusSizeOptions),
  showDescriptionText: PropTypes.string,
  textContent: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.node,
  ]).isRequired,
};
