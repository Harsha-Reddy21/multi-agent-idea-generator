import { useContext } from 'react';

import LdsChatMessageBot from '../../LdsChat/Message/Bot.jsx';
import { LdsChatModalContext } from '../LdsChatModalProvider.jsx';

function MessageBot({
  children,
  actionsLocation,
  background,
  className,
  generating,
  generatingLabel,
  generatingAnimation,
  icon,
  ref,
  shadow,
  stopped,
  ...rest
}) {
  const {
    showingLegalAlert,
  } = useContext(LdsChatModalContext);

  // If the legal alert is showing, don't render the bot message
  if (showingLegalAlert) {
    return null;
  }

  return (
    <LdsChatMessageBot
      actionsLocation={actionsLocation}
      background={background}
      className={className}
      generating={generating}
      generatingLabel={generatingLabel}
      generatingAnimation={generatingAnimation}
      icon={icon}
      ref={ref}
      shadow={shadow}
      stopped={stopped}
      {...rest}
    >
      {children}
    </LdsChatMessageBot>
  );
}

export default MessageBot;
