import { useContext } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import { LdsChatModalContext } from './LdsChatModalProvider.jsx';
import LdsPromptInput from '../LdsPromptInput/index.jsx';
import LdsButton from '../LdsButton/index.jsx';

// JSDoc type definitions
/**
 * @typedef LdsChatModalFooterProps
 * @property {function} handleSubmit - Function to handle form submission
 * @property {string} inputAriaLabel - Text to use on the ARIA label of the input field
 * @property {string} inputId - HTML id to assign to the input field
 * @property {string} inputPlaceholder - Text to use as placeholder text for the input field
 * @property {React.Ref} promptInputRef - Ref to the input field
 * @property {string} sendBtnAriaLabel - Text to use on the ARIA label of the send button
 * @property {string} stopBtnAriaLabel - Text to use on the ARIA label of the stop button
 * @property {string} textValue - Value of the chat input field
 * @property {function} setTextValue - Function to set the value of the chat input field
 */
/**
 * LdChat.Footer subcomponent
 * @param {LdsChatModalFooterProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
*/
function Footer({
  handleSubmit,
  inputAriaLabel,
  inputId,
  inputPlaceholder,
  promptInputRef,
  sendBtnAriaLabel,
  stopBtnAriaLabel,
  textValue,
  setTextValue,
}) {
  const {
    handleKeyDown,
    isBotResponding,
    showingLegalAlert,
    setIsEditing,
  } = useContext(LdsChatModalContext);

  const handleSubmitBtnClick = () => {
    setIsEditing(false);
    handleSubmit(promptInputRef);
  };

  if (showingLegalAlert) {
    return null;
  }

  return (
    <div
      className={cn(
        'footer',
        {
          'bot-responding': isBotResponding,
        }
      )}
    >
      <LdsPromptInput
        borderRadius='small'
        inputAriaLabel={inputAriaLabel}
        inputId={inputId}
        inputPlaceholder={inputPlaceholder}
        layout='dynamic'
        showDivider={false}
        // state
        textValue={textValue}
        setTextValue={setTextValue}
        // refs
        ref={promptInputRef}
        // event handlers
        onFocus={() => setIsEditing(false)}
        onKeyDown={handleKeyDown}
        onSubmit={handleSubmitBtnClick}
      >
        <LdsButton
          aria-label={isBotResponding ? stopBtnAriaLabel : sendBtnAriaLabel}
          className="send-btn pill"
          disabled={!isBotResponding && !textValue.trim()}
          icon={isBotResponding ? 'StopFill' : 'ArrowUpBold'}
          iconOnly
          onClick={handleSubmitBtnClick}
          />
      </LdsPromptInput>
    </div>
  );
}

Footer.propTypes = {
  handleSubmit: PropTypes.func.isRequired,
  inputAriaLabel: PropTypes.string,
  inputId: PropTypes.string.isRequired,
  inputPlaceholder: PropTypes.string,
  promptInputRef: PropTypes.object.isRequired,
  sendBtnAriaLabel: PropTypes.string,
  stopBtnAriaLabel: PropTypes.string,
  textValue: PropTypes.string.isRequired,
  setTextValue: PropTypes.func.isRequired,
};

export default Footer;
