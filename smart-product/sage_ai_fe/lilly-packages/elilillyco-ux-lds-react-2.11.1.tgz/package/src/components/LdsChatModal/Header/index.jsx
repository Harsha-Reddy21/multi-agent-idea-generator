import { useContext } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import { LdsChatModalContext } from '../LdsChatModalProvider.jsx';
import LdsIcon from '../../LdsIcon/index.jsx';
import LdsButton from '../../LdsButton/index.jsx';

// JSDoc type definitions
/**
 * @typedef LdsChatModalHeaderProps
 * @property {string} actionsMenuBtnAriaLabelOpened - Text to use on the ARIA label of the actions menu button when the ActionsMenu is open
 * @property {string} actionsMenuBtnAriaLabelClosed - Text to use on the ARIA label of the actions menu button when the ActionsMenu is closed
 * @property {React.ReactNode} children - The children of the Header component
 * @property {string} closeBtnAriaLabel - Text to use on the ARIA label of the close button
 * @property {React.RefObject<HTMLButtonElement>} closeBtnRef - Reference to the close button
 * @property {string} headerText - Text to use as header H2 heading
 * @property {string} [subHeaderText] - Text to use as header H3 subheading
*/
/**
 * LdChat.Header subcomponent
 * @param {LdsChatModalHeaderProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
function Header({
  children,
  actionsMenuBtnAriaLabelOpened = 'Close actions menu',
  actionsMenuBtnAriaLabelClosed = 'Open actions menu',
  closeBtnAriaLabel = 'Close chat',
  closeBtnRef,
  headerText,
  subHeaderText,
}) {
  const {
    isActionsOpen,
    setIsActionsOpen,
    setIsEndChatConfOpen,
  } = useContext(LdsChatModalContext);

  const toggleActionsMenu = () => {
    setIsActionsOpen(prevState => !prevState);
  };

  return (
    <>
      <div className="header">
        <div className="header-avatar">
          <LdsIcon
            name="robot"
            decorative
          />
        </div>
        <div className="header-text">
          <h2>{headerText}</h2>
          {subHeaderText && <h3>{subHeaderText}</h3>}
        </div>
        <div className="header-actions">
          <LdsButton
            clearDefaultClasses
            className={cn(
              'lds-button-clear-style',
              'actions-menu-btn',
              'icon',
              {
                active: isActionsOpen,
              }
            )}
            disableRipple={true}
            onClick={toggleActionsMenu}
            aria-label={isActionsOpen ? actionsMenuBtnAriaLabelOpened : actionsMenuBtnAriaLabelClosed}
            icon="DotsThreeOutlineFill"
            iconOnly
          />
          <LdsButton
            clearDefaultClasses
            className="lds-button-clear-style close-chat-btn icon"
            disableRipple={true}
            onClick={() => setIsEndChatConfOpen(true)}
            ref={closeBtnRef}
            aria-label={closeBtnAriaLabel}
            icon="X"
            iconOnly
          />
        </div>
      </div>
      {children}
    </>
  );
}

Header.propTypes = {
  actionsMenuBtnAriaLabelOpened: PropTypes.string,
  actionsMenuBtnAriaLabelClosed: PropTypes.string,
  children: PropTypes.node,
  closeBtnAriaLabel: PropTypes.string,
  closeBtnRef: PropTypes.object.isRequired,
  headerText: PropTypes.string.isRequired,
  subHeaderText: PropTypes.string,
};

export default Header;
