import { useContext } from 'react';
import cn from 'classnames';
import { LdsChatModalContext } from '../LdsChatModalProvider.jsx';

function ActionsMenu({
  children,
}) {
  const {
    isActionsOpen,
  } = useContext(LdsChatModalContext);

  return (
    <div
      className={cn(
        'drawer-wrapper',
        'actions-menu',
        {
          open: isActionsOpen,
        }
      )}
    >
      <div className="overlay"></div>
      <nav className="drawer actions-menu-options">
        <ul>
          {children}
        </ul>
      </nav>
    </div>
  );
}

export default ActionsMenu;
