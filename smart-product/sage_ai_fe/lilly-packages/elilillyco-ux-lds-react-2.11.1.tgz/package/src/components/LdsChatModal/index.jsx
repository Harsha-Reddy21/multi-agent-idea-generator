import { useState } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import { LdsChatModalProvider } from './LdsChatModalProvider.jsx';

/* subcomponents */
import Alert from './Alert.jsx';
import CitationsDrawer from './CitationsDrawer.jsx';
import EndChatConf from './EndChatConf.jsx';
import Footer from './Footer.jsx';
import Header from './Header/index.jsx';
import ActionsMenu from './Header/ActionsMenu.jsx';
import ActionsMenuItem from './Header/ActionsMenuItem.jsx';
import Message from './Messages/Message.jsx';
import MessageBot from './Messages/MessageBot.jsx';
import Messages from './Messages/index.jsx';
import Intro from './Messages/Intro.jsx';

// JSDoc type definitions
/**
 * @typedef LdsChatModalProps
 * @property {React.ReactNode} children - The children of the LdsChatModal component
 * @property {string} [className] - Optional custom user-defined CSS class(es) to add to the component root container element; will be appended to the list of any other component classes
 * @property {string} editValue - Value of the message being edited
 * @property {function} setEditValue - Function to set the value of the message being edited
 * @property {boolean} isActionsOpen - Whether the actions menu is open
 * @property {function} setIsActionsOpen - Function to set whether the actions menu is open
 * @property {boolean} isBotResponding - Whether the bot is responding
 * @property {function} setIsBotResponding - Function to set whether the bot is responding
 * @property {boolean} isEndChatConfOpen - Whether the end chat confirmation modal is open
 * @property {function} setIsEndChatConfOpen - Function to set whether the end chat confirmation modal is open
 * @property {boolean} isOpen - Whether the chat is open
 * @property {function} setIsOpen - Function to set whether the chat is open
 * @property {string} textValue - Value of the chat input field
 * @property {function} setTextValue - Function to set the value of the chat input field
 * @property {function} handleSubmit - Function to handle form submission
 */
/**
 * LdsChatModal component
 * @param {LdsChatModalProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
function LdsChatModal({
  children,
  className,
  /* state */
  isActionsOpen,
  setIsActionsOpen,
  isBotResponding,
  setIsBotResponding,
  isEndChatConfOpen,
  setIsEndChatConfOpen,
  isOpen,
  setIsOpen,
}) {
  const [isEditing, setIsEditing] = useState(false);
  const [showingLegalAlert, setShowingLegalAlert] = useState(true);

  const handleKeyDown = (e) => {
    if (isEditing) {
      if (e.key === 'Enter') {
        e.preventDefault();
        setIsEditing(false);
      } else if (e.key === 'Escape') {
        setIsEditing(false);
      }
    } else if (e.key === 'Escape') {
      setIsEndChatConfOpen(true);
    }
  };

  const handleEndChat = () => {
    setIsEndChatConfOpen(false);
    setIsOpen(false);
  };

  return (
    <LdsChatModalProvider
      /* state */
      isActionsOpen={isActionsOpen}
      setIsActionsOpen={setIsActionsOpen}
      isBotResponding={isBotResponding}
      setIsBotResponding={setIsBotResponding}
      isEditing={isEditing}
      setIsEditing={setIsEditing}
      isEndChatConfOpen={isEndChatConfOpen}
      setIsEndChatConfOpen={setIsEndChatConfOpen}
      isOpen={isOpen}
      setIsOpen={setIsOpen}
      showingLegalAlert={showingLegalAlert}
      setShowingLegalAlert={setShowingLegalAlert}
      /* event handlers */
      handleEndChat={handleEndChat}
      handleKeyDown={handleKeyDown}
    >
      <div
        className={cn(
          'lds-chat-modal',
          {
            open: isOpen,
          },
          className
        )}
      >
        {children}
      </div>
    </LdsChatModalProvider>
  );
}

LdsChatModal.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
  /* state */
  isActionsOpen: PropTypes.bool.isRequired,
  setIsActionsOpen: PropTypes.func.isRequired,
  isBotResponding: PropTypes.bool.isRequired,
  setIsBotResponding: PropTypes.func.isRequired,
  isEndChatConfOpen: PropTypes.bool.isRequired,
  setIsEndChatConfOpen: PropTypes.func.isRequired,
  isOpen: PropTypes.bool.isRequired,
  setIsOpen: PropTypes.func.isRequired,
  /* event handlers */
  handleSubmit: PropTypes.func.isRequired,
};

LdsChatModal.Header = Header;
LdsChatModal.ActionsMenu = ActionsMenu;
LdsChatModal.ActionsMenuItem = ActionsMenuItem;
LdsChatModal.Message = Message;
LdsChatModal.MessageBot = MessageBot;
LdsChatModal.Messages = Messages;
LdsChatModal.Intro = Intro;
LdsChatModal.Footer = Footer;
LdsChatModal.CitationsDrawer = CitationsDrawer;
LdsChatModal.Alert = Alert;
LdsChatModal.EndChatConf = EndChatConf;

export default LdsChatModal;
