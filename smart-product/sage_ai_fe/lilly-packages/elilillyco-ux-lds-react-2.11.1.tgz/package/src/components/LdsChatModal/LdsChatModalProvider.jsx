import {
  createContext
} from 'react';

export const LdsChatModalContext = createContext();

export function LdsChatModalProvider({
  children,
  /* state */
  isActionsOpen,
  setIsActionsOpen,
  isBotResponding,
  setIsBotResponding,
  isEditing,
  setIsEditing,
  isEndChatConfOpen,
  setIsEndChatConfOpen,
  isOpen,
  setIsOpen,
  showingLegalAlert,
  setShowingLegalAlert,
  /* event handlers */
  handleEndChat,
  handleKeyDown,
}) {
  return (
    <LdsChatModalContext.Provider
      value={{
        /* state */
        isActionsOpen,
        setIsActionsOpen,
        isBotResponding,
        setIsBotResponding,
        isEditing,
        setIsEditing,
        isEndChatConfOpen,
        setIsEndChatConfOpen,
        isOpen,
        setIsOpen,
        showingLegalAlert,
        setShowingLegalAlert,
        /* event handlers */
        handleEndChat,
        handleKeyDown,
      }}
    >
      {children}
    </LdsChatModalContext.Provider>
  );
}
