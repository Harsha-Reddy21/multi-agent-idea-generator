import { useContext } from 'react';
import PropTypes from 'prop-types';

import LdsAlert from '../LdsAlert/index.jsx';
import { LdsChatModalContext } from './LdsChatModalProvider.jsx';

/**
 * @typedef AlertProps
 * @property {React.ReactNode} children - The children of the Alert component
 * @property {boolean} [dismissible] - Whether the alert is dismissible
 * @property {string} [iconName] - Name of the icon to use in the alert
 * @property {string} [id] - ID of the alert
 * @property {boolean} [inline] - Whether the alert is inline
 * @property {'info' | 'warning' | 'error' | 'success'} [level] - Level of the alert
 */
/**
 * Alert component
 * @param {AlertProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
function Alert({
  children,
  dismissible,
  iconName,
  id,
  inline,
  level,
}) {
  const {
    setShowingLegalAlert,
  } = useContext(LdsChatModalContext);

  return (
    <div className="alert-wrapper">
      <LdsAlert
        dismissible={dismissible}
        iconName={iconName}
        id={id}
        inline={inline}
        level={level}
        onClose={() => setShowingLegalAlert(false)}
      >
        {children}
      </LdsAlert>
    </div>
  );
}

Alert.propTypes = {
  children: PropTypes.node.isRequired,
  dismissible: PropTypes.bool,
  iconName: PropTypes.string,
  id: PropTypes.string,
  inline: PropTypes.bool,
  level: PropTypes.oneOf(['info', 'warning', 'error', 'success']),
};

export default Alert;
