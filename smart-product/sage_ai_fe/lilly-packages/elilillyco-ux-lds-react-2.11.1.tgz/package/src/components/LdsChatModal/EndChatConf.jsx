import { useContext } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import { LdsChatModalContext } from './LdsChatModalProvider.jsx';
import LdsButton from '../LdsButton/index.jsx';

/**
 * @typedef EndChatConfProps
 * @property {React.ReactNode} children - The children of the EndChatConf component
 * @property {string} [closeEndChatBtnAriaLabel] - Text to use on the ARIA label of the close end chat button
 * @property {string} [cancelBtnText] - Text to use on the cancel button
 * @property {string} [confirmBtnText] - Text to use on the confirm button
 * @property {string} [endChatHeaderText] - Text to use as drawer header H2 heading
*/
/**
 * EndChatConf component
 * @param {EndChatConfProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
*/
function EndChatConf({
  children,
  closeEndChatBtnAriaLabel = 'Close end chat confirmation',
  cancelBtnText = 'No',
  confirmBtnText = 'Yes',
  endChatHeaderText = 'End chat',
}) {
  const {
    handleEndChat,
    isEndChatConfOpen,
    setIsEndChatConfOpen,
  } = useContext(LdsChatModalContext);

  return (
    <div
      className={cn(
        'drawer-wrapper',
        'end-chat-drawer',
        {
          open: isEndChatConfOpen,
        }
      )}
    >
      <div className="overlay"></div>
      <div className="drawer">
        <div className="drawer-header">
          <div className="drawer-header-text">
            <h2>{endChatHeaderText}</h2>
          </div>
          <LdsButton
            clearDefaultClasses
            className="lds-button-clear-style close-end-chat-btn icon"
            disableRipple={true}
            onClick={() => setIsEndChatConfOpen(false)}
            aria-label={closeEndChatBtnAriaLabel}
            icon="X"
            iconOnly
          />
        </div>
        <div className="end-chat-body">
          {children}
          <div className="end-chat-buttons">
            <LdsButton
              className="compact radius-sm end-chat-confirm-btn"
              onClick={handleEndChat}
            >{confirmBtnText}</LdsButton>
            <LdsButton
              className="compact radius-sm outlined end-chat-cancel-btn"
              onClick={() => setIsEndChatConfOpen(false)}
            >{cancelBtnText}</LdsButton>
          </div>
        </div>
      </div>
    </div>
  );
}

EndChatConf.propTypes = {
  children: PropTypes.node,
  closeEndChatBtnAriaLabel: PropTypes.string,
  cancelBtnText: PropTypes.string,
  confirmBtnText: PropTypes.string,
  endChatHeaderText: PropTypes.string,
};

export default EndChatConf;
