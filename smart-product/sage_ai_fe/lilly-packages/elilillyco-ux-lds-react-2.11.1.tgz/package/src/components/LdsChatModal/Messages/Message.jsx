import { useContext } from 'react';

import LdsChatMessage from '../../LdsChat/Message/Index.jsx';
import { LdsChatModalContext } from '../LdsChatModalProvider.jsx';

function Message({
  children,
  align,
  authorLabel,
  className,
  icon,
  isRead,
  isSent,
  readLabel,
  ref,
  sentLabel,
  showAvatar,
  showTimestamp,
  timestamp,
  typing,
  typingAnimation,
  typingLabel,
  metaLocation,
  userName,
  ...rest
}) {
  const {
    showingLegalAlert,
  } = useContext(LdsChatModalContext);

  // If the legal alert is showing, don't render the bot message
  if (showingLegalAlert) {
    return null;
  }

  return (
    <LdsChatMessage
      align={align}
      authorLabel={authorLabel}
      className={className}
      icon={icon}
      isRead={isRead}
      isSent={isSent}
      readLabel={readLabel}
      ref={ref}
      sentLabel={sentLabel}
      showAvatar={showAvatar}
      showTimestamp={showTimestamp}
      timestamp={timestamp}
      typing={typing}
      typingAnimation={typingAnimation}
      typingLabel={typingLabel}
      metaLocation={metaLocation}
      userName={userName}
      {...rest}
    >
      {children}
    </LdsChatMessage>
  );
}

export default Message;
