function ActionsMenuItem({
  children,
}) {
  return (
    <li>
      {children}
    </li>
  );
}

export default ActionsMenuItem;
