import { useEffect, useRef, useState } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

// JSDoc type definitions
/**
 * @typedef LdsChatModalMessagesProps
 * @property {React.ReactNode} children - The children of the Messages component
*/
/**
 * LdChat.Messages subcomponent
 * @param {LdsChatModalMessagesProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */

function Messages({
  children,
  messagesEndRef,
}) {
  const [hasScrollbar, setHasScrollbar] = useState(false);

  const messagesRef = useRef(null);

  useEffect(() => {
    // Scroll to bottom of messages container
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });

    // Check if messages container has a scrollbar
    if (messagesRef.current?.scrollHeight > messagesRef.current?.clientHeight) {
      setHasScrollbar(true);
    } else {
      setHasScrollbar(false);
    }
  }, [
    messagesRef,
    setHasScrollbar,
    messagesEndRef,
  ]);

  return (
    <div
      aria-live='polite'
      className={cn(
        'messages',
        {
          'has-scrollbar': hasScrollbar,
        }
      )}
      ref={messagesRef}
      role='log'
    >
      <div className="messages-top"></div>
        {children}
      <div ref={messagesEndRef} />
      <div className="messages-bottom"></div>
    </div>
  );
}

Messages.propTypes = {
  children: PropTypes.node,
};

export default Messages;
