import { useEffect, useState } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsButton from '../LdsButton/index.jsx';
import LdsIcon from '../LdsIcon/index.jsx';

// JSDoc type definitions
/**
 * @typedef CitationsDrawerProps
 * @property {Array<{title: string, description: string, url: string, external?: boolean}>} citations - Array of citation objects
 * @property {string} citationsHeaderText - Text to use as drawer header H2 heading
 * @property {React.Ref} citationsRef - Ref to the drawer element
 * @property {string} citationsSubHeaderText - Text to use as drawer header H3 subheading
 * @property {string} closeCitationsBtnAriaLabel - Text to use on the ARIA label of the close citations button
 * @property {string} internalDomain - The domain of the internal site
 * @property {boolean} isCitationsOpen - Whether the citations drawer is open
 * @property {function} setIsCitationsOpen - Function to set whether the citations drawer is open
*/
/**
 * CitationsDrawer component
 * @param {CitationsDrawerProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
*/
function CitationsDrawer({
  citations,
  citationsHeaderText,
  citationsRef,
  citationsSubHeaderText,
  closeCitationsBtnAriaLabel,
  internalDomain,
  isCitationsOpen,
  setIsCitationsOpen,
}) {
  const [isScrolledTop, setIsScrolledTop] = useState(true);
  const [isScrolledBottom, setIsScrolledBottom] = useState(false);

  const getDomain = (url) => {
    const domain = url.split('/')[2];
    // remove www. from the domain
    if (domain.startsWith('www.')) {
      return domain.slice(4);
    }
    return domain;
  };

  useEffect(() => {
    // watch scroll event and call the function to check if the user has scrolled to the bottom
    const element = document.querySelector('.message-citations-list');

    const handleScroll = () => {
      if (element.scrollTop === 0) {
        setIsScrolledTop(true);
        setIsScrolledBottom(false);
      } else if (element.scrollTop === element.scrollHeight - element.clientHeight) {
        setIsScrolledBottom(true);
        setIsScrolledTop(false);
      } else {
        setIsScrolledTop(false);
        setIsScrolledBottom(false);
      }
    };

    element.addEventListener('scroll', handleScroll);
  }, []);

  return (
    <div
      className={cn(
        'drawer-wrapper',
        'message-citations-drawer',
        {
          open: isCitationsOpen,
        }
      )}
      ref={citationsRef}
    >
      <div className="overlay"></div>
      <div className="drawer">
        <div className="drawer-header">
          <div className="drawer-header-text">
            <h2>{`${citationsHeaderText} (${citations.length})`}</h2>
            {citationsSubHeaderText && <h3>{citationsSubHeaderText}</h3>}
          </div>
          <LdsButton
            clearDefaultClasses
            className="lds-button-clear-style close-citations-btn icon"
            disableRipple={true}
            onClick={() => setIsCitationsOpen(false)}
            aria-label={closeCitationsBtnAriaLabel}
            icon="X"
            iconOnly
          />
        </div>
        <div
          className={cn(
            'message-citations-list',
            {
              'scrolled-top': isScrolledTop,
            },
            {
              'scrolled-bottom': isScrolledBottom,
            }
          )}
        >
          <div className="message-citations-top"></div>
          {citations.map((citation, index) => (
            <a
              href={citation.url}
              key={index}
              className="message-citation"
            >
              <h4 className="citation-domain">{getDomain(citation.url)}</h4>
              <h3 className="citation-title">
                <span>{citation.title}</span>
                {(internalDomain && getDomain(citation.url) !== internalDomain) && <LdsIcon name="ArrowSquareOut" decorative />}
              </h3>
              <p className="citation-description">{citation.description}</p>
            </a>
          ))}
          <div className="message-citations-bottom"></div>
        </div>
      </div>
    </div>
  );
}

CitationsDrawer.propTypes = {
  citations: PropTypes.arrayOf(
    PropTypes.shape({
      title: PropTypes.string.isRequired,
      description: PropTypes.string.isRequired,
      url: PropTypes.string.isRequired,
      external: PropTypes.bool,
    })
  ).isRequired,
  citationsHeaderText: PropTypes.string.isRequired,
  citationsRef: PropTypes.object.isRequired,
  citationsSubHeaderText: PropTypes.string,
  closeCitationsBtnAriaLabel: PropTypes.string.isRequired,
  internalDomain: PropTypes.string,
  isCitationsOpen: PropTypes.bool.isRequired,
  setIsCitationsOpen: PropTypes.func.isRequired,
};

export default CitationsDrawer;
