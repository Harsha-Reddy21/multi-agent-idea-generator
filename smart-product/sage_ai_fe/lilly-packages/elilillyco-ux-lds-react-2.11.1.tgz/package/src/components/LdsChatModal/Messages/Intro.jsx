import { useContext } from 'react';
import PropTypes from 'prop-types';

import { LdsChatModalContext } from '../LdsChatModalProvider.jsx';
import ChatIntro from '../../LdsChat/Intro.jsx';

// JSDoc type definitions
/**
 * @typedef LdsChatModalIntroProps
 * @property {React.ReactNode} children - The children of the Intro component
 * @property {string} [className] - Optional custom user-defined CSS class(es) to add to the component root container element; will be appended to the list of any other component classes
 * @property {string} [icon] - Icon to display in the intro
 * @property {number} startingTimestamp - The starting timestamp of the chat
 * @property {React.HTMLAttributes<HTMLDivElement>} [rest] - Additional props to be spread to the component
*/
/**
 * LdChat.Intro subcomponent
 * @param {LdsChatModalIntroProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
*/
function Intro({
  children,
  className,
  icon,
  startingTimestamp,
  ...rest
}) {
  const {
    showingLegalAlert,
  } = useContext(LdsChatModalContext);

  const readableTime = new Date(startingTimestamp).toLocaleTimeString('en-US', {
    weekday: 'short',
    month: 'short',
    day: '2-digit',
    hour: 'numeric',
    minute: 'numeric',
    hour12: true,
  });

  return (
    <ChatIntro
      className={className}
      icon={icon}
      {...rest}
    >
      {children}
      {(!showingLegalAlert && startingTimestamp) && (
        <div className="intro-timestamp">{readableTime}</div>
      )}
    </ChatIntro>
  );
}

Intro.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  icon: PropTypes.string,
  startingTimestamp: PropTypes.number,
  rest: PropTypes.object,
};

export default Intro;
