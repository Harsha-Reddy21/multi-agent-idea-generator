/* LDS Internal component. Not exported for general use */

import { useContext } from 'react';
import cn from 'classnames';

// TODO: If this component is to be used with anything other than the Header
//       Update it to include/detect/set by prop the parent component context
//       The height of this component is dependent upon variable factors
//       So it must set it's height based upon it's context
//       The current context is only mobile header menu panels
import { LdsHeaderContext } from '../LdsHeader/LdsHeaderProvider.jsx';

export default function MobileExpandPanel({
  expanded = false,
  children,
  className,
  style,
  ...rest
}) {
  const { mobileTopBarHeight } = useContext(LdsHeaderContext);

  return (
    <div
      className={cn(
        'mobile-expand-panel',
        className,
        { expanded }
      )}
      style={{ top: `${mobileTopBarHeight}px`, height: `calc(100vh - ${mobileTopBarHeight}px)`, ...style }}
      {...rest}
    >
      {children}
    </div>
  );
}
