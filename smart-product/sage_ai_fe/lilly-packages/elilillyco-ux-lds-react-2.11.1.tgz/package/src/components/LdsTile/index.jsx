import cn from 'classnames';
import PropTypes from 'prop-types';

// JSDoc type definitions
/**
 * @typedef LdsTileProps
 * @property {string} [ariaLabel] - Custom ARIA label value
 * @property {string} [styleClass] - Optional; set a string value for one of the variant component style classes; valid value is 'outlined' or leave undefined for the default style
 * @property {string} [densityClass] - Optional; set one of the density size classes for the component; valid values are 'padding-sm', 'padding-md', 'padding-lg' or leave undefined for the default density
 * @property {string} [radiusClass] - Optional; set one of the border radius size classes for the component; valid values are 'radius-sm', 'radius-md', 'radius-lg' or leave undefined to use the theme radius default
 * @property {string} [className] - Optional; custom user-defined CSS class(es) for the component, will be appended to the list of any other component classes
 * @property {string} [role] - The value of the tile's HTML role attribute
 * @property {React.ReactNode} [children] - React child slot object
 */
/**
 * LdsTile component
 * @param {LdsTileProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsTile component
 */
function LdsTile({
  ariaLabel = undefined,
  styleClass,
  densityClass,
  radiusClass,
  className,
  role = undefined,
  children,
  ...rest
}) {
  const classes = cn(
    'lds-tile',
    styleClass,
    radiusClass,
    densityClass,
    className
  );
  return (
    <div
      aria-label={ariaLabel}
      className={classes}
      role={role}
      {...rest}
    >
      {children}
    </div>
  );
}

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef TileBodyProps
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {React.ReactNode} [children] - Optional children
 */
/**
 * LdsTile.Body subcomponent
 * @param {TileBodyProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - TileBody component
 */
function Body({
  children,
  className,
  ...rest
}) {
  return (
    <div
      className={cn(
        'tile-body',
        className
      )}
      {...rest}
    >
      {children}
    </div>
  );
}
LdsTile.Body = Body;

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef TileFooterProps
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {React.ReactNode} [children] - Optional children
 */
/**
 * LdsTile.Footer subcomponent
 * @param {TileFooterProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - TileFooter component
 */
function Footer({
  children,
  className,
  ...rest
}) {
  return (
    <div
      className={cn(
        'tile-footer',
        className
      )}
      {...rest}
    >
      {children}
    </div>
  );
}
LdsTile.Footer = Footer;

export default LdsTile;

LdsTile.propTypes = {
  ariaLabel: PropTypes.string,
  styleClass: PropTypes.oneOf(['outlined', undefined]),
  densityClass: PropTypes.oneOf(['padding-sm', 'padding-md', 'padding-lg', undefined]),
  radiusClass: PropTypes.oneOf(['radius-sm', 'radius-md', 'radius-lg', undefined]),
  className: PropTypes.string,
  role: PropTypes.string,
};
