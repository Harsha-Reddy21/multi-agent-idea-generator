import { useState, useRef } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import LdsCheckbox from '../LdsCheckbox/index.jsx';

const OptionListItem = ({
  option,
  idx,
  parentRef,
  values,
  setValues,
  focusIndex,
  setFocusIndex,
}) => {
  const ref = useRef(null);
  const [tabIndex] = useState(idx === 0 ? 0 : -1);

  const changeValues = (isChecked) => {
    if (isChecked) {
      const newValues = [...values, option.value];
      setValues(newValues);
    } else {
      const newValues = values.filter((value) => value !== option.value);
      setValues(newValues);
    }
  };

  const handleChange = (e) => {
    // setIsChecked(e.currentTarget.checked);
    const isChecked = e.currentTarget.checked;
    changeValues(isChecked);
  };

  const handleBlur = (e) => {
    /*
      when focusing away from the checkbox -> onto another checkbox
      remove tabindex from this checkbox.

      If tabbing away from this checkbox -> onto something else (not a checkbox)
      we need to preserve tabindex 0 so this checkbox can be tabbed back onto with a shift tab
    */
    if (e?.relatedTarget?.matches('.lds-checkbox-option')) {
      e.target.setAttribute('tabindex', '-1');
    }

    // set the group list as tabbable again when we focus away from a checkbox
    parentRef.current.setAttribute('tabindex', '0');
  };

  const handleFocus = () => {
    // if focusing on a checkbox -> remove tabindex from the wrapper so it cant be tabbed
    parentRef.current.setAttribute('tabindex', '-1');
    // set current checkbox as tabbable
    ref.current.parentElement.parentElement.setAttribute('tabindex', '0');
  };

  const handleLiClick = () => {
    const isChecked = ref.current.checked;
    changeValues(isChecked);
  };

  const handleKeyDown = (event) => {
    // Use arrow keys to shift focus up and down on checkboxes
    // use space to click checkbox
    const isSpacebar = event.code === 'Space';
    const isUpArrow = event.code === 'ArrowUp';
    const isDownArrow = event.code === 'ArrowDown';

    if (isUpArrow || isDownArrow || isSpacebar) {
      event.preventDefault();
    }

    if (isDownArrow) {
      if (focusIndex >= parentRef.current.children.length - 1) return;
      const newIndex = focusIndex + 1;

      parentRef.current.children[newIndex].focus();
      setFocusIndex(newIndex);
    }
    if (isUpArrow) {
      if (focusIndex <= 0) return;
      const newIndex = focusIndex - 1;
      parentRef.current.children[newIndex].focus();
      setFocusIndex(newIndex);
    }

    if (isSpacebar) {
      const isChecked = ref.current.checked;
      changeValues(!isChecked);
    }
  };

  return (
    <li
      aria-live="assertive"
      aria-label={`${option.value} checkbox ${values.includes(option.value) ? 'checked' : 'unchecked'}`}
      aria-checked={() => values.includes(option.value)}
      role="option"
      tabIndex={tabIndex}
      onClick={handleLiClick}
      onKeyDown={handleKeyDown}
      onFocus={handleFocus}
      onBlur={handleBlur}
      className="lds-checkbox-option"
    >
      <LdsCheckbox
        name={option.name}
        label={option.label}
        value={option.value}
        disabled={option.disabled}
        error={option.error}
        aria-hidden="true"
        tabIndex="-1"
        ref={ref}
        {...option.inputProps}
        checked={values.includes(option.value)}
        onChange={handleChange}
      />
    </li>
  );
};

// JSDoc type definitions
/**
 * @typedef LdsScrollingCheckboxGroupProps
 * @property {Array} options - An array of options objects to create the checkboxes. Each object should contain "id", "name", and "value" properties
 * @property {Array} values - A React state object to manage the selected values
 * @property {Function} setValues - A React state function to manage the selected values
 * @property {string} [label] - Optional label text to display above the scrolling checkbox group box
 * @property {string} [labelId] - When the optional label text is used, this ID must also be set for proper accessibility functionality
 * @property {string} [className] - Optional custom user-defined CSS class(es), will be appended to the list of any other component classes on the root scrolling checkbox group wrapper DIV element
 * @property {string} [containerClassName] - Optional custom user-defined CSS class(es), will be appended to the list of any other component classes on the checkbox list UL container element
 * @property {object} [containerProps] - An additional properties object to pass generic HTML attributes onto the checkbox list UL container element
 */
/**
 * LdsScrollingCheckboxGroup component
 * @param {LdsScrollingCheckboxGroupProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsScrollingCheckboxGroup({
  options = [],
  values = [],
  setValues = () => {},
  containerProps,
  label,
  labelId,
  className,
  containerClassName,
  ...rest
}) {
  const [focusIndex, setFocusIndex] = useState(-1);
  const groupRef = useRef(null);

  const handleFocus = (event) => {
    // divert focus away from the scrollable box onto the checkboxes
    if (event.target.matches('.lds-scrolling-checkbox-group')) {
      // set tabindex -1 so the wrapper can not be focused again.
      groupRef.current.setAttribute('tabindex', '-1');

      if (focusIndex === -1) {
        groupRef.current.firstChild.focus();
        setFocusIndex(0);
      } else {
        groupRef.current.children[focusIndex].focus();
      }
    }
  };

  return (
    <div
      className={cn(
        'lds-scrolling-checkbox-group-wrapper',
        'd-inline-flex',
        'flex-column',
        className
      )}
      {...rest}
    >
      {
        label && <span className="lds-scrolling-checkbox-group-label caption d-flex justify-content-between" id={labelId}>
          {label}
        </span>
      }
      <ul
        className={cn(
          'lds-scrolling-checkbox-group',
          containerClassName
        )}
        tabIndex="0"
        aria-labelledby={labelId}
        role="listbox"
        ref={groupRef}
        onFocus={handleFocus}
        {...containerProps}
      >
        {
          options.map((option, idx) => (
            <OptionListItem
              key={idx}
              option={option}
              idx={idx}
              parentRef={groupRef}
              values={values}
              setValues={setValues}
              focusIndex={focusIndex}
              setFocusIndex={setFocusIndex}
            />
          ))
        }
      </ul>
    </div>
  );
}

LdsScrollingCheckboxGroup.propTypes = {
  options: PropTypes.arrayOf((propValue, key, componentName, propFullName) => { // eslint-disable-line
    if (!propValue[key].value) {
      return new Error(
        `Invalid prop ${propFullName} supplied to ${componentName} at index ${key}. Each option must contain a "value" property.`
      );
    }
    if (!propValue[key].label) {
      return new Error(
        `Invalid prop ${propFullName} supplied to ${componentName} at index ${key}. Each option must contain a "label" property.`
      );
    }
    if (!propValue[key].name) {
      return new Error(
        `Invalid prop ${propFullName} supplied to ${componentName} at index ${key}. Each option must contain a "name" property.`
      );
    }
  }),
  values: PropTypes.array.isRequired,
  setValues: PropTypes.any.isRequired,
};
