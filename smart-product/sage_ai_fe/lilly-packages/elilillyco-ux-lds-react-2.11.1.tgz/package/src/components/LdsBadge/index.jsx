import cn from 'classnames';
import PropTypes from 'prop-types';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsBadgeProps
 * @property {React.ReactNode} [children] - HTML content handled by the React component's `children` property
 * @property {boolean} [outlined] - Sets the outlined class on the span
 * @property {boolean} [disabled] - Sets disabled class on the span
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 */
/**
 * LdsBadge component
 * @param {LdsBadgeProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsBadge component
 */
function LdsBadge({
  children,
  outlined = false,
  disabled = false,
  className = '',
  ...rest
}) {
  return (
    <span
      className={cn(
        'lds-badge',
        {
          outlined,
          disabled,
        },
        className
      )}
      {...rest}
    >
      {children}
    </span>
  );
}

LdsBadge.propTypes = {
  outlined: PropTypes.bool,
  disabled: PropTypes.bool,
  className: PropTypes.string,
};

export default LdsBadge;
