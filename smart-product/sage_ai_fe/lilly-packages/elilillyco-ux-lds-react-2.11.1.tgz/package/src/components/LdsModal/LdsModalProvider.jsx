import { createContext, useState, useEffect } from 'react';

import { setCookie, getCookie, deleteCookie } from '../../util/cookies.js';

export const LdsModalContext = createContext();

export function LdsModalProvider({
  necessaryCookie = 'lds_cookiesAcceptedNecessary',
  functionalCookie = 'lds_cookiesAllowFunctional',
  analyticsCookie = 'lds_cookiesAllowAnalytics',
  advertisingCookie = 'lds_cookiesAllowAdvertising',
  cookieExpirationDays = 365,
  children,
}) {
  const [activeModal, setActiveModal] = useState(null);
  const [modalQueue, setModalQueue] = useState([]);
  const [showCookieModalPrefs, setShowCookieModalPrefs] = useState(false);

  /**
   * LDS Modal Provider - Open Modal Function
   * @param {string} modalID - The element ID attribute of the LDS Modal component to open
   * @param {boolean} forcePriority - Whether to prioritize the modal to the top of the open modals queue
   *
   * Opens a modal by passing in the ID attribute value of a valid LDS Modal component instance.
   * Modals are "queued" into the modalQueue array. This allows for the use case of multiple modals
   * to be open at the same time to be stacked into a logical in first-in-first-out (FIFO) order.
   *
   * If modals should be prioritized to the top of the queue (to set which one the user ineratcts
   * with first), they can be flagged on open with the forcePriority prop. If multiple modals are
   * flagged with forced priority they are stacked in a logical last-in-first-out (LIFO) order.
   */
  const openModal = (modalId, forcePriority = false) => {
    // First, check if the modal is already in the modalQueue, if so stop and do nothing
    if (modalQueue.includes(modalId)) return;

    /* IMPORTANT: to keep things straight we must filter the prevState of the modalQueue array to
     * make sure it does not already include what we are adding to it. This is because for some
     * frustrating reason prevState has the modalId in it before the actual state value has it in it.
     */
    if (forcePriority) {
      // The modal will be pushed in to the top of the queue
      // If multiple are flagged forcePriority then they are displayed LIFO
      setModalQueue(prevState => {
        const filteredPrevState = prevState.filter((id) => id !== modalId);
        return [modalId, ...filteredPrevState];
      });
    } else {
      // The modals are added to the queue and are displayed FIFO
      setModalQueue(prevState => {
        const filteredPrevState = prevState.filter((id) => id !== modalId);
        return [...filteredPrevState, modalId];
      });
    }
  };

  /**
   * LDS Modal Provider - Active Modal Effect
   *
   * This useEffect makes the first modal in the modalQueue array as the active modal only if the
   * modalQueue array has any modal ID values.
   */
  useEffect(() => {
    if (modalQueue.length && activeModal !== modalQueue[0]) {
      setActiveModal(modalQueue[0]);
    } else if (!modalQueue.length) {
      setActiveModal(null);
    }
  }, [modalQueue, activeModal]);

  /**
   * LDS Modal Provider - Close Modal Function
   *
   * Modals are "queued" into a modalQueue array. To close a modal we create an updatedQueue by
   * slicing the first item out of the modalQueue and then updating modalQueue to the new updatedQueue.
   */
  const closeModal = () => {
    const updatedQueue = modalQueue.slice(1);
    setModalQueue(updatedQueue);
  };

  /**
   * LDS Modal Provider - Set Audience Affirmation Cookie Function
   * @param {string} audienceCookieName The name of the cookie to set for audience affirmation, default is 'lds_hcp'
   * @param {number} cookieExpirationDays The number of days the cookie persists on the client; must be a value between 0 and 365.
   *
   * Audience Interstitial Utility:
   * Used to set a cookie that tracks the end-user's audience type affirmation for managing access
   * to certain kinds of content. The default use caseis the healthcare proivder/professional (HCP)
   * audience affirmation interstitial, therefore the default cookie name is `lds_hcp`. If checking
   * for a custom audience type the audienceCookieName param can be set to any custom cookie name.
   *
   * Optionally, the client persistence duration of the cookie may be configured by setting the
   * number of days from the date set it will expire. This must be an integer value between 0 and 365.
   * Setting 0 is a "session cookie" and will be deleted after the client browser application is
   * terminated. Setting 1-365 expires it in days after the date set. Certain regulatory restrictions
   * preclude storing cookies on client devices for more than 365 days (one year).
   */
  const setAudienceAffirmationCookie = (cookieName = 'lds_hcp', cookieExpirationDays = 365) => {
    let expires = cookieExpirationDays;
    if (expires < 0) {
      // eslint-disable-next-line no-console
      console.warn(`LdsModalProvider Warning: setAudienceAffirmationCookie received an invalid cookieExpirationDays parameter value of '${cookieExpirationDays}' which will be reset to '0'; please correct this warning by setting a valid prop input value between 0-365.`);
      expires = 0;
    }
    if (expires > 365) {
      // eslint-disable-next-line no-console
      console.warn(`LdsModalProvider Warning: setAudienceAffirmationCookie received an invalid cookieExpirationDays parameter value of '${cookieExpirationDays}' which will be reset to '365'; regulatory restrictions preclude storing cookies on client devices for more than one year (365 days); please correct this warning by setting a valid prop input value between 0-365.`);
      expires = 365;
    }
    setCookie(cookieName, true, expires);
    closeModal();
  };

  /**
   * LDS Modal Provider - Is Audience Affirmed Function
   * @param audienceCookieName The name of the cookie to query for audience affirmation, default is 'lds_hcp'
   *
   * Audience Interstitial Utility:
   * Used to determine if an audience affirmation cookie is set when the end-user must affirm they
   * are of a specific audience type when accessing certain kinds of content. The default use case
   * is the healthcare proivder/professional (HCP) audience affirmation interstitial, therefore the
   * default cookie name is `lds_hcp`. If checking for a custom audience type the audienceCookieName
   * param can be set to any custom cookie name.
   */
  const isAudienceAffirmed = (audienceCookieName = 'lds_hcp') => {
    const cookie = getCookie(audienceCookieName);
    return !!cookie;
  };

  /**
   * LDS Modal Provider - Accept All Cookie Consent Preference Cookies
   *
   * Cookie Consent Utility:
   * Sets the "necessary cookies" cookie; all preference cookies are set/updated to true.
   */
  const acceptAllCookies = () => {
    setCookie(necessaryCookie, 'true', cookieExpirationDays);
    setCookie(functionalCookie, 'true', cookieExpirationDays);
    setCookie(analyticsCookie, 'true', cookieExpirationDays);
    setCookie(advertisingCookie, 'true', cookieExpirationDays);
  };

  /**
   * LDS Modal Provider - Decline All Cookie Consent Preference Cookies
   *
   * Cookie Consent Utility:
   * Sets only the "necessary cookies" cookie; all preference cookies are set/updated to false.
   */
  const declineCookies = () => {
    setCookie(necessaryCookie, 'true', cookieExpirationDays);
    setCookie(functionalCookie, 'false', cookieExpirationDays);
    setCookie(analyticsCookie, 'false', cookieExpirationDays);
    setCookie(advertisingCookie, 'false', cookieExpirationDays);
  };

  /**
   * LDS Modal Provider - Reset Cookie Consent Function
   *
   * Cookie Consent Utility:
   * DELETES all end-user cookie consent preference cookies used by the cookie consent modal.
   * This effectively resets the end-user's cookie consent preference to "undefined".
   */
  const resetCookieConsent = () => {
    deleteCookie(necessaryCookie);
    deleteCookie(functionalCookie);
    deleteCookie(analyticsCookie);
    deleteCookie(advertisingCookie);
  };

  /**
   * LDS Modal Provider - Get Cookie Consent Status Function
   *
   * Cookie Consent Utility:
   * Returns the values of the cookie consent status tracking cookies, if they exist.
   */
  const getCookieConsentStatus = () => {
    return {
      necessary: getCookie(necessaryCookie),
      functional: getCookie(functionalCookie),
      analytics: getCookie(analyticsCookie),
      advertising: getCookie(advertisingCookie),
    };
  };

  /**
   * LDS Modal Provider - Save Cookie Consent Preferences Function
   * @param {boolean} functional whether the functional cookies preference should be enabled or disabled
   * @param {boolean} analytics whether the analytics cookiees preference should be enabled or disabled
   * @param {boolean} advertising whether the advertising cookies preference should be enabled or disabled
   *
   * Cookie Consent Utility:
   * Sets the "necessary cookies" cookie; the value to set on the preference cookies is defined by prop.
   */
  const saveCookieConsentPrefs = ({ functional, analytics, advertising }) => {
    setCookie(necessaryCookie, 'true', cookieExpirationDays);
    setCookie(functionalCookie, functional, cookieExpirationDays);
    setCookie(analyticsCookie, analytics, cookieExpirationDays);
    setCookie(advertisingCookie, advertising, cookieExpirationDays);
  };

  /**
   * LDS Modal Provider - Open Cookie Consent Modal Function
   * @param {string} modalID - The element ID attribute of the LDS Cookie Consent Modal component to open; the default value is 'cookieConsentModal'
   * @param {string} showPreferences - Whether to show the "manage cookie preferences" UI panel; default is 'false' which shows the default "acceptance panel" UI.
   *
   * Cookie Consent Utility:
   * Opens an LDS Cookie Consent Modal component instance by ID attribute value.
   * Also forces the stack priority of the modal to the top of the modalQueue.
   *
   * By default it will display the "acceptance panel" UI unless the showPreferences prop is set to 'true'.
   */
  const openCookieConsentModal = ({ modalId = 'cookieConsentModal', showPreferences = false }) => {
    setShowCookieModalPrefs(showPreferences);
    openModal(modalId, true);
  };

  return (
    <LdsModalContext.Provider
      value={{
        acceptAllCookies,
        activeModal,
        closeModal,
        declineCookies,
        getCookieConsentStatus,
        isAudienceAffirmed,
        modalQueue,
        openCookieConsentModal,
        openModal,
        resetCookieConsent,
        saveCookieConsentPrefs,
        setAudienceAffirmationCookie,
        setShowCookieModalPrefs,
        showCookieModalPrefs,

      }}
    >
      {children}
    </LdsModalContext.Provider>
  );
}
