import { useEffect, useRef } from 'react';
// import { createPortal } from 'react-dom';

import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsButton from '../LdsButton/index.jsx';

import getFocusableElements from '../../util/getFocusableElements.js';
import removeBodyScroll from '../../util/removeBodyScroll.js';
import resetBodyScroll from '../../util/resetBodyScroll.js';

// JSDoc type definitions
/**
 * @typedef LdsModalProps
 * @property {string} modalId - HTML id to assign to modal. Required for modal to work.
 * @property {boolean} open - Whether the modal should initially be open (displayed) on page load
 * @property {function} closeModal - Function to close the modal
 * @property {string} [ariaLabelledBy] - If not using the "heading" property pass the id of your custom heading into ariaLabelledBy
 * @property {React.ReactNode} [children] - The children of the modal
 * @property {string} [closeBtnAriaLabel] - Text to use on the ARIA label of the built-in close button of non-persistent modals
 * @property {boolean} [disableModalTabFocus] - Set this property to disable automatic focus handlers on the first and last focusable elements within the modal.
 * @property {string} [heading] - Text to use as modal H2 heading
 * @property {string} [modalSizeClass] - Pass in grid classes to change the size of the modal
 * @property {boolean} [noPadding] - Set this property to remove modal padding
 * @property {boolean} [persistent] - When true, removes the "×" close icon button and disables clicking the backdrop (anywhere off the modal) to close modal.
 * @property {string} [className] - Optional custom user-defined CSS class(es) to add to the component root container element; will be appended to the list of any other component classes
 */
/**
 * LdsModal component
 * @param {LdsModalProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
function LdsModal({
  ariaLabelledBy = '',
  children,
  closeBtnAriaLabel = 'close modal',
  disableModalTabFocus = false,
  heading,
  modalId,
  modalSizeClass = 'col-12 col-md-9',
  noPadding = false,
  open = false,
  persistent = false,
  closeModal,
  className,
  ...rest
}) {
  const modalRef = useRef(null);
  const closeBtnRef = useRef(null);

  const handleOpen = () => {
    removeBodyScroll();
    try {
      const focusableElements = getFocusableElements(modalRef.current);
      focusableElements[0].focus();
    } catch {
      // no focusable element
    }
  };

  const handleBackdropClick = (e) => {
    if (persistent) return;
    if (e.target.closest('.lds-modal-window')) return; // clicked inside modal window

    closeModal();
  };

  const handleKeyDown = (e) => {
    if (!persistent && e.code === 'Escape') {
      resetBodyScroll();
      closeModal();
    }

    const focusableElements = getFocusableElements(modalRef.current);
    const focusableLength = focusableElements.length - 1;
    const isShift = e.shiftKey;

    // Trying to shift tab away from first focusable element
    // Focus on last focusable element
    if (e.target === focusableElements[0] && isShift && e.code === 'Tab' && !disableModalTabFocus) {
      e.preventDefault();
      focusableElements[focusableLength].focus();
    }

    // Trying to tab away from last focusable element
    // Focus on first focusable element
    if (e.target === focusableElements[focusableLength] && !isShift && e.code === 'Tab' && !disableModalTabFocus) {
      e.preventDefault();
      focusableElements[0].focus();
    }
  };

  useEffect(() => {
    if (open) {
      handleOpen();
    } else {
      resetBodyScroll();
    }
  }, [open]);

  const ModalCloseIcon = () => {
    if (persistent) return '';

    return (
      <LdsButton
        clearDefaultClasses
        className="lds-button-clear-style lds-modal-close-btn focus icon"
        onClick={closeModal}
        ref={closeBtnRef}
        aria-label={closeBtnAriaLabel}
        icon="X"
        iconOnly
      />
    );
  };

  const ModalHeading = () => {
    if (!heading) return '';

    return (
      <h2 id={`${modalId}-heading`}>{heading}</h2>
    );
  };

  return (
    <div
      id={modalId}
      className={cn(
        'lds-modal',
        {
          open,
        },
        className
      )}
      onClick={handleBackdropClick}
      onKeyDown={handleKeyDown}
      ref={modalRef}
      {...rest}
    >
      <div className="wrapper">
        <div className="row justify-content-center">
          <div className={modalSizeClass}>
            <div
              role="dialog"
              aria-modal="true"
              aria-labelledby={heading ? `${modalId}-heading` : ariaLabelledBy}
              className={cn(
                'lds-modal-window',
                {
                  'no-padding': noPadding,
                }
              )}
            >
              <ModalCloseIcon />
              <div className="lds-modal-body">
                <ModalHeading />
                {children}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

LdsModal.propTypes = {
  ariaLabelledBy: PropTypes.string,
  closeBtnAriaLabel: PropTypes.string,
  disableModalTabFocus: PropTypes.bool,
  modalId: PropTypes.string.isRequired,
  heading: PropTypes.string,
  modalSizeClass: PropTypes.string,
  noPadding: PropTypes.bool,
  open: PropTypes.bool.isRequired,
  persistent: PropTypes.bool,
  closeModal: PropTypes.func.isRequired,
};

export default LdsModal;
