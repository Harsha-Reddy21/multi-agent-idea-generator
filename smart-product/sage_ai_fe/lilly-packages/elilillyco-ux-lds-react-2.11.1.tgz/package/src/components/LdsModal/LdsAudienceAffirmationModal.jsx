import { useContext, useEffect } from 'react';
import PropTypes from 'prop-types';

import LdsModal from './index.jsx';
import { LdsModalContext } from './LdsModalProvider.jsx';

// JSDoc type definitions
/**
 * @typedef LdsModalProps
 * @property {string} modalId - HTML id to assign to modal. Required for modal to work.
 * @property {React.ReactNode} [children] - The children of the modal
 * @property {string} [heading] - Text to use as modal H2 heading
 * @property {boolean} [defaultOpen] - When true, hcp modal will open upon page load
 */
/**
 * LdsModal component
 * @param {LdsAudienceAffirmationModal & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsAudienceAffirmationModal({
  defaultOpen = true,
  modalId = 'hcpModal',
  heading = '',
  cookieName = 'lds_hcp',
  children,
}) {
  const {
    openModal,
    closeModal,
    activeModal,
    isAudienceAffirmed,
  } = useContext(LdsModalContext);

  useEffect(() => {
    if (defaultOpen && defaultOpen !== 'false') {
      if (!isAudienceAffirmed(cookieName)) openModal(modalId);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modalId, defaultOpen, cookieName]);

  return (
    <LdsModal
      modalId={modalId}
      open={activeModal === modalId}
      closeModal={closeModal}
      heading={heading}
      persistent
    >
      {children}
    </LdsModal>
  );
}

LdsModal.propTypes = {
  defaultOpen: PropTypes.bool,
  modalId: PropTypes.string.isRequired,
  heading: PropTypes.string.isRequired,
};
