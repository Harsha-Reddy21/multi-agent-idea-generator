import { useState, useRef, useEffect } from 'react';

import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsIcon from '../LdsIcon/index.jsx';
import getFocusableElements from '../../util/getFocusableElements.js';
import useClickOutside from '../../hooks/useClickOutside.js';
import handleTabAway from '../../util/handleTabAway.js';

// JSDoc type definitions
/**
 * @typedef BreadcrumbDropdownProps
 * @property {Array.<Object>} dropdownItems - Array of breadcrumb objects passed as dropdown list items.
 * @property {string} [ellipsisUnicode] - optional Unicode character for ellipsis when breadcrumb in dropdown mode.
 */
/**
 * BreadcrumbDropdown component
 * @param {BreadcrumbDropdownProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */

export default function BreadcrumbDropdown({
  dropdownItems = [],
  ellipsisUnicode = '\u2026',
}) {
  const [isOpen, setIsOpen] = useState(false);

  const dropdownContentRef = useRef(null);

  const dropdownRef = useClickOutside(() => {
    if (isOpen) setIsOpen(false);
  });

  const focusFirstItem = () => {
    const focusableElements = getFocusableElements(dropdownContentRef.current);
    if (!focusableElements.length) return;

    focusableElements[0].focus();
  };

  useEffect(() => {
    if (isOpen) focusFirstItem();
  }, [isOpen]);

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  const handleKeyDown = (e) => {
    const callback = () => setIsOpen(false);
    return handleTabAway(e, dropdownRef, callback);
  };

  return (
    <div
      className={cn(
        'lds-breadcrumb-dropdown',
        {
          expanded: isOpen,
        }
      )}
      onKeyDown={handleKeyDown}
      ref={dropdownRef}
    >
      <button
        className="lds-button-clear-style lds-breadcrumb-ellipsis-button"
        type="button"
        data-toggle="dropdown"
        onClick={toggleDropdown}
      >
        <span className="lds-breadcrumb-ellipsis">{ellipsisUnicode}</span>
      </button>
      <LdsIcon className="caret-icon" decorative inline name="CaretRight"></LdsIcon>
      <div
        className="lds-breadcrumb-dropdown-content"
        ref={dropdownContentRef}
      >
        <ul>
          {dropdownItems.map((item, index) => (
            <li key={index} className={`dropdownItem-${index + 1}`}>
              <a
                className={cn(
                  'lds-breadcrumb-dropdown-content-item',
                  item.className
                )}
                aria-label={item.ariaLabel}
                href={item.href}
                tabIndex={item.tabindex}
                target={item.target}
              >
                {item.text}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

BreadcrumbDropdown.propTypes = {
  dropdownItems: PropTypes.array.isRequired,
  ellipsisUnicode: PropTypes.string,
};
