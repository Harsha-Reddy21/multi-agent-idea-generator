import {
  createRef,
  forwardRef,
  useState,
  useRef,
  useEffect
} from 'react';
import PropTypes from 'prop-types';

import LdsIcon from '../LdsIcon/index.jsx';
import BreadcrumbItem from './BreadcrumbItem.jsx';
import BreadcrumbDropdown from './BreadcrumbDropdown.jsx';

// JSDoc type definitions
/**
 * @typedef LdsBreadcrumbProps
 * @property {Array.<Object>} breadcrumbs - Array of "breadcrumb" objects
 * @property {string} [ariaLabel] - Value for `<nav>` wrapper `aria-label` property. Set to an empty string to remove.
 * @property {string} [ariaLabelledBy] - Value for `<nav>` wrapper `aria-labelledby` property
 * @property {string} [className] - optional CSS class(es) applied to the `nav` wrapper element
 * @property {string} [ellipsisUnicode] - optional Unicode character for ellipsis when breadcrumb in dropdown mode.
*/
const LdsBreadcrumb = forwardRef(
  /**
   * LdsBreadcrumb component
   * @param {LdsBreadcrumbProps & React.InputHTMLAttributes<HTMLInputElement>} props
   * @returns {React.JSX.Element} - LdsBreadcrumb component
   */
  function LdsBreadcrumb({
    breadcrumbs = [],
    ariaLabel = 'Bread crumb',
    ariaLabelledBy,
    className,
    ellipsisUnicode,
    ...rest
  }, ref) {
    const [isDropdownRequired, setIsDropdownRequired] = useState(false);
    const [dropdownList, setDropdownList] = useState([]);
    const breadcrumbRef = useRef(null);
    const breadcrumbsListRef = useRef(breadcrumbs.map(() => createRef()));

    const resetDropdown = () => {
      setIsDropdownRequired(false);
      breadcrumbsListRef?.current.forEach(el => el.current.classList.remove('d-none'));
    };

    const getBreadcrumbWidth = () => {
      let width = 0;
      breadcrumbsListRef?.current.forEach(el => {
        const listWidth = el.current.offsetWidth + (el.current.offsetWidth ? 10 : 0); // 10px for margin
        width += listWidth;
      });
      width = width + 10 + 50; // 50px for ellipsis width and 10px is margin
      return width;
    };

    useEffect(() => {
      const checkWidth = () => {
        const list = [];
        const totalWidth = breadcrumbRef.current.offsetWidth;
        let breadcrumbWidth = 0;
        resetDropdown();
        breadcrumbsListRef?.current.forEach((el, index) => {
          if (index > 0 && index < breadcrumbsListRef.current.length - 1) {
            breadcrumbWidth = getBreadcrumbWidth();
            if (breadcrumbWidth >= totalWidth) {
              const anchorItem = el.current.children[0];
              const anchorItemClasses = [... anchorItem.classList].filter(el => !el.includes('lds')).join();
              setIsDropdownRequired(true);
              list.push({
                ariaLabel: anchorItem.ariaLabel || null,
                href: anchorItem.href || null,
                tabIndex: anchorItem.tabindex || null,
                target: anchorItem.target || null,
                className: anchorItemClasses,
                text: anchorItem.text,
              });
              el.current.classList.add('d-none');
            }
          }
        });
        setDropdownList(list);
      };
      checkWidth();
      window.addEventListener('resize', checkWidth);
      return () => window.removeEventListener('resize', checkWidth);
    }, []);

    const hasCustomContent = () => {
    // if there are two items without an href, then the last is custom content and should not have the aria-current="page" attribute
      let numNoHrefs = 0;
      for (let i = 0; i < breadcrumbs.length; i += 1) {
        if (!breadcrumbs[i].href) {
          numNoHrefs += 1;
        }
      }
      return numNoHrefs > 1;
    };

    return (
      <div className='lds-breadcrumb-container'>
        <nav
          aria-label={ariaLabel === '' ? null : ariaLabel}
          aria-labelledby={ariaLabelledBy === '' ? null : ariaLabelledBy}
          className={className}
          ref={ref}
          {...rest}
        >
          <ol
            className="lds-breadcrumbs"
            ref={breadcrumbRef}
            role="list"
          >
            {breadcrumbs.map((result, idx) => (
              <>
                {idx === 1 && isDropdownRequired && (
                  <li>
                    <BreadcrumbDropdown
                      dropdownItems={dropdownList}
                      ellipsisUnicode={ellipsisUnicode}
                    ></BreadcrumbDropdown>
                  </li>
                )}
                <li
                  key={idx}
                  ref={breadcrumbsListRef.current[idx]}
                >
                  <BreadcrumbItem
                    isCurrentPage={(idx + 1 === breadcrumbs.length && !hasCustomContent()) || (idx + 2 === breadcrumbs.length && hasCustomContent())}
                    {...result}
                  />
                  {/* Add icon if it's not the last item */}
                  {idx + 1 < breadcrumbs.length && (
                    <LdsIcon
                      id={`crumb-icon-${idx}`}
                      className="caret-icon"
                      decorative
                      inline
                      name="CaretRight"
                    ></LdsIcon>
                  )}
                </li>
              </>
            ))}
          </ol>
        </nav>
      </div>
    );
  }
);

LdsBreadcrumb.propTypes = {
  breadcrumbs: PropTypes.arrayOf((propValue, key, componentName, propFullName) => { // eslint-disable-line
    if (!propValue[key].text) {
      return new Error(
        `Invalid prop ${propFullName} supplied to ${componentName} at index ${key}. Each Breadcrumb link object must contain a "text" property.`
      );
    }
    if (!propValue[key].href) {
      return new Error(
        `Invalid prop ${propFullName} supplied to ${componentName} at index ${key}. Each Breadcrumb link object must contain a "href" property.`
      );
    }
  }).isRequired,
  ariaLabel: PropTypes.string,
  ariaLabelledBy: PropTypes.string,
  className: PropTypes.string,
  ellipsisUnicode: PropTypes.string,
};

export default LdsBreadcrumb;
