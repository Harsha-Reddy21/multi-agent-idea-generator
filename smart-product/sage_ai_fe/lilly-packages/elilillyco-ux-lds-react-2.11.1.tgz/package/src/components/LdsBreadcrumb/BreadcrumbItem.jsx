import cn from 'classnames';
import PropTypes from 'prop-types';
import LdsLink from '../LdsLink/index.jsx';

export default function BreadcrumbItem({
  ariaLabel,
  className,
  clearDefaultClasses,
  href,
  isCurrentPage,
  text,
  ...rest
}) {
  return (
    <LdsLink
      aria-current={isCurrentPage ? 'page' : null}
      ariaLabel={isCurrentPage ? null : ariaLabel}
      disableAutoAriaLabel={isCurrentPage}
      className={cn(
        {
          'lds-breadcrumb': !clearDefaultClasses,
        },
        className
      )}
      clearDefaultClasses={clearDefaultClasses}
      href={href}
      {...rest}
    >
      {text}
    </LdsLink>
  );
}

BreadcrumbItem.propTypes = {
  ariaLabel: PropTypes.string,
  className: PropTypes.string,
  clearDefaultClasses: PropTypes.bool,
  href: PropTypes.string.isRequired,
  isCurrentPage: PropTypes.bool,
  text: PropTypes.node.isRequired,
};
