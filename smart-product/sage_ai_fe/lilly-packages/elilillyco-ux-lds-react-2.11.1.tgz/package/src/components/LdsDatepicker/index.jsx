import { useState, forwardRef } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import Calendar from './Calendar.jsx';
import DateInput from './DateInput.jsx';
import { en } from './datepicker.translation.js';
import {
  validateTranslation,
  validateDateFormat,
  zeroPrefix
} from './datepicker.helpers.js';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsDatepickerProps
 * @property {string} id - Unique identifier for the datepicker
 * @property {string} [dateFormat] - Format dates should be displayed in
 * @property {string} [defaultValue] - Initial value for the date picker
 * @property {string} [yearInputType] - Option to show input or dropdown for the year. Valid options are 'input' or 'select'
 * @property {string} [openCalendarBtnClass] - Class to apply to the button that opens the calendar. Valid options are 'primary' or 'ghost'
 * @property {boolean} [disableCalendar] - Hides the calendar
 * @property {string[]} [disabledDates] - An array of dates to disable. Dates must be a string in format YYYY-MM-DD
 * @property {boolean} [disableWeekends] - Disables weekends
 * @property {boolean} [error] - Sets error styling for the date picker input
 * @property {string} [focusDay] - Day to focus on when calendar is opened initially. Must be in format YYYY-MM-DD. Defaults to current date if not set.
 * @property {string} [hint] - Hint to display above the input. Typically used to show format.
 * @property {string} [label] - Label to display above the input.
 * @property {string} [max] - Maximum date that can be selected. Must be in format YYYY-MM-DD.
 * @property {string} [min] - Minimum date that can be selected. Must be in format YYYY-MM-DD.
 * @property {function} [onChange] - Function that is called when date value changes
 * @property {Object} [translation] - Object used to translate text in the datepicker
 * @property {string} [startOfWeek] - Day to show as start of the week in the calendar
 * @property {string} [className] - Optional custom user-defined CSS class(es) for the date picker root container element, will be appended to the list of any other component classes
 */
const LdsDatepicker = forwardRef(
  /**
   * LdsDatepicker component
   * @param {LdsDatepickerProps & React.InputHTMLAttributes<HTMLInputElement>} props
   * @returns {React.JSX.Element} - LdsDatepicker component
   */
  function LdsDatepicker({
    className,
    dateFormat = 'MM/DD/YYYY',
    defaultValue = '',
    disableCalendar = false,
    disabledDates = [],
    disableWeekends = false,
    focusDay,
    hint = '',
    id,
    label = '',
    max,
    min,
    onChange = () => {},
    openCalendarBtnClass = 'primary',
    startOfWeek = 'sunday',
    translation = en,
    yearInputType = 'input',
    error,
    ...rest
  }, ref) {
  /*
    This component was built fully custom due to a lack of accessible date picker options
    After an a11y review of <input type="date" /> and other library date pickers such as mui or wc-datepicker got close
    but did not meet all a11y requirements
  */
    const [dateValue, setDateValue] = useState(defaultValue);
    const [isCalendarOpen, setIsCalendarOpen] = useState(false);

    const handleChangeFromCalendar = (year, month, day) => {
      let newValue = '';
      const prefixDay = zeroPrefix(day);
      const prefixMonth = zeroPrefix(month);
      if (dateFormat === 'MM/DD/YYYY') {
        newValue = `${prefixMonth}/${prefixDay}/${year}`;
      } else if (dateFormat === 'DD/MM/YYYY') {
        newValue = `${prefixDay}/${prefixMonth}/${year}`;
      } else if (dateFormat === 'YYYY-MM-DD') {
        newValue = `${year}-${prefixMonth}-${prefixDay}`;
      }

      setDateValue(newValue);
      onChange(newValue);
    };

    return (
    <div
      className={cn(
        'lds-datepicker-wrapper',
        className
      )}
      {...rest}
    >
      <DateInput
        dateFormat={dateFormat}
        dateValue={dateValue}
        disableCalendar={disableCalendar}
        hint={hint}
        id={id}
        isCalendarOpen={isCalendarOpen}
        label={label}
        onChange={onChange}
        openCalendarBtnClass={openCalendarBtnClass}
        ref={ref}
        setDateValue={setDateValue}
        setIsCalendarOpen={setIsCalendarOpen}
        translation={translation}
        error={error}
      />
      <Calendar
        dateFormat={dateFormat}
        dateValue={dateValue}
        disabledDates={disabledDates}
        disableWeekends={disableWeekends}
        focusDay={focusDay}
        id={id}
        isCalendarOpen={isCalendarOpen}
        max={max}
        min={min}
        onChange={handleChangeFromCalendar}
        setIsCalendarOpen={setIsCalendarOpen}
        startOfWeek={startOfWeek}
        translation={translation}
        yearInputType={yearInputType}
      />
    </div>
    );
  }
);

LdsDatepicker.propTypes = {
  id: PropTypes.string.isRequired,
  dateFormat: PropTypes.oneOf(['MM/DD/YYYY', 'DD/MM/YYYY', 'YYYY-MM-DD']),
  translation: (props, propName, componentName) => validateTranslation(props[propName], componentName),
  min: (props, propName, componentName) => props[propName] && validateDateFormat(props, propName, componentName, '', 'min'),
  max: (props, propName, componentName) => props[propName] && validateDateFormat(props, propName, componentName, '', 'max'),
  disabledDates: PropTypes.arrayOf(validateDateFormat),
  focusDay: (props, propName, componentName) => props[propName] && validateDateFormat(props, propName, componentName, '', 'focusDay'),
  startOfWeek: PropTypes.oneOf(['sunday', 'monday', 'saturday']),
  yearInputType: PropTypes.oneOf(['input', 'select']),
  openCalendarBtnClass: PropTypes.oneOf(['primary', 'ghost']),
  error: PropTypes.bool,
};

export default LdsDatepicker;
