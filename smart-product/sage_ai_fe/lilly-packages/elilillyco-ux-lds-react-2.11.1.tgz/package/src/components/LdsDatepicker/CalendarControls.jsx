import { useState, useEffect } from 'react';

import OptionSelector from './OptionSelector.jsx';

import {
  getMonthOptions,
  subtractDays
} from './datepicker.helpers.js';

export default function CalendarControls({
  id,
  max,
  min,
  selectedMonth,
  selectedYear,
  setSelectedMonth,
  setSelectedYear,
  translation,
  yearInputType,
}) {
  const monthOptions = getMonthOptions(translation);
  const [yearOptions, setYearOptions] = useState([{ label: selectedYear, value: selectedYear }]);

  // Generate year options based on year range if using yearInputType === 'select'
  useEffect(() => {
    const years = [];

    let yearRangeEnd = new Date().getUTCFullYear();

    if (max) yearRangeEnd = subtractDays(new Date(max), 1).getUTCFullYear();

    let yearRangeStart = yearRangeEnd - 100;
    if (min) yearRangeStart = new Date(min).getUTCFullYear();

    for (let i = yearRangeEnd; i >= yearRangeStart; i -= 1) {
      years.push({ label: i, value: i });
    }

    setYearOptions(years);
  }, [min, max]);

  const handleYearInputChange = (e) => {
    const value = e.target.value;
    if (value.length <= 4) {
      setSelectedYear(value);
    }
  };

  const handleCalendarKeyDown = (e) => {
    const isNumber = isFinite(e.key);
    const isBackspace = e.key === 'Backspace';
    const isArrowKey = e.key.includes('Arrow');
    const isDeleteKey = e.key === 'Delete';
    const isTabKey = e.key === 'Tab';
    if (
      !isNumber
      && !isBackspace
      && !isArrowKey
      && !isDeleteKey
      && !isTabKey
    ) e.preventDefault();
  };

  return (
    <div
      className="date-selection"
    >
      <div className="calendar-control-wrapper">
        <OptionSelector
          value={selectedMonth}
          onChange={(value) => setSelectedMonth(value)}
          options={monthOptions}
          ariaLabel={translation.selectMonthDropdownAriaLabel}
        />
      </div>
      <div className="calendar-control-wrapper">
        {
          yearInputType === 'input'
          && <input
            id={`${id}-calendarYear`}
            name="calendarYear"
            className="date-input year"
            type="text"
            inputMode="numeric"
            pattern="[0-9]*"
            value={selectedYear}
            onChange={handleYearInputChange}
            maxLength="4"
            minLength="4"
            aria-label={translation.inputYearAriaLabel}
            onKeyDown={handleCalendarKeyDown}
          />
        }

        {
          yearInputType === 'select'
          && <OptionSelector
            value={selectedYear}
            onChange={(value) => setSelectedYear(value)}
            options={yearOptions}
            ariaLabel={translation.inputYearAriaLabel}
          />
        }
      </div>
    </div>
  );
}
