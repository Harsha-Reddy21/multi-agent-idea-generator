import { forwardRef } from 'react';
import cn from 'classnames';

import LdsButton from '../LdsButton/index.jsx';
import { getPlaceholder } from './datepicker.helpers.js';

export default forwardRef(function DateInput({
  dateFormat,
  dateValue,
  disableCalendar,
  error,
  hint,
  id,
  isCalendarOpen,
  label,
  onChange,
  openCalendarBtnClass,
  setDateValue,
  setIsCalendarOpen,
  translation,
}, ref) {
  const placeholder = getPlaceholder(dateFormat);

  const handleInputTextChange = (e) => {
    let newValue = e.target.value;
    const separator = dateFormat === 'YYYY-MM-DD' ? '-' : '/';

    // Automatically add a slash if we are at the corresponding part of the string and they add another number
    const dateParts = dateFormat.split(separator);
    const shouldAddFirstSlash = newValue.length === dateParts[0].length + 1;
    const shouldAddSecondSlash = newValue.length === dateParts[0].length + dateParts[1].length + 2;
    const lastCharacter = newValue.slice(-1);
    const isLastSlash = lastCharacter === separator;
    if (
      (shouldAddFirstSlash || shouldAddSecondSlash)
      && !isLastSlash
    ) {
      newValue = dateValue + separator + lastCharacter;
    }

    setDateValue(newValue);
    onChange(newValue);
  };

  const handleInputTextKeyDown = (e) => {
    const separator = dateFormat === 'YYYY-MM-DD' ? '-' : '/';

    // Restricting input to only allow numbers and the separator
    // otherwise component declared "unusable"
    const allowedKeys = [];
    allowedKeys.push(separator);
    allowedKeys.push('Backspace');
    allowedKeys.push('Delete');
    allowedKeys.push('ArrowLeft');
    allowedKeys.push('ArrowRight');
    allowedKeys.push('Tab');
    allowedKeys.push('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');

    if (!allowedKeys.includes(e.key)) {
      e.preventDefault();
    }

    // Do not allow separator to be typed when not appropriate
    const dateParts = dateFormat.split(separator);
    const isFirstSlash = dateValue.length === dateParts[0].length;
    const isSecondSlash = dateValue.length === dateParts[0].length + dateParts[1].length + 1;
    if (e.key === separator && !isFirstSlash && !isSecondSlash) {
      e.preventDefault();
    }
  };

  return (
    <div>
      <label
        htmlFor={id}
        className="lds-form-label">
        {label}
        <span
          className="lds-form-hint"
        >
          {hint}
        </span>
      </label>
      <div className="lds-datepicker-input-wrapper">
        <input
          id={id}
          className={cn(
            'lds-text-field',
            'lds-date-picker-input',
            {
              'has-calendar': !disableCalendar,
              error,
            }
          )}
          type="text"
          inputMode="numeric"
          placeholder={placeholder}
          value={dateValue}
          maxLength={10}
          onKeyDown={handleInputTextKeyDown}
          onChange={handleInputTextChange}
          aria-invalid={!!error || null}
          ref={ref}
        />
        {
          !disableCalendar
          && <LdsButton
            onClick={() => setIsCalendarOpen(!isCalendarOpen)}
            icon={isCalendarOpen ? 'calendar-blank-fill' : 'calendar-blank'}
            aria-label={translation.calendarBtnAria}
            iconOnly
            className={cn(
              'calendar-btn',
              openCalendarBtnClass,
              {
                'calendar-open': isCalendarOpen,
              }
            )}
          ></LdsButton>
        }
      </div>
    </div>
  );
});
