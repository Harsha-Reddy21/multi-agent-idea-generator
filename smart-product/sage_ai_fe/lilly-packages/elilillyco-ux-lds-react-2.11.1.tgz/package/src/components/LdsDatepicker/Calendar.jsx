import { useState, useEffect, useRef } from 'react';
import cn from 'classnames';

import {
  getNumberOfDaysInMonth,
  getMonthDays,
  addDays,
  isValidDate,
  getYearMonthDay,
  getMonthOptions,
  getDateTime,
  subtractDays
} from './datepicker.helpers.js';
import TableHead from './TableHead.jsx';
import CalendarControls from './CalendarControls.jsx';
import LdsIcon from '../LdsIcon/index.jsx';
import LdsButton from '../LdsButton/index.jsx';

import useClickOutside from '../../hooks/useClickOutside.js';
import handleTabAway from '../../util/handleTabAway.js';
import isRTL from '../../util/isRTL.js';

/* IT IS IMPORTANT to remember that months are 0 indexed */

export default function Calendar({
  dateFormat,
  dateValue,
  disabledDates,
  disableWeekends,
  focusDay,
  id,
  isCalendarOpen,
  max,
  min,
  onChange,
  setIsCalendarOpen,
  startOfWeek,
  translation,
  yearInputType,
}) {
  const calendarRef = useRef(null);
  const today = new Date();
  const [selectedYear, setSelectedYear] = useState(
    max ? new Date(max).getUTCFullYear() : today.getUTCFullYear()
  );
  const [selectedMonth, setSelectedMonth] = useState(today.getMonth());
  const [selectedDay, setSelectedDay] = useState(today.getDay());

  const [weeksInMonth, setWeeksInMonth] = useState([]);
  const [focusedCalendarButton, setFocusedCalendarButton] = useState(null);
  const [tableTabIndex, setTableTabIndex] = useState(-1);
  const monthOptions = getMonthOptions(translation);
  const isRtl = isRTL(calendarRef);

  // Close calendar if you click outside of it
  useEffect(() => {
    const handleClickOutsideCalendar = (e) => {
      if (!calendarRef?.current.contains(e.target)) {
        setIsCalendarOpen(false);
      }
    };
    document.addEventListener('click', handleClickOutsideCalendar, true);
    return () => {
      document.removeEventListener('click', handleClickOutsideCalendar, true);
    };
  }, [calendarRef, setIsCalendarOpen]);

  /* Set the initial date of the calendar
    This will either be the day currently typed in the input - or will default to today
  */
  useEffect(() => {
    let calendarDate;

    try {
      if (dateValue && dateValue.length >= 8) {
        // Date value is typed in the input
        const { year, month, day } = getYearMonthDay(dateValue, dateFormat);
        const monthIndex = parseInt(month, 10) - 1;
        calendarDate = new Date(year, monthIndex, day);
      } else if (!dateValue && focusDay && focusDay.length >= 8) {
        // focusDay is a prop passed in
        const { year, month, day } = getYearMonthDay(focusDay, 'YYYY-MM-DD');
        const monthIndex = parseInt(month, 10) - 1;
        calendarDate = new Date(year, monthIndex, day);
      } else if (max && !dateValue && !focusDay) {
        // max date is specified so we default to that if it is before todays date

        const { year, month, day } = getYearMonthDay(max, 'YYYY-MM-DD');
        const monthIndex = parseInt(month, 10) - 1;
        const maxDate = new Date(year, monthIndex, day);

        const maxMinusOne = subtractDays(maxDate, 1);
        const maxTime = getDateTime(maxMinusOne);
        const today = getDateTime(new Date());

        if (maxTime <= today) {
          calendarDate = new Date(maxMinusOne);
        } else {
          calendarDate = new Date();
        }
      } else {
        calendarDate = new Date();
      }

      if (!isValidDate(calendarDate)) throw new Error('Invalid date');

      const month = calendarDate.getMonth();
      const year = calendarDate.getFullYear();
      const day = calendarDate.getDate();
      setSelectedMonth(month);
      setSelectedYear(year);
      setSelectedDay(day);
      setFocusedCalendarButton(`${year}-${month}-${day}`);
    } catch (e) {
      // eslint-disable-next-line
      console.error(`LdsDatepicker - error parsing date ${calendarDate}`);
    }
  }, [dateFormat, dateValue, focusDay, max]);

  // Focus on the startDate
  useEffect(() => {
    if (focusedCalendarButton && isCalendarOpen) {
      // specific focus day is set - focus it
      const dayBtn = calendarRef.current.querySelector(`[data-date="${focusedCalendarButton}"]`);
      if (dayBtn) dayBtn.focus();
    } else if ((focusedCalendarButton === 0) && isCalendarOpen) {
      // Will be 0 on initial open of calendar - focus on a day
      setFocusedCalendarButton(`${selectedYear}-${selectedMonth}-${selectedDay}`);
    }
  }, [focusedCalendarButton, isCalendarOpen, selectedDay, selectedMonth, selectedYear]);

  useEffect(() => {
    if (isCalendarOpen) {
      // set to 0 to indicate that this is the initial opening of the calendar and a day should be focused
      setFocusedCalendarButton(0);
    } else {
      setFocusedCalendarButton(null);
    }
  }, [isCalendarOpen]);

  useEffect(() => {
    // Get all days for the month and break them into chunks of 7 day weeks
    // We have to use a table for a11y purposes so this makes it a little easier to build the rows
    const monthDays = getMonthDays({
      month: selectedMonth,
      year: selectedYear,
      disableWeekends,
      disabledDates,
      min,
      max,
      startOfWeek,
    });
    const weeks = [];
    monthDays.forEach((day, index) => {
      const chunkIndex = Math.floor(index / 7);

      if (!weeks[chunkIndex]) {
        weeks[chunkIndex] = [];
      }

      weeks[chunkIndex].push(day);
    });
    setWeeksInMonth(weeks);
  }, [selectedMonth, selectedYear, disableWeekends, disabledDates, min, max, startOfWeek]);

  useEffect(() => {
    /* We have to adjust the tab index of the table in order to preserve arrow key functionality.
      If at any point a focused date is cleared, allow the table to be tabbed to.
      When the table is focused - it will redirect focus to the first day button
    */
    if (focusedCalendarButton) {
      setTableTabIndex(-1);
    } else {
      setTableTabIndex(0);
    }
    const dayBtn = calendarRef.current.querySelector(`[data-date="${focusedCalendarButton}"]`);
    if (dayBtn) dayBtn.focus();
  }, [focusedCalendarButton, weeksInMonth]);

  const handleMonthForward = () => {
    let month = selectedMonth;
    let year = selectedYear;

    if (selectedMonth < 11) {
      month += 1;
      setSelectedMonth(month);
    } else {
      month = 0;
      year += 1;
      setSelectedMonth(month); // january
      setSelectedYear(year);
    }
    const newDateString = `${year}-${month}-${1}`;
    setFocusedCalendarButton(newDateString);
  };
  const handleMonthBack = () => {
    let month = selectedMonth;
    let year = selectedYear;
    if (selectedMonth > 0) {
      month -= 1;
      setSelectedMonth(month);
    } else {
      month = 11;
      year -= 1;
      setSelectedMonth(month); // december
      setSelectedYear(year);
    }
    const newDateString = `${year}-${month}-${1}`;
    setFocusedCalendarButton(newDateString);
  };

  const handleDayKeyDown = (e, day) => {
    // use arrow keys to navigate the calendar.
    // Go to Next day in the direction of arrow
    // If the next day is not in this month, go to the next month
    const arrowKeyNavigate = (currentDay, daysToAdd) => {
      e.preventDefault(); // To avoid scroll on key up/down
      const nextDay = addDays(currentDay, daysToAdd);

      const newDay = nextDay.getDate();
      const newYear = nextDay.getFullYear();
      const newMonth = nextDay.getMonth();

      if (newMonth !== selectedMonth) {
        setSelectedMonth(newMonth);
      }
      if (newYear !== selectedYear) {
        setSelectedYear(newYear);
      }
      // find the newly selected date and focus it
      const newDateString = `${newYear}-${newMonth}-${newDay}`;
      // Check to see if the next date is disabled. If it is - go to the next one in sequence
      const dayBtn = calendarRef.current.querySelector(`[data-date="${newDateString}"]`);
      if (dayBtn && dayBtn.hasAttribute('disabled')) {
        arrowKeyNavigate(nextDay, daysToAdd);
      } else {
        setFocusedCalendarButton(newDateString);
      }
    };

    // tabbing away from days
    if (e.key === 'Tab') {
      setFocusedCalendarButton(null);
    } else if (e.key === 'ArrowLeft') {
      arrowKeyNavigate(day.date, isRtl ? 1 : -1);
    } else if (e.key === 'ArrowRight') {
      arrowKeyNavigate(day.date, isRtl ? -1 : 1);
    } else if (e.key === 'ArrowUp') {
      arrowKeyNavigate(day.date, -7);
    } else if (e.key === 'ArrowDown') {
      arrowKeyNavigate(day.date, 7);
    }
  };

  const handleCalendarKeyDown = (e) => {
    /* Page Up/Page Down keys should move focus between months.
      Home and End keys should move focus to the first and last date of the month.
    */

    if (e.key === 'Home') {
      const newDateString = `${selectedYear}-${selectedMonth}-${1}`;
      setFocusedCalendarButton(newDateString);
    } else if (e.key === 'End') {
      const lastDay = getNumberOfDaysInMonth(selectedMonth, selectedYear);
      const newDateString = `${selectedYear}-${selectedMonth}-${lastDay}`;
      setFocusedCalendarButton(newDateString);
    } else if (e.key === 'PageUp') {
      handleMonthBack();
    } else if (e.key === 'PageDown') {
      handleMonthForward();
    } else if (e.key === 'Escape') {
      setIsCalendarOpen(false);
    }

    handleTabAway(e, calendarRef, () => setIsCalendarOpen(false));
  };

  const handleSelectDate = (e, date) => {
    const {
      year,
      month,
      day,
      outside,
    } = date;

    if (outside) {
      // if clicking on a day outside of the current month - change the calendar view
      if (month !== selectedMonth) {
        setSelectedMonth(month);
      }
      if (year !== selectedYear) {
        setSelectedYear(year);
      }
      // find the newly selected date and focus it
      const newDateString = `${year}-${month}-${day}`;
      setFocusedCalendarButton(newDateString);
      return;
    }

    setSelectedYear(year);
    setSelectedMonth(month);
    setSelectedDay(day);

    // we have to add 1 to the month that displays in the input because months are 0 indexed
    const stringMonth = month + 1;
    onChange(year, stringMonth, day);
    setIsCalendarOpen(false);
    setFocusedCalendarButton(null);
  };

  const handleTableFocus = (e) => {
    // If tabbing onto the table -> focus on the first day of the month that is not disabled
    if (!focusedCalendarButton) {
      const table = e.target;
      const days = table.querySelectorAll('[data-date]:not([disabled]):not([data-outside])');
      if (days && days[0]) {
        const dataDateValue = days[0].getAttribute('data-date');
        setFocusedCalendarButton(dataDateValue);
      }
    }
  };

  const isSelectedDay = (calendarDay) => {
    if (!dateValue || dateValue.length < 8) return false;

    const { year, month, day } = getYearMonthDay(dateValue, dateFormat);
    const indexedMonth = parseInt(month, 10) - 1;
    const intDay = parseInt(day, 10);
    const intYear = parseInt(year, 10);
    return intYear === calendarDay.year && indexedMonth === calendarDay.month && intDay === calendarDay.day;
  };

  const selectToday = () => {
    handleSelectDate({}, {
      year: today.getFullYear(),
      month: today.getMonth(),
      day: today.getDate(),
    });
  };

  const tbodyRef = useClickOutside(() => {
    // if we click outside of the table body we need to remove focus
    // from the currently focused day in order to reset tabbing
    setFocusedCalendarButton(null);
  }, ['.calendar-btn', '.calendar-blank']); // selectors for the button that opens the calendar

  return (
    <div
      className={cn(
        'lds-calendar-popup',
        {
          open: isCalendarOpen,
        }
      )}
      role="dialog"
      aria-modal="true"
      onKeyDown={handleCalendarKeyDown}
      aria-describedby={`${id}-modalTitle`}
      ref={calendarRef}
    >
      <span id={`${id}-modalTitle`} className="sr-only">{translation.hiddenDialogTitle}</span>
      <CalendarControls
        id={id}
        max={max}
        min={min}
        selectedMonth={selectedMonth}
        selectedYear={selectedYear}
        setFocusedCalendarButton={setFocusedCalendarButton}
        setSelectedMonth={setSelectedMonth}
        setSelectedYear={setSelectedYear}
        translation={translation}
        yearInputType={yearInputType}
      />
      <table
        className="lds-calendar-table"
        role="grid"
        tabIndex={tableTabIndex}
        onFocus={handleTableFocus}
        aria-label={`${monthOptions[selectedMonth]?.label} ${selectedYear}`}
      >
        <TableHead translation={translation} startOfWeek={startOfWeek} />
        <tbody
          ref={tbodyRef}
        >
          {
            weeksInMonth.map((week, idx) => (
              <tr key={idx}>
                {
                  week.map((day) => (
                    <td
                      key={`daycell-${day.year}-${day.month}-${day.day}`}
                      className={cn(
                        'calendar-day',
                        {
                          outside: day.outside,
                          today: day.today,
                        }
                      )}
                      role="gridcell"
                    >
                      <button
                        type="button"
                        className={cn(
                          'lds-button-clear-style',
                          'day-btn',
                          {
                            selected: isSelectedDay(day),
                          }
                        )}
                        tabIndex="-1"
                        data-date={`${day.year}-${day.month}-${day.day}`}
                        data-outside={day.outside}
                        onKeyDown={(e) => handleDayKeyDown(e, day)}
                        onClick={(e) => handleSelectDate(e, day)}
                        disabled={day.disabled}
                      >
                        { day.today && <span className="sr-only">{translation.screenReaderTextToday}</span> }
                        { isSelectedDay(day) && <span className="sr-only">{translation.screenReaderTextSelected}</span> }
                        <span className="sr-only">{`${monthOptions[selectedMonth]?.label} ${day.day} ${selectedYear}`}</span>
                        <span aria-hidden="true">{day.day}</span>
                      </button>
                    </td>
                  ))
                }
              </tr>
            ))
          }
        </tbody>
      </table>
      <div>
        <LdsButton
          className={cn(
            'action-ghost',
            'today-button'
          )}
          aria-label={translation.todayButtonAriaLabel}
          onClick={selectToday}
        >
          <LdsIcon name="calendar-blank" inline decorative />
          {translation.todayButtonText}
        </LdsButton>
      </div>
    </div>
  );
}
