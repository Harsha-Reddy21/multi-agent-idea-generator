export function getPlaceholder(dateFormat) {
  const separator = dateFormat === 'YYYY-MM-DD' ? '-' : '/';
  const dateParts = dateFormat.split(separator);
  const regex = /./g; // . Matches any character other than newline
  return dateParts.map((str) => str.replaceAll(regex, '_')).join(separator);
}

export function getMonthOptions(translation) {
  const months = Object.values(translation.months);
  return months.map((month, index) => {
    return { label: month.name, value: index };
  });
}

export function isSameDay(day1, day2) {
  return day1.toDateString() === day2.toDateString();
}

export function getNumberOfDaysInMonth(month, year) {
  /* Passing day 0 of a month will get us the last day of the previous month.
    Because dates are 0 indexed we add 1 to the current month to get next month - in order to see the last day of this month
  */
  const nextMonth = month + 1;
  return new Date(year, nextMonth, 0).getDate();
}

export function addDays(startDate, days) {
  const date = new Date(startDate);
  date.setDate(date.getDate() + days);
  return date;
}

export function subtractDays(startDate, days) {
  const date = new Date(startDate);
  date.setDate(date.getDate() - days);
  return date;
}

export function zeroPrefix(value) {
  if (value.toString().length < 2) return `0${value}`;
  return value;
}

export function getDateParts(date) {
  return {
    day: date.getDate(),
    year: date.getFullYear(),
    month: date.getMonth(),
    weekIndex: date.getDay(),
  };
}

export function isDayDisabled(date, disableWeekends = false, disabledDates = [], minTime = null, maxTime = null) {
  try {
    const {
      day, year, month, weekIndex,
    } = getDateParts(date);
    if (disableWeekends && (weekIndex === 0 || weekIndex === 6)) return true;

    if (disabledDates && Array.isArray(disabledDates)) {
      const prefixMonth = zeroPrefix(month + 1);
      const prefixDay = zeroPrefix(day);
      const dayStr = `${year}-${prefixMonth}-${prefixDay}`;
      if (disabledDates.includes(dayStr)) return true;
    }

    if (minTime && date.getTime() < minTime) {
      return true;
    }
    if (maxTime && date.getTime() > maxTime) {
      return true;
    }
    return false;
  } catch (e) {
    // eslint-disable-next-line
    console.error(`LdsDatepicker Error at isDayDisabled. Verify disabledDates array, min, and max props all follow YYYY-MM-DD format`, e);
    return false;
  }
}

export function getDateTime(dateStr) {
  try {
    const dateObj = new Date(dateStr);
    if (!isValidDate(dateObj)) throw new Error(`getDateTime - Invalid date ${dateStr}`);
    return dateObj.getTime();
  } catch (e) {
    // eslint-disable-next-line
    throw new Error(`getDateTime - Invalid date ${dateStr}`);
  }
}

/* Get all of the days in a month for the calendar. Includes
 days outside of the month to fill out weeks and checks for disabled days
*/
export function getMonthDays({
  month,
  year,
  startOfWeek = 'sunday',
  disableWeekends = false,
  disabledDates = [],
  min,
  max,
} = {}) {
  const today = new Date();
  const firstDay = new Date(year, month, 1);
  const days = [];

  const minTime = min ? getDateTime(min) : undefined;
  const maxTime = max ? getDateTime(max) : undefined;

  // fill days based on the configurable start day of week
  const firstDayCount = firstDay.getDay();
  const dayFillFirst = {};

  if (startOfWeek === 'sunday') {
    if (firstDayCount === 1) {
      dayFillFirst.sunday = 1;
    } else {
      dayFillFirst.sunday = 6 - (6 - firstDayCount);
    }
  } else if (startOfWeek === 'monday') {
    if (firstDayCount === 0) {
      dayFillFirst.monday = 6;
    } else {
      dayFillFirst.monday = 6 - (7 - firstDayCount);
    }
  } else if (startOfWeek === 'saturday') {
    if (firstDayCount === 6) {
      dayFillFirst.saturday = 0;
    } else {
      dayFillFirst.saturday = 6 - (5 - firstDayCount);
    }
  }

  function getDayInformation(date) {
    const {
      day, year, month,
    } = getDateParts(date);
    return {
      disabled: isDayDisabled(date, disableWeekends, disabledDates, minTime, maxTime),
      day,
      year,
      month,
      date,
      today: isSameDay(today, date),
    };
  }

  // Get any days needed to fill out the calendar that are before the month starts
  for (let i = 0; i < dayFillFirst[startOfWeek]; i += 1) {
    const dayDate = subtractDays(firstDay, (dayFillFirst[startOfWeek] - i));
    const dayInfo = getDayInformation(dayDate);
    days.push({
      ...dayInfo,
      outside: true,
    });
  }

  // add the days of the calendar for this month
  for (let i = 0; i < getNumberOfDaysInMonth(month, year); i += 1) {
    const dayDate = addDays(firstDay, i);
    const dayInfo = getDayInformation(dayDate);
    days.push(dayInfo);
  }

  // add days from next month to fill out calendar
  const lastDay = days[days.length - 1].date;
  const maxDaysLength = days.length;
  let maxDays = 28;
  if (maxDaysLength > 28) {
    maxDays = maxDaysLength <= 35 ? 35 : 42;
  }
  for (let i = 1; i <= (maxDays - maxDaysLength); i += 1) {
    const dayDate = addDays(lastDay, i);
    const dayInfo = getDayInformation(dayDate);
    days.push({
      ...dayInfo,
      outside: true,
    });
  }

  return days;
}

/* eslint-disable no-console, consistent-return */
export function validateTranslation(translation, componentName) {
  if (!translation.days) {
    return new Error(
      `Invalid prop "translation" supplied to ${componentName}. Translation must include "days" property`
    );
  }

  const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  if (Object.keys(translation.days).sort().join('') !== days.sort().join('')) {
    return new Error(
      `Invalid prop "translation" supplied to ${componentName}.
      Translation must include "days" property with keys: ${days}`
    );
  }

  let isDaysValid = true;
  Object.keys(translation.days).forEach((dayKey) => {
    if (!translation.days[dayKey].abbr) {
      isDaysValid = false;
    }
    if (!translation.days[dayKey].name) {
      isDaysValid = false;
    }
  });
  if (!isDaysValid) {
    return new Error(
      `Invalid prop "translation" supplied to ${componentName}.
      Each day in translation.days must include a 'name' property and an 'abbr' property.`
    );
  }
}
/* eslint-enable */

export function validateDateFormat(propValue, key, componentName, location, propFullName) { // eslint-disable-line
  if (!/\d{4}-{1}\d{2}-{1}\d{2}/.test(propValue[key])) {
    return new Error(
      `Invalid prop ${propFullName} supplied to ${componentName}. Must be an array of date string with format YYYY-MM-DD`
    );
  }
}

export function isValidDate(d) {
  return d instanceof Date && !isNaN(d);
}

export function getYearMonthDay(string, format) {
  const dateParts = string.split(format === 'YYYY-MM-DD' ? '-' : '/');

  if (format === 'MM/DD/YYYY') {
    return {
      year: dateParts[2],
      month: dateParts[0],
      day: dateParts[1],
    };
  }

  if (format === 'DD/MM/YYYY') {
    return {
      year: dateParts[2],
      month: dateParts[1],
      day: dateParts[0],
    };
  }

  if (format === 'YYYY-MM-DD') {
    return {
      year: dateParts[0],
      month: dateParts[1],
      day: dateParts[2],
    };
  }
  throw new Error(`Error at function getYearMonthDay - incorrect format "${format}" supplied `);
}
