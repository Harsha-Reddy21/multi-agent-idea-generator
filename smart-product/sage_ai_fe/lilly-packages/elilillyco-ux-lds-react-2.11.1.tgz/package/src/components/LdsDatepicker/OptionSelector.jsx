// Option selector used for month and year selection in the datepicker
import {
  useRef,
  useState,
  useEffect,
  useId
} from 'react';
import cn from 'classnames';

import LdsIcon from '../LdsIcon/index.jsx';

import handleTabAway from '../../util/handleTabAway.js';

export default function OptionSelector({
  value,
  onChange = () => {},
  options = [],
  ariaLabel,
}) {
  const dropId = useId();
  const dropdownRef = useRef(null);

  const [isOpen, setIsOpen] = useState(false);
  const buttonLabel = options && options.find((option) => option.value === value)?.label;

  useEffect(() => {
    if (isOpen && dropdownRef.current) {
      const firstButton = dropdownRef.current.querySelector('.option-button');
      firstButton.focus();
    }
  }, [isOpen]);

  const handleSelectOption = (option) => {
    onChange(option.value);
    setIsOpen(false);
  };

  const handleKeyDown = (e) => {
    const callback = () => setIsOpen(false);
    return handleTabAway(e, dropdownRef, callback);
  };

  return (
    <>
      <button
        className={cn(
          'lds-button-base',
          'date-option-button',
          {
            expanded: isOpen,
          }
        )}
        aria-haspopup="listbox"
        aria-expanded={isOpen}
        aria-controls={dropId}
        onClick={() => setIsOpen(!isOpen)}
        aria-label={ariaLabel}
      >
        {buttonLabel}
        <LdsIcon name="caret-down-fill" inline decorative />
      </button>

      <div
        ref={dropdownRef}
        inert={isOpen ? null : ''}
        className={cn(
          'lds-datepicker-option-selector',
          {
            open: isOpen,
          }
        )}
        onKeyDown={handleKeyDown}
      >
        <div
          id={dropId}
          className="inner-expandable"
          role="listbox"
        >
          {
            options.map((option) => (
              <button
                key={option.value}
                className={cn(
                  'lds-button-base',
                  'option-button',
                  {
                    selected: value === option.value,
                  }
                )}
                onClick={() => handleSelectOption(option)}
                aria-selected={value === option.value}
                role="option"
                type="button"
              >
                {option.label}
                {value === option.value && <LdsIcon name="check" inline decorative />}
              </button>
            ))
          }
        </div>
      </div>
    </>
  );
}
