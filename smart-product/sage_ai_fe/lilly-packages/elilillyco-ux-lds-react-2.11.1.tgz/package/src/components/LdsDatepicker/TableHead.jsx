import cn from 'classnames';

export default function TableHead({ translation, startOfWeek }) {
  const {
    sunday,
    monday,
    tuesday,
    wednesday,
    thursday,
    friday,
    saturday,
  } = translation.days;

  sunday.isWeekend = true;
  saturday.isWeekend = true;

  let days = [];
  if (startOfWeek === 'sunday') {
    days = [sunday, monday, tuesday, wednesday, thursday, friday, saturday];
  } else if (startOfWeek === 'monday') {
    days = [monday, tuesday, wednesday, thursday, friday, saturday, sunday];
  } else if (startOfWeek === 'saturday') {
    days = [saturday, sunday, monday, tuesday, wednesday, thursday, friday];
  }

  return (
    <thead>
      <tr>
      {
        days.map((day) => (
          <th
            key={day.name}
            scope="col"
            aria-label={day.name}
            className={cn(
              {
                weekend: day.isWeekend,
              }
            )}
          >
            {day.abbr}
          </th>
        ))
      }
      </tr>
    </thead>
  );
}
