import { useContext } from 'react';
import cn from 'classnames';
import { VideoListContext } from '../VideoListContext.jsx';

// Private Sub-Components
import LdsIcon from '../../LdsIcon/index.jsx';

/**
 * [Private] Video List Player Sub-Component
 *
 * Defines the video player's video or chapter list items
 */
export default function ListItem({
  chapterTitle,
  description,
  duration,
  index,
  // partnerId,
  startTime,
  thumbnail,
  title,
}) {
  const {
    activeVideoIndex,
    chapterized,
    handleListItemClick,
  } = useContext(VideoListContext);

  return (
    <li
      role="listitem"
      className={cn(
        'lds-video-list-item',
        {
          'lds-video-list-item-chapter': chapterized,
          'lds-video-list-item-no-img': !thumbnail,
        }
      )}
    >
      <button
        onClick={(e) => handleListItemClick(e, index)}
        type="button"
        aria-label={`Play video: ${chapterized ? chapterTitle : title}`}
        className={`lds-button-base ${
          activeVideoIndex === index ? 'active' : ''
        } ${chapterized ? 'no-thumb' : ''}`}
      >

        <span className="lds-video-list-item-img">
          {thumbnail
            && <>
                <img
                  src={thumbnail}
                  alt={chapterized ? chapterTitle : title}
                />
              {!chapterized
                && <span className="lds-video-list-item-time">{duration}</span>
              }
            </>
          }
          {chapterized
            && <span className="lds-video-list-item-img-icon">
              {activeVideoIndex === index
                ? <LdsIcon name="play-circle-fill" decorative={true} label="Play chapter" />
                : <LdsIcon name="pause-circle-fill" decorative={true} label="Pause chapter" />
              }
            </span>
          }
        </span>

        <span className="lds-video-list-item-text">
          <h6 className="lds-video-list-item-title">{chapterized ? chapterTitle : title}</h6>
          {description && <p className="lds-video-list-item-desc">{description}</p>}
        </span>
        {chapterized
          && <span className="lds-video-list-item-chapter-time">{startTime}</span>
        }
      </button>
    </li>
  );
}
