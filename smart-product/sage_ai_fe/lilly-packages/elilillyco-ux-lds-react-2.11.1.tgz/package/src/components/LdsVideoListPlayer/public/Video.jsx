import { useContext } from 'react';
import PropTypes from 'prop-types';
import { VideoListContext } from '../VideoListContext.jsx';

// Private Sub-Components
import LdsVideoPlayer from '../../LdsVideoPlayer/index.jsx';

// JSDoc type definitions
/**
 * @typedef VideoProps
 * @property {number} [index] - Required; Index number for the video embed in the list player's video list. It should match with the `id` property of a `videoList` object.
 * @property {React.ReactNode} [children] - Required; Child components; use either the LdsKalturaPlayer or LdsYoutubePlayer utility components or a custom video embed implementation compatible with the LDS video player component.
 * @property {string} [aspectRatio='16/9'] - Optional; Aspect ratio of the video player for the specific video instance
 * @property {string} [className] - Optional; custom user-defined CSS class(es) for the video player component context, will be appended to the list of any other component classes on the video player cmponent.
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Optional, define any additional non-prop attributes to be rendered on the video player component.
 */
/**
 * LDS Video List Player Video sub-component
 * @param {VideoProps} props
 * @returns {React.JSX.Element}
 */
export default function Video({
  index,
  children,
  aspectRatio,
  className,
  ...rest
}) {
  const {
    activeVideo,
    activeVideoIndex,
    backgroundImageUrl,
    brandBorder,
    buttonText,
    chapterized,
    interstitial,
    interstitialContent,
  } = useContext(VideoListContext);
  const heading = activeVideo?.title;
  const time = activeVideo?.duration;

  return (((activeVideoIndex === index) || chapterized)
    && <LdsVideoPlayer
      aspectRatio={aspectRatio || '16/9'}
      backgroundImageUrl={backgroundImageUrl}
      brandBorder={brandBorder}
      buttonText={buttonText}
      heading={heading}
      interstitial={interstitial}
      interstitialContent={interstitialContent}
      time={time}
      className={className}
      {...rest}
    >
      {children}
    </LdsVideoPlayer>
  );
}

Video.propTypes = {
  index: PropTypes.number.isRequired,
  children: PropTypes.any.isRequired,
  aspectRatio: PropTypes.string,
  className: PropTypes.string,
  rest: PropTypes.any,
};
