// Private Sub-Components
import LdsLink from '../../LdsLink/index.jsx';

/**
 * [Private] Video List Player Sub-Component
 *
 * Defines the video player's accessible skip-to options for keyboard navigation
 */
export default function SkipPanel({
  playlistId,
  skipToPlaylistText = 'Skip to playlist',
  transcriptButtonId,
  skipToTranscriptText = 'Skip to transcript',
}) {
  return (
    <div className="col-lg-12 col-xl-10">
      <div className="lds-skip-panel">
        <LdsLink
          classes="compact mr-100"
          href={`#${playlistId}`}
          mode="button"
          tabIndex="0"
        >
          {skipToPlaylistText}
        </LdsLink>
        <LdsLink
          classes="compact"
          href={`#${transcriptButtonId}`}
          mode="button"
          tabIndex="0"
        >
          {skipToTranscriptText}
        </LdsLink>
      </div>
    </div>
  );
}
