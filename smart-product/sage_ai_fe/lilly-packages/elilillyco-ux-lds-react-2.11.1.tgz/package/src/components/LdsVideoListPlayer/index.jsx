// MARK: IMPORTS
import { useId, useRef } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import { VideoListContextProvider } from './VideoListContext.jsx';

// Private Sub-Components
import ListItem from './private/ListItem.jsx';
import SkipPanel from './private/SkipPanel.jsx';
import LdsFigureCaption from '../LdsFigureCaption/index.jsx';
import PlayerDescription from './private/PlayerDescription.jsx';

// Public Sub-Components
import Video from './public/Video.jsx';

// Utility Functions
import * as LdsFigureCaptionUtils from '../LdsFigureCaption/util.js';

// MARK: DEFINITION

// JSDoc type definitions
/**
 * @typedef LdsVideoListPlayerProps
 * @property {{id: number, autoplay: boolean, chapterTitle: string, startTime: string, videoId: string, title: string, description: string, duration: string, thumbnail: string, transcript: string|React.ReactNode}[]} videoList - Required: Array of video or video chapter objects in the playlist
 * @property {boolean} [chapterized=false] - Optional; Whether the video playlist is a list of videos (false - default) or a list of chapter time stamps ("chapterized") for a single video (true)
 * @property {object} [activeVideo] - Required; a React `useState` variable with a value of the active video object from the `videoList` prop array (creating this `useState` variable is a necessary implementation detail)
 * @property {function} [setActiveVideo] - Required; the `activeVideo` prop's React `useState` variable setter function (creating the `useState` variable with this setter function is a necessary implementation detail)
 * @property {object} [activeVideoIndex] - Required; a React `useState` variable with a value of the active video object's numeric index in the `videoList` array (creating this `useState` variable is a necessary implementation detail)
 * @property {function} [setActiveVideoIndex] - Required; the `activeVideoIndex` prop's React `useState` variable setter function (creating the `useState` variable with this setter function is a necessary implementation detail)
 * @property {React.ReactNode} [children] - Required; the child nodes of the `<LdsVideoListPlayer>` component; should only be `<LdsVideoListPlayer.Video>` sub-component nodes
 * @property {boolean} [brandBorder=false] - Optional; whether to use the brand border presentation option
 * @property {string} [listTitle] - Optional; title text appearing above the video player's playlist column
 * @property {string} [description] - Optional; the default video description content to appear below the transcript; typically used with the chapterized option; this is overridden by the current active `videoList` object’s `description` property if it has a value
 * @property {string} [skipToPlaylistText='Skip to Playlist'] - Optional; text label for the button in the accessibility panel that allows a user navigating the page with a keyboard to skip to the playlist
 * @property {string} [skipToTranscriptText='Skip to Transcript'] - Optional; text label for the button in the accessibility panel that allows a user navigating the page with a keyboard to skip to the transcript
 * @property {function} [onVideoSelect] - Optional; set a user-defined function that will be called when a video is selected from the playlist
 * @property {string|React.ReactNode} [textContent] - Optional; TRANSCRIPT PROP: the default video transcript content; typically used with the chapterized option;  this is overridden by the current active `videoList` object’s `transcript` property if it has a value
 * @property {string} [ariaLabel='video with transcript'] - Optional; TRANSCRIPT PROP: the ARIA label attribute value for the video transcript's figure element. Must be set for accessibility compliance; if not explicitly then a default value is used
 * @property {string} [buttonId] - Optional; TRANSCRIPT PROP: transcript toggle button - allows setting a user-defined ID for the button; by default it will have a random React `useID` set.
 * @property {string} [showDescriptionText='Open transcript'] - Optional; TRANSCRIPT PROP: toggle button - the button label to display when the transcript content is closed/collapsed; has a default value appropriate for U.S. English usage
 * @property {string} [hideDescriptionText='Close transcript'] - Optional; TRANSCRIPT PROP: toggle button - the buton label to display when the transcript content is open/expanded; has a default value appropriate for U.S. English usage
 * @property {string} [buttonTextAlign='left'] - Optional; TRANSCRIPT PROP: toggle button - sets the button's text alignment. Must be one of: `left`, `center`, or `right`
 * @property {string} [buttonIcon='CaretCircleUpFill'] - Optional; TRANSCRIPT PROP: toggle button - set the name value of an LDS Icon to show when the description is collapsed. Must be one of: `CaretCircleUpFill`, `CaretUp`, `CaretUpFill`, `MinusCircle`, `MinusCircleFill`, `Minus`
 * @property {string} [contentMaxHeight] - Optional; TRANSCRIPT PROP: set a pre-defined maximum height constraint for the transcript content; it will scroll internally to this height if the content exceeds the height; must be one of: `small`, `medium`, or `large`
 * @property {number} [contentMaxHeightOverride] - Optional; TRANSCRIPT PROP: set a user-defined maximum height constraint as a number of CSS pixels for the transcript content; it will scroll internally to this height if the content exceeds the height; when set it overrides `transcriptMaxHeight`
 * @property {boolean} [initExpanded=false] Optional; TRANSCRIPT PROP: whether the transcript should be expanded by default
 * @property {boolean} [noCollapse=false] Optional; TRANSCRIPT PROP: whether the transcript should be presented as static content; if true, removes the expand/collapse button and panel to display the transcript content directly below the video; the content is by centered by default. Also overrides the function of the `initExpanded` prop.
 * @property {string} [radiusSize='meduim'] - Optional; TRANSCRIPT PROP: size of the transcript feature's border radius, must be one of: `small`, `medium`, or `large`
 * @property {boolean} [interstitial=false] - Optional; VIDEO INTERSTITIAL PROP: whether to use the `LdsVideoPlayer` component's interstitial feature
 * @property {string} [backgroundImageUrl] - Optional; VIDEO INTERSTITIAL PROP: the video player interstitial's background image URL
 * @property {React.ReactNode} [interstitialContent] - Optional; VIDEO INTERSTITIAL PROP: the video player interstitial content; can be a text string or any valid HTML or JSX within a React fragment.
 * @property {string} [buttonText='Continue'] - Optional; VIDEO INTERSTITIAL PROP: The interstitial button text label
 * @property {string} [className] - Optional; custom user-defined CSS class(es) applied to the video list player component's root container element, will be appended to the list of any other component classes
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Optional; define any additional non-prop attributes to be rendered on the video list player component's root container element.
 */
/**
 * LdsVideoListPlayer component
 * @param {LdsVideoListPlayerProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsVideoListPlayer({
  // MARK: PROPS
  // video list player props
  videoList,
  chapterized = false,
  activeVideo,
  setActiveVideo,
  activeVideoIndex,
  setActiveVideoIndex,
  children,
  brandBorder,
  listTitle,
  description,
  skipToPlaylistText = 'Skip to Playlist',
  skipToTranscriptText = 'Skip to Transcript',
  onVideoSelect,
  // transcript figureCaption props
  textContent,
  ariaLabel = 'video with transcript',
  buttonId,
  showDescriptionText = 'Open transcript',
  hideDescriptionText = 'Close transcript',
  buttonIcon = 'CaretCircleUpFill',
  buttonTextAlign = 'left',
  contentMaxHeight,
  contentMaxHeightOverride,
  initExpanded = false,
  noCollapse = false,
  radiusSize = 'medium',
  // usage interstitial props
  interstitial = false,
  backgroundImageUrl,
  interstitialContent = <>
    <p>This video is hosted on YouTube, a platform which Lilly USA, LLC does not control, influence, or endorse. Lilly is not responsible for any content on this third-party site, including the privacy policy.</p>
    <p>Click &ldquo;continue&rdquo; to watch this video hosted on YouTube.</p>
  </>,
  buttonText = 'Continue',
  // Default Props
  className,
  ...rest
}) {
  // MARK: METHODS
  const playerRef = useRef(null);

  // Render the description content if the current videoList object has a description or the player has one
  const playerDescription = videoList[activeVideoIndex]?.description || description;

  // Render the transcript content if either the current videoList object has a transcript or the player has one
  const playerTranscript = videoList[activeVideoIndex]?.transcript || textContent;

  // remove colons from the generated ID
  const playlistId = `lds-playlist-${useId().slice(1, -1)}`;
  const tempId = useId();
  // if a `buttonId` prop is provided, use that. Otherwise generate one
  const transcriptButtonId = buttonId || `lds-transcript-btn-${tempId.slice(1, -1)}`;

  const handleListItemClick = (e, index) => {
    scrollActiveVideoIntoView(playerRef);

    setActiveVideoIndex(index);
    const newActiveVideo = videoList[index];
    setActiveVideo(newActiveVideo);

    onVideoSelect(newActiveVideo);
  };

  // MARK: RENDER
  return (
    <VideoListContextProvider
      activeVideo={activeVideo}
      activeVideoIndex={activeVideoIndex}
      backgroundImageUrl={backgroundImageUrl}
      brandBorder={brandBorder}
      buttonText={buttonText}
      chapterized={chapterized}
      handleListItemClick={handleListItemClick}
      interstitial={interstitial}
      interstitialContent={interstitialContent}
      videoList={videoList}
    >
      <div
        className={cn(
          'lds-video-list-player',
          { 'lds-video-list-player-chapterized': chapterized },
          className
        )}
        {...rest}
      >
        <div className="row lds-video-list-player-row">
          <SkipPanel
            playlistId={playlistId}
            skipToPlaylistText={skipToPlaylistText}
            transcriptButtonId={transcriptButtonId}
            skipToTranscriptText={skipToTranscriptText}
          />
          <div
            className="col-lg-8 col-xl-7 lds-video-list-player-column"
            ref={playerRef}
          >
            {playerTranscript
              ? <LdsFigureCaption
                ariaLabel={ariaLabel}
                buttonIcon={buttonIcon}
                buttonId={transcriptButtonId}
                buttonTextAlign={buttonTextAlign}
                contentMaxHeight={contentMaxHeight}
                contentMaxHeightOverride={contentMaxHeightOverride}
                hideDescriptionText={hideDescriptionText}
                initExpanded={initExpanded}
                noCollapse={noCollapse}
                radiusSize={radiusSize}
                showDescriptionText={showDescriptionText}
                textContent={playerTranscript}
              >
                {children}
              </LdsFigureCaption>
              : children
            }
            {playerDescription
              && <PlayerDescription playerDescription={playerDescription} />
            }
          </div>
          <div className="col-lg-4 col-xl-3 lds-video-list-column">
            {listTitle
              && <h5 className="lds-video-list-title">{listTitle}</h5>
            }
            <ol
              id={playlistId}
              role="list"
              className={`lds-video-list lds-video-list-${chapterized ? 'chapters' : 'videos'}`}
            >
              {videoList.map((video, index) => {
                return (
                  <ListItem
                    chapterTitle={video.chapterTitle}
                    description={video.description}
                    duration={video.duration}
                    index={index}
                    key={`${video.videoId}-${index}`}
                    scrollActiveVideoIntoView={scrollActiveVideoIntoView}
                    startTime={video.startTime}
                    thumbnail={video.thumbnail}
                    title={video.title}
                  />
                );
              })}
            </ol>
          </div>
        </div>
      </div>
    </VideoListContextProvider>
  );
}

// MARK: SUBROUTINES
function scrollActiveVideoIntoView(elementRef) {
  if (elementRef.current) {
    elementRef.current.scrollIntoView({ behavior: 'smooth' });
  }
}

// MARK: SUB COMPONENTS
LdsVideoListPlayer.Video = Video;

// MARK: PROP TYPES
LdsVideoListPlayer.propTypes = {
  videoList: PropTypes.arrayOf(
    PropTypes.shape({
      videoId: PropTypes.string.isRequired,
      title: PropTypes.string.isRequired,
      duration: PropTypes.string.isRequired,
      transcript: PropTypes.object,
    })
  ).isRequired,
  chapterized: PropTypes.bool,
  activeVideo: PropTypes.object,
  setActiveVideo: PropTypes.any,
  activeVideoIndex: PropTypes.number,
  setActiveVideoIndex: PropTypes.any,
  children: PropTypes.node.isRequired,
  brandBorder: PropTypes.bool,
  listTitle: PropTypes.oneOfType([PropTypes.string, PropTypes.object, PropTypes.node]),
  description: PropTypes.oneOfType([PropTypes.string, PropTypes.object, PropTypes.node]),
  skipToPlaylistText: PropTypes.oneOfType([PropTypes.string, PropTypes.object, PropTypes.node]),
  skipToTranscriptText: PropTypes.oneOfType([PropTypes.string, PropTypes.object, PropTypes.node]),
  onVideoSelect: PropTypes.any,
  // Figure Caption Transcript Props
  textContent: PropTypes.oneOfType([PropTypes.string, PropTypes.object, PropTypes.node]),
  ariaLabel: PropTypes.string,
  buttonId: PropTypes.string,
  showDescriptionText: PropTypes.oneOfType([PropTypes.string, PropTypes.object, PropTypes.node]),
  hideDescriptionText: PropTypes.oneOfType([PropTypes.string, PropTypes.object, PropTypes.node]),
  buttonTextAlign: PropTypes.PropTypes.oneOf(LdsFigureCaptionUtils.validButtonTextAlignmentOptions),
  buttonIcon: PropTypes.PropTypes.oneOf(LdsFigureCaptionUtils.validButtonIconOptions),
  contentMaxHeight: PropTypes.oneOf(LdsFigureCaptionUtils.validContentMaxHeightOptions),
  contentMaxHeightOverride: PropTypes.number,
  initExpanded: PropTypes.bool,
  noCollapse: PropTypes.bool,
  radiusSize: PropTypes.PropTypes.oneOf(LdsFigureCaptionUtils.validRadiusSizeOptions),
  // Usage Interstitial Props
  interstitial: PropTypes.bool,
  backgroundImageUrl: PropTypes.string,
  interstitialContent: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.object,
    PropTypes.node,
  ]),
  buttonText: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.object,
    PropTypes.node,
  ]),
  // Default Props
  className: PropTypes.string,
  rest: PropTypes.any,
};
