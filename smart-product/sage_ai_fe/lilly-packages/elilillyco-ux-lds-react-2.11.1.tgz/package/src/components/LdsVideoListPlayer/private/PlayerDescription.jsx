import cn from 'classnames';

/**
 * [Private] Video List Player Sub-Component
 *
 * Defines the video player description caption content block
 */
export default function PlayerDescription({
  playerDescription,
  className,
  ...rest
}) {
  return (
    <div
      className={cn(
        'lds-video-details',
        {
          className,
        }
      )}
      {...rest}
    >
      <p>{playerDescription}</p>
    </div>
  );
}
