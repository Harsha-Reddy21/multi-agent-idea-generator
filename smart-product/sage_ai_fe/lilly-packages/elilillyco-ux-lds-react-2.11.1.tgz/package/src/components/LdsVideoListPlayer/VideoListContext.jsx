import { createContext } from 'react';

export const VideoListContext = createContext();

export function VideoListContextProvider({
  activeVideo,
  activeVideoIndex,
  backgroundImageUrl,
  brandBorder,
  buttonText,
  chapterized,
  children,
  handleListItemClick,
  interstitial,
  interstitialContent,
  videoList,
}) {
  return (
    <VideoListContext.Provider value={{
      activeVideo,
      activeVideoIndex,
      backgroundImageUrl,
      brandBorder,
      buttonText,
      chapterized,
      handleListItemClick,
      interstitial,
      interstitialContent,
      videoList,
    }}>
      {children}
    </VideoListContext.Provider>
  );
}
