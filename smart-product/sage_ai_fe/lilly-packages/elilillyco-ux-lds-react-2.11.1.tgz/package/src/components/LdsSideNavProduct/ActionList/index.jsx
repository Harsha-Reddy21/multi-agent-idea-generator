import List from './List.jsx';
import Item from './Item.jsx';
import ItemLink from './ItemLink.jsx';
import ItemCollapse from './ItemCollapse.jsx';
import Subnav from './Subnav.jsx';
import { LeadingVisual, TrailingVisual, TrailingAction } from './Slots.jsx';

const ActionList = List;

ActionList.Item = Item;
ActionList.ItemLink = ItemLink;
ActionList.ItemCollapse = ItemCollapse;
ActionList.Subnav = Subnav;
ActionList.LeadingVisual = LeadingVisual;
ActionList.TrailingVisual = TrailingVisual;
ActionList.TrailingAction = TrailingAction;

ActionList.displayName = 'ActionList';
ActionList.Item.displayName = 'ActionList.Item';
ActionList.ItemLink.displayName = 'ActionList.ItemLink';
ActionList.ItemCollapse.displayName = 'ActionList.ItemCollapse';
ActionList.Subnav.displayName = 'ActionList.Subnav';
ActionList.LeadingVisual.displayName = 'ActionList.LeadingVisual';
ActionList.TrailingVisual.displayName = 'ActionList.TrailingVisual';
ActionList.TrailingAction.displayName = 'ActionList.TrailingAction';

export default ActionList;
