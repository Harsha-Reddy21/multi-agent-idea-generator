import { forwardRef } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import useSlots from './hooks/useSlots.jsx';

/**
 * @typedef HeadingLeadingVisualProps
 * @property {React.ReactNode} children - Child elements
 * @property {string} [className] - Additional CSS classes
 * @property {boolean} [hideOnExpand=false] - Whether to hide when the side navigation has expanded
 */
/**
 * Heading-specific leading visual
 * @param {HeadingLeadingVisualProps} props - Component props
 * @returns {React.JSX.Element} - The rendered <span> containing the leading visual
 */
const HeadingLeadingVisual = ({ children, className, hideOnExpand = false }) => (
  <span
    className={cn(
      'lds-sidenav-product-leading-visual',
      { 'is-hidden-on-sidenav-expand': hideOnExpand },
      className
    )}
  >
    {children}
  </span>
);

HeadingLeadingVisual.propTypes = {
  children: PropTypes.node.isRequired,
  hideOnExpand: PropTypes.bool,
};

/**
 * @typedef HeadingProps
 * @property {React.ReactNode | React.ReactElement<HeadingLeadingVisualProps>} children - Child elements
 * @property {string} [className] - Additional CSS classes
 * @property {string} [id] - HTML id attribute
 * @property {'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6'} [as='h2'] - HTML heading element to render
 * @property {boolean} [isVisuallyHidden=false] - Whether to visually hide the heading
 */
const Heading = forwardRef(
  /**
   * Heading sub-component for LdsSideNavProduct
   * @param {HeadingProps} props - Component props
   * @param {React.ForwardedRef<HTMLHeadingElement>} ref - Forwarded ref
   * @returns {React.JSX.Element} - The rendered <div> containing the text label
   */
  function Heading({
    children,
    className,
    id,
    as: Component = 'h2',
    isVisuallyHidden = false,
    ...props
  }, ref) {
    const [slots, childrenWithoutSlots] = useSlots(children, {
      leadingVisual: HeadingLeadingVisual,
    });

    return (
      <div
        className={cn(
          'lds-sidenav-product-heading',
          {
            'sr-only': isVisuallyHidden,
            'is-hidden-on-sidenav-collapse-icon': !slots.leadingVisual,
          },
          className
        )}
      >
        {slots?.leadingVisual}
        <Component
          ref={ref}
          id={id}
          className='lds-sidenav-product-heading-content'
          {...props}
        >
          {childrenWithoutSlots}
        </Component>
      </div>
    );
  }
);

Heading.propTypes = {
  children: PropTypes.oneOfType([
    PropTypes.node,
    PropTypes.instanceOf(HeadingLeadingVisual),
  ]).isRequired,
  className: PropTypes.string,
  id: PropTypes.string,
  as: PropTypes.oneOf(['h1', 'h2', 'h3', 'h4', 'h5', 'h6']),
  isVisuallyHidden: PropTypes.bool,
};

Heading.displayName = 'Heading';

Heading.LeadingVisual = HeadingLeadingVisual;

Heading.LeadingVisual.displayName = 'Heading.LeadingVisual';

export default Heading;
