import { forwardRef } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import Button from './Button.jsx';

const OMITTED_PROPS = ['_PrivateRenderWrapper', '_PrivateSlotConfig', 'disabled'];

const omitProps = (obj, keys) => {
  const result = { ...obj };
  keys.forEach(key => delete result[key]);
  return result;
};

// JSdoc type definitions
/**
 * @typedef LinkCustomProps
 * @property {React.ElementType} [as='a'] - Component to render as
 */
/**
 * @typedef {Omit<import('./Button').ButtonProps, '_PrivateRenderWrapper' | 'disabled'> & LinkCustomProps & React.AnchorHTMLAttributes<HTMLAnchorElement>} LinkProps
 */
const Link = forwardRef(
  /**
   * Button (link variant) sub-component for LdsSideNavProduct
   * @param {LinkProps} props - Component props
   * @param {React.ForwardedRef<HTMLAnchorElement>} ref - Forwarded ref
   * @returns {React.JSX.Element} - The rendered <a> container
   */
  function Link({
    children,
    className,
    as: Component = 'a',
    truncateText = false,
    showTrailingActionOnHover = false,
    isActive = false,
    ...props
  }, ref) {
    return (
      <Button
        className={cn(
          'lds-sidenav-product-action-link',
          className
        )}
        truncateText={truncateText}
        showTrailingActionOnHover={showTrailingActionOnHover}
        isActive={isActive}
        {...props}
        _PrivateRenderWrapper={({
          children: wrapperChildren,
          onClick,
          ...rest
        }) => {
          const cleanProps = omitProps(rest, OMITTED_PROPS);
          const handleClick = (e) => {
            if (onClick) {
              onClick(e);
            }
            if (props.onClick) {
              props.onClick(e);
            }
          };
          return (
            <Component
              {...cleanProps}
              ref={ref}
              rel={props?.target === '_blank' ? 'noopener noreferrer' : props?.rel}
              onClick={handleClick}
            >
              {wrapperChildren}
            </Component>
          );
        }}
      >
        {children}
      </Button>
    );
  }
);

// Remove unused variables by using object rest operator
// eslint-disable-next-line no-unused-vars
const { disabled, _PrivateRenderWrapper, ...buttonPropTypes } = Button.propTypes;

Link.propTypes = {
  ...buttonPropTypes,
  as: PropTypes.elementType,
  download: PropTypes.string,
  href: PropTypes.string,
  hrefLang: PropTypes.string,
  media: PropTypes.string,
  ping: PropTypes.string,
  rel: PropTypes.string,
  target: PropTypes.string,
  type: PropTypes.string,
};

export default Link;
