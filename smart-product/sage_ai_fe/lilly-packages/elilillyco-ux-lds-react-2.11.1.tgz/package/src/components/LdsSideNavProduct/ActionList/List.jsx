import { forwardRef } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import { ActionListContext } from '../contexts/ActionListContext.jsx';
import Item from './Item.jsx';
import ItemLink from './ItemLink.jsx';
import ItemCollapse from './ItemCollapse.jsx';

// JSdoc type definitions
/**
 * @typedef ActionListProps
 * @property {Array<
 *   React.ReactElement<React.ComponentProps<import('./Item').ItemComponent>> |
 *   React.ReactElement<React.ComponentProps<import('./ItemLink').ItemLinkComponent>> |
 *   React.ReactElement<React.ComponentProps<import('./ItemCollapse').ItemCollapseComponent>>
 * >} children - List items
 * @property {string} [className] - Additional CSS classes to ul element
 * @property {string} [role] - ARIA role for the list
 * @property {React.ReactElement} [defaultLeadingVisual] - Default leading visual for all items to use
 * @property {React.ReactElement} [defaultTrailingVisual] - Default trailing visual for all items to use
 */
const List = forwardRef(
  /**
   * List sub-component for LdsSideNavProduct
   * @param {ActionListProps} props - Component props
   * @param {React.ForwardedRef<HTMLUListElement>} ref - Forwarded ref
   * @returns {React.JSX.Element} - The rendered <ul> tag
   */
  function List({
    children,
    className,
    role,
    defaultLeadingVisual,
    defaultTrailingVisual,
    ...props
  }, ref) {
    const listRole = role || 'list';

    return (
      <ActionListContext.Provider
        value={{
          defaultLeadingVisual,
          defaultTrailingVisual,
        }}
      >
        <ul
          ref={ref}
          className={cn(
            'lds-sidenav-product-action-list',
            className
          )}
          role={listRole}
          {...props}
        >
          {children}
        </ul>
      </ActionListContext.Provider>
    );
  }
);

const validItemTypes = PropTypes.oneOfType([
  PropTypes.element,
  PropTypes.elementType,
  PropTypes.shape({ type: PropTypes.oneOf([Item, ItemLink, ItemCollapse]) }),
]);

List.propTypes = {
  children: PropTypes.oneOfType([
    validItemTypes,
    PropTypes.arrayOf(validItemTypes),
  ]).isRequired,
  className: PropTypes.string,
  role: PropTypes.string,
  defaultLeadingVisual: PropTypes.element,
  defaultTrailingVisual: PropTypes.element,
};

export default List;
