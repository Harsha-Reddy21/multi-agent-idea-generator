import { forwardRef } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

// JSdoc type definitions
/**
 * @typedef GroupProps
 * @property {React.ReactNode} children - Child elements
 * @property {string} [className] - Additional CSS classes
 */
const Group = forwardRef(
  /**
   * Group sub-component for LdsSideNavProduct
   * Used to create groupings of menu items
   * @param {GroupProps} props - Component props
   * @param {React.ForwardedRef<HTMLDivElement>} ref - Forwarded ref
   * @returns {React.JSX.Element} - The rendered <div> container
   */
  function Group({
    children,
    className,
    ...props
  }, ref) {
    return (
      <div
        ref={ref}
        className={cn(
          'lds-sidenav-product-group',
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);

Group.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
};

Group.displayName = 'Group';

export default Group;
