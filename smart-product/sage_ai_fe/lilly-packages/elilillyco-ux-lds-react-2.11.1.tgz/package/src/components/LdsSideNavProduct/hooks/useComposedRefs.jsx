import { useCallback } from 'react';
/**
 * A custom hook to compose multiple refs into a single ref callback.
 *
 * @param {...React.Ref} refs - The refs to be composed. Can be a function ref or an object ref.
 * @returns {React.RefCallback} - A ref callback that assigns the DOM node to all provided refs.
 */
const useComposedRefs = (...refs) => {
  return useCallback((node) => {
    refs.forEach((ref) => {
      if (typeof ref === 'function') {
        ref(node);
      } else if (ref) {
        // eslint-disable-next-line no-param-reassign
        ref.current = node;
      }
    });
  }, [refs]);
};

export default useComposedRefs;
