import { createContext } from 'react';

// JSdoc type definitions
/**
 * @typedef {object} SideNavContext
 * @property {'expanded' | 'collapsed'} state - Current state of the side navigation
 * @property {boolean} open - Current open state of the side navigation
 * @property {(open: boolean) => void} setOpen - Function to update open state
 * @property {boolean} isMobile - Whether the side navigation is in mobile view
 * @property {boolean} openMobile - Current open state of the mobile sidenav
 * @property {(open: boolean) => void} setOpenMobile - Function to update mobile dialog state
 * @property {() => void} toggleSideNav - Function to toggle the side navigation state
*/
/** @type {React.Context<SideNavContext>} */
export const SideNavContext = createContext({
  state: undefined,
  open: undefined,
  setOpen: undefined,
  isMobile: undefined,
  openMobile: undefined,
  setOpenMobile: undefined,
  toggleSideNav: undefined,
});
