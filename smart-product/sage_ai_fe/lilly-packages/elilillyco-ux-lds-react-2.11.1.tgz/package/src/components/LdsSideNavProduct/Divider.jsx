import { forwardRef } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

// JSdoc type definitions
/**
 * @typedef DividerProps
 * @property {string} [className] - Additional CSS classes
 */
const Divider = forwardRef(
  /**
   * Divider sub-component for LdsSideNavProduct
   * @param {DividerProps} props - Component props
   * @param {React.ForwardedRef<HTMLDivElement>} ref - Forwarded ref
   */
  function Divider({
    className,
    ...props
  }, ref) {
    return (
      <div
        ref={ref}
        className={cn(
          'lds-sidenav-product-divider',
          className
        )}
        {...props}
      />
    );
  }
);

Divider.propTypes = {
  className: PropTypes.string,
};

Divider.displayName = 'Divider';

export default Divider;
