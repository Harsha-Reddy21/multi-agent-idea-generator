import { forwardRef } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

// JSdoc type definitions
/**
 * @typedef HeaderProps
 * @property {React.ReactNode} children - Child elements
 * @property {string} [className] - Additional CSS classes
 */
const Header = forwardRef(
  /**
   * Header sub-component for LdsSideNavProduct
   * @param {HeaderProps} props - Component props
   * @param {import('react').ForwardedRef<HTMLDivElement>} ref - Forwarded ref
   * @returns {React.JSX.Element} - The rendered <div> container
   */
  function Header({
    children,
    className,
    ...props
  }, ref) {
    return (
      <div
        ref={ref}
        className={cn(
          'lds-sidenav-product-header',
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);

Header.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
};

Header.displayName = 'Header';

export default Header;
