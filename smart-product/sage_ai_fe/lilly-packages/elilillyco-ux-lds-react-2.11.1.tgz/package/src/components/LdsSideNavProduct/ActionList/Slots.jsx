import { LeadingVisual as BaseLeadingVisual, TrailingVisual as BaseTrailingVisual } from '../shared/Visuals.jsx';
import { TrailingAction as BaseTrailingAction } from '../shared/TrailingAction.jsx';
import { Subnav } from './Subnav.jsx';

/**
 * LeadingVisual slot component for ActionList
 * @param {import('../shared/Visuals').LeadingVisual} props
 */
export const LeadingVisual = (props) => <BaseLeadingVisual {...props} />;

/**
 * TrailingVisual slot component for ActionList
 * @param {import('../shared/Visuals').TrailingVisual} props
 */
export const TrailingVisual = (props) => <BaseTrailingVisual {...props} />;

/**
 * TrailingAction slot component for ActionList
 * @param {import('../shared/TrailingAction').TrailingAction} props
 */
export const TrailingAction = (props) => <BaseTrailingAction {...props} />;

LeadingVisual.propTypes = BaseLeadingVisual.propTypes;
TrailingVisual.propTypes = BaseTrailingVisual.propTypes;
TrailingAction.propTypes = BaseTrailingAction.propTypes;

export const itemSlotConfig = {
  leadingVisual: { Component: LeadingVisual, maxCount: 1 },
  trailingVisual: { Component: TrailingVisual, maxCount: 1 },
  trailingAction: { Component: TrailingAction, maxCount: 2 },
};

export const itemCollapseSlotConfig = {
  ...itemSlotConfig,
  trailingAction: { Component: TrailingAction, maxCount: 0 },
  subnav: { Component: Subnav, maxCount: 1 },
};
