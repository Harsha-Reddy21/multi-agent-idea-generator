import { createContext } from 'react';

// JSdoc type definitions
/**
 * @typedef ActionListContextProps
 * @property {React.ReactElement} [defaultLeadingVisual] - Default leading visual element
 * @property {React.ReactElement} [defaultTrailingVisual] - Default trailing visual element
 */
/** @type {React.Context<ActionListContextProps>} */
export const ActionListContext = createContext({
  defaultLeadingVisual: undefined,
  defaultTrailingVisual: undefined,
});

// JSdoc type definitions
/**
 * @typedef NestingContextProps
 * @property {number} [level] - Nesting level [0 - infinite]
 */
/** @type {React.Context<NestingContextProps>} */
export const NestingContext = createContext({
  level: 0,
});
