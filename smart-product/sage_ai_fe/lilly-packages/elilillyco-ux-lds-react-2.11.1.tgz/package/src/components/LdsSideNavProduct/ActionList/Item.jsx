import { forwardRef, useContext } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import { ActionListContext, NestingContext } from '../contexts/ActionListContext.jsx';
import { LeadingVisual, TrailingVisual, itemSlotConfig } from './Slots.jsx';
import useSlots from '../hooks/useSlots.jsx';
import Button from '../Action/Button.jsx';

// JSdoc type definitions
/**
 * @typedef ItemButtonBaseProps
 * @property {string} [className] - Additional CSS classes added to the li element
 */
/**
 * @typedef {Omit<import('../Action/Button').ButtonProps, '_PrivateRenderWrapper' | 'className'> & ItemButtonBaseProps} ItemButtonProps
 */
/** @typedef {React.ForwardRefExoticComponent<ItemButtonProps & React.RefAttributes<HTMLButtonElement>>} ItemComponent */
const Item = forwardRef(
  /**
   * List item button sub-component for LdsSideNavProduct
   * @param {ItemButtonProps} props - Component props
   * @param {React.ForwardedRef<HTMLButtonElement>} ref - Forwarded ref
   * @returns {React.JSX.Element} - The rendered <li> with button
   */
  function Item({
    children,
    className,
    ...props
  }, ref) {
    const {
      defaultLeadingVisual,
      defaultTrailingVisual,
    } = useContext(ActionListContext);
    const { level = 0 } = useContext(NestingContext);

    const [slots, childrenWithoutSlots] = useSlots(children, itemSlotConfig);

    const wrappedDefaultLeadingVisual = level === 0 && defaultLeadingVisual ? (
      <LeadingVisual>{defaultLeadingVisual}</LeadingVisual>
    ) : null;

    const wrappedDefaultTrailingVisual = level === 0 && defaultTrailingVisual ? (
      <TrailingVisual>{defaultTrailingVisual}</TrailingVisual>
    ) : null;

    return (
      <li
        className={cn(
          'lds-sidenav-product-action-list-item',
          { 'is-hidden-on-sidenav-collapse-icon': !slots.leadingVisual && !defaultLeadingVisual },
          className
        )}
      >
        <Button
          ref={ref}
          className='lds-sidenav-product-action-list-item-action-button'
          _PrivateSlotConfig={itemSlotConfig}
          {...props}
        >
          {level === 0 && (slots.leadingVisual || wrappedDefaultLeadingVisual)}
          {childrenWithoutSlots}
          {level === 0 && (slots.trailingVisual || wrappedDefaultTrailingVisual)}
          {slots.trailingAction}
        </Button>
      </li>
    );
  }
);

Item.propTypes = {
  ...Button.propTypes,
  className: PropTypes.string,
};

/** @type {ItemComponent} */
export default Item;
