import { forwardRef, useCallback } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import useSlots from '../hooks/useSlots.jsx';
import {
  LeadingVisual, TrailingVisual, TrailingAction, slotConfig
} from './Slots.jsx';

// JSdoc type definitions
/**
 * @typedef ButtonSlots
 * @property {import('../shared/Visuals').LeadingVisual} [LeadingVisual] - Visual element at start
 * @property {import('../shared/Visuals').TrailingVisual} [TrailingVisual] - Visual element at end
 * @property {import('../shared/TrailingAction').TrailingAction} [TrailingAction] - Action buttons at end
 */
/**
 * @typedef ButtonProps
 * @property {React.ReactNode | ButtonSlots} children - Child elements
 * @property {string} [className] - Additional CSS classes
 * @property {boolean} [disabled=false] - Whether the button is disabled
 * @property {boolean} [truncateText=false] - Whether to truncate text content
 * @property {boolean} [showTrailingActionOnHover=false] - Whether to show trailing actions only on hover/focus
 * @property {(event: React.MouseEvent<HTMLButtonElement>) => void} [onClick] - Click handler
 * @property {boolean} [isActive=false] - Whether the button is in active state
 * @property {import('../hooks/useSlots').SlotsConfig} [_PrivateSlotConfig] - Internal slot configuration
 * @property {React.ComponentType} [_PrivateRenderWrapper] - Internal wrapper component for custom rendering
 */
const Button = forwardRef(
  /**
   * Button sub-component for LdsSideNavProduct
   * @param {ButtonProps} props - Component props
   * @param {React.ForwardedRef<HTMLButtonElement>} ref - Forwarded ref
   * @returns {React.JSX.Element} - The rendered <button> container
   */
  function Button({
    children,
    className,
    disabled = false,
    truncateText = false,
    showTrailingActionOnHover = false,
    onClick,
    isActive = false,
    _PrivateSlotConfig = slotConfig,
    _PrivateRenderWrapper: Wrapper,
    ...props
  }, ref) {
    const [slots, childrenWithoutSlots] = useSlots(children, _PrivateSlotConfig);

    const handleClick = useCallback((e) => {
      if (disabled) return;
      onClick?.(e);
    }, [disabled, onClick]);

    const hasTrailingActions = Array.isArray(slots.trailingAction) && slots.trailingAction.length > 0;
    const leadingVisual = slots.leadingVisual;
    const trailingVisual = !hasTrailingActions ? slots.trailingVisual : null;

    const content = (
      <>
        <span className="lds-sidenav-product-action-container">
          {leadingVisual}

          <span className="lds-sidenav-product-action-content">
            {childrenWithoutSlots}
          </span>
        </span>

        {trailingVisual}
      </>
    );

    const commonProps = {
      ref,
      className: cn(
        'lds-sidenav-product-action',
        { 'is-hidden-on-sidenav-collapse-icon': !leadingVisual },
        className
      ),
      onClick: handleClick,
      'data-active': isActive,
      'data-truncate': truncateText,
      ...props,
    };

    const buttonElement = Wrapper ? (
      <Wrapper
        {...commonProps}
      >
        {content}
      </Wrapper>
    ) : (
      <button
        {...commonProps}
        type="button"
        disabled={disabled}
      >
        {content}
      </button>
    );

    return hasTrailingActions ? (
      <span className="lds-sidenav-product-action-wrapper-outside">
        {buttonElement}
        <span
          className="lds-sidenav-product-action-trailing-action"
          data-show-hover={showTrailingActionOnHover}
        >
          {slots.trailingAction}
        </span>
      </span>
    ) : buttonElement;
  }
);

Button.propTypes = {
  children: PropTypes.oneOfType([
    PropTypes.node,
    PropTypes.shape({
      leadingVisual: PropTypes.instanceOf(LeadingVisual),
      trailingVisual: PropTypes.instanceOf(TrailingVisual),
      trailingAction: PropTypes.oneOfType([
        PropTypes.instanceOf(TrailingAction),
        PropTypes.arrayOf(PropTypes.instanceOf(TrailingAction)),
      ]),
    }),
  ]).isRequired,
  className: PropTypes.string,
  disabled: PropTypes.bool,
  truncateText: PropTypes.bool,
  showTrailingActionOnHover: PropTypes.bool,
  onClick: PropTypes.func,
  isActive: PropTypes.bool,
  _PrivateSlotConfig: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.elementType,
      PropTypes.shape({
        Component: PropTypes.elementType.isRequired,
        maxCount: PropTypes.number,
      }),
    ])
  ),
  _PrivateRenderWrapper: PropTypes.elementType,
};

export default Button;
