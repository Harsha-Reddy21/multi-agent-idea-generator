import {
  useState, useCallback, useMemo, forwardRef
} from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import useIsMobile from '../../hooks/useIsMobile.js';
import { SideNavContext } from './contexts/SideNavContext.jsx';

// JSdoc type definitions
/**
 * @typedef ProviderProps
 * @property {React.ReactNode} children - Child elements
 * @property {string} [className] - Additional CSS classes
 * @property {boolean} [defaultOpen=true] - Default open state
 * @property {boolean} [open] - Controlled open state
 * @property {(open: boolean) => void} [onOpenChange] - Controlled open state change handler
 * @property {number} [mobileBreakpoint] - Breakpoint for mobile view of side-navigation
 */
const Provider = forwardRef(
  /**
   * Provider sub-component for LdsSideNavProduct
   * @param {ProviderProps} props - Component props
   * @param {React.ForwardedRef<HTMLDivElement>} ref - Forwarded ref
   */
  function Provider({
    children,
    className,
    defaultOpen = true,
    open: openProp,
    onOpenChange: setOpenProp,
    mobileBreakpoint,
    ...props
  }, ref) {
    const isMobile = useIsMobile(mobileBreakpoint);
    const [openMobile, setOpenMobile] = useState(false);

    const [uncontrolledOpen, setUncontrolledOpen] = useState(defaultOpen);
    const open = openProp ?? uncontrolledOpen;
    const setOpen = useCallback((newOpen) => {
      const value = typeof newOpen === 'function' ? newOpen(open) : newOpen;
      if (setOpenProp) {
        setOpenProp(value);
      } else {
        setUncontrolledOpen(value);
      }
    }, [open, setOpenProp]);

    const toggleSideNav = useCallback(() => {
      return isMobile ? setOpenMobile(open => !open)
        : setOpen(open => !open);
    }, [isMobile, setOpen, setOpenMobile]);

    const state = open ? 'expanded' : 'collapsed';

    const value = useMemo(
      () => ({
        state,
        open,
        setOpen,
        isMobile,
        openMobile,
        setOpenMobile,
        toggleSideNav,
      }),
      [state, open, setOpen, isMobile, openMobile, setOpenMobile, toggleSideNav]
    );

    return (
      <SideNavContext.Provider value={value}>
        <div
          ref={ref}
          className={cn(
            'lds-sidenav-product-wrapper',
            className
          )}
          {...props}
        >
          {children}
        </div>
      </SideNavContext.Provider>
    );
  }
);

Provider.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
  defaultOpen: PropTypes.bool,
  open: PropTypes.bool,
  onOpenChange: PropTypes.func,
  mobileBreakpoint: PropTypes.number,
};

Provider.displayName = 'Provider';

export default Provider;
