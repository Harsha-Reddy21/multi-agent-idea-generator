import { forwardRef, useState } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import LdsIcon from '../LdsIcon/index.jsx';

// JSdoc type definitions
/**
 * @typedef AvatarProps
 * @property {React.ReactNode} [children] - Elements to render on top of avatar
 * @property {string} [className] - Additional CSS classes
 * @property {string|number} [size] - Size of the avatar
 * @property {string} [src] - Image URL for avatar
 * @property {string} [alt] - Alt text for avatar image
 * @property {string} [initials] - Two character initials to display
 * @property {string} [icon='user-circle-fill'] - Icon to show on fallback (phosphor set)
 * @property {React.ReactNode} [fallback] - Custom fallback element
 * @property {boolean} [showFallback=false] - Whether to show initials on image load error
 */
const Avatar = forwardRef(
  /**
   * Avatar sub-component for LdsSideNavProduct
   * @param {AvatarProps} props - Component props
   * @param {React.ForwardedRef<HTMLDivElement>} ref - Forwarded ref
   * @returns {React.JSX.Element} - The rendered <div> containing the avatar
   */
  function Avatar({
    children,
    className,
    size,
    src,
    alt,
    initials,
    icon = 'user-circle-fill',
    fallback,
    showFallback = false,
    style: userStyle,
    ...props
  }, ref) {
    const [imageError, setImageError] = useState(false);

    const style = {
      ...userStyle,
      ...(size !== undefined && {
        '--lds-spacing-sidenav-avatar-size': getSizeWithUnit(size),
      }),
    };

    const shouldShowFallback = !src || (showFallback && imageError);

    const renderFallback = () => {
      if (fallback) {
        return fallback;
      }

      if (initials) {
        return (
          <span className="lds-sidenav-product-avatar-initials">
            {initials}
          </span>
        );
      }

      return (
        <LdsIcon
          decorative
          inline
          name={icon}
          className="lds-sidenav-product-avatar-icon"
        />
      );
    };

    return (
      <div
        ref={ref}
        className={cn(
          'lds-sidenav-product-avatar',
          className
        )}
        style={style}
        {...props}
      >
        {shouldShowFallback ? (
          renderFallback()
        ) : (
          <span className="lds-sidenav-product-avatar-image">
            <img
              src={src}
              alt={alt}
              onError={() => setImageError(true)}
            />
          </span>
        )}
        {children && (
          <div className="lds-sidenav-product-avatar-content">
            {children}
          </div>
        )}
      </div>
    );
  }
);

// JSdoc type definitions
/**
 * Ensures the size value has a unit.
 * @param {string|number} size
 * @returns {string}
 */
const getSizeWithUnit = (size) => {
  // If it's a number or a string that's a number, add 'px'
  if (!isNaN(size)) return `${size}px`;

  // If it already has a unit (px, rem, em, etc.), return as is
  if (typeof size === 'string' && /^\d+(\.\d+)?(px|rem|em|%|vh|vw)$/.test(size)) {
    return size;
  }

  // Default fallback - add px
  return `${size}px`;
};

Avatar.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  size: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.string,
  ]),
  src: PropTypes.string,
  alt: PropTypes.string,
  initials: (props, propName, componentName) => {
    if (props[propName] && props[propName].length > 2) {
      return new Error(
        `Invalid prop '${propName}' supplied to '${componentName}'. `
        + 'Initials must not exceed 2 characters.'
      );
    }
    return null;
  },
  icon: PropTypes.string,
  showFallback: PropTypes.bool,
  fallback: PropTypes.node,
  style: PropTypes.object,
};

Avatar.displayName = 'Avatar';

export default Avatar;
