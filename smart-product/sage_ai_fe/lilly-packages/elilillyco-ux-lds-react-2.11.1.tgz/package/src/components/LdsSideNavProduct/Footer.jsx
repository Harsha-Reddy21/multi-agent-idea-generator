import { forwardRef } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

// JSdoc type definitions
/**
 * @typedef FooterProps
 * @property {React.ReactNode} children - Child elements
 * @property {string} [className] - Additional classes to add to the component.
 */
const Footer = forwardRef(
  /**
   * Footer sub-component for LdsSideNavProduct
   * @param {FooterProps} props - Component props
   * @param {React.ForwardedRef<HTMLDivElement>} ref - Forwarded ref
   * @returns {React.JSX.Element} - The rendered <div> container
   */
  function Footer({
    children,
    className,
    ...props
  }, ref) {
    return (
      <div
        ref={ref}
        className={cn(
          'lds-sidenav-product-footer',
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);

Footer.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
};

Footer.displayName = 'Footer';

export default Footer;
