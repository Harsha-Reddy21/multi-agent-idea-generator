import { forwardRef, useContext } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import useSlots from '../hooks/useSlots.jsx';
import useCollapse from '../hooks/useCollapse.jsx';
import { ActionListContext, NestingContext } from '../contexts/ActionListContext.jsx';
import { LeadingVisual, TrailingVisual, itemCollapseSlotConfig } from './Slots.jsx';
import Button from '../Action/Button.jsx';
import Subnav from './Subnav.jsx';
import LdsIcon from '../../LdsIcon/index.jsx';

// JSdoc type definitions
/**
 * @typedef ItemCollapseSlots
 * @property {React.ReactNode} Content - Content for the collapse button
 * @property {import('../shared/Visuals').LeadingVisual} [LeadingVisual] - Visual element at the start, placed in the button's leading visual area
 * @property {import('../shared/Visuals').TrailingVisual} [TrailingVisual] - Visual element at the end, placed in the button's trailing visual area
 * @property {import('./Subnav').SubnavComponent} Subnav - Nested content, placed next to the button
 */
/**
 * @typedef ItemCollapseBaseProps
 * @property {ItemCollapseSlots} children - Child elements, must include exactly one Subnav component
 * @property {string} [className] - Additional CSS classes added to the li element
 * @property {boolean} [defaultOpen] - Whether the collapse is open by default
 * @property {boolean} [open] - Open state (controlled)
 * @property {function} [onOpenChange] - Callback when the open state changes
 */
/**
 * @typedef {Omit<import('../Action/Button').ButtonProps, 'children' | '_PrivateRenderWrapper' | 'className' | 'isActive'> & ItemCollapseBaseProps} ItemCollapseProps
 */
/** @typedef {React.ForwardRefExoticComponent<ItemCollapseProps & React.RefAttributes<HTMLButtonElement>>} ItemCollapseComponent */
export const ItemCollapse = forwardRef(
  /**
   * List item collapse component for LdsSideNavProduct
   * @param {ItemCollapseProps} props - Component props
   * @param {React.ForwardedRef<HTMLButtonElement>} ref - Forwarded ref
   * @returns {React.JSX.Element} - The rendered <li> with collapsible button
   */
  function ItemCollapse({
    children,
    className,
    defaultOpen,
    open,
    onOpenChange,
    ...props
  }, ref) {
    const { defaultLeadingVisual } = useContext(ActionListContext);
    const { level = 0 } = useContext(NestingContext);

    const { isOpen, onOpenChange: handleOpenChange, collapseId } = useCollapse({
      defaultOpen,
      open,
      onOpenChange,
    });

    const [{ subnav, ...slots }, childrenWithoutSlots] = useSlots(children, itemCollapseSlotConfig);

    const wrappedDefaultLeadingVisual = level === 0 && defaultLeadingVisual ? (
      <LeadingVisual>{defaultLeadingVisual}</LeadingVisual>
    ) : null;

    const collapseState = isOpen ? 'expanded' : 'collapsed';

    const trailingVisual = slots.trailingVisual || (
      <TrailingVisual>
        <LdsIcon
          className="lds-sidenav-product-expand-icon"
          name="CaretDown"
          decorative
          inline
          data-state={collapseState}
        />
      </TrailingVisual>
    );

    const handleToggle = () => {
      handleOpenChange(!isOpen);
    };

    return (
      <li
        className={cn(
          'lds-sidenav-product-action-list-item',
          'lds-sidenav-product-action-list-item-collapse',
          { 'is-hidden-on-sidenav-collapse-icon': !slots.leadingVisual && !defaultLeadingVisual },
          className
        )
        }
      >
        <div
          className='lds-sidenav-product-action-list-item-collapse-container'
          data-state={collapseState}
        >
          <Button
            {...props}
            ref={ref}
            className='lds-sidenav-product-action-list-item-collapse-toggle-action'
            aria-expanded={isOpen}
            aria-controls={collapseId}
            onClick={handleToggle}
            _PrivateSlotConfig={itemCollapseSlotConfig}
          >
            {level === 0 && (slots.leadingVisual || wrappedDefaultLeadingVisual)}
            {childrenWithoutSlots}
            {trailingVisual}
          </Button>

          <div
            className='lds-sidenav-product-action-list-item-collapse-content'
            id={collapseId}
            data-state={collapseState}
            hidden={!isOpen}
          >
            {subnav && (
              <Subnav
                {...subnav.props}
              >
                {subnav.props.children}
              </Subnav>
            )}
          </div>
        </div>
      </li>
    );
  }
);

// Remove unused variables by using object rest operator
const {
  // eslint-disable-next-line no-unused-vars
  children, _PrivateRenderWrapper, isActive, ...buttonPropTypes
} = Button.propTypes;

ItemCollapse.propTypes = {
  ...buttonPropTypes,
  children: PropTypes.oneOfType([
    PropTypes.node,
    PropTypes.shape({
      leadingVisual: PropTypes.instanceOf(LeadingVisual),
      trailingVisual: PropTypes.instanceOf(TrailingVisual),
      subnav: PropTypes.instanceOf(Subnav).isRequired,
    }),
  ]).isRequired,
  defaultOpen: PropTypes.bool,
  open: PropTypes.bool,
  onOpenChange: PropTypes.func,
};

/** @type {ItemCollapseComponent} */
export default ItemCollapse;
