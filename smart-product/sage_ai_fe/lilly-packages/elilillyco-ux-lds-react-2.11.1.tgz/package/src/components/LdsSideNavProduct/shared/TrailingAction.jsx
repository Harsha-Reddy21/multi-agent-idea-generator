import { forwardRef } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import LdsButton from '../../LdsButton/index.jsx';

// JSdoc type definitions
/**
 * @typedef {Omit<import('../../LdsButton').LdsButtonProps, 'icon' | 'iconOnly' | 'disableIconSpace' | 'iconPosition' | 'linkButton'>} LdsButtonBaseProps
 */
/**
 * @typedef TrailingActionProps
 * @property {string} label - Accessible name for button
 * @property {string} icon - Setting a truthy string value enables the "Easy Icon" function; the value must be the name of a valid LDS Icon
 */
/** @typedef {React.ForwardRefExoticComponent<TrailingActionProps & React.RefAttributes<HTMLButtonElement>>} TrailingActionComponent */
export const TrailingAction = forwardRef(
  /**
   * TrailingAction sub-component for LdsSideNavProduct
   * @param {TrailingActionProps & LdsButtonBaseProps} props - Component props
   * @param {import('react').ForwardedRef<HTMLButtonElement>} ref - Forwarded ref
   */
  function TrailingAction({
    className,
    label,
    icon,
    ...props
  }, ref) {
    return (
      <LdsButton
        ref={ref}
        aria-label={label}
        classes={cn(
          'action-ghost',
          className
        )}
        icon={icon}
        iconOnly
        disableRipple
        {...props}
      />
    );
  }
);

TrailingAction.propTypes = {
  className: PropTypes.string,
  label: PropTypes.string.isRequired,
  icon: PropTypes.string.isRequired,
};

/** @type {TrailingActionComponent} */
export default TrailingAction;
