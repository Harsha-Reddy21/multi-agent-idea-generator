import {
  forwardRef, useEffect, useRef, useCallback, useState, useContext
} from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import { SideNavContext } from './contexts/SideNavContext.jsx';
import Provider from './Provider.jsx';
import useSideNav from './hooks/useSideNav.jsx';
import Header from './Header.jsx';
import Footer from './Footer.jsx';
import Content from './Content.jsx';
import Divider from './Divider.jsx';
import Group from './Group.jsx';
import Heading from './Heading.jsx';
import Avatar from './Avatar.jsx';
import ToggleButton from './ToggleButton.jsx';
import Action from './Action/index.jsx';
import ActionList from './ActionList/index.jsx';

// JSdoc type definitions
/**
 * @typedef LdsSideNavProductProps
 * @property {React.ReactNode} children - Child elements
 * @property {string} [className] - Additional CSS classes
 * @property {'icon'} [collapsible='icon'] - Type of collapse behavior
 */
const LdsSideNavProduct = forwardRef(
  /**
  * LdsSideNavProduct component
  * @param {LdsSideNavProductProps} props - Component props
  * @param {React.ForwardedRef<HTMLDivElement>} ref - Forwarded ref
  * @returns {React.JSX.Element} - The rendered side-navigation container
  */
  function LdsSideNavProduct({
    children,
    className,
    collapsible = 'icon',
    ...props
  }, ref) {
    const {
      state, isMobile, openMobile, setOpenMobile,
    } = useContext(SideNavContext);
    /**
     * Dialog status: animation and collapsed state
     * @type {[{
     *   animation: 'closed' | 'opening' | 'open' | 'closing',
     *   state: 'expanded' | 'collapsed'
     * }, React.Dispatch<React.SetStateAction<{
     *   animation: 'closed' | 'opening' | 'open' | 'closing',
     *   state: 'expanded' | 'collapsed'
     * }>>]}
     */
    const [dialogStatus, setDialogStatus] = useState({
      animation: 'closed',
      state: 'collapsed',
    });
    const dialogRef = useRef();
    const internalRef = useRef();
    const componentRef = ref || internalRef;

    useEffect(() => {
      if (!isMobile || !dialogRef.current) return;
      if (openMobile && !dialogRef.current.open) {
        dialogRef.current.showModal();
        setDialogStatus({
          animation: 'opening',
          state: 'expanded',
        });
      } else if (!openMobile && dialogRef.current.open) {
        setDialogStatus(prev => ({
          ...prev,
          animation: 'closing',
        }));
      }
    }, [openMobile, isMobile]);

    const handleAnimationEnd = useCallback(() => {
      if (dialogStatus.animation === 'closing') {
        dialogRef.current?.close();
        requestAnimationFrame(() => {
          setDialogStatus({
            animation: 'closed',
            state: 'collapsed',
          });
        });
      } else if (dialogStatus.animation === 'opening') {
        requestAnimationFrame(() => {
          setDialogStatus(prev => ({
            ...prev,
            animation: 'open',
          }));
        });
      }
    }, [dialogStatus.animation]);

    const handleDialogClose = useCallback(() => {
      if (!dialogRef.current) return;
      setOpenMobile(false);
    }, [setOpenMobile]);

    if (isMobile) {
      return (
        <dialog
          ref={dialogRef}
          className={cn(
            'lds-sidenav-product-dialog',
            className
          )}
          data-state={dialogStatus.animation}
          onClose={handleDialogClose}
          onCancel={handleDialogClose}
          onKeyDown={(e) => {
            if (e.key === 'Escape') {
              e.preventDefault();
              handleDialogClose();
            }
          }}
        >
          <div
            className='lds-sidenav-product-dialog-container'
            onAnimationEnd={handleAnimationEnd}
          >
            <div
              className='lds-sidenav-product'
              data-state={dialogStatus.state}
              data-mobile
            >
              {children}
            </div>
          </div>
          <div
            className='lds-sidenav-product-dialog-overlay'
            onClick={handleDialogClose}
          />
        </dialog>
      );
    }

    return (
      <aside
        ref={componentRef}
        className={cn(
          'lds-sidenav-product',
          className
        )}
        data-state={state}
        data-collapsible={collapsible}
        {...props}
      >
      <div className='lds-sidenav-product-spacer'/>
      <div className='lds-sidenav-product-container'>
        <div className='lds-sidenav-product-container-inner'>
          {children}
        </div>
      </div>
      </aside>
    );
  }
);

LdsSideNavProduct.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  collapsible: PropTypes.oneOf(['icon']),
};

LdsSideNavProduct.displayName = 'LdsSideNavProduct';

LdsSideNavProduct.Provider = Provider;
LdsSideNavProduct.useSideNav = useSideNav;
LdsSideNavProduct.Header = Header;
LdsSideNavProduct.Footer = Footer;
LdsSideNavProduct.Content = Content;
LdsSideNavProduct.Group = Group;
LdsSideNavProduct.Heading = Heading;
LdsSideNavProduct.Avatar = Avatar;
LdsSideNavProduct.Divider = Divider;
LdsSideNavProduct.Action = Action;
LdsSideNavProduct.ActionList = ActionList;
LdsSideNavProduct.ToggleButton = ToggleButton;

export default LdsSideNavProduct;
