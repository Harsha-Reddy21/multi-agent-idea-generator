import { Children, isValidElement } from 'react';
import PropTypes from 'prop-types';

// JSdoc type definitions
/**
 * @typedef {Object.<string, React.ComponentType | { Component: React.ComponentType, maxCount?: number }>} SlotsConfig
 */
/**
 * @typedef {Object} SlotReturn
 * @property {Object.<string, React.ReactElement | React.ReactElement[]>} slots - Mapped slot elements
 * @property {React.ReactNode[]} childrenWithoutSlots - Children that don't match any slots
 */
/**
 * Hook to organize children into named slots with optional count limits
 * @param {React.ReactNode} children - Children to organize into slots
 * @param {SlotsConfig} config - Configuration object mapping slot names to components
 * @returns {[Object.<string, React.ReactElement | React.ReactElement[]>, React.ReactNode[]]}
 */
const useSlots = (children, config) => {
  // Create initial slots object with arrays for multi-slots and undefined for single slots
  const slots = Object.entries(config).reduce((acc, [key, value]) => {
    // Handle both simple Component and {Component, maxCount} configs
    const isObject = typeof value === 'object';
    const maxCount = isObject ? value.maxCount : 1;

    // Initialize as array if maxCount > 1, otherwise undefined
    acc[key] = maxCount > 1 ? [] : undefined;
    return acc;
  }, {});

  // Store children that don't match any slot configuration
  const childrenWithoutSlots = [];

  // Process each child element
  Children.forEach(children, child => {
    // If not a valid React element (string, number, etc), add to non-slot children
    if (!isValidElement(child)) {
      childrenWithoutSlots.push(child);
      return;
    }

    // Find matching slot configuration by comparing child.type with Component
    // eslint-disable-next-line no-unused-vars
    const [slotKey, slotConfig] = Object.entries(config).find(([slotName, cfg]) => {
      const Component = typeof cfg === 'object' ? cfg.Component : cfg;
      return child.type === Component;
    }) || [];

    // If no matching slot found, add to non-slot children
    if (!slotKey) {
      childrenWithoutSlots.push(child);
      return;
    }

    // Get max allowed elements for this slot
    const maxCount = typeof slotConfig === 'object' ? slotConfig.maxCount : 1;

    // Handle single-element slots (maxCount === 1)
    if (maxCount === 1) {
      if (!slots[slotKey]) {
        slots[slotKey] = child;
      } else {
        // eslint-disable-next-line no-console
        console.warn(`Found duplicate "${slotKey}" slot. Only the first will be rendered.`);
      }

    // Handle multi-element slots (maxCount > 1)
    } else {
      if (!Array.isArray(slots[slotKey])) {
        slots[slotKey] = [];
      }

      // Add child if under maxCount limit
      if (slots[slotKey].length < maxCount) {
        slots[slotKey].push(child);
      }
    }
  });

  // Return tuple of [organized slots, remaining children]
  return [slots, childrenWithoutSlots];
};

useSlots.propTypes = {
  children: PropTypes.node,
  config: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.elementType,
      PropTypes.shape({
        Component: PropTypes.elementType.isRequired,
        maxCount: PropTypes.number,
      }),
    ])
  ).isRequired,
};

export default useSlots;
export const useSlotsPropTypes = useSlots.propTypes;
