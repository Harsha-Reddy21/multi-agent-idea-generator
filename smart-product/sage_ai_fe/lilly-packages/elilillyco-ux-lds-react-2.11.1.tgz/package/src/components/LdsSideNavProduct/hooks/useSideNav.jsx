import { useContext } from 'react';
import { SideNavContext } from '../contexts/SideNavContext.jsx';

// JSdoc type definitions
/**
 * Hook to access and control the sideNav state
 * @returns {import('../contexts/SideNavContext').SideNavContext}
 * @throws {Error} When used outside of LdsSideNavProduct.Provider on client-side
 */
const useSideNav = () => {
  const context = useContext(SideNavContext);

  if (!context || context.state === undefined) {
    throw new Error('useSideNav must be used within a LdsSideNavProduct.Provider');
  }

  return context;
};

export default useSideNav;
