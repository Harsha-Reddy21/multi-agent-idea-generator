import Button from './Button.jsx';
import Link from './Link.jsx';
import { LeadingVisual, TrailingVisual, TrailingAction } from './Slots.jsx';

const Action = Button;

Action.Link = Link;
Action.LeadingVisual = LeadingVisual;
Action.TrailingVisual = TrailingVisual;
Action.TrailingAction = TrailingAction;

Action.displayName = 'Action';
Action.Link.displayName = 'Action.Link';
Action.LeadingVisual.displayName = 'Action.LeadingVisual';
Action.TrailingVisual.displayName = 'Action.TrailingVisual';
Action.TrailingAction.displayName = 'ActionList.TrailingAction';

export default Action;
