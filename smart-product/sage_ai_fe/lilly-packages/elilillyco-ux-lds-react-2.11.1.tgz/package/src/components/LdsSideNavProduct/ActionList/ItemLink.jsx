import { forwardRef, useContext } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import { ActionListContext, NestingContext } from '../contexts/ActionListContext.jsx';
import useSlots from '../hooks/useSlots.jsx';
import { LeadingVisual, TrailingVisual, itemSlotConfig } from './Slots.jsx';
import Link from '../Action/Link.jsx';

// JSdoc type definitions
/**
 * @typedef ItemLinkBaseProps
 * @property {string} [className] - Additional CSS classes added to the li element
 */
/**
 * @typedef {Omit<import('../Action/Link').LinkProps, 'className'> & ItemLinkBaseProps} ItemLinkProps
 */
/** @typedef {React.ForwardRefExoticComponent<ItemLinkProps & React.RefAttributes<HTMLAnchorElement>>} ItemLinkComponent */
const ItemLink = forwardRef(
  /**
   * List item link sub-component for LdsSideNavProduct
   * @param {ItemLinkProps} props - Component props
   * @param {React.ForwardedRef<HTMLAnchorElement>} ref - Forwarded ref
   * @returns {React.JSX.Element} - The rendered <li> with link
   */
  function ItemLink({
    children,
    className,
    ...props
  }, ref) {
    const {
      defaultLeadingVisual,
      defaultTrailingVisual,
    } = useContext(ActionListContext);
    const { level = 0 } = useContext(NestingContext);

    const [slots, childrenWithoutSlots] = useSlots(children, itemSlotConfig);

    const wrappedDefaultLeadingVisual = level === 0 && defaultLeadingVisual ? (
      <LeadingVisual>{defaultLeadingVisual}</LeadingVisual>
    ) : null;

    const wrappedDefaultTrailingVisual = level === 0 && defaultTrailingVisual ? (
      <TrailingVisual>{defaultTrailingVisual}</TrailingVisual>
    ) : null;

    return (
      <li
        className={cn(
          'lds-sidenav-product-action-list-item',
          'lds-sidenav-product-action-list-item-link',
          { 'is-hidden-on-sidenav-collapse-icon': !slots.leadingVisual && !defaultLeadingVisual },
          className
        )}
      >
        <Link
          ref={ref}
          className='lds-sidenav-product-action-list-item-action-link'
          _PrivateSlotConfig={itemSlotConfig}
          {...props}
        >
          {level === 0 && (slots.leadingVisual || wrappedDefaultLeadingVisual)}
          {childrenWithoutSlots}
          {level === 0 && (slots.trailingVisual || wrappedDefaultTrailingVisual)}
          {slots.trailingAction}
        </Link>
      </li>
    );
  }
);

ItemLink.propTypes = {
  ...Link.propTypes,
  className: PropTypes.string,
};

/** @type {ItemLinkComponent} */
export default ItemLink;
