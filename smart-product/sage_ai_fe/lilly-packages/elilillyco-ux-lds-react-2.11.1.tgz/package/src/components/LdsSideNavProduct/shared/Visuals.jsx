import PropTypes from 'prop-types';
import cn from 'classnames';

// JSdoc type definitions
/**
 * LeadingVisual sub-component for LdsSideNavProduct
 * Renders a visual element at the start of an action
 * @param {Object} props - Component props
 * @param {React.ReactNode} props.children - The content to be rendered
 * @param {string} [className] - Additional CSS classes
 * @param {boolean} [props.hideOnExpand] - Whether to hide the visual when expanded
 */
export const LeadingVisual = ({ children, className, hideOnExpand }) => (
  <span
    className={cn(
      'lds-sidenav-product-leading-visual',
      { 'is-hidden-on-sidenav-expand': hideOnExpand },
      className
    )}
  >
    {children}
  </span>
);

// JSdoc type definitions
/**
 * TrailingVisual sub-component for LdsSideNavProduct
 * Renders a visual element at the end of an action
 * @param {Object} props - Component props
 * @param {string} [className] - Additional CSS classes
 * @param {React.ReactNode} props.children - The content to be rendered
 */
export const TrailingVisual = ({ children, className }) => (
  <span
    className={cn(
      'lds-sidenav-product-trailing-visual',
      className
    )}
  >
    {children}
  </span>
);

LeadingVisual.propTypes = {
  children: PropTypes.node.isRequired,
  hideOnExpand: PropTypes.bool,
};

TrailingVisual.propTypes = {
  children: PropTypes.node.isRequired,
};
