import {
  useState, useCallback, useMemo, useId
} from 'react';
import PropTypes from 'prop-types';

// JSdoc type definitions
/**
 * @typedef CollapseProps
 * @property {boolean} [defaultOpen=false] - Default open state when uncontrolled
 * @property {boolean} [open] - Controlled open state
 * @property {(open: boolean) => void} [onOpenChange] - Callback when open state changes
 */
/**
 * @typedef CollapseReturn
 * @property {boolean} isOpen - Current open state
 * @property {(value: boolean) => void} onOpenChange - Function to update open state
 * @property {string} collapseId - Unique ID for collapse section
 */
/**
 * Hook to handle collapse/expand functionality with controlled/uncontrolled modes
 * @param {CollapseProps} props
 * @returns {CollapseReturn} Collapse state and handlers
 */
export const useCollapse = ({
  defaultOpen = false,
  open: openProp,
  onOpenChange,
} = {}) => {
  const [uncontrolledOpen, setUncontrolledOpen] = useState(defaultOpen);
  const isOpen = openProp !== undefined ? openProp : uncontrolledOpen;
  const collapseId = useId();

  const handleOpenChange = useCallback((value) => {
    if (openProp === undefined) setUncontrolledOpen(value);
    onOpenChange?.(value);
  }, [openProp, onOpenChange]);

  return useMemo(() => ({
    isOpen,
    onOpenChange: handleOpenChange,
    collapseId,
  }), [isOpen, handleOpenChange, collapseId]);
};

useCollapse.propTypes = {
  defaultOpen: PropTypes.bool,
  open: PropTypes.bool,
  onOpenChange: PropTypes.func,
};

export default useCollapse;
