import { forwardRef, useContext } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import LdsButton from '../LdsButton/index.jsx';
import { SideNavContext } from './contexts/SideNavContext.jsx';

// JSdoc type definitions
/**
 * @typedef {Omit<import('../LdsButton').LdsButtonProps, 'iconOnly' | 'linkButton' | 'onClick'>} ToggleButtonBaseProps
 */
/**
 * @typedef ToggleButtonCustomProps
 * @property {string} [className] - Additional CSS classes
 * @property {string} [collapsedIcon] - Icon (phosphor set) to show when collapsed
 * @property {string} [expandedIcon] - Icon (phosphor set) to show when expanded
 * @property {string} label - Accessible name for button
 * @property {string} [onClick] - Click handler
 */
const ToggleButton = forwardRef(
  /**
   * ToggleButton sub-component for LdsSideNavProduct
   * @param {ToggleButtonBaseProps & ToggleButtonCustomProps} props - Component props
   * @param {React.ForwardedRef<HTMLButtonElement>} ref - Forwarded ref
   * @returns {React.JSX.Element} - The rendered LdsButton
   */
  function ToggleButton({
    className,
    collapsedIcon = 'list',
    expandedIcon = 'text-outdent',
    label,
    onClick,
    ...props
  }, ref) {
    const {
      toggleSideNav, open, openMobile, isMobile,
    } = useContext(SideNavContext);

    const handleClick = (event) => {
      if (onClick) onClick(event);
      toggleSideNav();
    };

    const isExpanded = isMobile ? openMobile : open;

    return (
      <LdsButton
        ref={ref}
        className={cn(
          'action-ghost compact',
          'lds-sidenav-product-toggle-button',
          className
        )}
        icon={isExpanded ? expandedIcon : collapsedIcon}
        iconOnly
        onClick={handleClick}
        aria-label={label || undefined}
        {...props}
      />
    );
  }
);

ToggleButton.propTypes = {
  className: PropTypes.string,
  collapsedIcon: PropTypes.string,
  expandedIcon: PropTypes.string,
  label: PropTypes.string.isRequired,
  onClick: PropTypes.func,
};

ToggleButton.displayName = 'ToggleButton';

export default ToggleButton;
