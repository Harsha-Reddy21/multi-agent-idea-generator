import { forwardRef, useContext } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import { NestingContext } from '../contexts/ActionListContext.jsx';
import { SideNavContext } from '../contexts/SideNavContext.jsx';

// JSdoc type definitions
/**
 * @typedef SubnavSlots
 * @property {React.ReactNode} [Content] - A React node to render as content
 * @property {import('./Item').ItemComponent} [Item] - An instance of the `Item` component
 * @property {import('./ItemLink').ItemLinkComponent} [ItemLink] - An instance of the `ItemLink` component
 * @property {import('./ItemCollapse').ItemCollapseComponent} [ItemCollapse] - An instance of the `ItemCollapse` component
 * @property {Array<React.ReactNode | import('./Item').ItemComponent | import('./ItemLink').ItemLinkComponent | import('./ItemCollapse').ItemCollapseComponent>} [childrenArray] - An array of allowed children types
 */
/**
 * @typedef SubnavProps
 * @property {SubnavSlots} children - Child elements to be rendered within the sub-navigation
 * @property {string} [className] - Additional CSS classes to the ul element
 */
/** @typedef {React.ForwardRefExoticComponent<SubnavProps & React.RefAttributes<HTMLUListElement>>} SubnavComponent */
export const Subnav = forwardRef(
  /**
   * List subnav sub-component for LdsSideNavProduct
   * @param {SubnavProps} props - Component props
   * @param {React.ForwardedRef<HTMLUListElement>} ref - Forwarded ref
   * @returns {React.JSX.Element} - The rendered <ul>
   */
  function Subnav({
    children,
    className,
    ...props
  }, ref) {
    const { level = 0 } = useContext(NestingContext);
    const { state } = useContext(SideNavContext);
    const isCollapsed = state === 'collapsed';

    return (
      <NestingContext.Provider value={{ level: level + 1 }}>
        <ul
          ref={ref}
          className={cn(
            'lds-sidenav-product-action-list-sub',
            { 'is-hidden-on-sidenav-collapse-icon': isCollapsed },
            className
          )}
          {...props}
        >
          {children}
        </ul>
      </NestingContext.Provider>
    );
  }
);

Subnav.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
};

/** @type {SubnavComponent} */
export default Subnav;
