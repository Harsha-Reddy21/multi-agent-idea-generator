import cn from 'classnames';
import { useEffect, useContext, useState } from 'react';

import createRipple from '../../../util/createRipple.js';
import { isLinkActive } from '../helpers.js';
import { SideNavContext } from '../SideNavContext.jsx';
import DynamicLink from './DynamicLink.jsx';

export default function JumpMenu({
  activeLabel,
  children,
  href,
  label,
  linkProps,
  to,
}) {
  const {
    currentRoute,
    prefersReducedMotion,
    routerBasePath,
    routerLink,
    setUrlHash,
  } = useContext(SideNavContext);
  const [isCurrent, setIsCurrent] = useState(currentRoute === href || currentRoute === to);

  const handleClick = (e) => {
    // If the user prefers reduced motion, the button is a link button, or the dev has disabled the ripple, don't create the ripple effect
    if (!prefersReducedMotion) {
      createRipple(e);
    }
    setIsCurrent(!isCurrent);
  };

  const getPageAnchorElems = () => {
    const anchorElems = Array.from(document.querySelectorAll('#lds-side-nav-menu a[href^="#"]')).map((item) => {
      return document.getElementById(item.href.split('#')[1]);
    }).filter(element => element !== null); // remove null values
    return anchorElems;
  };

  useEffect(() => {
    const pageAnchorElems = getPageAnchorElems();

    const config = {
      root: null,
      rootMargin: '0px',
      threshold: 0.5,
    };

    let observer = new IntersectionObserver(onChange, config);
    pageAnchorElems.forEach(anchor => observer.observe(anchor));

    function onChange(changes) {
      changes.forEach(change => {
        if (change.intersectionRatio > 0) {
          // update url hash, which automatically updates the active link in sidenav
          setUrlHash(change.target.id);
        }
      });
      return () => pageAnchorElems.length && pageAnchorElems.forEach(anchor => observer.unobserve(anchor));
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentRoute]);

  useEffect(() => {
    const isActive = isLinkActive(currentRoute, href, to, routerBasePath);
    setIsCurrent(isActive);
  }, [currentRoute, href, routerBasePath, setIsCurrent, to]);

  return (
    <li
      className={cn(
        'side-nav-item',
        'has-jump-menu',
        {
          active: isCurrent,
        }
      )}
    >
      <DynamicLink
        handleClick={handleClick}
        href={href}
        linkProps={linkProps}
        routerLink={routerLink}
        to={to}
      >
        {isCurrent ? activeLabel || label : label}
      </DynamicLink>
      {isCurrent
        && <ul
          className={cn(
            'side-nav-menu',
            'side-nav-jump-menu'
          )}
        >
          {children}
        </ul>
      }
    </li>
  );
}
