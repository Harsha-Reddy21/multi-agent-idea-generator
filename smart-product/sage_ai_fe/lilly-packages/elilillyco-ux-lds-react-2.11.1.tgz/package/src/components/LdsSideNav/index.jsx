import cn from 'classnames';
import { useState } from 'react';

import usePrefersReducedMotion from '../../hooks/usePrefersReducedMotion.js';
import { SideNavContextProvider } from './SideNavContext.jsx';
import removeTrailingSlash from '../../util/removeTrailingSlash.js';

// SideNav subcomponents for export
import PageContentCol from './PageContentCol.jsx';
import MenuCol from './MenuCol.jsx';
import Divider from './SideNavMenuObjects/Divider.jsx';
import Link from './SideNavMenuObjects/Link.jsx';
import Menu from './SideNavMenuObjects/Menu.jsx';
import JumpMenu from './SideNavMenuObjects/JumpMenu.jsx';
import JumpMenuLink from './SideNavMenuObjects/JumpMenuLink.jsx';

// JSdoc type definitions
/**
 * @typedef LdsSideNavProps
 * @property {React.ReactNode} [children] - The children of the component. Used to define custom content.
 * @property {string} [className] - Additional classes to add to the component
 * @property {React.JSX.Element} [contactLilly] - The contact lilly component
 * @property {string} [currentRoute] - The current route
 * @property {React.JSX.Element} [languageSelector] - The language selector component
 * @property {string} [navContainerAriaLabel] - The aria label for the nav container
 * @property {React.JSX.Element} [routerLink] - The router link component
 * @property {string} [routerBasePath] - The router base path
 * @property {boolean} [showUtilityLogo] - Whether to show the utility logo
 * @property {string} [sideNavCloseText] - The text for the close side nav button
 * @property {string} [sideNavCollapsedText] - The text for the collapsed side nav button
 * @property {string} [sideNavExpandedText] - The text for the expanded side nav button
 * @property {string} [sideNavMenuText] - The text for the side nav menu
 * @property {Array.<Object>} [utilityMenuLinks] - The utility menu links
 * @property {React.ReactNode[]} [utilityMenuCustomLinkItems] - The custom utility menu link items
 * @property {string} [utilityMenuCustomLinkItemsPosition] - The position of the custom utility menu link items. Accepts: before, after
 * @property {boolean} [showSSO] - Whether the header should show SSO content
 * @property {boolean} [ssoIsLoggedIn] - Whether the user is logged in and info can be displayed in sso dropdown
 * @property {string} [ssoSignInText] - Sign in text for the SSO dropdown
 * @property {Object} [ssoSignInLinkProps] - Object of props to apply to the sign in link. (href, aria-label...)
 * @property {string} [ssoOrText] - Text to display between sign in and register links
 * @property {string} [ssoRegisterText] - Text to show for register link
 * @property {Object} [ssoRegisterLinkProps] - Object of props to apply to the sign in link.
 * @property {string} [ssoWelcomeText] - Welcome message to display next to logged in users name in the utility nav
 * @property {string} [ssoDisplayName] - Name of logged in user to display in utility nav. Should be set as First Name
 * @property {boolean} [ssoIconOnly] - Set to true to make the sso area in the utility menu only show an icon and no user name
 * @property {string} [ssoSignOutText] - Text to show for sign out button
 * @property {Object} [ssoSignOutButtonProps] - Object of props to apply to the sign out button (onClick)
 * @property {string} [ssoMyProfileText] - Text to show for the my profile link
 * @property {Object} [ssoMyProfileLinkProps] - Object of props to apply to the my profile link.
 * @property {string} [ssoEmail] - Email address of the signed in user
 * @property {string} [ssoFullName] - Full name of logged in user to display in the open SSO menu
 * @property {React.JSX.Element} [ssoContent] - Optional custom JSX content to insert into the SSO dropdown
 * @property {string} [ssoMobileCloseAriaLabel] - String for aria-label on the mobile close button for the sso dropdown
 * @property {string} [ssoMobileCloseLabel] - Visible text to show next to close button for the mobile sso dropdown
 * @property {string} [ssoOpenedAnnouncement] - Hidden accessibility text to announce that sso dropdown has opened in mobile
 * @property {string} [ssoClosedAnnouncement] - Hidden accessibility text to announce that sso dropdown has closed in mobile
 * @property {string} [ssoUserIcon] - Image src to use for user icon
 * @property {string} [ssoMobileAccountAriaLabel] - Aria label for mobile account open button
 * @property {boolean} [search] - Whether to show the search feature
 * @property {string} [searchTerm] - The current value of the search input
 * @property {function} [setSearchTerm] - Handler to set the search term
 * @property {Array.<Object>} [searchSuggestions] - Array of search suggestion objects
 * @property {function} [searchCustomResult] - Custom render function for search suggestions
 * @property {string} [searchInputPlaceholder] - Placeholder text for the search input
 * @property {string} [searchBtnLabel] - Label for the search button
 * @property {string} [searchNoResultsText] - Text to display when there are no search results
 * @property {string} [searchAnotherSearchText] - Text to display for another search prompt
 * @property {boolean} [searchLoading] - Whether the search is loading
 * @property {string} [searchClearBtnAriaLabel] - Aria label for the clear search button
 * @property {string} [searchMobileBtnAriaLabel] - Aria label for the mobile search button
 * @property {string} [searchMobileCloseAriaLabel] - Aria label for the mobile search close button
 * @property {string} [searchMobileCloseLabel] - Label for the mobile search close button
 * @property {function} [searchOnBtnClick] - Handler for search button click. Receives (event: React.MouseEvent, value: string) as arguments, where value is the current input value.
 * @property {function} [searchOnSuggestionClick] - Handler for search suggestion click
 * @property {string} [searchSubmitBtnAriaLabel] - Aria label for the search submit button
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Additional props to add to the component
 */
/**
 * LdsSideNav component
 * @param {LdsSideNavProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
*/
export default function LdsSideNav({
  children,
  className,
  contactLilly,
  currentRoute = null,
  languageSelector,
  navContainerAriaLabel = 'primary',
  routerLink,
  routerBasePath = null,
  showUtilityLogo,
  sideNavCloseText = 'Close',
  sideNavCollapsedText = 'Menu closed',
  sideNavExpandedText = 'Menu opened',
  sideNavMenuText = 'Menu',
  // Utility Menu
  utilityMenuLinks = [],
  utilityMenuCustomLinkItems,
  utilityMenuCustomLinkItemsPosition = 'after',
  // SEARCH
  search = false,
  searchTerm,
  setSearchTerm,
  searchSuggestions,
  searchCustomResult,
  searchInputPlaceholder,
  searchBtnLabel,
  searchNoResultsText,
  searchAnotherSearchText,
  searchLoading,
  searchClearBtnAriaLabel,
  searchMobileBtnAriaLabel,
  searchMobileCloseAriaLabel,
  searchMobileCloseLabel = 'Close',
  searchOnBtnClick,
  searchOnSuggestionClick,
  searchSubmitBtnAriaLabel,
  // SSO
  showSSO = false,
  ssoClosedAnnouncement,
  ssoContent,
  ssoDisplayName = '',
  ssoEmail,
  ssoFullName,
  ssoIconAriaLabel = 'Account',
  ssoIconOnly = false,
  ssoIsLoggedIn = false,
  ssoMobileAccountAriaLabel = 'Account',
  ssoMobileCloseAriaLabel = 'Close account',
  ssoMobileCloseLabel = 'Close',
  ssoMyProfileLinkProps = {},
  ssoMyProfileText = 'My Profile',
  ssoOpenedAnnouncement,
  ssoOrText = 'or',
  ssoRegisterLinkProps = {},
  ssoRegisterText = 'Register',
  ssoSignInLinkProps = {},
  ssoSignInText = 'Sign in',
  ssoSignOutButtonProps = {},
  ssoSignOutText = 'Sign out',
  ssoUserIcon,
  ssoWelcomeText = 'Hi,',
  ...rest
}) {
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const prefersReducedMotion = usePrefersReducedMotion();

  return (
    <SideNavContextProvider
      currentRoute={removeTrailingSlash(currentRoute)}
      navContainerAriaLabel={navContainerAriaLabel}
      prefersReducedMotion={prefersReducedMotion}
      routerLink={routerLink}
      routerBasePath={routerBasePath}
      setShowMobileMenu={setShowMobileMenu}
      showMobileMenu={showMobileMenu}
      sideNavCloseText={sideNavCloseText}
      sideNavCollapsedText={sideNavCollapsedText}
      sideNavExpandedText={sideNavExpandedText}
      sideNavMenuText={sideNavMenuText}
      // Utility menui
      utilityMenuLinks={utilityMenuLinks}
      utilityMenuCustomLinkItems={utilityMenuCustomLinkItems}
      utilityMenuCustomLinkItemsPosition={utilityMenuCustomLinkItemsPosition}
      showUtilityLogo={showUtilityLogo}
      contactLilly={contactLilly}
      languageSelector={languageSelector}
      // search
      search={search}
      searchAnotherSearchText={searchAnotherSearchText}
      searchBtnLabel={searchBtnLabel}
      searchClearBtnAriaLabel={searchClearBtnAriaLabel}
      searchCustomResult={searchCustomResult}
      searchInputPlaceholder={searchInputPlaceholder}
      searchLoading={searchLoading}
      searchMobileBtnAriaLabel={searchMobileBtnAriaLabel}
      searchNoResultsText={searchNoResultsText}
      searchSuggestions={searchSuggestions}
      searchTerm={searchTerm}
      searchOnBtnClick={searchOnBtnClick}
      searchSubmitBtnAriaLabel={searchSubmitBtnAriaLabel}
      setSearchTerm={setSearchTerm}
      searchMobileCloseAriaLabel={searchMobileCloseAriaLabel}
      searchMobileCloseLabel={searchMobileCloseLabel}
      searchOnSuggestionClick={searchOnSuggestionClick}
      // SSO
      showSSO={showSSO}
      ssoSignInLinkProps={ssoSignInLinkProps}
      ssoRegisterLinkProps={ssoRegisterLinkProps}
      ssoUserIcon={ssoUserIcon}
      ssoIsLoggedIn={ssoIsLoggedIn}
      ssoWelcomeText={ssoWelcomeText}
      ssoDisplayName={ssoDisplayName}
      ssoFullName={ssoFullName}
      ssoSignOutText={ssoSignOutText}
      ssoSignOutButtonProps={ssoSignOutButtonProps}
      ssoMyProfileText={ssoMyProfileText}
      ssoMyProfileLinkProps={ssoMyProfileLinkProps}
      ssoEmail={ssoEmail}
      ssoContent={ssoContent}
      ssoIconOnly={ssoIconOnly}
      ssoMobileCloseAriaLabel={ssoMobileCloseAriaLabel}
      ssoMobileCloseLabel={ssoMobileCloseLabel}
      ssoOpenedAnnouncement={ssoOpenedAnnouncement}
      ssoClosedAnnouncement={ssoClosedAnnouncement}
      ssoMobileAccountAriaLabel={ssoMobileAccountAriaLabel}
      ssoIconAriaLabel={ssoIconAriaLabel}
      ssoOrText={ssoOrText}
      ssoRegisterText={ssoRegisterText}
      ssoSignInText={ssoSignInText}
    >
      <div
        className={cn(
          'lds-side-nav-wrapper',
          {
            expanded: showMobileMenu,
          },
          className
        )}
        {...rest}
      >
        {children}
      </div>
    </SideNavContextProvider>
  );
}

LdsSideNav.PageContent = PageContentCol;
LdsSideNav.MenuCol = MenuCol;
LdsSideNav.Divider = Divider;
LdsSideNav.Link = Link;
LdsSideNav.Menu = Menu;
LdsSideNav.JumpMenu = JumpMenu;
LdsSideNav.JumpMenuLink = JumpMenuLink;
