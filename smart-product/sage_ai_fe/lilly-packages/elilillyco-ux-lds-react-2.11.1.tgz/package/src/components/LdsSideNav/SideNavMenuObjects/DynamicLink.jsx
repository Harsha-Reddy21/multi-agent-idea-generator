import { useContext } from 'react';
import LdsIcon from '../../LdsIcon/index.jsx';
import RouterLink from './RouterLink.jsx';
import { SideNavContext } from '../SideNavContext.jsx';

export default function DynamicLink({
  ariaControls,
  children,
  external = false,
  handleClick,
  href,
  isExpanded,
  linkProps = {},
  routerLink,
  to,
}) {
  const { setShowMobileMenu } = useContext(SideNavContext);

  const handleLinkClick = (e) => {
    setShowMobileMenu(false);
    handleClick(e);
  };

  const handleButtonClick = (e) => {
    handleClick(e);
  };

  if (to) {
    return <RouterLink
        className="lds-button-base menu-button"
        handleClick={(e) => handleLinkClick(e)}
        routerLink={routerLink}
        to={to}
        {...linkProps}
      >
        {children}
        {
          external && <>&nbsp;<LdsIcon inline label="links to an external site" name="ArrowSquareOut" className="side-nav-external-icon" /></>
        }
      </RouterLink>;
  }

  if (href) {
    return <a
        className="lds-button-base menu-button"
        href={href}
        onClick={(e) => handleLinkClick(e)}
        {...linkProps}
      >
        {children}
        {
          external && <>&nbsp;<LdsIcon inline label="links to an external site" name="ArrowSquareOut" className="side-nav-external-icon" /></>
        }
      </a>;
  }

  return <button
      aria-controls={ariaControls}
      aria-expanded={isExpanded}
      className="lds-button-base menu-button"
      onClick={(e) => handleButtonClick(e)}
      {...linkProps}
    >
      {children}
      {
        external && <>&nbsp;<LdsIcon inline label="links to an external site" name="ArrowSquareOut" className="side-nav-external-icon" /></>
      }
    </button>;
}
