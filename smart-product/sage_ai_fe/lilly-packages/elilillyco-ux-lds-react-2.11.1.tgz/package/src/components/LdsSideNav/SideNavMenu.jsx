import cn from 'classnames';
import { useContext } from 'react';

import LdsIcon from '../LdsIcon/index.jsx';
import UtilityMenuMobile from '../LdsHeader/UtilityMenu/Mobile.jsx';

import useIsMobile from '../../hooks/useIsMobile.js';
import { SideNavContext } from './SideNavContext.jsx';

// JSdoc type definitions
/**
 * @typedef SideNavMenuProps
 * @property {React.ReactNode} [children] - The children of the component. Used to define custom content.
 * @property {React.ReactNode} [logo] - The logo for the side nav
 * @property {React.RefObject} [mobileCloseButtonRef] - The mobile close button ref
 * @property {Function} [toggleMobileMenu] - The toggle mobile menu function
 */
/**
 * SideNavMenu component
 * @param {SideNavMenuProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */

export default function SideNavMenu({
  children,
  logo,
  mobileCloseButtonRef,
  toggleMobileMenu,
}) {
  const {
    contactLilly,
    languageSelector,
    navContainerAriaLabel,
    showMobileMenu,
    showUtilityLogo,
    sideNavCloseText,
    utilityMenuLinks,
    utilityMenuCustomLinkItems,
    utilityMenuCustomLinkItemsPosition,
  } = useContext(SideNavContext);

  const isMobile = useIsMobile(1000);

  return (
    <nav
      className={cn(
        'lds-side-nav-menu-container'
      )}
      aria-label={navContainerAriaLabel}
      aria-hidden={showMobileMenu || !isMobile ? 'false' : 'true'}
    >
      <div
        className="lds-side-nav-menu-container-logo"
      >
        {logo}
        <button
          ref={mobileCloseButtonRef}
          className="lds-button-clear-style lds-side-nav-toggle"
          onClick={toggleMobileMenu}
          aria-hidden={showMobileMenu || !isMobile ? 'false' : 'true'}
          style={{ visibility: showMobileMenu || !isMobile ? 'visible' : 'hidden' }}
        >
          <span className="lds-side-nav-toggle-text">
            {sideNavCloseText}
          </span>
          <LdsIcon
            name="X"
            decorative
            inline
          />
        </button>
      </div>

      <div
        className="lds-side-nav-scroll-container"
      >
        <ul
          className="lds-side-nav-menu"
          id="lds-side-nav-menu"
        >
          {children}
        </ul>
      </div>

      <UtilityMenuMobile
        contactLilly={contactLilly}
        customLinkItems={utilityMenuCustomLinkItems}
        customLinkItemsPosition={utilityMenuCustomLinkItemsPosition}
        languageSelector={languageSelector}
        showUtilityLogo={showUtilityLogo}
        toggleMobileMenu={toggleMobileMenu}
        utilityMenuLinks={utilityMenuLinks}
      />

    </nav>
  );
}
