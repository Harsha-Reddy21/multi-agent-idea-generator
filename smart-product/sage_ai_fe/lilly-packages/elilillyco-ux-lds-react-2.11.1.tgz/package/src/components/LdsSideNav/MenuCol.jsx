import { useContext, useRef } from 'react';

import { SideNavContext } from './SideNavContext.jsx';
import TopContainer from './TopContainer.jsx';
import SideNavMenu from './SideNavMenu.jsx';

// JSdoc type definitions
/**
 * @typedef MenuColProps
 * @property {React.ReactNode} [children] - The children of the component. Used to define custom content.
 * @property {string} [logo] - The logo for the side nav
 * @property {string} [logoDesktop] - The desktop logo for the side nav
*/
/**
 * MenuCol component
 * @param {MenuColProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function MenuCol({
  children,
  logo,
  logoDesktop,
}) {
  const {
    setShowMobileMenu,
    showMobileMenu,
  } = useContext(SideNavContext);

  const mobileCloseButtonRef = useRef(null);
  const mobileMenuButtonRef = useRef(null);

  const toggleMobileMenu = () => {
    if (showMobileMenu) {
      setShowMobileMenu(false);
      mobileMenuButtonRef.current.focus();
    } else {
      setShowMobileMenu(true);
      mobileCloseButtonRef.current.focus();
    }
  };

  return (
    <div
      className="lds-side-nav-col"
    >
      <aside>
        <TopContainer
          logo={logo}
          logoDesktop={logoDesktop}
          mobileMenuButtonRef={mobileMenuButtonRef}
          toggleMobileMenu={toggleMobileMenu}
        />

        {/* <!-- MAIN SIDE NAV MENU RENDERING COMPONENT --> */}
        <SideNavMenu
          logo={logo}
          mobileCloseButtonRef={mobileCloseButtonRef}
          toggleMobileMenu={toggleMobileMenu}
        >
          {children}
        </SideNavMenu>

      </aside>
    </div>
  );
}
