import { createContext, useEffect, useState } from 'react';

export const SideNavContext = createContext();

export function SideNavContextProvider({
  children,
  currentRoute,
  navContainerAriaLabel,
  prefersReducedMotion,
  routerLink,
  routerBasePath,
  setShowMobileMenu,
  showMobileMenu,
  sideNavCloseText,
  sideNavCollapsedText,
  sideNavExpandedText,
  sideNavMenuText,
  toggleMobileMenu,
  // utility menu
  utilityMenuLinks,
  utilityMenuCustomLinkItems,
  utilityMenuCustomLinkItemsPosition,
  showUtilityLogo,
  contactLilly,
  languageSelector,
  // search
  search,
  searchTerm,
  setSearchTerm,
  searchSuggestions,
  searchCustomResult,
  searchInputPlaceholder,
  searchBtnLabel,
  searchNoResultsText,
  searchAnotherSearchText,
  searchLoading,
  searchClearBtnAriaLabel,
  searchMobileBtnAriaLabel,
  searchMobileCloseAriaLabel,
  searchMobileCloseLabel,
  searchOnBtnClick,
  searchOnSuggestionClick,
  searchSubmitBtnAriaLabel,
  // SSO
  showSSO,
  ssoSignInLinkProps,
  ssoRegisterLinkProps,
  ssoUserIcon,
  ssoIsLoggedIn,
  ssoWelcomeText,
  ssoDisplayName,
  ssoFullName,
  ssoSignOutText,
  ssoSignOutButtonProps,
  ssoMyProfileText,
  ssoMyProfileLinkProps,
  ssoEmail,
  ssoContent,
  ssoIconOnly,
  ssoMobileCloseAriaLabel,
  ssoMobileCloseLabel,
  ssoOpenedAnnouncement,
  ssoClosedAnnouncement,
  ssoMobileAccountAriaLabel,
  ssoIconAriaLabel,
  ssoOrText,
  ssoRegisterText,
  ssoSignInText,
}) {
  const [currentHash, setCurrentHash] = useState(null);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  // used for search dropdown
  const [openDropdownId, setOpenDropdownId] = useState(null);

  // SSO state
  const [isSSOOpen, setIsSSOOpen] = useState(false);

  const setUrlHash = (anchor) => {
    const url = new URL(window.location);
    url.hash = anchor;
    history.pushState({}, '', url);
    setCurrentHash(window.location.hash);
  };

  useEffect(() => {
    setCurrentHash(window.location.hash);
  }, []);

  return (
    <SideNavContext.Provider
      value={{
        contactLilly,
        currentHash,
        currentRoute,
        languageSelector,
        navContainerAriaLabel,
        prefersReducedMotion,
        routerBasePath,
        routerLink,
        showMobileMenu,
        setCurrentHash,
        setUrlHash,
        setShowMobileMenu,
        showUtilityLogo,
        sideNavCloseText,
        sideNavCollapsedText,
        sideNavExpandedText,
        sideNavMenuText,
        toggleMobileMenu,
        utilityMenuLinks,
        utilityMenuCustomLinkItems,
        utilityMenuCustomLinkItemsPosition,
        // search
        search,
        searchTerm,
        setSearchTerm,
        searchSuggestions,
        searchCustomResult,
        searchInputPlaceholder,
        searchBtnLabel,
        searchNoResultsText,
        searchAnotherSearchText,
        searchLoading,
        searchClearBtnAriaLabel,
        searchMobileBtnAriaLabel,
        searchMobileCloseAriaLabel,
        searchMobileCloseLabel,
        searchOnBtnClick,
        searchOnSuggestionClick,
        searchSubmitBtnAriaLabel,
        isSearchOpen,
        setIsSearchOpen,
        openDropdownId,
        setOpenDropdownId,
        // SSO
        showSSO,
        ssoSignInLinkProps,
        ssoRegisterLinkProps,
        ssoUserIcon,
        ssoIsLoggedIn,
        ssoWelcomeText,
        ssoDisplayName,
        ssoFullName,
        ssoSignOutText,
        ssoSignOutButtonProps,
        ssoMyProfileText,
        ssoMyProfileLinkProps,
        ssoEmail,
        ssoContent,
        ssoIconOnly,
        ssoMobileCloseAriaLabel,
        ssoMobileCloseLabel,
        ssoOpenedAnnouncement,
        ssoClosedAnnouncement,
        ssoMobileAccountAriaLabel,
        isSSOOpen,
        setIsSSOOpen,
        ssoIconAriaLabel,
        ssoOrText,
        ssoRegisterText,
        ssoSignInText,
      }}
    >
      {children}
    </SideNavContext.Provider>
  );
}
