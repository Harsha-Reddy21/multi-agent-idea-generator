import cn from 'classnames';
import { useContext } from 'react';

import createRipple from '../../../util/createRipple.js';
import { isLinkActive } from '../helpers.js';

import { SideNavContext } from '../SideNavContext.jsx';
import DynamicLink from './DynamicLink.jsx';

export default function Link({
  children,
  external = false,
  href,
  linkProps = {},
  to,
  ...rest
}) {
  const {
    currentRoute,
    prefersReducedMotion,
    routerBasePath,
    routerLink,
  } = useContext(SideNavContext);

  const handleClick = (e) => {
    // If the user prefers reduced motion, the button is a link button, or the dev has disabled the ripple, don't create the ripple effect
    if (!prefersReducedMotion) {
      createRipple(e);
    }
  };

  return (
    <li
      className={cn(
        'side-nav-item',
        {
          active: isLinkActive(currentRoute, href, to, routerBasePath),
        }
      )}
      {...rest}
    >
      <DynamicLink
        external={external}
        handleClick={(e) => handleClick(e)}
        href={href}
        linkProps={linkProps}
        routerLink={routerLink}
        to={to}
      >
        {children}
      </DynamicLink>
    </li>
  );
}
