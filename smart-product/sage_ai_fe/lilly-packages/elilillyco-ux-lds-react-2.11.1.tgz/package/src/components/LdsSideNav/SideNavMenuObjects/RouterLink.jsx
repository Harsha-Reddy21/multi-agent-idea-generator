export default function RouterLink({
  children,
  className,
  handleClick,
  routerLink,
  to,
}) {
  return routerLink(
    {
      className: className,
      onClick: (e) => handleClick(e),
      to: to,
    },
    <>{children}</>
  );
}
