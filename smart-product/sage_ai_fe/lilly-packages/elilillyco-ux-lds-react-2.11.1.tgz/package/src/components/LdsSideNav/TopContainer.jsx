import cn from 'classnames';
import { useContext } from 'react';

import LdsIcon from '../LdsIcon/index.jsx';

import { SideNavContext } from './SideNavContext.jsx';

// JSdoc type definitions
/**
 * @typedef TopContainerProps
 * @property {React.ReactNode} [logo] - The logo for the side nav
 * @property {React.ReactNode} [logoDesktop] - The desktop logo for the side nav
 * @property {React.RefObject} [mobileMenuButtonRef] - The mobile menu button ref
 * @property {Function} [toggleMobileMenu] - The toggle mobile menu function
 */
/**
 * TopContainer component
 * @param {TopContainerProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */

export default function TopContainer({
  logo,
  logoDesktop,
  mobileMenuButtonRef,
  toggleMobileMenu,
}) {
  const {
    search,
    showMobileMenu,
    sideNavCollapsedText,
    sideNavExpandedText,
    sideNavMenuText,
    isSearchOpen,
    setIsSearchOpen,
    searchMobileBtnAriaLabel,
    searchMobileCloseAriaLabel,
    searchMobileCloseLabel,
    // SSO
    showSSO,
    ssoIsLoggedIn,
    isSSOOpen,
    setIsSSOOpen,
    ssoMobileCloseLabel,
    ssoOpenedAnnouncement,
    ssoClosedAnnouncement,
    ssoSignInLinkProps,
    ssoMobileAccountAriaLabel,
    ssoUserIcon,
    ssoMobileCloseAriaLabel,
  } = useContext(SideNavContext);

  return (
    <div
      className="lds-side-nav-top-container"
    >
      {logoDesktop
        ? <>
          <div className="lds-side-nav-logo-mobile">{logo}</div>
          <div className="lds-side-nav-logo-desktop">{logoDesktop}</div>
        </>
        : <div className="lds-side-nav-logo">{logo}</div>
      }
      <div
        className={cn(
          'lds-side-nav-mobile-actions'
        )}
      >
        {
          search
          && <>

            {!isSearchOpen && !isSSOOpen && <button
              className={cn(
                'lds-button-clear-style',
                'lds-side-nav-search-button',
                'mobile-search-button'
              )}
              onClick={() => setIsSearchOpen(true)}
            >
              <LdsIcon
                label={searchMobileBtnAriaLabel}
                name="MagnifyingGlass"
                inline
              />
            </button>}
          </>
        }

        {/* SSO - Login page link */}
        {/* In mobile when logged out this will just be a link to the sign in page - no dropdown */}
        {
          showSSO && !ssoIsLoggedIn && !isSearchOpen && !isSSOOpen
          && <a
            className="lds-button-base mobile-search-button d-flex flex-column justify-content-center"
            {...ssoSignInLinkProps}
          >
            <LdsIcon decorative inline name="user-circle-fill" />
          </a>
        }

        {/* SSO - logged in */}
        {
          showSSO && ssoIsLoggedIn && !isSearchOpen && !isSSOOpen
          && <button
            className="lds-button-base mobile-sso-button d-flex flex-column justify-content-center"
            aria-label={ssoMobileAccountAriaLabel}
            onClick={() => setIsSSOOpen(true)}
          >
            <img className="sso-user-icon" src={ssoUserIcon} />
          </button>
        }

        <div
          className="screen-reader-text"
          aria-live="polite"
        >
          { showMobileMenu ? sideNavExpandedText : sideNavCollapsedText }
        </div>

        <div aria-live="polite" className="screen-reader-text">
          {isSSOOpen ? ssoOpenedAnnouncement : ssoClosedAnnouncement}
        </div>

        {/* Hamburger Menu Toggle */}
        {!isSearchOpen && !isSSOOpen
          && <button
            className="lds-button-clear-style lds-side-nav-toggle"
            onClick={toggleMobileMenu}
            ref={mobileMenuButtonRef}
          >
            <span className="lds-side-nav-toggle-text">
              {sideNavMenuText}
            </span>
            <LdsIcon
              name="List"
              decorative
              inline
            />
          </button>
        }

        {/* Search - close */}
        {isSearchOpen
          && <button
            className="lds-button-base mobile-search-button d-flex flex-column"
            aria-label={searchMobileCloseAriaLabel}
            onClick={() => setIsSearchOpen(false)}
          >
            <LdsIcon decorative inline name="x" />
            <span className="lds-header-toggle-text">{searchMobileCloseLabel}</span>
          </button>
        }

        {/* SSO - Close */}
        {
          isSSOOpen && <button
            className="lds-button-base mobile-search-button d-flex flex-column"
            aria-label={ssoMobileCloseAriaLabel}
            onClick={() => setIsSSOOpen(false)}
          >
            <LdsIcon decorative inline name="x" />
            <span className="lds-header-toggle-text">{ssoMobileCloseLabel}</span>
          </button>
        }
      </div>
    </div>
  );
}
