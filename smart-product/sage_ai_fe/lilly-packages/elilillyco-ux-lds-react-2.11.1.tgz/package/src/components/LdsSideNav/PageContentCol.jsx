import cn from 'classnames';
import { useContext, useEffect, useState } from 'react';

import { SideNavContext } from './SideNavContext.jsx';
import UtilityMenu from '../LdsHeader/UtilityMenu/Desktop.jsx';
import SearchModal from '../LdsHeader/Search/SearchModal.jsx';
import LdsSticky from '../LdsSticky/index.jsx';
import useIsMobile from '../../hooks/useIsMobile.js';
import SSOModal from '../LdsHeader/UtilityMenu/SSO/SSOModal.jsx';

// JSdoc type definitions
/**
 * @typedef PageContentColProps
 * @property {React.ReactNode} [stickyContent] - The sticky content
 * @property {React.ReactNode} [children] - The children of the component. Used to define custom content.
*/
/**
 * PageContentCol component
 * @param {PageContentColProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */

export default function PageContentCol({
  stickyContent,
  children,
}) {
  const {
    contactLilly,
    languageSelector,
    showUtilityLogo,
    utilityMenuLinks,
    utilityMenuCustomLinkItems,
    utilityMenuCustomLinkItemsPosition,
    // SEARCH
    search,
    searchTerm,
    setSearchTerm,
    searchSuggestions,
    searchCustomResult,
    searchInputPlaceholder,
    searchBtnLabel,
    searchNoResultsText,
    searchAnotherSearchText,
    searchLoading,
    searchClearBtnAriaLabel,
    searchOnBtnClick,
    searchOnSuggestionClick,
    searchSubmitBtnAriaLabel,
    // SSO
    showSSO,
    ssoSignInLinkProps,
    ssoRegisterLinkProps,
    ssoUserIcon,
    ssoIsLoggedIn,
    ssoWelcomeText,
    ssoDisplayName,
    ssoFullName,
    ssoSignOutText,
    ssoSignOutButtonProps,
    ssoMyProfileText,
    ssoMyProfileLinkProps,
    ssoEmail,
    ssoContent,
    ssoIconOnly,
  } = useContext(SideNavContext);

  const isMobile = useIsMobile(992);
  const [stickyTop, setStickyTop] = useState(0);

  const hasUtilityLinks = utilityMenuLinks && Array.isArray(utilityMenuLinks) && utilityMenuLinks.length > 0;
  const showUtilityMenu = hasUtilityLinks || languageSelector || contactLilly;

  /*
    In desktop the sticky container is at the top of the page

    In mobile the sticky container is below the side nav top container so we have to calc its height
  */
  useEffect(() => {
    if (isMobile) {
      const sideNavTopContainer = document.querySelector('.lds-side-nav-top-container');
      const top = sideNavTopContainer.offsetHeight || 0;
      setStickyTop(top);
    } else {
      setStickyTop(0);
    }
  }, [isMobile]);

  return (
    <div
      id="contentId"
      className={cn(
        'lds-side-nav-content-col'
      )}
    >
      {(stickyContent || showUtilityMenu || search)
        && <>
          <LdsSticky
            top={stickyTop}
          >
            {stickyContent}
            { (showUtilityMenu || search)
              && <header id="header">
                <div className="lds-side-nav-top-header">
                  <div></div>
                  <UtilityMenu
                    isSideNav
                    utilityMenuLinks={utilityMenuLinks}
                    showUtilityLogo={showUtilityLogo}
                    contactLilly={contactLilly}
                    languageSelector={languageSelector}
                    customLinkItems={utilityMenuCustomLinkItems}
                    customLinkItemsPosition={utilityMenuCustomLinkItemsPosition}
                    // Search
                    search={search}
                    searchBtnLabel={searchBtnLabel}
                    // SSO
                    showSSO={showSSO}
                    ssoSignInLinkProps={ssoSignInLinkProps}
                    ssoRegisterLinkProps={ssoRegisterLinkProps}
                    ssoUserIcon={ssoUserIcon}
                    ssoIsLoggedIn={ssoIsLoggedIn}
                    ssoWelcomeText={ssoWelcomeText}
                    ssoDisplayName={ssoDisplayName}
                    ssoFullName={ssoFullName}
                    ssoSignOutText={ssoSignOutText}
                    ssoSignOutButtonProps={ssoSignOutButtonProps}
                    ssoMyProfileText={ssoMyProfileText}
                    ssoMyProfileLinkProps={ssoMyProfileLinkProps}
                    ssoEmail={ssoEmail}
                    ssoContent={ssoContent}
                    ssoIconOnly={ssoIconOnly}
                  />
                </div>
              </header>
            }
          </LdsSticky>
        </>
      }
      {search && <SearchModal
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        searchSuggestions={searchSuggestions}
        searchCustomResult={searchCustomResult}
        searchInputPlaceholder={searchInputPlaceholder}
        searchNoResultsText={searchNoResultsText}
        searchAnotherSearchText={searchAnotherSearchText}
        searchLoading={searchLoading}
        searchClearBtnAriaLabel={searchClearBtnAriaLabel}
        searchOnBtnClick={searchOnBtnClick}
        searchOnSuggestionClick={searchOnSuggestionClick}
        searchSubmitBtnAriaLabel={searchSubmitBtnAriaLabel}
        isSideNav
      />}

      {/* SSO Modal only appears in mobile */}
      {
        showSSO
          && <SSOModal
          isSideNav
          ssoFullName={ssoFullName}
          ssoUserIcon={ssoUserIcon}
          ssoSignOutText={ssoSignOutText}
          ssoSignOutButtonProps={ssoSignOutButtonProps}
          ssoMyProfileText={ssoMyProfileText}
          ssoMyProfileLinkProps={ssoMyProfileLinkProps}
          ssoEmail={ssoEmail}
          ssoContent={ssoContent}
        />
      }

      {/* <!-- DEFAULT SLOT (USUALLY CONTAINS THE main PAGE CONTENT INJECTION POINT) --> */}
      {children}
    </div>
  );
}
