import cn from 'classnames';
import { useContext } from 'react';

import { SideNavContext } from '../SideNavContext.jsx';
import offsetTopDocument from '../../../util/offsetTopDocument.js';

export default function JumpMenuLink({
  children,
  anchor,
}) {
  const { currentHash, setUrlHash } = useContext(SideNavContext);
  const jumpOffset = 16;

  const jumpToAnchor = (e, anchor) => {
    e.preventDefault();
    const target = document.getElementById(anchor);

    if (target) {
      window.scrollTo({ top: offsetTopDocument(target) - parseInt(jumpOffset, 10), behavior: 'smooth' });
      setUrlHash(anchor);
      // focus on the anchor after we scroll to it for a11y purposes
      // half a second delay to allow for scrolling to finish
      setTimeout(() => target.focus({ focusVisible: true }), 500);
    }
  };

  return (
    <li
      className={cn(
        'side-nav-item',
        'side-nav-jump-menu-item',
        {
          active: currentHash === `#${anchor}`,
        }
      )}
    >
      <a
        className="lds-button-base menu-button"
        href={`#${anchor}`}
        onClick={(e) => jumpToAnchor(e, anchor)}
      >
        {children}
      </a>
    </li>
  );
}

const isValidAnchor = (props, propName, componentName) => {
  const regex = /^[a-zA-Z][^\s]*$/;

  if (!regex.test(props[propName])) {
    return new Error(`Invalid prop ${propName} passed to ${componentName}. Expected a string starting with a letter and with no white space.`);
  }

  return null;
};

JumpMenuLink.propTypes = {
  anchor: isValidAnchor,
};
