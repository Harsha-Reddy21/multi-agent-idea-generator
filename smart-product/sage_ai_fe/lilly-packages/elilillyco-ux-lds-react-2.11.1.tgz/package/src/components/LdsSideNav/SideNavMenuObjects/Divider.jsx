import LdsDivider from '../../LdsDivider/index.jsx';

export default function Divider() {
  return (
    <li className="side-nav-item divider">
      <LdsDivider orientation="horizontal" type="secondary" />
    </li>
  );
}
