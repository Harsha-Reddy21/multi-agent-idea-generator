import removeTrailingSlash from '../../util/removeTrailingSlash.js';

export function isLinkActive(currentRoute, href, to, routerBasePath) {
  const cleanHref = removeTrailingSlash(href);
  const cleanTo = removeTrailingSlash(to);

  return currentRoute === cleanHref
    || currentRoute === cleanTo
    || currentRoute === `${routerBasePath}${cleanHref}`
    || currentRoute === `${routerBasePath}${cleanTo}`
    || `${routerBasePath}${currentRoute}` === cleanHref
    || `${routerBasePath}${currentRoute}` === cleanTo;
}
