import cn from 'classnames';
import {
  useEffect,
  useContext,
  useId,
  useRef,
  useState
} from 'react';

import LdsIcon from '../../LdsIcon/index.jsx';
import createRipple from '../../../util/createRipple.js';
import removeTrailingSlash from '../../../util/removeTrailingSlash.js';
import { SideNavContext } from '../SideNavContext.jsx';
import DynamicLink from './DynamicLink.jsx';

export default function Menu({
  activeIcon,
  activeLabel,
  children,
  icon,
  label,
}) {
  // id will be used to generate unique Id for each menu instance and then referenced in the aria-controls attribute
  const id = useId();
  const menuId = `side-nav-menu-${id.slice(1, -1)}`; // remove colons
  const menuButtonRef = useRef(null);
  const subMenuRef = useRef(null);
  const {
    currentRoute,
    prefersReducedMotion,
    routerBasePath,
  } = useContext(SideNavContext);
  const [isExpanded, setIsExpanded] = useState(false);

  const handleClick = (e) => {
    // If the user prefers reduced motion, the button is a link button, or the dev has disabled the ripple, don't create the ripple effect
    if (!prefersReducedMotion) {
      createRipple(e);
    }
    setIsExpanded(!isExpanded);
  };

  const closeSubMenu = () => {
    setIsExpanded(false);
  };

  const renderItemIcon = () => {
    return (isExpanded && activeIcon)
      ? <LdsIcon inline decorative name={activeIcon} className="side-nav-menu-item-icon" />
      : <LdsIcon inline decorative name={icon} className="side-nav-menu-item-icon" />;
  };

  useEffect(() => {
    const toggleCurrentMenu = () => {
      let isInitExpanded = false;

      /* expand if current route is on the menu expand/collapse link */
      if (!menuButtonRef.current) return;
      const buttonLinkPathname = removeTrailingSlash(menuButtonRef.current.querySelector('.menu-button').pathname);
      if (buttonLinkPathname === currentRoute
        || buttonLinkPathname === `${routerBasePath}${currentRoute}`
        || `${routerBasePath}${buttonLinkPathname}` === currentRoute) {
        isInitExpanded = true;
        setIsExpanded(isInitExpanded);
        return;
      }

      /* expand if current route is in the menu */
      if (!subMenuRef.current) return;
      const elements = subMenuRef.current.querySelectorAll('.menu-button');

      if (!elements.length) return;

      elements.forEach((item) => {
        const itemPathname = removeTrailingSlash(item.pathname);
        if (itemPathname === currentRoute
          || itemPathname === `${routerBasePath}${currentRoute}`
          || `${routerBasePath}${itemPathname}` === currentRoute
        ) {
          isInitExpanded = true;
        }
      });

      setIsExpanded(isInitExpanded);
    };

    toggleCurrentMenu();
  }, [currentRoute, routerBasePath]);

  return (
    <li
      className={cn(
        'side-nav-item',
        'has-sub-menu',
        {
          'is-expanded': isExpanded,
        }
      )}
      ref={menuButtonRef}
    >
      <DynamicLink
        handleClick={handleClick}
        isExpanded={isExpanded}
        ariaControls={menuId}
      >
        {icon && renderItemIcon()}
        <span
          className={cn(
            'side-nav-button-text',
            'has-expand-icon'
          )}
        >
        {isExpanded ? activeLabel || label : label}
        </span>
        <LdsIcon inline name="CaretDown" className="side-nav-expand-icon" label={isExpanded ? 'Collapse submenu' : 'Expand submenu'} />
      </DynamicLink>
      <div
        className={cn(
          'side-nav-menu-wrapper'
        )}
        inert={isExpanded ? null : ''}
      >
        <ul
          aria-hidden={isExpanded ? 'false' : 'true'}
          className={cn(
            'side-nav-menu'
          )}
          id={menuId}
          ref={subMenuRef}
        >
          <li
            className={cn(
              'side-nav-item',
              'side-nav-sub-menu-back'
            )}
          >
            <button
              className="lds-button-base menu-button"
              onClick={closeSubMenu}
            >
              <LdsIcon inline name="CaretLeft" className="side-nav-menu-item-icon side-nav-back-icon" title="Close submenu" />
              <span
                className={cn(
                  'side-nav-button-text'
                )}
              >
                {activeLabel || label}
              </span>
            </button>
          </li>
          {children}
        </ul>
      </div>
    </li>
  );
}
