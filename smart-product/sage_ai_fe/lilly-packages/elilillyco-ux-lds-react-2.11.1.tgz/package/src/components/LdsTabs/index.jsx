import PropTypes from 'prop-types';
import cn from 'classnames';

import DesktopTabButtons from './private/DesktopTabButtons.jsx';
import MobileTabButtons from './private/MobileTabButtons.jsx';
import {
  useLayoutEffect,
  useState,
  useId,
  useRef
} from 'react';

// JSDoc type definitions
/**
 * @typedef {Object} LdsTabsProps
 * @property {React.ReactNode} [children] - Required child nodes; must be instances of LdsTabPanel
 * @property {{tabId: number, label: string|React.ReactNode}[]} tabLabels - Required; an array of tab label objects. Each object should contain a "tabId" corresponding to each child tab panel and a "label" property for the text to display on the tab
 * @property {number|string} [activeTab] - Required; the current active tab value, typically a React state variable value
 * @property {any} onChange - Required; the function to call to set the new active tab, typically a React state variable setter function
 * @property {string} [displayClass] - Optional; set the display method class for the tab group. Options are "contained" or "full-width; default is "contained"
 * @property {string} [tabClass] - Optional; set the style of the tab group. Options are "solid" or "underlined"; default is "solid"
 * @property {string} [tabAlign] - Optional; set the alignment of the tabs. Options are "left", "center", and "right"; default is "left"
 * @property {string} [ariaLabel] - Optional; set the accessible aria-label description on the tab group
 * @property {string} [className] - Optional; custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Optional, define any additional non-prop attributes to be rendered on the component's root container element.
 */

/**
 * LdsTabs component
 * @param {LdsTabsProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} LdsTabs component
 */

export default function LdsTabs({
  children,
  tabLabels = [],
  activeTab,
  onChange,
  displayClass = 'contained',
  tabClass = 'solid',
  tabAlign = 'left',
  className = '',
  ariaLabel,
  ...rest
}) {
  const tabGroupId = useId();
  const tabGroupRef = useRef(null);
  const [forceMobile, setForceMobile] = useState(false);

  // If tab labels are too long for one row in desktop, render the mobile version
  useLayoutEffect(() => {
    function checkWindowSize() {
      const tabs = document.querySelectorAll('.tab-btn-container .tab-btn');
      const tabContainerWidth = tabs[0].closest('.tab-btn-container').offsetWidth;
      let totalTabWidth = 0;
      tabs.forEach((tab) => { totalTabWidth += tab.offsetWidth; });
      if (totalTabWidth > tabContainerWidth) setForceMobile(true);
      else setForceMobile(false);
    }
    checkWindowSize();
    window.addEventListener('resize', checkWindowSize);
    return () => window.removeEventListener('resize', checkWindowSize);
  }, []);

  const handleTabClick = (e, tabId) => {
    onChange(tabId);
  };

  return (
    <div
      ref={tabGroupRef}
      className={cn(
        'lds-tab-group',
        displayClass,
        tabClass,
        className
      )}
      id={tabGroupId}
      aria-label={ariaLabel}
      {...rest}
    >
      <div
        className={cn(
          'lds-tab-header',
          {
            [tabAlign]: tabAlign,
          }
        )}
      >
        <DesktopTabButtons
          activeTab={activeTab}
          tabClass={tabClass}
          displayClass={displayClass}
          onTabClick={handleTabClick}
          tabLabels={tabLabels}
          tabRef={tabGroupRef}
          forceMobile={forceMobile}
        />
        <MobileTabButtons
          activeTab={activeTab}
          onTabClick={handleTabClick}
          tabLabels={tabLabels}
          forceMobile={forceMobile}
          displayClass={displayClass}
        />
      </div>
      <div
        className={cn(
          'lds-tab-container',
          {
            'tab-padded': displayClass === 'contained',
            wrapper: displayClass === 'full-width',
          }
        )}
      >
        {children}
      </div>
    </div>
  );
}

LdsTabs.propTypes = {
  children: PropTypes.any,
  tabLabels: PropTypes.array.isRequired,
  activeTab: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
  ]),
  onChange: PropTypes.func.isRequired,
  displayClass: PropTypes.oneOf(['contained', 'full-width']),
  tabClass: PropTypes.oneOf(['solid', 'underlined']),
  tabAlign: PropTypes.oneOf(['left', 'right', 'center', 'full']),
  className: PropTypes.string,
  ariaLabel: PropTypes.string,
  rest: PropTypes.any,
};
