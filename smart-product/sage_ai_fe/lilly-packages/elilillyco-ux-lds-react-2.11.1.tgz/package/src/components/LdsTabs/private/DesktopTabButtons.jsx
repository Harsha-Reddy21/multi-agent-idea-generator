import {
  createRef, useRef, useState
} from 'react';
import cn from 'classnames';
import isRTL from '../../../util/isRTL.js';

export default function DesktopTabButtons({
  activeTab,
  tabLabels,
  displayClass,
  onTabClick,
  tabRef,
  forceMobile,
}) {
  const [focusedTab, setFocusedTab] = useState(activeTab);
  const btnsRef = useRef(tabLabels.map(() => createRef()));

  const setFocusOnNext = (newIdx) => {
    const nextBtn = btnsRef.current[newIdx];
    setFocusedTab(tabLabels[newIdx].tabId);
    nextBtn.current.focus();
  };

  // Keyboard interactions should follow this pattern https://www.w3.org/WAI/ARIA/apg/patterns/tabs/#keyboardinteraction
  const handleKeyDown = (e, idx) => {
    const isRtl = isRTL(tabRef);
    const isFirst = idx === 0;
    const isLast = idx === tabLabels.length - 1;

    if (e.code === 'ArrowLeft') {
      if (!isRtl && !isFirst) {
        setFocusOnNext(idx - 1);
      }
      if (isRtl && !isLast) {
        setFocusOnNext(idx + 1);
      }
    }

    if (e.code === 'ArrowRight') {
      if (!isRtl && !isLast) {
        setFocusOnNext(idx + 1);
      }
      if (isRtl && !isFirst) {
        setFocusOnNext(idx - 1);
      }
    }
  };

  const handleClick = (e, tabId) => {
    setFocusedTab(tabId);
    onTabClick(e, tabId);
  };

  return (
    <div
      className={cn(
        'tab-btn-container',
        {
          wrapper: displayClass === 'full-width',
          'tab-btn-container__force-mobile': forceMobile,
        }
      )}
      role="tablist"
    >
      {
        tabLabels.map((label, idx) => (
          <button
            key={label.tabId}
            ref={btnsRef.current[idx]}
            id={`tab-btn-${label.tabId}`}
            className={cn(
              'lds-button-clear-style',
              'tab-btn',
              {
                active: activeTab === label.tabId,
              }
            )}
            onClick={(e) => handleClick(e, label.tabId)}
            role="tab"
            aria-selected={activeTab === label.tabId}
            aria-controls={`tab-panel-${label.tabId}`}
            tabIndex={focusedTab === label.tabId ? 0 : -1}
            onKeyDown={(e) => handleKeyDown(e, idx)}
          >
            {label.label}
          </button>
        ))
      }
    </div>
  );
}
