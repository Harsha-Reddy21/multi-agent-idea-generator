import { useState } from 'react';
import cn from 'classnames';

import LdsDropdown from '../../LdsDropdown/index.jsx';

export default function MobileTabButtons({
  activeTab,
  onTabClick,
  tabLabels,
  forceMobile,
  displayClass,
}) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const label = tabLabels.find((label) => label.tabId === activeTab).label;

  const handleDrawerBtnClick = (e, tabId) => {
    setDrawerOpen(false);
    onTabClick(e, tabId);
  };

  return (
    <div
      className={cn(
        'lds-tab-drawer',
        {
          open: drawerOpen,
          'd-block': forceMobile,
          wrapper: displayClass === 'full-width',
        }
      )}
    >
      <LdsDropdown
        arrowNavigation
        isOpen={drawerOpen}
        setIsOpen={setDrawerOpen}
        label={<span className="lds-tab-drawer-label" aria-label={label}>{label}</span>}
        buttonProps={{
          className: 'lds-button-clear-style tab-btn tab-drawer-btn active',
        }}
        dropdownProps={{
          className: 'lds-tab-drawer-dropdown',
        }}
      >
        {
          tabLabels.map((label) => (
            <LdsDropdown.Button
              key={label.tabId}
              className={cn(
                'drawer-btn',
                {
                  active: activeTab === label.tabId,
                }
              )}
              onClick={(e) => handleDrawerBtnClick(e, label.tabId)}
              role="option"
              aria-selected={activeTab === label.tabId}
              aria-controls={`tab-panel-${label.tabId}`}
            >
              {label.label}
            </LdsDropdown.Button>
          ))
        }
      </LdsDropdown>
    </div>
  );
}
