import PropTypes from 'prop-types';
import cn from 'classnames';

// JSDoc type definitions
/**
 * @typedef {Object} LdsTabPanelProps
 * @property {number|string} [tabId] - Required; the index id of tab
 * @property {number|string} [activeTab] - Required; the current active tab value, typically a React state variable value
 * @property {string} [className] - Optional; custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {React.ReactNode} [children] - Optional; children content nodes
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Optional, define any additional non-prop attributes to be rendered on the component's root container element.
 */

/**
 * LdsTabPanel component
 * @param {LdsTabPanelProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} LdsTabPanel component
 */
export default function LdsTabPanel({
  tabId,
  activeTab,
  className,
  children,
  ...rest
}) {
  return (
    <div
      id={`tab-panel-${tabId}`}
      role="tabpanel"
      className={cn(
        'lds-tab',
        {
          active: activeTab === tabId,
        },
        className
      )}
      aria-labelledby={`tab-btn-${tabId}`}
      {...rest}
    >
      {children}
    </div>
  );
}

LdsTabPanel.propTypes = {
  tabId: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
  ]).isRequired,
  activeTab: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
  ]).isRequired,
  children: PropTypes.any,
  rest: PropTypes.any,
};
