import PropTypes from 'prop-types';
import cn from 'classnames';

import {
  validateUsage,
  altValue,
  isAriaHidden
} from './image.helpers.jsx';

import { LdsImageError } from './LdsImageError.jsx';

// JSDoc type definitions
/**
 * @typedef LdsImageProps
 * @property {string} [alt] - The value of the image\'s "alt" attribute; required unless the image is explicitly decorative; the string value must not be longer than 125 characters
 * @property {boolean} [decorative] - Whether the image is decorative; it has no useful context beyond pure visual decoration and should be ignored by assistive technology
 * @property {string} [id] - The default HTML id attribute is overridden as a prop. For basic images it will simply apply as normal to the rendered "img" element. For responsive images the id value will be rendered directly on the "picture" element's id attribute, additionally the fallback image "img" element will get its id attribute set to the id appended with '-fallback'
 * @property {{srcset: string, media?: string}[]} [images] - An object which defines an array of responsive image source objects to render with an HTML picture element
 * @property {string} [loading] - The loading policy the browser will use for the image. The prop must be set to one of the string values below or not set (undefined). When "undefined" loading defaults to "eager". See: https://developer.mozilla.org/en-US/docs/Web/API/HTMLImageElement/loading
 * @property {string} [src] - Basic HTML image element source attribute, set to the URL of an image file to render with an HTML img element
 * @property {boolean} [responsive] - Whether the component should render a responsive image from an array of source objects defined on the "images" prop
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 */
/**
 * LdsImage component
 * @param {LdsImageProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsImage({
  alt,
  decorative = false,
  id,
  images,
  loading,
  responsive = false,
  src,
  className,
  ...rest
}) {
  // If the critical prop useage or values are invalid handle it
  if (!validateUsage(src, responsive, images)) return <LdsImageError />;

  // If the valid image uses responsive mode, generate a responsive picture image
  if (responsive) {
    // Give the fallback image an HTML ID if the component has an ID (which renders on the picture element).
    let fallbackImgId;
    if (id) fallbackImgId = `${id}-fallback`;

    // Render it
    return (
      <picture
        id={id}
        className={cn(
          'lds-image',
          className
        )}
        aria-hidden={isAriaHidden(decorative)}
        {...rest}
      >
        { images && Array.isArray(images) && images.map((image, i) => (
          <source
            key={i}
            media={image.media}
            srcSet={image.srcset}
          />
        ))}
        <img
          id={fallbackImgId}
          src={images[images.length - 1].srcset}
          alt={altValue(alt, decorative)}
          aria-hidden={isAriaHidden(decorative)}
          loading={loading}
        />
      </picture>
    );
  }

  // Otherwise assum the valid image is a basic HTML image
  // Render it
  return (
    <img
      id={id}
      className={cn(
        'lds-image',
        className
      )}
      src={src}
      alt={altValue(alt, decorative)}
      aria-hidden={isAriaHidden(decorative)}
      loading={loading}
      {...rest}
    />
  );
}

LdsImage.propTypes = {
  alt: PropTypes.string,
  decorative: PropTypes.bool,
  loading: PropTypes.oneOf(['eager', 'lazy', undefined]),
  src: PropTypes.string,
  responsive: PropTypes.bool,
  images: PropTypes.arrayOf((propValue, key) => { // eslint-disable-line
    if (!propValue[key].srcset) {
      return new Error(`\n
      >>> LDS ERROR: [Invalid Component Data] in LdsImage: responsive image object missing 'srcset' property at index ${key} (${key + 1}/${propValue.length}).
      Each responsive image object must contain an 'srcset' property.
      `);
    }
    if (!propValue[key].media && key !== (propValue.length - 1)) {
      return new Error(`\n
      >>> LDS ERROR: [Invalid Component Data] in LdsImage: responsive image object missing 'media' property at index ${key} (${key + 1}/${propValue.length}).
      Each responsive image object EXCEPT the fallback default must contain a 'media' property.
      `);
    }
    if (propValue[key].media && key === (propValue.length - 1)) {
      return new Error(`\n
      >>> LDS ERROR: [Invalid Component Data] in LdsImage: responsive image default fallback object contains an invalid 'media' property at index ${key} (${key + 1}/${propValue.length}).
      The fallback responsive image object MUST always be the last object in the array and MUST NOT contain a 'media' property.
      `);
    }
  }),
};
