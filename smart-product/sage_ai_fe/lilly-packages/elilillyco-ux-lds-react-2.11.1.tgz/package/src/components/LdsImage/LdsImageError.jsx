/**
 * Get a simple error state HTML element to display when there is a problem with the component
 *
 * @returns {HTMLElement} html element
 */
export const LdsImageError = () => {
  return (
    <div className="lds-render-error-block">LdsImage ERROR!</div>
  );
};
