/**
 * Valdiate image usage
 *
 * @param src the src prop value
 * @param responsive the responsive prop value; whether the image should use the responsive feature
 * @param images the images prop value
 *
 * @returns {boolean} a boolean value indicating whether the image element has been properly used
 */
export const validateUsage = (src, responsive, images) => {
  // When the image is using the responsive feature
  if (responsive) {
    // Return if valid
    if (!src && images && images.length >= 2 && images[images.length - 1].srcset) return true;

    // If invalid, provide console errors for all potential problems:

    // The src prop must not be used
    if (src) {
      // eslint-disable-next-line no-console
      console.error(`
      >>> LDS ERROR [Invalid Usage] in LdsImage: invalid image src value
      When rendering a responsive image the value of the src prop must be undefined because it is not used.
      src: ${src}
      Please remove the src prop.
      `);
    }

    // An Images array is required
    if (!images) {
      // eslint-disable-next-line no-console
      console.error(`
      >>> LDS ERROR [Invalid Component Data] in LdsImage: missing images object for responsive image.
      Nothing (or something falsey or otherwise invalid) was set to the "images" prop.
      images: ${images}
      Please provide a well formed images object array.
      `);
    }

    // The Images array must contain at least 2 elements
    if (images.length < 2) {
      // eslint-disable-next-line no-console
      console.error(`
      >>> LDS ERROR [Invalid Component Data] in LdsImage: invalid responsive images object
      Insufficent source images count; there must be two or more image source objects in the array to create a responsive image.
      Found ${images.length} image source objects in the images array: ${images}
      Please provide a well formed images object array.
     `);
    }

    // The last item in the images array wasn't found or doesn't have an srcset property
    if (!images[images.length - 1].srcset) {
      // eslint-disable-next-line no-console
      console.error(`
      >>> LDS ERROR [Invalid Component Data] in LdsImage: failed to detect fallback image source in the responsive images array.
      The last image object in the images object array did not have an srcset property or it is set to a falsey value.
      Please provide a well formed images object array.
      `);
    }

    // Finally, return invalid
    return false;
  }

  // Otherwise *assume* the use case is a basic image

  // return if valid
  if (src && !images) return true;

  // If invalid, provide console errors for all potential problems:

  // The src prop is required
  if (!src) {
    // eslint-disable-next-line no-console
    console.error(`
    >>> LDS ERROR [Invalid Usage] in LdsImage: invalid image src value
    When rendering a basic image the src prop is required.
    src: ${src}
    Please provide the src prop with a string value containing either a URL or a "#" anchor to an element ID on the page.
    `);
  }

  // The images prop should be undefined
  if (images) {
    // eslint-disable-next-line no-console
    console.error(`
    >>> LDS ERROR [Invalid Usage] in LdsImage: invalid images value
    When rendering a basic image the images prop must be left undefined as it is unused.
    src: ${src}
    Please remove the images prop.
    `);
  }

  // Finally return invalid
  return false;
};

/**
 * Process the alt input
 *
 * @param alt the alt prop value
 * @param decorative the decorative prop value; whether the image is flagged as decorative
 *
 * @returns {string} either the user-defined value of the alt text or an empty string
 */
export const altValue = (alt, decorative) => {
  // First, throw an accessibility error if the raw alt value is falsey on a non-decorative image
  if (!alt && !decorative) {
    // eslint-disable-next-line no-console
    console.error(`
    >>> LDS ERROR [Accessibility Compliance Violation] in LdsImage: image missing alt attribute.
    Images require that the 'alt' attribute is ALWAYS set UNLESS the image is explcitily decorative (as set with that named prop).
    alt: ${alt}
    `);
    return '';
  }

  // Coerce the alt input to string
  const altStr = String(alt);

  // Warn if the alt text string exceeds 125 characters
  if (altStr.length > 125) {
    // eslint-disable-next-line no-console
    console.warn(`
    >>> LDS WARNING [alt attribute recommended max length exceeded] in LDS Image.
    The alt attribute value length (character count) is: ${altValue.length}
    The maximum practical limit for alt text is 125 characters (some screen readers will refuse to announce more).
    Value:\n
    ${altValue}
    `);
    return alt;
  }

  // If the image is not decorative, return the alt text input
  if (!decorative) {
    return altStr;
  }

  // For all other cases return empty string; the alt attribute must always be set, even if empty, no matter what
  return '';
};

/**
 * Get the image's aria-hidden attribute value
 *
 * @param decorative the decorative prop value; whether the image is flagged as decorative
 *
 * @returns {boolean|undefined} boolean true if the image is explicty decorative so that aria-hidden="true" OR undefined so that an unnecessary default aria-hidden="false" attribute does not render
 */
export const isAriaHidden = (decorative) => {
  if (decorative) return true;
  return undefined;
};
