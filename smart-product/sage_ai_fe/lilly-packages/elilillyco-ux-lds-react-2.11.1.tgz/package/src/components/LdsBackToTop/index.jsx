import { useState, useEffect, useRef } from 'react';
import { Transition } from 'react-transition-group';
import PropTypes from 'prop-types';
import cn from 'classnames';

import LdsIcon from '../LdsIcon/index.jsx';
import { duration } from '../../util/motion.js';
import LdsButton from '../LdsButton/index.jsx';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsBackToTopProps
 * @property {number} [threshold] - Distance from the top of the screen that must be scrolled before the Back to Top button will appear
 * @property {string} [backToTopText] - Language dependent Text for component
 * @property {boolean} [hideText] - Whether the button text should be visually hidden. The button text will still be read by a screen reader when enabled.
 * @property {boolean} [mobileOnly] - Determines whether the Back to Top component is visible only on mobile or always visible.
 * @property {number} [scrollOffset] - Distance from the top of the screen the page will scroll when clicked.
 * @property {string} [scrollBehaviour] - Scroll behaviour passed into native scroll function.
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {string} [radiusClass] - Property to determine border radius of button.
 * @property {boolean} [expandOnHover] - Property to determine whether text should be hidden and then button expanded to show on hover.
 */
/**
 * LdsBackToTop component
 * @param {LdsBackToTopProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsBackToTop component
 */
function LdsBackToTop({
  radiusClass,
  threshold = 100,
  backToTopText = 'Top',
  hideText = false,
  expandOnHover = false,
  mobileOnly = false,
  scrollOffset = 0,
  scrollBehaviour = 'smooth',
  className = '',
  ...rest
}) {
  const [isShowing, setIsShowing] = useState(false);

  const buttonRef = useRef(null);

  const handleScrollToTop = () => {
    window.scrollTo({
      top: scrollOffset,
      behavior: scrollBehaviour,
    });
  };

  useEffect(() => {
    const handleWindowScroll = () => {
      if (window.scrollY >= threshold) {
        setIsShowing(true);
      } else {
        setIsShowing(false);
      }
    };

    window.removeEventListener('scroll', handleWindowScroll);
    window.addEventListener('scroll', handleWindowScroll);
    return () => window.removeEventListener('scroll', handleWindowScroll);
  }, [threshold]);

  const transitionStyles = {
    entering: { opacity: 0, transform: 'translateX(1rem)' },
    entered: { opacity: 1, transform: 'translateX(0)' },
    exiting: { opacity: 0, transform: 'translateX(1rem)' },
    exited: { opacity: 0, transform: 'translateX(1rem)' },
  };
  return (
    <Transition
      nodeRef={buttonRef}
      in={isShowing}
      timeout={duration.short}
    >
      { state => (
        <LdsButton
          ref={buttonRef}
          className={cn(
            'lds-back-to-top',
            radiusClass,
            {
              ['d-md-none']: mobileOnly,
            },
            expandOnHover ? 'expand-on-hover' : '',
            className
          )}
          style={{ ...transitionStyles[state] }}
          onClick={handleScrollToTop}
          {...rest}
        >
          <div className='no-expand'>
            <LdsIcon className="back-to-top-icon" name="ArrowUp" decorative />
            <span className={`${hideText || expandOnHover ? 'sr-only' : ''}`}>{backToTopText}</span>
          </div>
          <div className='expand-wrapper'>
            <div className='expand'>
              {backToTopText}
            </div>
          </div>
        </LdsButton>
      )}
    </Transition>
  );
}

export default LdsBackToTop;

LdsBackToTop.propTypes = {
  backToTopText: PropTypes.string,
  hideText: PropTypes.bool,
  mobileOnly: PropTypes.bool,
  expandOnHover: PropTypes.bool,
  scrollOffset: PropTypes.number,
  scrollBehaviour: PropTypes.string,
  threshold: PropTypes.number,
  radiusClass: PropTypes.oneOf(['radius-sm', 'radius-md', 'radius-pill']),
};
