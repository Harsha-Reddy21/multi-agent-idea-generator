import {
  useCallback,
  useEffect,
  useRef,
  useState
} from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsIcon from '../LdsIcon/index.jsx';
import getFocusableElements from '../../util/getFocusableElements.js';
import useClickOutside from '../../hooks/useClickOutside.js';
import handleTabAway from '../../util/handleTabAway.js';

export default function PaginationDropdown({
  ariaLabel,
  className,
  dropdownItems = [],
  onItemClick = () => {},
  value,
}) {
  const [selectedItem, setSelectedItem] = useState(dropdownItems[0]);
  const [isOpen, setIsOpen] = useState(false);
  const [menuPosition, setMenuPosition] = useState('');

  const dropdownContentRef = useRef(null);

  const dropdownRef = useClickOutside(() => {
    if (isOpen) setIsOpen(false);
  });

  const focusFirstItem = () => {
    const focusableElements = getFocusableElements(dropdownContentRef.current);
    if (!focusableElements.length) return;

    focusableElements[0].focus();
  };

  const detectEdges = useCallback(() => {
    /*
      Dropdown open direction logic:
      1. By default dropdowns open below.
      2. Check to see if the dropdown would go off the edge of the screen when opened. If it will - open above.
    */
    const ddWrapper = dropdownRef.current;

    const ddBtn = ddWrapper.querySelector('.lds-pagination-dropdown-toggle');
    const dd = ddWrapper.querySelector('.lds-pagination-dropdown-content');

    const dropdownRect = ddBtn.getBoundingClientRect();
    const dropdownHeight = dd.offsetHeight;
    const screenHeight = window.innerHeight;

    const doesDropDownOverlapBottomEdge = (dropdownRect.top + dropdownHeight) > screenHeight;
    let pos = 'down'; // default dropdown direction
    if (doesDropDownOverlapBottomEdge) {
      pos = 'up';
    }
    setMenuPosition(pos);
  }, [dropdownRef]);

  useEffect(() => {
    detectEdges();

    // Add window resize event listener
    window.addEventListener('resize', detectEdges);

    // Clean up the event listener when component unmounts
    return () => {
      window.removeEventListener('resize', detectEdges);
    };
  }, [detectEdges]);

  useEffect(() => {
    if (isOpen) focusFirstItem();
  }, [isOpen]);

  useEffect(() => {
    if (value) setSelectedItem(value);
  }, [value]);

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  const handleKeyDown = (e) => {
    const callback = () => setIsOpen(false);
    return handleTabAway(e, dropdownRef, callback);
  };

  const handleSelectItem = (e) => {
    const value = Number(e.target.value);
    setSelectedItem(value);
    onItemClick(e, value);
    toggleDropdown();
  };

  return (
    <div
      className={cn(
        'lds-pagination-dropdown',
        className,
        {
          expanded: isOpen,
          down: menuPosition === 'down',
          up: menuPosition === 'up',
        }
      )}
      onKeyDown={handleKeyDown}
      ref={dropdownRef}
    >
      <button
        className="lds-button-clear-style lds-pagination-dropdown-toggle"
        type="button"
        data-toggle="dropdown"
        onClick={toggleDropdown}
      >
        <span style={{ marginInlineEnd: '.25rem' }}>{selectedItem}</span>
        <LdsIcon decorative inline name="CaretDown"></LdsIcon>
      </button>
      <div
        className="lds-pagination-dropdown-content"
        ref={dropdownContentRef}
      >
        <ul>
          {dropdownItems.map((item, index) => (
            <li key={index} className={`dropdownItem-${index + 1}`}>
              <button
                aria-label={`${ariaLabel} ${item}`}
                className={cn(
                  'lds-button-clear-style',
                  'lds-pagination-dropdown-item',
                  {
                    selected: item === selectedItem,
                  }
                )}
                value={item}
                onClick={handleSelectItem}
              >
                {item}
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

PaginationDropdown.propTypes = {
  ariaLabel: PropTypes.string,
  className: PropTypes.string.isRequired,
  dropdownItems: PropTypes.arrayOf(PropTypes.number).isRequired,
  onItemClick: PropTypes.func,
  value: PropTypes.number,
};
