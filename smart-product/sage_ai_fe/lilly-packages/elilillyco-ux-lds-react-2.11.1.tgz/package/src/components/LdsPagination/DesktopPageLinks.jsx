import PageLink from './PageLink.jsx';

export default function DesktopPageLinks({
  page,
  totalPages,
  currentPage,
  firstPageVisible,
  isDisabled,
  lastPageVisible,
  onLinkClick,
  pageLinkAriaLabel,
  useButtons,
}) {
  const EllipsisList = () => {
    return (
      <li>
        <span className="lds-pagination-ellipsis">...</span>
      </li>
    );
  };

  const showFirstEllipsis = (page) => {
    return page === 1 && (firstPageVisible > 1) && firstPageVisible !== 1;
  };

  const showLastEllipsis = (page) => {
    return page === totalPages && (lastPageVisible < totalPages) && lastPageVisible !== totalPages;
  };

  if (page === 1 || page === totalPages) {
    return (
      <>
        {
          showLastEllipsis(page) && <EllipsisList></EllipsisList>
        }
        <PageLink
          currentPage={currentPage}
          isDisabled={isDisabled}
          onLinkClick={onLinkClick}
          page={page}
          pageLinkAriaLabel={pageLinkAriaLabel}
          useButtons={useButtons}
        />
        {
          showFirstEllipsis(page) && <EllipsisList></EllipsisList>
        }
      </>
    );
  }

  if (page <= (lastPageVisible - 1) && page >= (firstPageVisible + 1)) {
    return (
      <PageLink
        currentPage={currentPage}
        isDisabled={isDisabled}
        onLinkClick={onLinkClick}
        page={page}
        pageLinkAriaLabel={pageLinkAriaLabel}
        useButtons={useButtons}
      />
    );
  }

  return null;
}
