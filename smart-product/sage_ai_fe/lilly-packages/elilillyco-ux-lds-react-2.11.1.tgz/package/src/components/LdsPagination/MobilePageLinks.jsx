import cn from 'classnames';
import PaginationDropdown from './PaginationDropdown.jsx';

export default function MobilePageLinks({
  className = '',
  currentPage,
  ofText = 'of',
  onLinkClick = () => {},
  pages = [],
  pageText = 'Page',
  pageLinkAriaLabel,
  totalPages = 10,
}) {
  return (
    <div className={cn(
      'lds-pagination-list-mobile',
      className
    )}>
      <li>
        <span className="lds-pagination-text">{pageText}{'\u003A'}</span>
      </li>
      <li>
        <PaginationDropdown
          ariaLabel={pageLinkAriaLabel}
          className="pagination-dropdown"
          dropdownItems={pages}
          onItemClick={onLinkClick}
          value={currentPage}
        >
        </PaginationDropdown>
      </li>
      <li>
        <span className="lds-pagination-text">{ofText}</span>
      </li>
      <li>
        <span className="lds-pagination-text">{totalPages}</span>
      </li>
    </div>
  );
}
