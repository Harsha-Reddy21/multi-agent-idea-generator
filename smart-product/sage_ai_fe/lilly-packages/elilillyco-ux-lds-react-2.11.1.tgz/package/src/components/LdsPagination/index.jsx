import { forwardRef, useEffect, useState } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import useIsMobile from '../../hooks/useIsMobile.js';

import CurrentPageInput from './CurrentPageInput.jsx';
import ItemsPerPageDropdown from './ItemsPerPageDropdown.jsx';
import PageLinksWrapper from './PageLinksWrapper.jsx';

// JSDoc type definitions
/**
 * @typedef LdsPaginationProps
 * @property {number} currentPage - State variable for currently active page
 * @property {function} setCurrentPage - State function used to set the current page
 * @property {boolean} [isDisabled] - Determines if the whole pagination component is currently disabled or not
 * @property {number} [itemsPerPage] - items/rows per page in the pagination
 * @property {string} [navAriaLabel] - Aria label value for the `nav` wrapper element
 * @property {string} [nextBtnAriaLabel] - Aria label value for the "Next" button
 * @property {string} [nextBtnText] - Text to be used in the "Next" button
 * @property {function} [onLinkClick] - Pagination link click event
 * @property {function} [onNextClick] - Next button click event
 * @property {function} [onPrevClick] - Previous button click event
 * @property {string} [pageLinkAriaLabel] - Aria label value for each pagination link. The value will be appended by the page number. So "Page" will become "Page 1", "Page 2", etc...
 * @property {number} [pageRangeVisible] - State variable for number of pages to be visible in the pagination at once. This should always be an odd number.
 * @property {string} [prevBtnAriaLabel] - Aria label value for the "Previous" button
 * @property {string} [prevBtnText] - Text to be used in the "Previous" button
 * @property {number} [totalItems] - Total number of items/rows in the pagination
 * @property {boolean} [useButtons] - By default the pagination uses links. If buttons should be used instead, set this to `true`
 * @property {string} [className] - Optional custom user-defined CSS class(es) to add to the component root container element; will be appended to the list of any other component classes
 * @property {string} [classes] - Optional additional classes to add to the root container element
 */
const LdsPagination = forwardRef(
  /**
   * LdsPagination component
   * @param {LdsPaginationProps & React.InputHTMLAttributes<HTMLInputElement>} props
   * @returns {React.JSX.Element}
   */
  function LdsPagination({
    currentPage = 1,
    isDisabled = false,
    itemsPerPage = 10,
    navAriaLabel = 'Pagination',
    nextBtnAriaLabel = 'Next page',
    nextBtnText = 'Next',
    onLinkClick = () => {},
    onNextClick = () => {},
    onPrevClick = () => {},
    pageLinkAriaLabel = 'Page',
    pageRangeVisible = 11,
    prevBtnAriaLabel = 'Back page',
    prevBtnText = 'Back',
    setCurrentPage = () => {},
    totalItems = 0,
    useButtons = false,
    className = '',
    classes,
    ...rest
  }, ref) {
    const isMobile = useIsMobile();
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const [firstPageVisible, setFirstPageVisible] = useState(1);
    const [lastPageVisible, setLastPageVisible] = useState(pageRangeVisible);

    const handleLinkClick = (e, value) => {
      e.preventDefault();
      onLinkClick(e, value);
      setCurrentPage(value);
    };

    const handlePrevClick = (e, value) => {
      e.preventDefault();
      onPrevClick(e, value);
      setCurrentPage(currentPage - 1);
    };

    const handleNextClick = (e, value) => {
      e.preventDefault();
      onNextClick(e, value);
      setCurrentPage(currentPage + 1);
    };

    useEffect(() => {
    // handle edge cases
      if (currentPage > totalPages) {
        setCurrentPage(totalPages);
      } else if (currentPage < 1) {
        setCurrentPage(1);
      }
      // update visible pages
      if (currentPage >= Math.ceil(pageRangeVisible / 2) && currentPage <= (totalPages - Math.floor(pageRangeVisible / 2))) {
        setFirstPageVisible(currentPage - Math.floor(pageRangeVisible / 2));
        setLastPageVisible(currentPage + Math.floor(pageRangeVisible / 2));
      }
    }, [currentPage, pageRangeVisible, setCurrentPage, totalPages]);

    useEffect(() => {
    // update visible pages
      if (currentPage < Math.ceil(pageRangeVisible / 2)) {
        setFirstPageVisible(1);
        setLastPageVisible(pageRangeVisible);
      } else if (currentPage > (totalPages - Math.ceil(pageRangeVisible / 2))) {
        setFirstPageVisible(totalPages - pageRangeVisible + 1);
        setLastPageVisible(totalPages);
      } else {
        setFirstPageVisible(currentPage - Math.floor(pageRangeVisible / 2));
        setLastPageVisible(currentPage + Math.floor(pageRangeVisible / 2));
      }
    }, [currentPage, pageRangeVisible, totalPages]);

    return (
    <div
      className={cn(
        'lds-pagination',
        className,
        classes,
        {
          'pagination-mobile': isMobile,
        }
      )}
    >
      <nav
        aria-label={navAriaLabel}
        className="lds-pagination-navigation"
        ref={ref}
        {...rest}
      >
        <ol className="lds-pagination-list">
          <PageLinksWrapper
            currentPage={currentPage}
            isDisabled={isDisabled}
            nextBtnAriaLabel={nextBtnAriaLabel}
            nextBtnText={nextBtnText}
            onLinkClick={handleLinkClick}
            onNextClick={handleNextClick}
            onPrevClick={handlePrevClick}
            lastPageVisible={lastPageVisible}
            firstPageVisible={firstPageVisible}
            pageLinkAriaLabel={pageLinkAriaLabel}
            prevBtnAriaLabel={prevBtnAriaLabel}
            prevBtnText={prevBtnText}
            setCurrentPage={setCurrentPage}
            totalPages={totalPages}
            useButtons={useButtons}
          />
        </ol>
      </nav>
    </div>
    );
  }
);

LdsPagination.CurrentPageInput = CurrentPageInput;
LdsPagination.ItemsPerPageDropdown = ItemsPerPageDropdown;

LdsPagination.propTypes = {
  className: PropTypes.string,
  classes: PropTypes.string,
  currentPage: PropTypes.number.isRequired,
  isDisabled: PropTypes.bool,
  itemsPerPage: PropTypes.number,
  navAriaLabel: PropTypes.string,
  nextBtnAriaLabel: PropTypes.string,
  nextBtnText: PropTypes.string,
  onLinkClick: PropTypes.func,
  onNextClick: PropTypes.func,
  onPrevClick: PropTypes.func,
  pageLinkAriaLabel: PropTypes.string,
  pageRangeVisible: PropTypes.number,
  prevBtnAriaLabel: PropTypes.string,
  prevBtnText: PropTypes.string,
  setCurrentPage: PropTypes.func.isRequired,
  totalItems: PropTypes.number.isRequired,
  useButtons: PropTypes.bool,
};

LdsPagination.CurrentPageInput.propTypes = {
  className: PropTypes.string,
  currentPage: PropTypes.number.isRequired,
  itemsPerPage: PropTypes.number,
  pageText: PropTypes.string,
  ofText: PropTypes.string,
  setCurrentPage: PropTypes.func.isRequired,
  totalItems: PropTypes.number.isRequired,
};

LdsPagination.ItemsPerPageDropdown.propTypes = {
  className: PropTypes.string,
  currentPage: PropTypes.number.isRequired,
  dropdownItems: PropTypes.arrayOf(PropTypes.number) && PropTypes.arrayOf((propValue, key, componentName, propFullName) => { // eslint-disable-line
    if (propValue[key] < 0) {
      return new Error(
        `Invalid prop ${propFullName} supplied to ${componentName} at index ${key}. Must be an array of positive integer.`
      );
    }
  }),
  endText: PropTypes.string,
  itemsPerPage: PropTypes.number,
  ofText: PropTypes.string,
  perPageText: PropTypes.string,
  setItemsPerPage: PropTypes.func.isRequired,
  totalItems: PropTypes.number.isRequired,
};

export default LdsPagination;
