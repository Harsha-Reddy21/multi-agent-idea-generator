export default function ConditionalWrapper({
  buttonWrapper,
  children,
  useButtons,
  linkWrapper,
}) { return useButtons ? buttonWrapper(children) : linkWrapper(children); }
