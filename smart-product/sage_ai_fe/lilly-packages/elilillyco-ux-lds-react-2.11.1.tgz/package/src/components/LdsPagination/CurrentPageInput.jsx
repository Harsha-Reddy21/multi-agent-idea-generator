import { useEffect, useState } from 'react';
import cn from 'classnames';

export default function CurrentPageInput({
  className = '',
  currentPage = 1,
  itemsPerPage = 10,
  pageText = 'Page',
  ofText = 'of',
  totalItems = 0,
  setCurrentPage = () => {},
}) {
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const [value, setValue] = useState(currentPage);

  const handleChange = (e) => {
    setValue(e.target.value);
  };

  useEffect(() => {
    const val = Number(value);
    if (val > 0 && val <= totalPages) setCurrentPage(val);
  }, [value, totalPages, setCurrentPage]);

  useEffect(() => {
    if (currentPage) setValue(currentPage);
  }, [currentPage]);

  return (
    <div
      className={cn(
        'lds-pagination',
        className
      )}
    >
      <div className="lds-pagination-current-page">
        <span className="lds-pagination-text">{pageText}{'\u003A'}</span>
        <input
          autoComplete="off"
          className="lds-text-field lds-pagination-input"
          type="number"
          min={1}
          max={totalPages}
          name="pageNumber"
          value={value}
          onChange={handleChange}
        />
        <span className="lds-pagination-text of-text">{ofText}</span>
        <span className="lds-pagination-text total-text">{totalPages}</span>
      </div>
    </div>
  );
}
