import { memo } from 'react';
import cn from 'classnames';

import LdsIcon from '../LdsIcon/index.jsx';
import ConditionalWrapper from './ConditionalWrapper.jsx';
import useIsMobile from '../../hooks/useIsMobile.js';

const NavigationButton = memo(function NavigationButton({
  btnAriaLabel,
  btnText,
  btnType,
  currentPage,
  isDisabled,
  onPrevClick,
  onNextClick,
  totalPages,
  useButtons,
}) {
  const isMobile = useIsMobile();
  const isBtnDisabled = ((currentPage <= 1) && (btnType === 'prev')) || ((currentPage >= totalPages) && (btnType === 'next'));

  const onBtnClick = (e) => {
    if (btnType === 'prev') {
      onPrevClick(e, btnText);
    } else {
      onNextClick(e, btnText);
    }
  };

  return (
    <li
      className={isBtnDisabled || isDisabled ? 'disabled' : ''}
    >
      <ConditionalWrapper
        useButtons={useButtons}
        buttonWrapper={
          (children) => <button
            aria-label={btnAriaLabel}
            className={cn(
              'lds-button-clear-style',
              'lds-pagination-link',
              `${isMobile ? 'nav-icon-btn' : 'nav-btn'}`,
              btnType,
              {
                disabled: isBtnDisabled,
              }
            )}
            disabled={isBtnDisabled || isDisabled}
            onClick={(e) => onBtnClick(e)}
          >
            {children}
          </button>
        }
        linkWrapper={
          (children) => <a
            aria-disabled={isBtnDisabled}
            aria-label={btnAriaLabel}
            className={cn(
              'lds-pagination-link',
              `${isMobile ? 'nav-icon-btn' : 'nav-btn'}`,
              btnType,
              {
                disabled: isBtnDisabled,
              }
            )}
            href={isBtnDisabled ? null : '#'}
            onClick={(e) => onBtnClick(e)}
            role={isBtnDisabled ? 'link' : null}
          >
            {children}
          </a>
        }
      >
        {
          btnType === 'prev' && <LdsIcon name="CaretLeft" decorative inline ></LdsIcon>
        }
        {
          !isMobile && <span>{btnText}</span>
        }
        {
          btnType === 'next' && <LdsIcon name="CaretRight" decorative inline></LdsIcon>
        }
      </ConditionalWrapper>
    </li>
  );
});

export default NavigationButton;
