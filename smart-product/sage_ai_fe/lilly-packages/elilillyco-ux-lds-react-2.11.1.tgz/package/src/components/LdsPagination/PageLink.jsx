import { memo } from 'react';
import cn from 'classnames';

import ConditionalWrapper from './ConditionalWrapper.jsx';

const PageLink = memo(function PageLink({
  currentPage,
  isDisabled,
  onLinkClick,
  page,
  pageLinkAriaLabel,
  useButtons,
}) {
  return (
    <li
      className={isDisabled ? 'disabled' : null}
    >
      <ConditionalWrapper
        useButtons={useButtons}
        buttonWrapper={
          (children) => <button
            aria-current={currentPage === page}
            aria-label={`${pageLinkAriaLabel} ${page}`}
            className={cn(
              'lds-button-clear-style',
              'lds-pagination-link',
              {
                active: currentPage === page,
              }
            )}
            disabled={isDisabled}
            id={page}
            onClick={(e) => onLinkClick(e, page)}
          >
            {children}
          </button>
        }
        linkWrapper={
          (children) => <a
            aria-current={currentPage === page}
            aria-disabled={isDisabled}
            aria-label={`${pageLinkAriaLabel} ${page}`}
            className={cn(
              'lds-pagination-link',
              {
                active: currentPage === page,
              }
            )}
            href={isDisabled ? null : '#'}
            id={`page-${page}`}
            onClick={(e) => onLinkClick(e, page)}
            role={isDisabled ? 'link' : null}
          >
            {children}
          </a>
        }
      >
        <span>{page}</span>
      </ConditionalWrapper>
    </li>
  );
});

export default PageLink;
