import { memo } from 'react';

import NavigationButton from './NavigationButton.jsx';
import CurrentPageInput from './CurrentPageInput.jsx';
import MobilePageLinks from './MobilePageLinks.jsx';
import useIsMobile from '../../hooks/useIsMobile.js';
import DesktopPageLinks from './DesktopPageLinks.jsx';

const PageLinksWrapper = memo(function PageLinksWrapper({
  currentPage,
  firstPageVisible,
  isDisabled,
  lastPageVisible,
  nextBtnAriaLabel,
  nextBtnText,
  onLinkClick,
  onNextClick,
  onPrevClick,
  totalPages,
  pageLinkAriaLabel,
  prevBtnAriaLabel,
  prevBtnText,
  setCurrentPage,
  useButtons,
}) {
  const isMobile = useIsMobile();
  let pages = [];
  for (let i = 1; i <= totalPages; i += 1) {
    pages.push(i);
  }

  return (
    <>
      {/* Previous button */}
      <NavigationButton
        btnAriaLabel={prevBtnAriaLabel}
        btnText={prevBtnText}
        btnType="prev"
        currentPage={currentPage}
        isDisabled={isDisabled}
        onPrevClick={onPrevClick}
        onNextClick={onNextClick}
        totalPages={totalPages}
        useButtons={useButtons}
      />

      { (isMobile && totalPages > 50)
        && <CurrentPageInput
          className='mx-3'
          currentPage={currentPage}
          setCurrentPage={setCurrentPage}
          totalPages={totalPages}
        />
      }

      { (isMobile && totalPages > 4 && totalPages < 51)
        && <MobilePageLinks
          currentPage={currentPage}
          onLinkClick={onLinkClick}
          pages={pages}
          pageLinkAriaLabel={pageLinkAriaLabel}
          totalPages={totalPages}
        />
      }

      {/* Page links */}
      { ((isMobile && totalPages < 5) || !isMobile)
        && pages.map((page, idx) => (
          <DesktopPageLinks
            key={idx}
            page={page}
            totalPages={totalPages}
            currentPage={currentPage}
            firstPageVisible={firstPageVisible}
            isDisabled={isDisabled}
            lastPageVisible={lastPageVisible}
            onLinkClick={onLinkClick}
            pageLinkAriaLabel={pageLinkAriaLabel}
            useButtons={useButtons}
          />
        ))
      }

      {/* Next button */}
      <NavigationButton
        btnAriaLabel={nextBtnAriaLabel}
        btnText={nextBtnText}
        btnType="next"
        currentPage={currentPage}
        isDisabled={isDisabled}
        onPrevClick={onPrevClick}
        onNextClick={onNextClick}
        totalPages={totalPages}
        useButtons={useButtons}
      />
    </>
  );
});

export default PageLinksWrapper;
