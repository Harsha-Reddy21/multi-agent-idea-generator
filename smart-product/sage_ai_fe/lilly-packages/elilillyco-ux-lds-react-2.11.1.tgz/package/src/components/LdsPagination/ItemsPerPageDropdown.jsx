import { useEffect, useState } from 'react';
import cn from 'classnames';
import PaginationDropdown from './PaginationDropdown.jsx';

export default function ItemsPerPageDropdown({
  className = '',
  currentPage = 1,
  dropdownItems = [10, 25, 50],
  endText = '', // end text to display after the total items count for example: 'items' from '10-20 of 100 items',
  ofText = 'of',
  itemsPerPage = 10,
  perPageText = 'Items per page',
  setItemsPerPage = () => {},
  totalItems = 0,
}) {
  const [selectedItem, setSelectedItem] = useState(itemsPerPage);
  const [pageEnd, setPageEnd] = useState(selectedItem * currentPage);
  const [pageStart, setPageStart] = useState(pageEnd - selectedItem + 1);

  const handleItemClick = (e, value) => {
    if (value) setSelectedItem(value);
  };

  useEffect(() => {
    setItemsPerPage(selectedItem);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedItem]);

  useEffect(() => {
    const value = selectedItem * currentPage;
    if (value > totalItems) setPageEnd(totalItems);
    else setPageEnd(value);
    setPageStart(value - selectedItem + 1);
  }, [selectedItem, currentPage, totalItems]);

  return (
    <div
      className={cn(
        'lds-pagination',
        className
      )}
    >
      <div className="lds-pagination-per-page">
        <span className="lds-pagination-text">{perPageText}</span>
        <PaginationDropdown
          className='items-per-page-dd'
          dropdownItems={dropdownItems}
          onItemClick={handleItemClick}
        ></PaginationDropdown>
        <span className="lds-pagination-text">{pageStart}{'\u002D'}</span>
        <span className="lds-pagination-text">{pageEnd}</span>
        <span className="lds-pagination-text of-text">{ofText}</span>
        <span className="lds-pagination-text">{totalItems}</span>
        {
          endText && <span className="lds-pagination-text">{'\u00A0'}{endText}</span>
        }
      </div>
    </div>
  );
}
