import {
  forwardRef, useState, useRef, useEffect, useCallback
} from 'react';
import cn from 'classnames';
import * as PropTypes from 'prop-types';

import LdsIcon from '../LdsIcon/index.jsx';
// import * as classNames from 'classnames';

// JSDoc comments to supply typescript compiler with the necessary types
/**
 * @typedef LdsProductJumpMenuProps
 * @property {Array} [menu] - Array of menu item objects that populates the Jump Menu
 * @property {string} [ariaLabel] - ARIA-LABEL text for nav element of Jump Menu
 * @property {string} [menuVerticalPosition] - Property to indicate position of the menu vertically as either existing at the 'top' or 'bottom'' of the page, defaults to 'top' if not defined.
 * @property {string} [menuHorizontalPosition] - Property to indicate horizontal position of the menu as either being 'left' or 'right', defaults to 'left' if not defined.
 * @property {string} [menuLabel] - Label to be displayed on menu when collapsed, defaults to 'Index'.
 * @property {string} [menuTitle] - Optional property, title to be displayed when jump menu is expanded.
 * @property {string} [mainIcon] - Property to indicate the name of the LDS icon to be the 'main' icon appearing to the right of the menu button text. Defaults to 'caret-up-down' but can also be any other LDS icon. Other recommended icons are 'caret-up-down-fill', 'caret-up', 'caret-up-fill' , 'caret-down', 'caret-down-fill'.
 * @property {string} [extraIcon] - Optional property, setting a truthy string value enables an LDS icon to be placed in the menu button in addition to the main icon. LDS Icons 'list-varied-line-lengths' and 'list-bullets' are recommended, but any LDs Icon name will work.
 * @property {string} [extraIconPosition] - Defaults to 'after', can be set to 'before' will move the extra icon position from after both the menu button text and the main icon to before.
 * @property {boolean} [backgroundOverlay] - Defaults to false, when set to true will include a black background overlay when the menu is expanded to blur out the background content.
 * @property {string} [backgroundOverlayColor] - Defaults to black when `backgroundOverlay` is set to true, can also be set to be white based on use case.
 * @property {Number} [menuWidthPadding] - Value representing how much padding, in pixels, should be added to the left and right of the menu, defaults to 16.
 * @property {Number} [menuCollapsedHeight] - Value representing height, in pixels, of the menu when collapsed, based on the font size and vertical padding, defaults to 40.
 * @property {Number} [linksHeightPadding] - Value representing how much padding, in pixels, is added vertically in the links container, defaults to 32.
 * @property {Number} [scrollOffset] - Number in pixels for the section scrolled to to be offset from the top of the viewport, defaults to 56.
 * @property {Number} [verticalOffset] - Value representing of how far, in pixels, the menu should be offset from the top or bottom of the screen when the menu is in the top or bottom position, respectively use to add headers or components that should appear above the menu, defaults to 0.
 * @property {Number} [horizontalOffset] - Value representing of how far, in pixels, the menu should be offset from the left or right of the screen when in the left or right position, respectively. Use to add side navigation or components that should appear to the left or right of the menu, defaults to 0.
 * @property {Number} [maxMenuWidth] - Value representing the maximum menu width possible for larger screens. If the screen size minus the padding would exceed  maxMenuWidth, then the menu's expanded width is set to this maxMenuWidth., defaults to 408.
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes.
*/

const LdsProductJumpMenu = forwardRef(
  /**
   * LdsProductJumpMenu component
   * @param {LdsProductJumpMenuProps & React.InputHTMLAttributes<HTMLInputElement>} props
   * @param {React.Ref} ref
   * @returns {React.JSX.Element} - LdsProductJumpMenu component
   */
  function LdsProductJumpMenu(props, ref) {
    const {
      menu,
      ariaLabel = 'in-page navigation',
      menuVerticalPosition = 'top',
      menuHorizontalPosition = '',
      menuLabel = 'Index',
      menuTitle = null,
      mainIcon = 'caret-up-down',
      extraIcon = null,
      extraIconPosition = 'after',
      backgroundOverlay = false,
      backgroundOverlayColor = 'black',
      menuWidthPadding = 16,
      menuCollapsedHeight = 40,
      linksHeightPadding = 32,
      scrollOffset = 56,
      verticalOffset = 0,
      horizontalOffset = 0,
      maxMenuWidth = 408,
      className = '',
    } = props;
    const [isExpanded, setIsExpanded] = useState(false);
    const [isScrollOverlay, setIsScrollOverlay] = useState(false);
    const [menuDimensions, setDimensions] = useState({
      expandedHeight: 0,
      collapsedHeight: menuCollapsedHeight, // Default starting height based on font size.
      expandedWidth: 0,
      collapsedWidth: 0,
    });
    const [activeLinks, setActiveLinks] = useState(
      new Array(menu.length).fill(false).map((link, index) => index === 0 ? true : link)
    );
    const menuRef = useRef(null);
    const innerLinks = useRef(null);
    const linksRef = useRef(null);
    const jumpLinkRefs = useRef([]);
    const windowRef = useRef(null);
    const backgroundOverlayRef = useRef(null);
    // On load set the first link to be considered 'active'
    // Based on scroll update the 'active' section of the page
    const checkActiveSection = useCallback(() => {
      const scrollPosition = windowRef.current.scrollY;
      const jumpSections = getJumpMenuSections();

      // Set active state to false for all links before checking
      setActiveLinks(new Array(menu.length).fill(false));

      let activeIndex = -1;
      // For every page section
      jumpSections.forEach((section, index) => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.offsetHeight;
        // Check whether the top of the section is above the halfway point of the page
        const isTopAboveScreenHalfway = scrollPosition >= (sectionTop - (windowRef.current.innerHeight / 2));
        // Check whether the bottom of the section is below the halfway point of the page
        const isBottomBelowScreenHalfway = scrollPosition < (sectionTop + sectionHeight - (windowRef.current.innerHeight / 2));
        // If the top of the section is above halfway and the bottom is below halfway consider the section to be "active"
        if (isTopAboveScreenHalfway && isBottomBelowScreenHalfway) {
          // If no new 'active' section found, or if current section closer to top than 'active' section
          if (activeIndex === -1 || Math.abs(scrollY - sectionTop) < Math.abs(scrollY - jumpSections[activeIndex].offsetTop)) {
            activeIndex = index;
          }
        }
      });
      if (activeIndex !== -1) {
        setActiveLinks((prevStates) => {
          const newStates = [...prevStates];
          newStates[activeIndex] = !newStates[activeIndex]; // Toggle the state at the given index
          return newStates;
        });
      }
    }, [menu.length]);

    // Update maximum height based on the top and bottom offsets on resize
    useEffect(() => {
      windowRef.current = window;
      if (linksRef?.current && menuRef.current && innerLinks.current) {
        // Calculate expanded height of menu
        const currScrollHeight = innerLinks.current.scrollHeight;
        // Calculate the collapsed width of the menu
        const offsetWidth = menuRef.current.offsetWidth;
        // Calculate the expanded width of the menu
        let currentExpandedWidth = windowRef.current.innerWidth - (menuWidthPadding * 2) - horizontalOffset;
        // Set maxScreenSize to the maxPossible menu width and the padding on both sides
        const maxScreenSize = maxMenuWidth + (menuWidthPadding * 2);
        // If the Window width is larger than the maxScreenSize (set for mobile), then set the expanded width to the defaulted menuWidth (so only part of the screen width is used in larger views)
        if (windowRef.current.innerWidth > maxScreenSize - horizontalOffset) {
          currentExpandedWidth = maxMenuWidth - horizontalOffset;
        } else {
          // Else set the expandedWidth to the size of the window minus the padding
          currentExpandedWidth = windowRef.current.innerWidth - (menuWidthPadding * 2) - horizontalOffset; // Full screen width minus padding
        }
        // Set the width to the collapsed width
        // Set dimensions for menu
        setDimensions({
          expandedHeight: currScrollHeight,
          collapsedHeight: menuCollapsedHeight,
          collapsedWidth: offsetWidth,
          expandedWidth: currentExpandedWidth,
        });
      }
      // Set the max height with space for padding and top or bottom offset
      const currentWindow = windowRef.current;
      // Listen for scrolling and call function to check active sections
      currentWindow.addEventListener('scroll', checkActiveSection);

      return () => {
        currentWindow.removeEventListener('scroll', checkActiveSection);
      };
    }, [linksRef, maxMenuWidth, menuWidthPadding, menuCollapsedHeight, linksHeightPadding, checkActiveSection, verticalOffset, horizontalOffset]);

    const getJumpMenuSections = () => {
      const element = document.querySelectorAll('.lds-product-jump-menu-section');
      if (!element) {
        return null;
      }
      return element;
    };

    const onJumpLinkClick = (i) => {
      const jumpSections = getJumpMenuSections();
      let target = jumpSections[i];
      if (target) {
        // Calculate the distance from the top of the page to the target element
        const targetPosition = target.getBoundingClientRect().top + windowRef.current.scrollY;

        // Adjust for the scroll offset
        const scrollToPosition = targetPosition - scrollOffset; // Shifts the scrolled position by an 'offset' so the portion scrolled to is just below the collapsed menu

        // Scroll smoothly to the target position
        windowRef.current.scrollTo({
          top: scrollToPosition,
          behavior: 'smooth',
        });
      }
    };
    // Check if there is scrolling within the menu
    const checkScroll = () => {
      const linksFullHeight = menuRef.scrollHeight - linksHeightPadding; // Subtract links height padding so scroll isn't created when link content is actually smaller than the client height
      const linksScreenHeight = menuDimensions.expandedHeight;
      if (linksFullHeight <= linksScreenHeight) {
        // Remove scroll overlay if height of links fits in screen height
        setIsScrollOverlay(false);
      } else {
        // Else, set scroll overlay to true
        setIsScrollOverlay(true);
      }
    };

    const handleClick = () => {
      checkScroll();
      if (!isExpanded) {
        // Add expanded class to menu and set width dimensions (height set to auto) if collapsed
        setIsExpanded(true);
      } else if (isExpanded) {
        closeJumpMenu();
      }
    };

    const closeJumpMenu = () => {
      // Remove expanded class, and set width dimensions to collapsed
      setIsExpanded(false);
    };

    const handleKeyPress = (e) => {
      // console.log(e.key); // DEBUG
      const links = jumpLinkRefs.current.filter((link) => link !== null); // Get valid links
      const currentIndex = links.findIndex((link) => link === document.activeElement);
      if ((e.key === 'Enter' || e.key === ' ') && !isExpanded) {
        handleClick();
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        const nextIndex = (currentIndex + 1) % links.length;
        links[nextIndex]?.focus();
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        const prevIndex = (currentIndex - 1 + links.length) % links.length;
        links[prevIndex]?.focus();
      } else if ((e.key === 'Escape' || e.key === 'Tab') && isExpanded) {
        closeJumpMenu(); // Close the menu when Escape is pressed
        requestAnimationFrame(() => menuRef.current.focus());
      } else if (e.key === 'Enter') {
        e.preventDefault();
        document.activeElement.click(); // Simulate link click on Enter
        requestAnimationFrame(() => menuRef.current.focus());
      }
    };

    const getTransform = () => {
      let translateY = verticalOffset;
      let translateX = horizontalOffset;
      if (menuVerticalPosition !== 'top') {
        translateY *= -1;
      }
      if (menuHorizontalPosition !== 'left') {
        translateX *= -1;
      }
      return `translateY(${translateY}px) translateX(${translateX}px)`;
    };

    return (
      <>
        <div ref={ref}>
          <div
            tabIndex="0"
            onKeyDown={handleKeyPress}
            ref={menuRef}
            onClick={handleClick}
            style={{
              transform: getTransform(),
              '--lds-product-jump-menu-link-wrappers-closed-width': `${menuDimensions.collapsedWidth}px`,
              '--lds-product-jump-menu-link-wrappers-open-height': `${menuDimensions.expandedHeight}px`,
              '--lds-product-jump-menu-link-wrappers-open-width': `${menuDimensions.expandedWidth}px`,
            }}
            aria-label={ariaLabel}
            className={cn(
              'lds-product-jump-menu-wrapper',
              menuVerticalPosition,
              menuHorizontalPosition,
              className,
              {
                expanded: isExpanded,
              }
            )}
          >
            <div className='lds-product-jump-menu-content'>
              <span className='lds-product-jump-menu-button'>
                {extraIcon && extraIconPosition === 'before' && <LdsIcon className={cn(
                  'lds-product-jump-menu-extra-icon-left'
                )} name={extraIcon} />}
                {menuLabel}
                <LdsIcon
                  className='lds-product-jump-menu-index-button-icon'
                  name={mainIcon}
                />
                {extraIcon && (extraIconPosition === 'after' || extraIconPosition === undefined) && <LdsIcon className={cn(
                  'lds-product-jump-menu-extra-icon-right'
                )} name={extraIcon} />}
              </span>
            </div>
            <div className='lds-product-jump-menu-links-outer-wrapper'>
              <div className={cn(
                'lds-product-jump-menu-links-inner-wrapper',
                {
                  expanded: isExpanded,
                }
              )}
                ref={innerLinks} >
                <div className='lds-product-jump-menu-links' ref={linksRef}>
                  {menuTitle && <h5 className="lds-product-jump-menu-title">{menuTitle}</h5>}
                  {
                    menu.map((menuItem, idx) => (
                      menuItem.anchor
                        ? <a
                          ref={(el) => {
                            jumpLinkRefs.current[idx] = el;
                          }}
                          key={idx}
                          className={cn(
                            'lds-product-jump-menu-link',
                            {
                              active: activeLinks[idx],
                            }
                          )}
                          href={`#${menuItem.anchor}`}
                          onClick={() => onJumpLinkClick(idx)}
                        >
                          {menuItem.text}
                        </a>
                        : <p className='lds-product-jump-menu-group-title' key={idx}> {menuItem.text} </p>
                    ))
                  }
                </div>
              </div>
              {(isScrollOverlay && menuVerticalPosition === 'top') && <div className='scroll-overlay'></div>}
            </div>
            {(isScrollOverlay && menuVerticalPosition === 'bottom') && <div className='scroll-overlay'></div>}
          </div>
        </div>
        {backgroundOverlay && (backgroundOverlayColor !== 'white' ?? true) && <div className={cn(
          'lds-product-jump-menu-background-overlay black',
          {
            expanded: isExpanded,
          }
        )} ref={backgroundOverlayRef}></div>}
        {backgroundOverlay && (backgroundOverlayColor === 'white' ?? true) && <div className={cn(
          'lds-product-jump-menu-background-overlay white',
          {
            expanded: isExpanded,
          }
        )} ref={backgroundOverlayRef}></div>}
      </>);
  }
);

export default LdsProductJumpMenu;

LdsProductJumpMenu.propTypes = {
  menu: PropTypes.array.isRequired,
  ariaLabel: PropTypes.string,
  menuVerticalPosition: PropTypes.oneOf(['top', 'bottom']),
  menuHorizontalPosition: PropTypes.oneOf(['left', 'right']),
  menuLabel: PropTypes.string,
  menuTitle: PropTypes.string,
  mainIcon: PropTypes.string,
  extraIcon: PropTypes.string,
  extraIconPosition: PropTypes.oneOf(['before', 'after']),
  backgroundOverlay: PropTypes.bool,
  backgroundOverlayColor: PropTypes.oneOf(['black', 'white']),
};
