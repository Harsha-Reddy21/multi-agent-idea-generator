import PropTypes from 'prop-types';
import cn from 'classnames';

import LdsIcon from '../LdsIcon/index.jsx';

// JSDoc type definitions
/**
 * @typedef LdsValidationMessageProps
 * @property {string} id - HTML `id` attribute value of the component
 * @property {string} [className] - Optional custom user-defined CSS class(es) for the component, will be appended to the list of any other component classes
 * @property {string} state - Set the "state" which determines the color and icon which will be used. Accepts: info, success, warning, error
 * @property {React.ReactNode} [children] - React child slot object
 */
/**
 * LdsValidationMessage component
 * @param {LdsValidationMessageProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsValidationMessage({
  id,
  className,
  children,
  state,
  ...rest
}) {
  const getIconName = () => {
    let icon = '';
    switch (state) {
      case ('warning'):
        icon = 'warning-fill';
        break;
      case ('success'):
        icon = 'check-circle-fill';
        break;
      case ('error'):
        icon = 'warning-circle-fill';
        break;
      default:
        icon = 'info-fill';
    }
    return icon;
  };

  return (
    <span
      id={id}
      className={cn(
        'lds-form-validation-message',
        state,
        className
      )}
      {...rest}
    >
      <span className="icon-wrapper">
        <LdsIcon name={getIconName()} inline decorative />
      </span>
      {children}
    </span>
  );
}

LdsValidationMessage.propTypes = {
  id: PropTypes.string.isRequired,
  state: PropTypes.string.isRequired,
};
