import PropTypes from 'prop-types';
import cn from 'classnames';

// JSDoc type definitions
/**
 * @typedef LdsIconProps
 * @property {string} name - Required; Set a string value of a valid LDS Icon name to render
 * @property {boolean} [inline] - Optional; When true this prop sets the icon to display in inline mode when used within a typographical element
 * @property {string} [label] - Optional; When set to a truthy string value, it overrides the content of the `<title>` element of the icon `<svg>`; defaults to the icon name value; used to modify how icons are contextually described by assistive techonology
 * @property {boolean} [decorative] - Optional; When set implies the icon has no contextual value; adds the `aria-hidden="true"` attribute to the icon SVG element which hides it from assistive technology.
 * @property {string} [className] - Optional; Custom user-defined CSS class(es) for the component context, will be appended to the list of any other component classes on the rendered icon SVG element.
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Optional; Define any additional non-prop attributes to be rendered on the icon SVG element.
 */
/**
 * LdsIcon component
 * @param {LdsIconProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsIcon({
  name,
  inline = false,
  label,
  decorative,
  className,
  ...rest
}) {
  const pascalToKebab = (str) => {
    let iconName;

    try {
      iconName = str;
      iconName = iconName.replace(/([a-z0–9])([A-Z])/g, '$1-$2').toLowerCase();
    } catch (ex) {
      // eslint-disable-next-line no-console
      console.error(`LDS ERROR: Unexpected failure converting icon name '${str}' from pascalToKebab:`, ex.message);
      iconName = '!ERROR';
    }

    return iconName;
  };
  const iconName = pascalToKebab(name);

  return (
    <svg
      className={cn(
        'lds-icon',
        `${iconName}`,
        {
          inline,
        },
        className
      )}
      aria-hidden={decorative}
      role={decorative ? null : 'img'}
      focusable="false"
      {...rest}
    >
      {!decorative
      && <title>
          {label || iconName}
        </title>
      }
    </svg>
  );
}

LdsIcon.propTypes = {
  name: PropTypes.string.isRequired,
  inline: PropTypes.bool,
  label: PropTypes.string,
  decorative: PropTypes.bool,
  className: PropTypes.string,
  rest: PropTypes.any,
};
