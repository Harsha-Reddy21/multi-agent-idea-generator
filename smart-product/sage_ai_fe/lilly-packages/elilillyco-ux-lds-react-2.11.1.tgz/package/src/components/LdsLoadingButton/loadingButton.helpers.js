/**
 * Create a predictable ID attribute for the LdsButton from the component ID prop
 *
 * @param id the value of the loading button's 'id' prop
 *
 * @returns {string} a string value to set on the LdsButton's ID attribute
 */
export const getButtonId = (id) => {
  if (id) return `${id}-button`;
  return undefined;
};

/**
 * Validate and return a valid state prop value; warn to console if invalid data is intercepted
 *
 * @param state the value of the loading button's 'state' prop
 *
 * @returns {string} a valid state value of 'ready', 'loading', 'success' or 'failure'; it defaults to 'failure' if the state value is invalid
 */
export const getState = (state) => {
  try {
    const btnState = state.toLowerCase();
    switch (btnState) {
      case 'ready':
      case 'loading':
      case 'success':
      case 'failure':
        return btnState;
      default:
        // eslint-disable-next-line no-console
        console.warn(`
        >>> LDS WARNING: [Invalid Component Data] in LdsLoadingButton: the state prop was set to an invalid value of '${state}'; state will default to 'failure'.
        `);
        return 'failure';
    }
  } catch (ex) {
    // eslint-disable-next-line no-console
    console.warn(`
    >>> LDS WARNING: [Invalid Component Data] in LdsLoadingButton: an unexpected value was found on the state prop of '${state}'; state will default to 'failure'.
    Exception: ${ex.message}
    `);
    return 'failure';
  }
};

/**
 * Determine whether the button should be disabled (non-clickable) in a given state
 *
 * @param {string} state the value of the loading button's 'state' prop (ideally this should already be passed through getState)
 *
 * @returns {boolean} If any state value other than 'ready' then return true.
 */
export const isDisabledState = (state) => {
  switch (state) {
    case 'loading':
    case 'success':
    case 'failure':
      return true;
    default:
      return false;
  }
};
