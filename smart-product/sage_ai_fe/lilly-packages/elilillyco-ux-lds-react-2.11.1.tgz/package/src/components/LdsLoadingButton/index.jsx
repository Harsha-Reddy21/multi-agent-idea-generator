import { useId, createContext } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import {
  getButtonId,
  getState,
  isDisabledState
} from './loadingButton.helpers.js';

import LdsButton from '../LdsButton/index.jsx';
import LdsIcon from '../LdsIcon/index.jsx';
import LdsLoadingSpinner from '../LdsLoadingSpinner/index.jsx';

const LabelByContext = createContext(null);

// JSDoc type definitions
/**
 * @typedef LdsLoadingButtonProps
 * @property {string} [buttonClasses] - Primarily used to set the LDS Button's Theme/Style variant. Passes a space-delimited list of LDS button classes (or any other user-defined classes) to the LDS Button sub-component using this prop
 * @property {boolean} [disabled] - Whether the loading button is in the disabled state; disabled buttons cannot be interacted with
 * @property {boolean} [linkButton] - Whether the LDS Button sub-component will be rendered to look like a text link
 * @property {number} [loadingSpinnerSize] - Set the overall size (both the height and width) of the loading spinner in pixels; larger numbers result in a bigger spinner
 * @property {number} [loadingSpinnerSpeed] - Set a number of milliseconds for the animation speed of the loading spinner to complete a rotation; smaller numbers result in a faster spin
 * @property {function} [onClick] - The click event handler.
 * @property {string} [state] - The state the loading button is in. This prop value should be dynamically modified by a React function, typically a useState hook. Must be set to one of the following values: 'loading', 'success', 'failure', or 'ready'
 * @property {string} [type] - The value of the LDS Button sub-component's "type" prop which corresponds to HTML button element types; it must be 'button', 'submit', or 'reset'
 * @property {boolean} [disableLoadingSpinner] - Whether the loading spinner will be disabled. When true the button will disable but remain visible during the loading state and show the LdsLoadingButton.LabelLoading content
 * @property {boolean} [iconOnly] - Whether the button will only have an icon as the content; when true the button has reduced horizontal density and icon position classes do not function
 * @property {boolean} [spinnerIconTitle] - The text value of the title tag within the Loading Spinner SVG element that defines the spinner image; may sometimes be visible as a browser tooltip if the user hovers the spinner image
 * @property {string} [className] - Additional custom user-defined classes to add to the loading button container DIV
 * @property {React.ReactNode} [children] - The children of the button.
 */
/**
 * LdsLoadingButton component
 * @param {LdsLoadingButtonProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
function LdsLoadingButton({
  buttonClasses = undefined,
  disabled = false,
  linkButton = false,
  loadingSpinnerSize = 20,
  loadingSpinnerSpeed = 1500,
  onClick,
  state = 'ready',
  type = 'button',
  disableLoadingSpinner = false,
  iconOnly = false,
  spinnerIconTitle,
  className,
  children,
  ...rest
}) {
  const id = useId();
  const labeledById = useId();
  // Ensure state value is valid
  const validState = getState(state);

  return (
    <div
      id={id}
      className={cn(
        'lds-loading-button',
        {
          loading: validState === 'loading',
          success: validState === 'success',
          failure: validState === 'failure',
          'no-spinner': disableLoadingSpinner,
        },
        className
      )}
      aria-live="assertive"
      {...rest}
    >
      <LdsButton
        id={getButtonId(id)}
        classes={cn(
          {
            'loading-success': validState === 'success',
            'loading-failure': validState === 'failure',
            [buttonClasses]: !!buttonClasses,
          }
        )}
        disabled={disabled || isDisabledState(validState)}
        linkButton={linkButton}
        onClick={onClick}
        type={type}
        iconOnly={iconOnly}
        aria-labelledby={`${validState}-${labeledById}`}
      >
        <LoadingButtonSpinner
          hide={disableLoadingSpinner}
          size={loadingSpinnerSize}
          speed={loadingSpinnerSpeed}
          svgTitle={spinnerIconTitle}
        />
        <LabelByContext.Provider value={labeledById}>
          {children}
        </LabelByContext.Provider>
      </LdsButton>
    </div>
  );
}

// Define the loading spinner based on whether it should be used
const LoadingButtonSpinner = ({
  hide, size, speed, svgTitle,
}) => {
  if (hide) {
    return null;
  }

  return (
    <LdsLoadingSpinner
      size={size}
      animationSpeed={speed}
      svgTitle={svgTitle}
      decorative
    />
  );
};

// JSDoc type definitions
/**
 * @typedef LdsLoadingButton.LabelDefaultProps
 * @property {string} [children] - The children of the default label.
 */
/**
 * LdsLoadingButton.LabelDefault sub-component
 * @param {LdsLoadingButton.LabelDefaultProps} props
 * @returns {React.JSX.Element}
 */
function LabelDefault({ children, ...rest }) {
  return (
    <LabelByContext.Consumer>
      {(id) => (
        <span
          className="lds-loading-btn-text-default"
          {...rest}
          id={cn(`ready-${id}`, rest.id)}
        >
          {children}
        </span>
      )}
    </LabelByContext.Consumer>
  );
}
LdsLoadingButton.LabelDefault = LabelDefault;

// JSDoc type definitions
/**
 * @typedef LdsLoadingButton.LabelLoadingProps
 * @property {string} [children] - The children of the loading label.
 */
/**
 * LdsLoadingButton.LabelLoading sub-component
 * @param {LdsLoadingButton.LabelLoadingProps} props
 * @returns {React.JSX.Element}
 */
function LabelLoading({ children, ...rest }) {
  return (
    <LabelByContext.Consumer>
      {(id) => (
        <span
          className="lds-loading-btn-text-loading"
          {...rest}
          id={cn(`loading-${id}`, rest.id)}
        >
          {children}
        </span>
      )}
    </LabelByContext.Consumer>
  );
}
LdsLoadingButton.LabelLoading = LabelLoading;

// JSDoc type definitions
/**
 * @typedef LdsLoadingButton.LabelSuccessProps
 * @property {string} [icon] - Optional name of LdsIcon to place next to the child label.
 * @property {string} [iconLabel] - The content of the icon's title element; defaults to the icon name; use on non-decorative icons
 * @property {string} [children] - The children of the success label.
 */
/**
 * LdsLoadingButton.LabelSuccess sub-component
 * @param {LdsLoadingButton.LabelSuccessProps} props
 * @returns {React.JSX.Element}
 */
function LabelSuccess({
  icon = 'check-circle-fill',
  iconLabel,
  children,
  ...rest
}) {
  return (
    <LabelByContext.Consumer>
      {(id) => (
        <span
          className="lds-loading-btn-text-success"
          {...rest}
          id={cn(`success-${id}`, rest.id)}
        >
          {icon
            && <LdsIcon
              name={icon}
              label={iconLabel}
              inline
              decorative={children !== undefined}
              className="button-icon status-icon"
            />
          }
          {children}
        </span>
      )}
    </LabelByContext.Consumer>
  );
}
LdsLoadingButton.LabelSuccess = LabelSuccess;

// JSDoc type definitions
/**
 * @typedef LdsLoadingButton.LabelFailureProps
 * @property {string} [icon] - Optional name of LdsIcon to place next to the child label.
 * @property {string} [iconLabel] - The content of the icon's title element; defaults to the icon name; use on non-decorative icons
 * @property {string} [children] - The children of the failure label.
 */
/**
 * LdsLoadingButton.LabelFailure sub-component
 * @param {LdsLoadingButton.LabelFailureProps} props
 * @returns {React.JSX.Element}
 */
function LabelFailure({
  icon = 'x-circle-fill',
  iconLabel,
  children,
  ...rest
}) {
  return (
    <LabelByContext.Consumer>
      {(id) => (
        <span
          className="lds-loading-btn-text-failure"
          {...rest}
          id={cn(`failure-${id}`, rest.id)}
        >
          {icon
            && <LdsIcon
              name={icon}
              label={iconLabel}
              inline
              decorative={children !== undefined}
              className="button-icon status-icon"
            />
          }
          {children}
        </span>
      )}
    </LabelByContext.Consumer>
  );
}
LdsLoadingButton.LabelFailure = LabelFailure;

export default LdsLoadingButton;

LdsLoadingButton.propTypes = {
  id: PropTypes.string,
  buttonClasses: PropTypes.string,
  className: PropTypes.string,
  disabled: PropTypes.bool,
  linkButton: PropTypes.bool,
  iconOnly: PropTypes.bool,
  spinnerIconTitle: PropTypes.string,
  loadingSpinnerSize: PropTypes.number,
  loadingSpinnerSpeed: PropTypes.number,
  state: PropTypes.oneOf(['loading', 'success', 'failure', 'ready']),
  type: PropTypes.oneOf(['button', 'submit', 'reset']),
};
