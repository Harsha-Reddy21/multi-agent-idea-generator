import LdsIcon from '../LdsIcon/index.jsx';
import LdsLink from '../LdsLink/index.jsx';

export default function Phone({
  phone,
}) {
  const phoneLink = () => {
    if (phone && phone.standard) {
      return `tel:${phone.standard.replace(/[^\d]/g, '')}`;
    }
    // eslint-disable-next-line no-console
    console.error('LDS ERROR [Invalid Usage]: prop "phone" object does not have a "standard" property. Check the phone input object to ensure that the required numeric "standard" version of the phone number has been included.', '\n>>> in LdsContactLilly');
    return '';
  };

  return (
    <div className='lds-contact-lilly-dropdown-content-item lds-contact-lilly-dropdown-content-item-phone'>
      <LdsLink
        href={phoneLink()}
      >
        <LdsIcon
          decorative
          inline
          name="PhoneFill"
        ></LdsIcon>
        <span>
          {
            phone.pretty
            && <span className="lds-contact-lilly-dropdown-content-item-text">{phone.pretty}</span>
          }
          {
            phone.standard
            && <span className="lds-contact-lilly-dropdown-content-item-text">{phone.standard}</span>
          }
        </span>
      </LdsLink>
    </div>
  );
}
