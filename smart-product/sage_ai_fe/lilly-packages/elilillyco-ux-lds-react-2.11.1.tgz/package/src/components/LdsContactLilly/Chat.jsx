import LdsButton from '../LdsButton/index.jsx';

export default function Chat({
  chatText,
  onChatClick,
}) {
  return (
    <div className="lds-contact-lilly-dropdown-content-item  lds-contact-lilly-dropdown-content-item-chat">
      <LdsButton
        disableIconSpace
        icon="ChatsFill"
        iconPosition="before"
        linkButton
        onClick={(e) => onChatClick(e)}
      >
        <span className="lds-contact-lilly-dropdown-content-item-text">{chatText}</span>
      </LdsButton>
    </div>
  );
}
