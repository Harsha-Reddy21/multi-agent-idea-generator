export default function Content({
  content,
}) {
  return (
    <div className="lds-contact-lilly-dropdown-content-item lds-contact-lilly-dropdown-content-item-generic">
      <div className="content-block">
        {content}
      </div>
    </div>
  );
}
