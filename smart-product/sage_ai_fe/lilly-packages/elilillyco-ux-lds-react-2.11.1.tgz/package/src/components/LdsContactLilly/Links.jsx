import LdsLink from '../LdsLink/index.jsx';

export default function Links({
  links,
  linkType,
  onQuestionClick,
}) {
  const isHcp = linkType === 'hcp';

  return (
    links.map((link, idx) => (
      <div
        className={`lds-contact-lilly-dropdown-content-item lds-contact-lilly-dropdown-content-item-${isHcp ? 'visit' : 'question'} lds-contact-lilly-${isHcp ? 'hcp' : 'question'}-list`}
        key={`${link.href}-${idx}`}
      >
        <LdsLink
          href={link.href}
          icon={link.iconName || (isHcp ? 'Link' : 'QuestionFill')}
          iconPosition="before"
          onClick={isHcp ? null : (e) => onQuestionClick(e)}
          useIcon
          contextualIcon
        >
          <span className="lds-contact-lilly-dropdown-content-item-text">{link.text}</span>
        </LdsLink>
      </div>
    ))
  );
}
