import LdsLillyLogo from '../LdsLillyLogo/index.jsx';

export default function AskLillyLogo({
  askText,
  introText,
}) {
  return (
    <div className="lds-contact-lilly-dropdown-bottom">
      <div className="lds-contact-lilly-logo">
          <span className="lds-logo-ask-lilly-ask">{askText}</span>
          <LdsLillyLogo className="lds-logo-ask-lilly" />
        </div>
      <div className="lds-contact-lilly-dropdown-intro">{introText}</div>
    </div>
  );
}
