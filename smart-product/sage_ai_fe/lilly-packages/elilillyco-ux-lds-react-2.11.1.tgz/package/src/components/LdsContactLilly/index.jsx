import cn from 'classnames';
import PropTypes from 'prop-types';
import { useState } from 'react';

import LdsDropdown from '../LdsDropdown/index.jsx';
import LdsIcon from '../LdsIcon/index.jsx';

import Phone from './Phone.jsx';
import Links from './Links.jsx';
import Chat from './Chat.jsx';
import Content from './Content.jsx';
import AskLillyLogo from './AskLillyLogo.jsx';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsContactLillyProps
 * @property {{
*  phone: {pretty: string, standard: string},
*  hcpLinks: {href: string, text: string, iconName?: string}[],
*  questionLinks: {href: string, text: string, iconName?: string}[],
*  enableChat: boolean,
*  content: string|React.ReactNode
 * }} options - Object of component options
 * @property {boolean} [askLillyLogo] - Set to `false` to hide the Ask Lilly logo
 * @property {string} [askText] - Text content for the Ask Lilly logo
 * @property {string} [btnAriaLabelOpened] - `aria-label` attribute value when component is opened
 * @property {string} [btnAriaLabelClosed] - `aria-label` attribute value when component is closed
 * @property {string} [btnText] - Text content for the open/close button
 * @property {string} [chatText] - Text content for the chat button
 * @property {string} [classes] - Classes applied to the `div.lds-contact-lilly` wrapper element
 * @property {boolean} [forceMobile] - Set to `true` to force the component into the "mobile" style (accordion instead of dropdown) regardless of screen size'
 * @property {string} [introText] - Text content for the top of the dropdown, just below the logo
 * @property {function} [onChat] - Chat click event
 * @property {function} [onCollapse] - Collapse/close event
 * @property {function} [onExpand] - Expand/open event
 * @property {function} [onQuestion] - Question link click event
 * @property {boolean} [closeOnDocumentClick] - Set to `false` to prevent the dropdown from closing when clicking outside of it
 * @property {boolean} [btnIcon] - Set to true to display a headset icon in the button that opens CL
 * @property {boolean} [iconOnly] - Set to make CL display with only an icon and no text in the button
 */
/**
 * LdsContactLilly component
 * @param {LdsContactLillyProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsContactLilly component
 */
export default function LdsContactLilly({
  dropdownAlignment = 'left',
  askLillyLogo = true,
  askText = 'Ask',
  btnAriaLabelOpened = 'Close Contact Us',
  btnAriaLabelClosed = 'Open Contact Us',
  btnText = 'Contact Us',
  btnIcon = true,
  iconOnly = false,
  chatText = 'Click to Chat',
  classes,
  forceMobile = false,
  introText = 'We’re here to help.',
  isOpenInit = false,
  onChat = () => {},
  onCollapse,
  onExpand,
  onQuestion = () => {},
  options,
  ...rest
}) {
  const [isOpen, setIsOpen] = useState(isOpenInit);
  const handleChatClick = (e) => {
    e.preventDefault();
    onChat(e);
  };

  const handleQuestionClick = (e) => {
    onQuestion(e);
  };

  return (
    <div
      className={cn(
        'lds-contact-lilly',
        {
          'force-mobile': forceMobile,
          [`${classes}`]: classes,
        }
      )}
      {...rest}
    >
      <LdsDropdown
        dropdownAlignment={dropdownAlignment}
        isOpen={isOpen}
        setIsOpen={setIsOpen}
        label={<span className="lds-contact-lilly-toggle-label">
          {(btnIcon || iconOnly)
            && <LdsIcon
              name="headset-fill"
              inline
              decorative
              className={cn(
                'cl-btn-icon',
                {
                  'icon-only': iconOnly,
                }
              )}
            />
          }
          {!iconOnly && <span className="cl-btn-text">{btnText}</span> }
        </span>}
        buttonProps={{
          className: 'lds-contact-lilly-toggle',
          'aria-label': isOpen ? btnAriaLabelOpened : btnAriaLabelClosed,
        }}
        dropdownProps={{
          className: 'lds-contact-lilly-dropdown',
        }}
        onCollapse={onCollapse}
        onExpand={onExpand}
      >
        <div className="lds-contact-lilly-dropdown-top">
          {options.phone
            && <Phone
              phone={options.phone}
            />
          }

          {options.hcpLinks
            && <Links
              links={options.hcpLinks}
              linkType="hcp"
            />
          }

          {options.questionLinks
            && <Links
              links={options.questionLinks}
              linkType="question"
              onQuestionClick={handleQuestionClick}
            />
          }

          {options.enableChat
            && <Chat
              chatText={chatText}
              onChatClick={handleChatClick}
            />
          }

          {options.content
            && <Content
              content={options.content}
            />
          }

        </div>

        {askLillyLogo
          && <AskLillyLogo
            askText={askText}
            introText={introText}
          />
        }

      </LdsDropdown>
    </div>
  );
}

LdsContactLilly.propTypes = {
  askLillyLogo: PropTypes.bool,
  askText: PropTypes.string,
  btnAriaLabelOpened: PropTypes.string,
  btnAriaLabelClosed: PropTypes.string,
  chatText: PropTypes.string,
  classes: PropTypes.string,
  forceMobile: PropTypes.bool,
  introText: PropTypes.string,
  isOpenInit: PropTypes.bool,
  onChat: PropTypes.func,
  onCollapse: PropTypes.func,
  onExpand: PropTypes.func,
  onQuestion: PropTypes.func,
  options: PropTypes.object.isRequired,
  iconOnly: PropTypes.bool,
  btnIcon: PropTypes.bool,
  dropdownAlignment: PropTypes.oneOf(['left', 'right']),
};
