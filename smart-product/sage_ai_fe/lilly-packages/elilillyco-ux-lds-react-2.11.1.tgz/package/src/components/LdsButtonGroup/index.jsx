import { useEffect, useRef, useState } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsDropdown from '../LdsDropdown/index.jsx';
import LdsIcon from '../LdsIcon/index.jsx';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsButtonGroupProps
 * @property {boolean} [split] - Optional; Whether the button is a split button group variant.
 * @property {string} [iconName] - Optional; Name of the phosphor icon for dropdown button.
 * @property {string} [styleClass] - Optional; Set a string value for one of the variant component style classes; same as button style variant classes like outlined and inverted.
 * @property {string} [densityClass] - Optional; set one of the density size classes for the component; only one valid value is 'compact' or leave undefined for the default density
 * @property {string} [radiusClass] - Optional; set one of the border radius size classes for the component; valid values are 'radius-sm', 'radius-md', 'radus-lg' or leave undefined to use the theme radius default
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {React.ReactNode} [children] - children as buttons are required for button group.
 */
/**
 * LdsButtonGroup component
 * @param {LdsButtonGroupProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsButtonGroup component
 */
function LdsButtonGroup({
  className,
  densityClass,
  radiusClass,
  styleClass,
  split,
  iconName,
  children,
  ...rest
}) {
  const btnGrpRef = useRef(null);
  const dropdownRef = useRef(null);
  const buttonsRef = useRef(null);
  const [dropdownIdx, setDropdownIdx] = useState(0);
  const [isOpen, setIsOpen] = useState(false);
  const [isDropdownRequired, setIsDropdownRequired] = useState(false);

  const getButtonsWidth = () => {
    let width = 55; // fixed 55px for dropdown expand icon btn width, so initilized instead later to add.
    const btnElements = buttonsRef.current.querySelectorAll(':scope > .lds-button');
    btnElements.forEach(el => { width += el.offsetWidth; });
    return width;
  };

  useEffect(() => {
    if (isDropdownRequired) {
      const totalBtns = dropdownRef.current.childElementCount;
      for (let btnIndex = 0; btnIndex < totalBtns; btnIndex += 1) {
        if (btnIndex < dropdownIdx) dropdownRef?.current.children[btnIndex].classList.add('d-none');
        else dropdownRef?.current.children[btnIndex].classList.remove('d-none');
      }
    }
  }, [isDropdownRequired, dropdownIdx]);

  useEffect(() => {
    const checkWidth = () => {
      let btnsWidth = 0;
      let ddIndex = 0;
      const totalWidth = btnGrpRef.current.offsetWidth;
      const btnElements = buttonsRef.current.querySelectorAll(':scope > .lds-button');
      if (split) {
        if (!isDropdownRequired) {
          btnElements.forEach((el, index) => { if (index !== 0) el.classList.add('d-none'); });
          setIsDropdownRequired(true);
          setDropdownIdx(1);
        }
        return;
      }
      setIsDropdownRequired(false);
      btnElements.forEach(el => el.classList.remove('d-none'));
      for (let btnIndex = btnElements.length - 1; btnIndex > 0; btnIndex -= 1) {
        btnsWidth = getButtonsWidth();
        if (btnsWidth >= totalWidth) {
          btnElements[btnIndex].classList.add('d-none');
          setIsDropdownRequired(true);
          ddIndex = btnIndex;
        }
      }
      setDropdownIdx(ddIndex);
    };
    checkWidth();
    window.addEventListener('resize', checkWidth);
    return () => window.removeEventListener('resize', checkWidth);
  }, [isDropdownRequired, split]);

  return (
    <div
      className={cn(
        'lds-button-group',
        className,
        densityClass,
        radiusClass,
        styleClass
      )}
      ref={btnGrpRef}
      {...rest}
    >
      <div className="lds-button-group-container">
        <div className="lds-button-group-buttons" ref={buttonsRef}>
          {children}
          { isDropdownRequired
            && <LdsDropdown
                  isOpen={isOpen}
                  setIsOpen={setIsOpen}
                  showExpandIcon={!(iconName || split)}
                  dropdownAlignment="left"
                  label={(iconName || split)
                    && <LdsIcon
                      className={cn({ 'lds-dropdown-expand-icon': split && !iconName })}
                      name={iconName || 'caret-down-fill' }
                      inline
                      decorative
                    />
                  }
                  wrapperProps={{
                    className: 'lds-button-group-dd-wrapper',
                  }}
                  buttonProps={{
                    className: cn(
                      'lds-button',
                      'lds-button-group-dd-icon-btn',
                      radiusClass,
                      densityClass,
                      styleClass
                    ),
                  }}
                  dropdownProps={{
                    className: 'lds-button-group-dropdown',
                  }}
                >
                  <div className="lds-button-group-dd-section" ref={dropdownRef}>
                    {children}
                  </div>
                </LdsDropdown>
          }
        </div>
      </div>
    </div>
  );
}

LdsButtonGroup.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
  styleClass: PropTypes.string,
  densityClass: PropTypes.oneOf(['compact', undefined]),
  radiusClass: PropTypes.oneOf(['radius-sm', 'radius-md', 'radius-pill', 'pill', undefined]),
  iconName: PropTypes.string,
  split: PropTypes.bool,
};
export default LdsButtonGroup;
