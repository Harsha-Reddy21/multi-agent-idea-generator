import cn from 'classnames';
import PropTypes from 'prop-types';
import { useId } from 'react';

import LdsIcon from '../LdsIcon/index.jsx';

// JSDoc type definitions
/**
 * @typedef LdsLoadingSpinnerProps
 * @property {number} [size] - Sets the height and width of the spinner in pixels; larger numbers render a larger spinner
 * @property {number} [animationSpeed] - Sets the apparent rotating animation speed of the spinner in milliseconds; lower numbers result in a faster spinner
 * @property {boolean} [decorative] - Whether the spinner should be decorative; when set it adds the ARIA hidden attribute to true which will cause the spinner to be ignored by assistive technology
 * @property {string} [ariaLabel] - The value of the ARIA label on the component which may be announced by assistive technologies
 * @property {string} [svgTitle] - The text value of the title tag within the SVG element that defines the spinner image; may sometimes be visible as a browser tooltip if the user hovers the spinner image
 * @property {string} [iconName] - Optional name of an LdsIcon to display in the center of the loading spinner.
 * @property {string} [backgroundColor] - Optional prop to set the color of the background ring.
 * @property {string} [spinnerColor] - Optional prop to set the color of the spinning element.
 * @property {string} [iconColor] - Optional prop to set the color of the icon.
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 */
/**
 * LdsLoadingSpinner component
 * @param {LdsLoadingSpinnerProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
function LdsLoadingSpinner({
  size = 60,
  animationSpeed = 1500,
  decorative = false,
  ariaLabel = 'loading',
  svgTitle = 'loading',
  iconName,
  backgroundColor,
  spinnerColor,
  iconColor,
  className = '',
  ...rest
}) {
  const dimSize = `${size}px`;
  const durAnimationSpeed = `${animationSpeed}ms`;
  const txtAriaLabel = ariaLabel || 'loading';
  const txtSvgTitle = svgTitle || txtAriaLabel;
  const titleId = useId();

  return (
    <div
      className={cn(
        'lds-loading-spinner',
        className
      )}
      style={{ width: dimSize, height: dimSize }}
      aria-label={decorative ? null : txtAriaLabel}
      aria-hidden={decorative ? 'true' : null}
      role={decorative ? null : 'alert'}
      aria-live={decorative ? null : 'assertive'}
      {...rest}
    >
      <svg
        style={{
          width: dimSize,
          height: dimSize,
        }}
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 50 50"
        aria-labelledby={titleId} // Not all screen readers announce the title tag alone.
      >
        <title id={titleId}>
          {txtSvgTitle}
        </title>
        {/* Solid background circle */}
        <circle
          className="lds-loading-spinner-svg-bg"
          style={{
            stroke: backgroundColor,
          }}
          cx="25"
          cy="25"
          r="20"
        />
        {/* Rotating stroke element */}
        <circle
          style={{
            animationDuration: durAnimationSpeed,
            stroke: spinnerColor,
          }}
          className="lds-loading-spinner-svg-dash"
          cx="25"
          cy="25"
          r="20"
        />
      </svg>
      {iconName && (
        <LdsIcon
          className="lds-loading-spinner-icon"
          style={{
            background: iconColor,
          }}
          name={iconName}
        />
      )}
    </div>
  );
}

export default LdsLoadingSpinner;

LdsLoadingSpinner.propTypes = {
  ariaLabel: PropTypes.string,
  animationSpeed: PropTypes.number,
  className: PropTypes.string,
  decorative: PropTypes.bool,
  size: PropTypes.number,
  svgTitle: PropTypes.string,
  iconName: PropTypes.string,
  backgroundColor: PropTypes.string,
  spinnerColor: PropTypes.string,
  iconColor: PropTypes.string,
};
