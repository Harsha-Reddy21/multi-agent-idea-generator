/* eslint-disable no-param-reassign */
import { Children } from 'react';

// Helper function to filter and map child components
export function filterAndMapComponents(children, type) {
  const childComponents = Children.toArray(children);

  return childComponents
    .filter((child) => child.type === type)
    .map((child) => child.props.children);
}

/**
 * Adjusts the position of a tooltip's description or arrow element relative to the tooltip itself.
 * @param {HTMLElement} tooltip - The main tooltip element.
 * @param {HTMLElement} descriptionOrArrow - The element that needs to be adjusted (either description or arrow).
 * @param {HTMLElement|null} toolTipWrapper - The parent element that may constrain the tooltip. Default is null.
 * @param {number} edgePadding - Additional padding from the edge when repositioning. Default is 0.
 * @param {boolean} constrainToParent - Flag to indicate if the position should be constrained to the parent. Default is false.
 *
 * @returns {number|null} The new 'left' position for the descriptionOrArrow element or null if either tooltip or descriptionOrArrow is missing.
 */

function adjustPosition({
  tooltip,
  descriptionOrArrow,
  toolTipWrapper = null,
  edgePadding = 0,
  constrainToParent = false,
}) {
  if (!tooltip || !descriptionOrArrow) {
    return null;
  }
  const tooltipRect = tooltip.getBoundingClientRect();
  // dynamic element will be either the description or the arrow
  const dynamicElement = descriptionOrArrow.getBoundingClientRect();
  const windowWidth = window.innerWidth;

  // Calculate the midpoints
  const tooltipMidpoint = tooltipRect.left + tooltipRect.width / 2;
  const dynamicElementMidpoint = dynamicElement.left + dynamicElement.width / 2;

  // Calculate the offset needed to align the midpoints
  const offset = tooltipMidpoint - dynamicElementMidpoint;

  // Use computed style to get the actual 'left' property of elemB
  const computedStyle = window.getComputedStyle(descriptionOrArrow);
  const currentLeft = parseFloat(computedStyle.left);

  let dynamicElementStart = currentLeft + offset;
  let roomOnLeft;
  let roomOnRight;

  // If the tooltip is constrained to the parent, we need to check if the tooltip is overflowing the parent
  if (constrainToParent && toolTipWrapper) {
    const edges = (dynamicElement.width - tooltipRect.width) / 2;
    const parentRect = toolTipWrapper.getBoundingClientRect();
    roomOnLeft = tooltipRect.left - parentRect.left;
    roomOnRight = parentRect.right - tooltipRect.right;

    if (edges > roomOnRight) {
      dynamicElementStart -= edges - roomOnRight + edgePadding;
    }
    if (roomOnLeft <= 0) {
      dynamicElementStart = edgePadding;
    }
  } else {
    // If the tooltip is not constrained to the parent, we need to check if the tooltip is overflowing the window
    roomOnLeft = dynamicElementMidpoint - dynamicElement.width;
    if (roomOnLeft < 0) {
      dynamicElementStart = dynamicElementStart - roomOnLeft + edgePadding;
    }

    roomOnRight = windowWidth - dynamicElementMidpoint;
    if (roomOnRight < 0) {
      dynamicElementStart = dynamicElementStart + roomOnRight - edgePadding;
    }
  }

  return dynamicElementStart;
}

export function centerDescription({
  tooltip,
  tooltipDescription,
  toolTipWrapper,
  edgePadding = 0,
  constrainToParent,
}) {
  if (!tooltipDescription) return;

  const newLeft = adjustPosition({
    tooltip,
    descriptionOrArrow: tooltipDescription,
    toolTipWrapper,
    edgePadding,
    constrainToParent,
  });
  if (newLeft === null) return;
  tooltipDescription.style.insetInlineStart = `${newLeft}px`;
}

export function centerElements({
  tooltip,
  tooltipDescription,
  toolTipWrapper,
  edgePadding = 0,
  constrainToParent,
  tooltipArrow,
}) {
  centerDescription({
    tooltip,
    tooltipDescription,
    toolTipWrapper,
    edgePadding,
    constrainToParent,
  });
  centerArrow({ tooltip, tooltipArrow });
}

// resetElements is used to reset the position of the tooltip description and
// arrow elements to their default positions. Having the correct default
// position is important for the centerElements function to work properly.
export function resetElements({ tooltipDescriptionRef, tooltipArrowRef }) {
  if (tooltipDescriptionRef.current) {
    tooltipDescriptionRef.current.style.left = '';
  }
  if (tooltipArrowRef.current) {
    tooltipArrowRef.current.style.left = '';
  }
}

export function centerArrow({ tooltip, tooltipArrow }) {
  if (!tooltipArrow) return;
  const newLeft = adjustPosition({
    tooltip,
    descriptionOrArrow: tooltipArrow,
  });
  if (newLeft === null) return;
  tooltipArrow.style.insetInlineStart = `${newLeft}px`;
}
