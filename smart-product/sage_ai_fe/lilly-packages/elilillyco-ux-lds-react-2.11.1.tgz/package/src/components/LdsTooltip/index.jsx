import cn from 'classnames';
import LdsIcon from '../LdsIcon/index.jsx';
import {
  useState, useEffect, useRef, useId
} from 'react';
import {
  filterAndMapComponents,
  centerElements,
  resetElements
} from './util.js';
import PropTypes from 'prop-types';
import useClickOutside from '../../hooks/useClickOutside.js';
import useHover from '../../hooks/useHover.js';
import useEventListener from '../../hooks/useEventListener.js';

// JSDoc type definitions
/**
 * @typedef {object} LdsTooltipProps
 * @property {React.ReactNode} children - React child slot object
 * @property {number} [width] - Width of the tooltip description box (Max: 300px).
 * @property {number} [openDelay] - Time before visibility is changed and before css transitions start
 * @property {number} [closeDelay] - Time before visibility is changed and before css transitions start
 * @property {boolean} [hideIcon] - Determines if the information icon is displayed next to the tooltip link text.
 * @property {string} [position] - The position of the tooltip description box, either "top" or "bottom", will automatically change to the other if too close to edge of the screen.
 * @property {number} [edgePadding] - Padding from the edge of the viewport.
 * @property {boolean} [constrainToParent] - If true, the tooltip will not be allowed to go outside of the parent element.
 * @property {object} [accessibilityLabels] - Accessibility labels for the tooltip and close button.
 * @property {string} [accessibilityLabels.closeButton] - Custom ARIA label value for the close button
 * @property {string} [accessibilityLabels.moreInfoIcon] - Custom ARIA label value for the info icon
 * @property {string} [styleClass] - Optional; Set a string value for one of the variant component style classes; valid value is 'inverted' or leave undefined for the default style.
 * @property {string} [radiusClass] - Optional; set one of the border radius size classes for the component; valid values are 'radius-sm', 'radius-md', or leave undefined to use the theme radius default
 * @property {string} [tooltipMode] - Optional; Set the mode of the tooltip; valid values are 'text', 'button', 'link', or 'custom'; default is 'text'. 'button' mode will display tooltip as an lds-button. Custom mode to be used for custom styling
 * @property {string} [buttonClass] - Optional; Custom css classes to be applied to the tooltip button trigger. To be used in conjunction with 'tooltipMode' prop set to 'button' or 'custom'
 * @property {string} [className] - Optional custom user-defined CSS class(es) for the component, will be appended to the list of any other component classes
 */
/**
 * LdsTooltip component
 * @param {LdsTooltipProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
function LdsTooltip({
  children,
  width = undefined,
  openDelay = 400,
  closeDelay = 400,
  hideIcon = false,
  position = 'top',
  edgePadding = 16,
  constrainToParent = false,
  accessibilityLabels = {
    closeButton: 'Close tooltip',
    moreInfoIcon: 'More information',
  },
  styleClass,
  radiusClass,
  tooltipMode = 'text',
  buttonClass = '',
  className,
  ...rest
}) {
  const ComponentWrapper = tooltipMode === 'button' ? 'div' : 'span';
  const [tooltipPosition, setTooltipPosition] = useState(position);

  const [isPersistent, setIsPersistent] = useState(false);

  /*
    It appears to me that "isVisible" is used for the general instant visibility of the tooltip, while "renderTooltip" is used for the transition visibility of the tooltip. Might need further assessment or a refactor down to one variable to make this easier to maintain.
  */
  const [renderTooltip, setRenderTooltip] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  const [adjustedWidth, setAdjustedWidth] = useState(width || (tooltipMode === 'link' ? undefined : 300));

  const wrapperRef = useClickOutside(() => setIsVisible(false));

  const [tooltipRef, toolTipIsHovered, imperativeSetTooltipHovered] = useHover();
  const [tooltipDescriptionRef, tooltipDescriptionHovered] = useHover();

  const tooltipArrowRef = useRef(null);
  const tooltipIconRef = useRef(null);
  const tooltipLinkRef = useRef(null);

  const isHovered = toolTipIsHovered || tooltipDescriptionHovered;

  const uniqueId = useId();
  const tooltipId = `lds-tooltip${uniqueId}`;

  const handleTransitionEnd = (event) => {
    // if tooltip is hovered after transition end, don't hide it
    if (event.propertyName === 'opacity' && !isVisible && !toolTipIsHovered) {
      setRenderTooltip(false);
      setIsPersistent(false);
    }
  };

  useEventListener(tooltipDescriptionRef, 'transitionend', handleTransitionEnd);

  /*
    Check the position of the tooltip before it renders.
    By default open in the direction set by the user with the "position" prop
    However if the tooltip would appear offscreen either by scroll or window edge, switch to the other position
  */
  useEffect(() => {
    if (!tooltipDescriptionRef.current) return;

    const viewPortHeight = window.innerHeight;
    const tooltipRect = tooltipDescriptionRef.current.getBoundingClientRect();

    const scrollHeight = window.scrollHeight;

    let newPosition = position; // default to user defined position

    const isTooltipOffTopOfScreen = tooltipRect.top < 0;
    const isTooltipTopHiddenByScroll = tooltipRect.top > scrollHeight;

    if (position === 'top' && (isTooltipOffTopOfScreen || isTooltipTopHiddenByScroll)) {
      newPosition = 'bottom';
    }

    const isTooltipOffBottomOfScreen = tooltipRect.bottom > viewPortHeight;
    const isTooltipBottomHiddenByScroll = tooltipRect.bottom < scrollHeight;
    if (position === 'bottom' && (isTooltipOffBottomOfScreen || isTooltipBottomHiddenByScroll)) {
      newPosition = 'top';
    }
    setTooltipPosition(newPosition);
  }, [renderTooltip, position, tooltipDescriptionRef]);

  useEffect(() => {
    if (!width) return;
    // Calculate adjusted width based on viewport and edgePadding
    const adjustedViewportWidth = window.innerWidth - 2 * edgePadding;
    const newAdjustedWidth = Math.min(width, adjustedViewportWidth);
    setAdjustedWidth(newAdjustedWidth);
  }, [edgePadding, width]);

  useEffect(() => {
    if (isPersistent) {
      setIsVisible(true);
    } else {
      setIsVisible(false);
    }
  }, [isPersistent]);

  useEffect(() => {
    if (renderTooltip) {
      centerElements({
        tooltip: tooltipRef.current,
        tooltipDescription: tooltipDescriptionRef.current,
        toolTipWrapper: wrapperRef.current.parentElement,
        edgePadding,
        constrainToParent,
        tooltipArrow: tooltipArrowRef.current,
      });
    } else {
      resetElements({ tooltipDescriptionRef, tooltipArrowRef });
    }
  }, [constrainToParent, edgePadding, renderTooltip, tooltipDescriptionRef, tooltipRef, wrapperRef]);

  // manages tooltip visibility based on the delay props
  useEffect(() => {
    let timeout;
    if (isHovered) {
      timeout = setTimeout(() => setIsVisible(true), openDelay);
    } else {
      timeout = setTimeout(() => {
        if (!isPersistent && !isHovered) setIsVisible(false);
      }, closeDelay);
    }
    return () => clearTimeout(timeout);
  }, [isHovered, isPersistent, openDelay, closeDelay]);

  // Add effect to handle focus events for link mode
  useEffect(() => {
    if (tooltipMode === 'link' && tooltipLinkRef.current) {
      const linkElement = tooltipLinkRef.current;

      const handleFocus = () => {
        setRenderTooltip(true);
        imperativeSetTooltipHovered(true);
      };

      const handleBlur = () => {
        imperativeSetTooltipHovered(false);
      };

      linkElement.addEventListener('focus', handleFocus, true);
      linkElement.addEventListener('blur', handleBlur, true);

      return () => {
        linkElement.removeEventListener('focus', handleFocus, true);
        linkElement.removeEventListener('blur', handleBlur, true);
      };
    }
    return () => {}; // Return empty cleanup function for when condition isn't met
  }, [tooltipMode, imperativeSetTooltipHovered]);

  const toggleTooltip = () => {
    // setIsVisible(false);
    setRenderTooltip(true);
    setIsPersistent(!isPersistent);
    if (isPersistent) {
      imperativeSetTooltipHovered(false);
    }
  };

  // render text and description functions
  const renderTooltipText = () => {
    return filterAndMapComponents(children, LdsTooltip.Text);
  };

  const renderTooltipDescription = () => {
    return filterAndMapComponents(children, LdsTooltip.Description);
  };

  return (
    <ComponentWrapper
      className={cn(
        'lds-tooltip-container',
        `lds-tooltip-container-${tooltipMode}`
      )}
      ref={wrapperRef}
    >
      <span
        id={`lds-tooltip-wrapper-${uniqueId}`}
        ref={tooltipRef}
        className={cn(
          'lds-tooltip',
          styleClass,
          radiusClass,
          className
        )}
        {...rest}
      >
        <span
          id={`lds-tooltip-container-${uniqueId}`}
          className="tooltip-container"
          onClick={tooltipMode === 'link' ? undefined : toggleTooltip}
          onMouseEnter={() => {
            setRenderTooltip(true);
          }}
        >
          {tooltipMode === 'link' ? (
            <span
              aria-describedby={tooltipId}
              className="lds-tooltip-link"
              ref={tooltipLinkRef}
            >
              {renderTooltipText()}
            </span>
          ) : (
            <button
              aria-describedby={tooltipId}
              className={cn(
                'lds-button-base',
                {
                  'tooltip-text': tooltipMode === 'text',
                  'lds-button': tooltipMode === 'button',
                },
                buttonClass
              )}
              onFocus={() => {
                setRenderTooltip(true);
                imperativeSetTooltipHovered(true);
              }}
              onBlur={() => {
                imperativeSetTooltipHovered(false);
              }}
            >
              {renderTooltipText()}
              {!hideIcon && (
                <span
                  className="lds-tooltip-icon"
                  ref={tooltipIconRef}
                >
                  <LdsIcon
                    className="tooltip-icon"
                    decorative
                    name="info-fill"
                    inline
                    label={accessibilityLabels.moreInfoIcon}
                  />
                </span>
              )}
            </button>
          )}
        </span>

        <span
          style={{
            width: tooltipMode === 'link' && !adjustedWidth ? 'auto' : `${adjustedWidth}px`,
            display: `${renderTooltip ? 'block' : 'none'}`,
          }}
          id={tooltipId}
          ref={tooltipDescriptionRef}
          data-testid="tooltip-description"
          className={cn(
            'tooltip-description',
            'lds-tooltip-description',
            tooltipPosition,
            {
              'lds-tooltip-enter-to': isVisible,
              'lds-tooltip-leave-to': !isVisible,
            }
          )}
          onClick={() => setIsPersistent(true)}
          onMouseEnter={() => {
            setRenderTooltip(true);
          }}
        >
          {renderTooltipDescription()}
          <span
            className="lds-tooltip-arrow"
            ref={tooltipArrowRef}
          />
          {isPersistent && (
            <button
              id="btnClose"
              data-testid="btnClose"
              onClick={() => {
                setIsVisible(false);
                imperativeSetTooltipHovered(false);
              }}
              className="lds-button-base tooltip-close"
            >
              <LdsIcon
                role="button"
                name="x-circle-fill"
                inline
                label={accessibilityLabels.closeButton}
              />
            </button>
          )}
        </span>
      </span>
    </ComponentWrapper>
  );
}

// JSDoc type definitions
/**
 * @typedef {object} LdsTooltipTextProps
 * @property {React.ReactNode} children - React child slot object
 */
/**
 * LdsTooltip.Text component
 * @param {LdsTooltipTextProps} props
 * @returns {React.JSX.Element}
 */
const Text = ({ children }) => <>{children}</>;
LdsTooltip.Text = Text;

// JSDoc type definitions
/**
 * @typedef {object} LdsTooltipDescriptionProps
 * @property {React.ReactNode} children - React child slot object
 */
/**
 * LdsTooltip.Description component
 * @param {LdsTooltipDescriptionProps} props
 * @returns {React.JSX.Element}
 */
const Description = ({ children }) => <>{children}</>;
LdsTooltip.Description = Description;

LdsTooltip.propTypes = {
  children: PropTypes.node,
  width: PropTypes.number,
  position: PropTypes.oneOf(['top', 'bottom']),
  styleClass: PropTypes.oneOf(['inverted', undefined]),
  radiusClass: PropTypes.oneOf(['radius-sm', 'radius-md', undefined]),
  openDelay: PropTypes.number,
  closeDelay: PropTypes.number,
  hideIcon: PropTypes.bool,
  edgePadding: PropTypes.number,
  constrainToParent: PropTypes.bool,
  accessibilityLabels: PropTypes.shape({
    closeButton: PropTypes.string,
    moreInfoIcon: PropTypes.string,
  }),
  tooltipMode: PropTypes.oneOf(['text', 'button', 'custom', 'link']),
  buttonClass: PropTypes.string,
};

LdsTooltip.Text.propTypes = {
  children: PropTypes.node,
};

LdsTooltip.Description.propTypes = {
  children: PropTypes.node,
};

export default LdsTooltip;
