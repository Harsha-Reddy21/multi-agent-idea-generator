import cn from 'classnames';

import LdsIcon from '../LdsIcon/index.jsx';

export default function DrawerDesktopToggle({
  expanded,
  attached,
  hiddenDrawerPanelCollapseText,
  hiddenDrawerPanelExpandText,
  toggleContent,
  drawerHeading,
}) {
  return (
    <button
      id="drawerHeading"
      type="button"
      aria-controls="drawerPanel"
      onClick={toggleContent}
      aria-expanded={expanded}
      tabIndex={attached ? '-1' : null}
      className={cn(
        'lds-button-clear-style',
        'lds-drawer-banner',
        {
          expanded: expanded,
          attached: attached,
        }
      )}
    >
      <span className="lds-drawer-banner-wrapper wrapper justify-content-between">
        <span
          className="lds-drawer-banner-column drawer"
        >
          <span
            className={cn(
              'lds-drawer-banner-text',
              'drawer',
              {
                'visually-hidden': !expanded,
              }
            )}
                >
            {drawerHeading}
          </span>
        </span>
        <span className="lds-drawer-banner-column toggle">
          { /* Element is set to display:none when attached in setAttached function */}
          {!attached && <span
            id="drawerBannerToggle"
            className="lds-drawer-toggle"
            >
              <LdsIcon
                id="drawerBannerIconExpand"
                label={expanded ? hiddenDrawerPanelCollapseText : hiddenDrawerPanelExpandText}
                name={expanded ? 'MinusCircleFill' : 'PlusCircleFill'}
                inline
                decorative
              ></LdsIcon>
          </span>}
        </span>
      </span>
    </button>
  );
}
