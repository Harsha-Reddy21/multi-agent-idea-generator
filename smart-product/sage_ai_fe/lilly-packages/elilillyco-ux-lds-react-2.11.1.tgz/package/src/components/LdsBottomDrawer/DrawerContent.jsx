import { forwardRef } from 'react';
import cn from 'classnames';

export default forwardRef(function DrawerContent({
  expanded,
  attached,
  drawerHeading,
  defaultContent = '',
}, ref) {
  return (
    <div
      id="drawerMainColumn"
      className={cn(
        'lds-drawer-main-column',
        'drawer',
        'col-12',
        {
          expanded: expanded,
          attached: attached,
        }
      )}
    >

      { /* <!-- CONTENT COLUMN PANEL CONTAINER: This element expands/collapses below the large breakpoint --> */}
      <div
        id="drawerPanelDrawer"
        className={cn(
          'lds-drawer-main-content-panel',
          'drawer',
          {
            expanded: expanded,
            attached: attached,
          }
        )}
      >

        { /* CONTENT COLUMN CONTENT CONTAINER: This is used to allow the content to scroll below the large breakpoint */}
        <div
          id="drawerContentColumnContainer"
          className={cn(
            'lds-drawer-content-container',
            'drawer',
            {
              expanded: expanded,
              attached: attached,
            }
          )}
          ref={ref}
        >
          { /* <!-- This wrapper adds the correct page layout gutter spacing BELOW the large breakpoint */ }
          <div className="lds-drawer-content-wrapper">
            <h2
              id="ldsDrawerColumnHeading"
              className="lds-drawer-heading drawer"
            >
              {drawerHeading}
            </h2>
            <div className="lds-drawer-content drawer">
              {/* Default content */}
              {defaultContent}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});
