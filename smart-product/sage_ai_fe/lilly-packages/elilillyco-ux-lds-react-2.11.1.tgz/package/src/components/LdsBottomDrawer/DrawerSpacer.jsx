export default function DrawerSpacer({ attached }) {
  if (attached) return '';

  return (
    <div id="drawerSpacer" className="lds-drawer-spacer"></div>
  );
}
