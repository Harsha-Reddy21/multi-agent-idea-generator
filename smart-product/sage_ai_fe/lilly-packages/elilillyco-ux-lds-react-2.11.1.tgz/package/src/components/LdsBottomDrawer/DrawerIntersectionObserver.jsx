import { useEffect, useRef, useCallback } from 'react';

export default function DrawerIntersectionObserver({ forceAttachment, setAttached, setIsPreDetach }) {
  const elmRef = useRef(null);

  const detach = () => {
    if (forceAttachment) return;
    setIsPreDetach(true);
    setAttached(false);
    // Wait a bit to remove the preDetach class
    // This prevents ugly animation "jitter" if you move up and down too slowly near the attach/detach point
    // However this prevents the "slide up" of the banner after detaching
    setTimeout(() => setIsPreDetach(false), 500);
  };

  const handleObserver = useCallback((entries) => {
    if (entries && Array.isArray(entries) && entries[0].isIntersecting) {
      setAttached(true);
    } else if (!entries[0].isIntersecting && entries[0].boundingClientRect.top > 0) {
      detach();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const bottomIntersectMargin = document.getElementById('drawerHeading').offsetHeight + 4;
    const options = {
      root: null,
      rootMargin: `0px 0px -${bottomIntersectMargin}px 0px`,
      threshold: 1.0,
    };

    const observer = new IntersectionObserver(handleObserver, options);
    if (elmRef.current) observer.observe(elmRef.current);

    return () => {
      // eslint-disable-next-line react-hooks/exhaustive-deps
      if (elmRef.current) observer.unobserve(elmRef.current);
    };
  }, [elmRef, handleObserver]);

  return (
    <div ref={elmRef} style={{ height: '1px', marginTop: '2px' }} id="drawerIntersectionObserver"></div>
  );
}
