import { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import DrawerIntersectionObserver from './DrawerIntersectionObserver.jsx';
import DrawerSpacer from './DrawerSpacer.jsx';
import DrawerToggle from './DrawerToggle.jsx';
import DrawerContent from './DrawerContent.jsx';
import useIsMobile from '../../hooks/useIsMobile.js';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsBottomDrawerProps
 * @property {string} drawerHeading - Heading text for the drawer content
 * @property {string} [hiddenDrawerPanelCollapseText] - Screen reader text for drawer panel collapse button
 * @property {string} [hiddenDrawerPanelExpandText] - Screen reader text for drawer panel expand button
 * @property {string|React.JSXElement} [content] - HTML content slot
 * @property {string} [className] - Optional custom user-defined CSS class(es) to add to the component root container element; will be appended to the list of any other component classes
 */
/**
 * LdsBottomDrawer component
 * @param {LdsBottomDrawerProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsBottomDrawer component
 */
export default function LdsBottomDrawer({
  drawerHeading = '',
  hiddenDrawerPanelCollapseText = '',
  hiddenDrawerPanelExpandText = '',
  content = '',
  className,
  ...rest
}) {
  const [expanded, setExpanded] = useState(false);
  const [attached, setAttached] = useState(false);
  const [offsetTop, setOffsetTop] = useState('0px');
  const [pagePosition, setPagePosition] = useState(null);
  const [forceAttachment] = useState(false);
  const [isCollapsing, setIsCollapsing] = useState(false);
  const [isPreDetach, setIsPreDetach] = useState(false);
  const [drawerLoaded, setDrawerLoaded] = useState(false);

  const isMobile = useIsMobile(992);

  const mainRef = useRef(null);
  const contentContainerDrawerRef = useRef(null);

  useEffect(() => {
    // TODO: Need to do more testing in no-js environments to see how to ensure no-js drawer works
    setDrawerLoaded(true);
  }, []);

  const resetScrollablePanelsToTop = () => {
    mainRef.current.scrollTop = 0;
    contentContainerDrawerRef.current.scrollTop = 0;
  };

  const expand = () => {
    const stickyElement = document.querySelector('.lds-sticky');
    const sideNav = document.querySelector('.lds-side-nav-top-container');
    let offset = 0;
    if (stickyElement) offset += stickyElement.offsetHeight;
    if (isMobile && sideNav) {
      offset += sideNav.offsetHeight;
    }
    setOffsetTop(offset);

    const htmlTag = document.documentElement;
    setExpanded(true);
    setPagePosition(htmlTag.scrollTop);
    htmlTag.setAttribute('data-drawer-expanded', 'true');
    htmlTag.style.top = `-${pagePosition}px`;
  };

  const collapse = async () => {
    const htmlTag = document.documentElement;

    setExpanded(false);

    // Begin collapsing
    setIsCollapsing(true);

    // Make sure that all scrollable-when-expanded drawer panels are "scrolled to top" while collapsing!
    resetScrollablePanelsToTop();

    // Update root HTML tag attributes
    htmlTag.style.top = null;
    htmlTag.removeAttribute('data-drawer-expanded');

    // Use a timer to ensure "collapsing" state clears after a second
    setTimeout(() => setIsCollapsing(false), 1000);

    // Finally, return the user to where they were on the page before the drawer was expanded (if possible)
    window.scrollTo(0, pagePosition);
  };

  const toggleContent = () => {
    if (attached) return;

    if (expanded) {
      collapse();
    } else {
      expand();
    }
  };

  return (
    <>
    <DrawerIntersectionObserver
      setAttached={setAttached}
      forceAttachment={forceAttachment}
      setIsPreDetach={setIsPreDetach}
    />
    <section
      id="drawerPanel"
      className={cn(
        'lds-drawer-wrapper',
        {
          'no-js': !drawerLoaded,
        },
        className
      )}
      role="region"
      aria-labelledby="ldsDrawerColumnHeading"
      {...rest}
    >
      <DrawerSpacer attached={attached} />
      <div
        id="lds-drawer"
        className={cn(
          'lds-drawer',
          {
            'lds-drawer-loaded': drawerLoaded,
            'lds-drawer-expanded': expanded,
            'lds-drawer-collapsing': isCollapsing,
            'lds-drawer-attached': attached,
            'lds-drawer-pre-detach': isPreDetach,
          }
        )}
        style={{
          top: expanded ? offsetTop : '0px',
          height: expanded ? `calc(100% - ${offsetTop}px)` : null,
        }}
        // TODO: Keydown events
      >
        {/* THIS IS THE SINGLE/PRIMARY "DETACHED" DRAWER TOGGLE BUTTON "BANNER" */}
        {/* It is always in the DOM but is only visible/functional above the LDS large breakpoint */}
        <DrawerToggle
          expanded={expanded}
          attached={attached}
          hiddenDrawerPanelCollapseText={hiddenDrawerPanelCollapseText}
          hiddenDrawerPanelExpandText={hiddenDrawerPanelExpandText}
          toggleContent={toggleContent}
          drawerHeading={drawerHeading}
        />

        {/* <!-- THIS IS THE MAIN CONTENT SECTION OF THE DRAWER --> */}
        {/* <!-- This is the detached and expanded scrollable container for the entire drawer contents --> */}
        <div
          id="drawerMain"
          className={cn(
            'lds-drawer-main',
            {
              expanded: expanded,
              attached: attached,
            }
          )}
          ref={mainRef}
        >

          { /* This wrapper adds the correct page layout gutter spacing ABOVE the large breakpoint */}
          <div
            id="drawerMainWrapper"
            className={cn(
              'lds-drawer-main-wrapper',
              {
                expanded: expanded,
                'expanded-drawer': expanded,
                attached: attached,
              }
            )}
          >

            { /* <!-- MAIN CONTENT --> */}
            <DrawerContent
              expanded={expanded}
              attached={attached}
              drawerHeading={drawerHeading}
              defaultContent={content}
              ref={contentContainerDrawerRef}
            />
          </div>
        </div>
      </div>
    </section>
    </>
  );
}

LdsBottomDrawer.propTypes = {
  drawerHeading: PropTypes.string.isRequired,
  hiddenDrawerPanelCollapseText: PropTypes.string,
  hiddenDrawerPanelExpandText: PropTypes.string,
  content: PropTypes.string,
  className: PropTypes.string,
};
