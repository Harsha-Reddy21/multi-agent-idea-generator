// eslint-disable-next-line consistent-return
export function validateBannerImageAltText(alt, componentName) {
  if (!alt) {
    const ex = `Invalid LDS Component prop "alt" supplied to ${componentName}. Accessibility compliance requires an alt text value be set for the Hero component's banner image`;
    return new Error(ex);
  }
  const sAlt = String(alt);
  if (sAlt.length > 125) {
    const ex = `Invalid LDS Component prop "alt" supplied to ${componentName}. Accessibility compliance requires an alt text value not be composed of more than 125 characters current alt text has ${sAlt.length}; some screen readers will refuse to read more than that`;
    return new Error(ex);
  }
}

export const isScrollable = (id, useScrollButton) => {
  // when useScrollButton is true
  if (useScrollButton) {
    // when id is truthy then hero is scrollable
    if (id) return true;

    // when id is not truthy then hero is not scrollable because PEBCAC
    // eslint-disable-next-line no-console
    console.error('Invalid LDS Component prop "isScrollable" supplied to LdsHero. The prop was set to \'true\' to enable the scroll button but the Hero component does not have an ID value set and therefore the scroll down function will not operate correctly; set an ID on the Hero to use the scroll button function.');
    return false;
  }

  // when useScrollButton is false then hero is not scrollable
  return false;
};

export const getContentAlignment = (alignmentToken) => {
  // The default is centered and it does not need to be explicitly set as a class
  if (!alignmentToken) return '';

  const sAlignmentToken = String(alignmentToken);

  switch (sAlignmentToken.toLowerCase()) {
    case 'left':
      return 'left';
    case 'right':
      return 'right';
    case 'center':
    default:
      return '';
  }
};

// eslint-disable-next-line consistent-return
export function validateScrollButtonClasses(classes, componentName) {
  const sClasses = String(classes);
  if (sClasses.toLowerCase().includes('compact')) {
    const ex = `Invalid LDS Component prop "scrollButtonClasses" supplied to ${componentName}. Must not use "compact" LDS Button Density classes (or custom classes with this string value)`;
    return new Error(ex);
  }
}

export const getScrollButtonClasses = (classes) => {
  // If no classes are set at all use the Ghost Inverted theme/style by default
  if (!classes) return 'neutral-ghost-inverted';

  // Otherwise just return what was set
  return String(classes);
};

export const getScrollButtonIconName = (type) => {
  // NOTE: PropTypes ensures that the prop input is one of the valid strings.
  // However to avoid any unusual JavaScript type errors we'll force whatever we have to be a string
  const sType = String(type);

  // This logic converts the input to a valid LDS Icon Name because we're not using the name as an input
  // Only these icons are valid to use so we are not allowing direct setting of the icon name values
  switch (sType.toLowerCase()) {
    case 'arrow':
      return 'arrow-down';
    case 'triangle':
      return 'caret-down-fill';
    case 'chevron':
    default:
      return 'caret-down';
  }
};

export function scrollDown(id) {
  let hero;
  try {
    // Get the unique hero element
    hero = document.getElementById(id);
  } catch (ex) {
    // Probably this is a PEBCAC error unless there's an unexpected fatal javascript error with the getElementById function
    // eslint-disable-next-line no-console
    console.error(`
    LDS ERROR: LdsHero scrollDown function encountered an unexpected exception creating an HTML element object from the provided Hero component ID
    Exception: ${ex.message}
    -- id (the unique ID attribute of the LDS Hero component to scroll down): ${id}
    -- hero HTML Element: ${hero}
    Make sure the LdsHero component element has prop 'id' set to a value
    `);
    return;
  }

  let heroBottom;
  try {
    // Get the hero element's RELATIVE bottom coordinate on the page
    // it will vary if the page has been scrolled
    // effectively it is the location of the bottom of the hero from the top of the VIEWPORT
    heroBottom = hero.getBoundingClientRect().bottom;
  } catch (ex) {
    // This shouldn't happen unless there's an unexpected fatal javascript error with the getBoundingClientRect function
    // eslint-disable-next-line no-console
    console.error(`
    LDS ERROR: LdsHero scrollDown function encountered an unexpected exception getting the bounding coordinates of the LDS Hero component
    Exception: ${ex.message}
    -- heroId (the unique ID attribute of the LDS Hero component to scroll down): ${id}
    -- hero HTML Element: ${hero}
    -- heroBottom (hero.getBoundingClientRect().bottom): ${heroBottom}
    If this error persists please contact LDS support
    `);
    return;
  }

  let scrollTopOffset;
  try {
    // Get the vertical location of the viewport RELATIVE to the top of the page
    // If page has not been scrolled this value should be zero
    // effectively it is the vertical distance from the top of the page it has been scrolled
    scrollTopOffset = document.documentElement.scrollTop;
  } catch (ex) {
    // This shouldn't happen unless there's an unexpected fatal javascript error with the document.documentElement.scrollTop property
    // eslint-disable-next-line no-console
    console.error(`
    LDS ERROR: LdsHero scrollDown function encountered an unexpected exception getting the current position the page has been scrolled from the top.
    Exception: ${ex.message}
    -- heroId (the unique ID attribute of the LDS Hero component to scroll down): ${id}
    -- hero HTML Element: ${hero}
    -- heroBottom (hero.getBoundingClientRect().bottom): ${heroBottom}
    -- scrollTopOffset (document.documentElement.scrollTop): ${scrollTopOffset}
    If this error persists please contact LDS support
    `);
    return;
  }

  // TODO: Once we build layouts with "sticky" elements that are stuck to the top of the page but
  //       don't scroll with it such as cookie banners or the header; this function will need to be
  //       revisited to compute the height of any stickied elements to subtract that from the
  //       final scroll position so that content does not scroll under stickied content.
  const stickyElement = document.querySelector('.lds-sticky');
  const stickyTopElementsOffset = stickyElement?.offsetHeight || 0;

  if (heroBottom && (scrollTopOffset || scrollTopOffset === 0)) {
    try {
      // The window.scrollTo function expects an ABSOLUTE location on the page
      // We need to know where the bottom of the hero is relative to the absolute top of the page NOT the viewport
      // Since heroBottom is where it is on the viewport we need to ADD in any distance scrolled vertically
      // MINUS anything that might be sticky to the top of the viewport that we don't want to scroll under
      const scrollYPOS = (heroBottom + scrollTopOffset) - stickyTopElementsOffset;
      // Attempt to scroll the window to the location of the bottom of the hero element
      if (scrollYPOS > 0) {
        window.scrollTo({
          top: scrollYPOS,
          left: 0,
          behavior: 'smooth',
        });
      } else {
        // GNDN if we can't scroll because the hero is already scrolled past vertically, but warn because this shouldn't happen
        // eslint-disable-next-line no-console
        console.warn(`
        LDS WARNING: LdsHero scrollDown function attempted to scroll the page to an invalid scroll position; scroll effect aborted
        -- heroId (the unique ID attribute of the LDS Hero component to scroll down): ${id}
        -- hero HTML Element: ${hero}
        -- heroBottom (hero.getBoundingClientRect().bottom): ${heroBottom}
        -- scrollTopOffset (document.documentElement.scrollTop): ${scrollTopOffset}
        -- Computed Scroll to Position: ${scrollYPOS}
        This function should not be invoked if the hero has already been scrolled past
        If this warning persists please contact LDS support
        `);
      }
    } catch (ex) {
      // Shouldn't happen, edge case
      // eslint-disable-next-line no-console
      console.error(`
      LDS ERROR: LdsHero scrollDown function encountered an unexpected exception invoking the JavaScript scrollTo() function to scroll to the bottom of the hero container element
      Exception: ${ex.message}
      -- heroId (the unique ID attribute of the LDS Hero component to scroll down): ${id}
      -- hero HTML Element: ${hero}
      -- heroBottom (hero.getBoundingClientRect().bottom): ${heroBottom}
      -- scrollTopOffset (document.documentElement.scrollTop): ${scrollTopOffset}
      If this error persists please contact LDS support
      `);
    }
  } else {
    // Probably should never fail out here unless something else went wrong above
    // eslint-disable-next-line no-console
    console.error(`
    LDS ERROR: LdsHero scrollDown function failed unexpectedly; either the heroBottom or scrollTopOffset values were falsey which suggests some other failure elsewhere
    -- heroId (the unique ID attribute of the LDS Hero component to scroll down): ${id}
    -- hero HTML Element: ${hero}
    -- heroBottom (hero.getBoundingClientRect().bottom): ${heroBottom}
    -- scrollTopOffset (document.documentElement.scrollTop): ${scrollTopOffset}
    If this error persists please contact LDS support
    `);
  }
}
