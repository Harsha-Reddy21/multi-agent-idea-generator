import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsHeroV1 from './v1.jsx';

import {
  getRowVerticalAlignClass,
  getLayoutClass,
  getLayoutImagePositionClass,
  getImageColumnClasses,
  getImageRenderClass,
  getImageRadiusClass,
  getImageHorizontalAlignClass,
  getImageVerticalAlignClass,
  getContentColumnClasses,
  validateBannerImageAltText
} from './hero.helpers.js';

import transparency from '../../assets/transparency.png';

// JSDoc type definitions
/**
 * @typedef LdsHeroProps
 * @property {string} [id] - The HTML `id` attribute to set on the Hero <section> element
 * @property {string} [layout] - The hero layout mode, one of "banner", "half-billboard" or undefined; renders "banner" mode when undefined as the default
 * @property {string} [layoutImagePosition] - The image layout mode position if the layout mode allows for it; one of "left", "right" or undefined; default value varies by layout mode. Layout modes which do not use this value, such as "banner" default it to undefined. Those that do will set a default value; half-billboard default is "left".
 * @property {{srcset: string, media?: string}[]} images - An array which must include at least one or more responsive Hero image source objects to render with an HTML picture element
 * @property {string} alt - The value of the Hero banner image's "alt" attribute; the string value must not be longer than 125 characters
 * @property {string} [imageRenderMode] - Specify an object-fit render mode for the image; valid values are: 'fit', 'contain', 'cover' or 'fill'; default is 'cover'
 * @property {string} [imageRadius] - Specify a radius T-shirt size; valid values are: 'small', 'medium' or 'large'; default is undefined but a medium radius is used in that case
 * @property {string} [imageHorizontalAlign] - When using the "fit" imageRenderMode this will horizontally align an image not wide enough to fill the image column; for all other render modes it does nothing
 * @property {string} [rowVerticalAlignColumns] - Set a vertical alignment for both columns on the hero row element; valid values are 'top', 'middle' or 'bottom'; default is undefined except when imageRenderMode is 'contain' where the value cannot be undefined so 'top' will be the default.
 * @property {string} [classNameSection] - Additional custom classes to add to the Hero <section> element's class list
 * @property {string} [classNameWrapper] - Additional custom classes to add to the Hero <div class="wrapper"> element's class list
 * @property {string} [classNameRow] - Additional custom classes to add to the Hero <div class="row"> element's class list
 * @property {string} [classNameImageColumn] - Additional custom classes to add to the Hero <div class="lds-hero-image-container-col"> element's class list
 * @property {string} [classNameImageWrapper] - Additional custom classes to add to the Hero <div class="lds-hero-image-wrapper"> element's class list
 * @property {string} [classNameImage] - Additional custom classes to add to the Hero Picture fallback <img class="lds-hero-image"> element's class list
 * @property {string} [classNameContentColumn] - Additional custom classes to add to the Hero <div class="lds-hero-content-col"> element's class list
 * @property {string} [classNameContentWrapper] - Additional custom classes to add to the Hero <div class="lds-hero-content-wrapper"> element's class list
 * @property {string} [classNameContentBlock] - Additional custom classes to add to the Hero content column <div class="content-block"> element's class list
 * @property {string} [imageColumnClasses] - Use to override the default responsive bootstrap grid column classes for the image column
 * @property {string} [contentColumnClasses] - Use to override the default responsive bootstrap grid column classes for the content column
 * @property {string} [version] - Which version to use, defaults to "2", set "1" to render the deprecated classic LDS v1 hero component
 * @property {object} [propsV1] - Component props object to pass into to the deprecated v1 hero component; do not set any of the other component props other than id, images and alt
 * @property {React.ReactNode} children - The children of the component
 */
/**
 * LdsHero component
 * @param {LdsHeroProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
function LdsHero({
  id,
  layout,
  layoutImagePosition,
  images,
  alt = '',
  imageRenderMode = 'cover',
  imageRadius,
  imageHorizontalAlign,
  classNameSection,
  classNameWrapper,
  rowVerticalAlignColumns,
  classNameRow,
  imageColumnClasses,
  classNameImageColumn,
  classNameImageWrapper,
  classNameImage,
  contentColumnClasses,
  classNameContentColumn,
  classNameContentWrapper,
  classNameContentBlock,
  version = '2',
  propsV1,
  children,
  ...rest
}) {
  // DEPRECATED in v2.0.0; REMOVAL TBD
  if (version === '1') {
    return (
      <LdsHeroV1
        id={id}
        images={images}
        alt={alt}
        {...propsV1}
        {...rest}
      >
        {children}
      </LdsHeroV1>
    );
  }

  const rowVertAlignClass = getRowVerticalAlignClass(rowVerticalAlignColumns, imageRenderMode);
  const layoutClass = getLayoutClass(layout);
  const imgLayoutPositionClass = getLayoutImagePositionClass(layout, layoutImagePosition);
  const imgColClasses = getImageColumnClasses(layout, layoutImagePosition, imageColumnClasses);
  const imgRenderClass = getImageRenderClass(imageRenderMode);
  const imgRadiusClass = getImageRadiusClass(imageRadius);
  const imgHorzAlignClass = getImageHorizontalAlignClass(imageHorizontalAlign, imageRenderMode);
  const imgVertAlignClass = getImageVerticalAlignClass(rowVerticalAlignColumns);
  const conColClasses = getContentColumnClasses(layout, layoutImagePosition, contentColumnClasses);

  /* eslint-disable react/prop-types */
  const PictureFallback = ({
    image,
  }) => {
    return (
      <img
        className={cn(
          'lds-hero-image',
          classNameImage
        )}
        style={{ backgroundImage: `url('${image}')` }}
        src={transparency}
        alt={alt}
      />
    );
  };

  const PictureSource = () => {
    if (images.length > 1) {
      return (
        <>
          { images && Array.isArray(images) && images.map((image, i) => (
            <source
              key={i}
              srcSet={image.srcset}
              media={image.media}
            />
          ))}
          <PictureFallback image={images[images.length - 1].srcset} />
        </>
      );
    }

    return (
      <>
        <source srcSet={images[0].srcset}/>
        <PictureFallback image={images[0].srcset} />
      </>
    );
  };

  return (
    <section
      id={id}
      className={cn(
        'lds-hero',
        layoutClass,
        'section',
        classNameSection
      )}
      {...rest}
    >
      <div
        className={cn(
          'wrapper',
          classNameWrapper
        )}
      >
        <div
          className={cn(
            'row',
            {
              [`${rowVertAlignClass}`]: rowVertAlignClass,
            },
            classNameRow
          )}
        >
          <div
            className={cn(
              'lds-hero-image-container-col',
              {
                [`${imgLayoutPositionClass}`]: imgLayoutPositionClass,
              },
              imgColClasses,
              classNameImageColumn
            )}
          >
            <div
              className={cn(
                'lds-hero-image-wrapper',
                imgRenderClass,
                imgHorzAlignClass,
                imgVertAlignClass,
                imgRadiusClass,
                classNameImageWrapper
              )}
            >
              <picture className="lds-hero-picture">
                <PictureSource />
              </picture>
            </div>
          </div>
          <div
            className={cn(
              'lds-hero-content-container-col',
              {
                [`${imgLayoutPositionClass}`]: imgLayoutPositionClass,
              },
              conColClasses,
              classNameContentColumn
            )}
          >
            <div
              className={cn(
                'lds-hero-content-wrapper',
                classNameContentWrapper
              )}
            >
              <div
                className={cn(
                  'content-block',
                  classNameContentBlock
                )}
              >
                {children}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default LdsHero;

LdsHero.propTypes = {
  id: PropTypes.string,
  layout: PropTypes.oneOf(['banner', 'half-billboard', undefined]),
  layoutImagePosition: PropTypes.oneOf(['left', 'right', undefined]),
  images: PropTypes.arrayOf((propValue, key) => { // eslint-disable-line
    if (!propValue[key].srcset) {
      return new Error(`\n
      >>> LDS ERROR: [Invalid Component Data] in LdsHero: banner images array object missing 'srcset' property at index ${key} (${key + 1}/${propValue.length}).
      Each responsive image object must contain an 'srcset' property.
      `);
    }
    if (!propValue[key].media && key !== (propValue.length - 1)) {
      return new Error(`\n
      >>> LDS ERROR: [Invalid Component Data] in LdsHero: banner images array object missing 'media' property at index ${key} (${key + 1}/${propValue.length}).
      Each responsive image object EXCEPT the fallback default must contain a 'media' property.
      `);
    }
    if (propValue[key].media && key === (propValue.length - 1)) {
      return new Error(`\n
      >>> LDS ERROR: [Invalid Component Data] in LdsHero: banner images array default fallback object contains an invalid 'media' property at index ${key} (${key + 1}/${propValue.length}).
      The fallback responsive image object MUST always be the last object in the array and MUST NOT contain a 'media' property.
      `);
    }
  }).isRequired,
  imageRenderMode: PropTypes.oneOf(['fit', 'contain', 'cover', 'fill']),
  imageRadius: PropTypes.oneOf(['none', 'small', 'medium', 'large', undefined]),
  imageHorizontalAlign: PropTypes.oneOf(['left', 'center', 'right', undefined]),
  alt: (props, propName, componentName) => validateBannerImageAltText(props[propName], componentName),
  children: PropTypes.any,
  rowVerticalAlignColumns: PropTypes.oneOf(['top', 'middle', 'bottom']),
  classNameSection: PropTypes.string,
  classNameWrapper: PropTypes.string,
  classNameRow: PropTypes.string,
  classNameImageColumn: PropTypes.string,
  classNameImageWrapper: PropTypes.string,
  classNameImage: PropTypes.string,
  classNameContentColumn: PropTypes.string,
  classNameContentWrapper: PropTypes.string,
  classNameContentBlock: PropTypes.string,
  imageColumnClasses: PropTypes.string,
  contentColumnClasses: PropTypes.string,
  version: PropTypes.oneOf(['1', '2']),
  propsV1: PropTypes.any,
  rest: PropTypes.any,
};
