export function getLayoutClass(layout) {
  switch (layout) {
    case 'half-billboard':
      return layout;
    case 'banner':
    default:
      return 'banner';
  }
}

export function getLayoutImagePositionClass(layout, imagePosition) {
  switch (layout) {
    case 'half-billboard':
      switch (imagePosition) {
        case 'right':
          return 'split-img-right';
        case 'left':
        default:
          return 'split-img-left';
      }
    case 'banner':
    default:
      return undefined;
  }
}

export function getImageColumnClasses(layout, imagePosition, override) {
  if (override) return `col ${override}`;
  return `col ${getColumnClasses('image', layout, imagePosition)}`;
}

export function getContentColumnClasses(layout, imagePosition, override) {
  if (override) return `col ${override}`;
  return `col ${getColumnClasses('content', layout, imagePosition)}`;
}

function getColumnClasses(column, layout, imagePosition) {
  const defaultCols = 'col-12';
  const splitImgCols = `${defaultCols} col-lg-6 col-xl-5 col-xxl-4`;
  const splitConCols = `${defaultCols} col-lg-6 col-xl-7 col-xxl-8`;

  switch (layout) {
    case 'half-billboard':
      switch (imagePosition) {
        case 'right':
          if (column === 'image') return `${splitImgCols} order-lg-2`;
          return `${splitConCols} order-lg-1`;
        case 'left':
        default:
          if (column === 'image') return splitImgCols;
          return splitConCols;
      }
    case 'banner':
    default:
      return defaultCols;
  }
}

export function getImageRenderClass(imageRenderMode) {
  if (!imageRenderMode || imageRenderMode === 'fit') return '';
  return imageRenderMode;
}

export function getImageRadiusClass(imageRadius) {
  if (imageRadius) return `radius-${imageRadius}`;
  return '';
}

export function getRowVerticalAlignClass(vertAlign, imageRenderMode) {
  switch (vertAlign) {
    case 'top':
      return 'align-items-start';
    case 'middle':
      return 'align-items-center';
    case 'bottom':
      return 'align-items-end';
    default:
      // When using imageRenderMode "contain" default to top column alignment or there will be image rendering errors
      if (imageRenderMode === 'contain') return 'align-items-start';
      // For all other image rendering modes, use nothing as the default
      return '';
  }
}

export function getImageVerticalAlignClass(vertAlign) {
  switch (vertAlign) {
    case 'top':
      return 'align-top';
    case 'middle':
      return 'align-middle';
    case 'bottom':
      return 'align-bottom';
    default:
      return '';
  }
}

export function getImageHorizontalAlignClass(horzAlign, imageRenderMode) {
  // If a valid image rendering mode is set, images will be as wide as the image container
  // Horizontal alignment is thus irrelevant so, GNDN
  if (imageRenderMode && imageRenderMode !== 'fit') return '';

  // When an explicit image rendering mode is NOT set or is set to 'fit'
  // is the only time the image will be rendered in a way in which it can be horizontally aligned
  switch (horzAlign) {
    case 'left':
      return 'align-left';
    case 'center':
      return 'align-center';
    case 'right':
      return 'align-right';
    default:
      return '';
  }
}

export function validateBannerImageAltText(alt, componentName) {
  if (!alt) {
    const ex = `Invalid LDS Component prop "alt" supplied to ${componentName}. Accessibility compliance requires an alt text value be set for the Hero component's banner image.`;
    return new Error(ex);
  }
  const sAlt = String(alt);
  if (sAlt.length > 125) {
    const ex = `Invalid LDS Component prop "alt" supplied to ${componentName}. Accessibility compliance requires an alt text value not be composed of more than 125 characters; current alt text has ${sAlt.length}; some screen readers will not announce more than that.`;
    return new Error(ex);
  }
  return null;
}
