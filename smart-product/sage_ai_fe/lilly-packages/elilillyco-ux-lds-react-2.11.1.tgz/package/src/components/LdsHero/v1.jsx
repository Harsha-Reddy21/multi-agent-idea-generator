import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsButton from '../LdsButton/index.jsx';
import LdsIcon from '../LdsIcon/index.jsx';

import transparency from '../../assets/transparency.png';

import {
  validateBannerImageAltText,
  getContentAlignment,
  isScrollable,
  validateScrollButtonClasses,
  getScrollButtonClasses,
  getScrollButtonIconName,
  scrollDown
} from './v1.helpers.js';

// JSDoc type definitions
/**
 * @typedef LdsHeroProps
 * @property {{srcset: string, media?: string}[]} images - An array which must include at least one or more responsive Hero banner image source objects to render with an HTML picture element
 * @property {string} alt - The value of the Hero banner image's "alt" attribute; the string value must not be longer than 125 characters
 * @property {string} [id] - The HTML `id` attribute to set on the Hero container SECTION element; MUST be set when using the scroll button function
 * @property {string} [contentAlign] - How the Hero's body content should be aligned horizontally; options are 'center' 'left' and 'right'; when undefined it defaults to "center" alignment
 * @property {boolean} [useScrollButton] - Whether to use the Hero\'s "Scroll Button" feature which adds a button which will scroll the Hero down on the page to reveal the content below it
 * @property {string} [scrollButtonLabel] - The text used in the Hero's scroll button; can be a string or React fragment but must only contain inline HTML
 * @property {string} [scrollButtonClasses] - Add a space-delimited list of LDS button classes or any custom classes to the Hero\'s scroll button using this prop; should typically use the special reserved button classes of \'ghost-inverted\' (default) or \'ghost\' on light or dark banner images respectively; the compact density variant should not be used
 * @property {string} [scrollButtonIcon] - Which valid LDS Icon to use in the scroll button; when undefined (not set) it defaults to "chevron"
 * @property {string} [className] - Additional custom classes to add to the Hero container SECTION element class list
 * @property {string} [classes] - Additional custom classes to add to the Hero container SECTION element class list
 * @property {React.ReactNode} children - The children of the component
 */
/**
 * LdsHero component
 * @param {LdsHeroProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
function LdsHeroV1({
  images,
  alt,
  id,
  contentAlign,
  useScrollButton = false,
  scrollButtonLabel = 'Scroll Down',
  scrollButtonClasses,
  scrollButtonIcon,
  className,
  classes,
  children,
  ...rest
}) {
  const scrollable = isScrollable(id, useScrollButton);

  const ScrollButton = () => {
    if (!scrollable) return '';

    const buttonClasses = getScrollButtonClasses(scrollButtonClasses);
    const iconName = getScrollButtonIconName(scrollButtonIcon);

    function clickScrollButton() {
      scrollDown(id);
    }

    return (
      <div className="lds-hero-scroll">
        <LdsButton
          classes={cn(
            'lds-hero-scroll-button',
            {
              [`${buttonClasses}`]: buttonClasses,
            }
          )}
          onClick={clickScrollButton}
        >
          <span className="lds-hero-scroll-button-label">
            {scrollButtonLabel}
          </span>
          <span className="lds-hero-scroll-button-icon">
            <LdsIcon
              name={iconName}
              inline
              decorative
            >
            </LdsIcon>
          </span>
        </LdsButton>
      </div>
    );
  };

  const contentAlignment = getContentAlignment(contentAlign);

  return (
    <section
      id={id}
      className={cn(
        'lds-hero-v1',
        {
          [`${contentAlignment}`]: contentAlignment,
          'use-scroll-button': scrollable,
        },
        className,
        classes
      )}
      {...rest}
    >
      <picture className="lds-hero-image">
        { images && Array.isArray(images) && images.map((image, i) => (
          <source
            key={i}
            media={image.media}
            srcSet={image.srcset}
          />
        ))}
        <img
          className="lds-hero-image-fallback"
          style={{ backgroundImage: `url(${images[images.length - 1].srcset})` }}
          src={transparency}
          alt={alt}
        />
      </picture>
      <div className="wrapper">
        <div className="lds-hero-body section row align-items-center">
          <div className="col">
            {children}
          </div>
        </div>
      </div>
      <ScrollButton></ScrollButton>
    </section>
  );
}

export default LdsHeroV1;

LdsHeroV1.propTypes = {
  id: PropTypes.string,
  contentAlign: PropTypes.oneOf(['center', 'left', 'right', undefined]),
  useScrollButton: PropTypes.bool,
  scrollButtonLabel: PropTypes.string,
  scrollButtonClasses: (props, propName, componentName) => validateScrollButtonClasses(props[propName], componentName),
  scrollButtonIcon: PropTypes.oneOf(['chevron', 'triangle', 'arrow']),
  alt: (props, propName, componentName) => validateBannerImageAltText(props[propName], componentName),
  images: PropTypes.arrayOf((propValue, key) => { // eslint-disable-line
    if (!propValue[key].srcset) {
      return new Error(`\n
      >>> LDS ERROR: [Invalid Component Data] in LdsHero: banner images array object missing 'srcset' property at index ${key} (${key + 1}/${propValue.length}).
      Each responsive image object must contain an 'srcset' property.
      `);
    }
    if (!propValue[key].media && key !== (propValue.length - 1)) {
      return new Error(`\n
      >>> LDS ERROR: [Invalid Component Data] in LdsHero: banner images array object missing 'media' property at index ${key} (${key + 1}/${propValue.length}).
      Each responsive image object EXCEPT the fallback default must contain a 'media' property.
      `);
    }
    if (propValue[key].media && key === (propValue.length - 1)) {
      return new Error(`\n
      >>> LDS ERROR: [Invalid Component Data] in LdsHero: banner images array default fallback object contains an invalid 'media' property at index ${key} (${key + 1}/${propValue.length}).
      The fallback responsive image object MUST always be the last object in the array and MUST NOT contain a 'media' property.
      `);
    }
  }).isRequired,
};
