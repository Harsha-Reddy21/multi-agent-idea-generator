import { forwardRef } from 'react';

export default forwardRef(function Controlled({
  id,
  name,
  ariaLabelledby,
  onChange,
  required,
  disabled,
  checked,
  ...rest
}, ref) {
  return (
    <input
      ref={ref}
      type="checkbox"
      role="switch"
      className="lds-switch-input"
      id={id}
      aria-labelledby={ariaLabelledby || id}
      name={name || id}
      checked={checked}
      disabled={disabled}
      required={required}
      aria-required={required || null}
      aria-checked={checked}
      onChange={onChange}
      {...rest}
    />
  );
});
