import PropTypes from 'prop-types';
import cn from 'classnames';
import { forwardRef } from 'react';

import Controlled from './Controlled.jsx';
import Uncontrolled from './Uncontrolled.jsx';

// JSDoc type definitions
/**
 * @typedef LdsSwitchProps
 * @property {string} id - Required Component `id`.
 * @property {string} label - Text value of the `<label>` element to display next to the switch
 * @property {string} [name] - Sets the value of the `name` attribute on the component's `<input>` element; defaults to the value of `id`
 * @property {string} [value] - Sets the value of the `value` attribute on the component's `<input>` element
 * @property {boolean} [defaultChecked] - Whether the switch should be on (`checked` attribute set) by default
 * @property {boolean} [required] - Whether the switch is a required field; when true the `required` attribute and `aria-required="true"` are set on the `<input>` element
 * @property {boolean} [disabled] - Whether the switch is in a disabled state
 * @property {string} [labelPlacement] - Whether the `<label>` text should be inserted before or after the interactive switch element; prop only accepts the string values `'left'` or `'right'`
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [wrapperAttributes] - An optional object to pass generic HTML attributes onto the component's wrapper `<div>` element
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [labelAttributes] - An optional object to pass generic HTML attributes onto the component\'s `<label>` element
 * @property {string} [ariaLabelledby] - The id of the element that labels the Switch
 * @property {string} [className] - Optional custom user-defined CSS class(es) for the component, will be appended to the list of any other component classes on the compoonent\'s wrapper `<div>` element
 */
const LdsSwitch = forwardRef(
  /**
   * LdsSwitch component
   * @param {LdsSwitchProps & React.InputHTMLAttributes<HTMLInputElement>} props
   * @returns {React.JSX.Element}
   */
  function LdsSwitch({
    id,
    name,
    value = null,
    defaultChecked = null,
    required = false,
    label,
    disabled = false,
    labelPlacement = 'left',
    className,
    wrapperAttributes,
    labelAttributes,
    ariaLabelledby,
    onChange = null,
    checked = null,
    ...rest
  }, ref) {
    function toggleSwitch(e) {
      if (defaultChecked !== null) {
        const isChecked = e.currentTarget.checked;
        e.currentTarget.setAttribute('aria-checked', isChecked);
      }
      if (onChange) onChange(e);
    }

    return (
      <div
        className={cn(
          'lds-switch lds-form-field',
          {
            disabled,
          },
          className
        )}
        {...wrapperAttributes}
      >
        <label
          htmlFor={id}
          className="lds-switch-label"
          {...labelAttributes}
        >
          {labelPlacement !== 'right' && label}
          { checked !== null && onChange
            && <Controlled
              ref={ref}
              id={id}
              aria-labelledby={ariaLabelledby || id}
              name={name || id}
              disabled={disabled}
              required={required}
              aria-required={required || null}
              checked={checked}
              onChange={onChange}
            {...rest}
            />}
          { checked === null && !onChange
            && <Uncontrolled
              ref={ref}
              id={id}
              aria-labelledby={ariaLabelledby || id}
              name={name || id}
              disabled={disabled}
              required={required}
              aria-required={required || null}
              value={value}
              defaultChecked={defaultChecked}
              toggleSwitch={toggleSwitch}
              {...rest}
            />}
          <span aria-hidden="true" className={`lds-switch-toggle ${labelPlacement === 'right' ? 'lds-switch-label-right' : ''}`} >
            <span className="lds-switch-toggle-knob"></span>
          </span>
          {labelPlacement === 'right' && label}
        </label>
      </div>
    );
  }
);

LdsSwitch.propTypes = {
  id: PropTypes.string.isRequired,
  name: PropTypes.string,
  value: PropTypes.string,
  defaultChecked: PropTypes.bool,
  required: PropTypes.bool,
  label: PropTypes.string,
  disabled: PropTypes.bool,
  labelPlacement: PropTypes.oneOf(['left', 'right']),
  wrapperAttributes: PropTypes.object,
  labelAttributes: PropTypes.object,
};

export default LdsSwitch;
