import { forwardRef } from 'react';

export default forwardRef(function Controlled({
  id,
  name,
  ariaLabelledby,
  value,
  required,
  disabled,
  toggleSwitch,
  defaultChecked,
  ...rest
}, ref) {
  return (
    <input
      ref={ref}
      type="checkbox"
      role="switch"
      className="lds-switch-input"
      id={id}
      aria-labelledby={ariaLabelledby || id}
      name={name || id}
      value={value}
      disabled={disabled}
      required={required}
      aria-required={required || null}
      defaultChecked={defaultChecked}
      aria-checked={defaultChecked}
      onChange={toggleSwitch}
      {...rest}
    />
  );
});
