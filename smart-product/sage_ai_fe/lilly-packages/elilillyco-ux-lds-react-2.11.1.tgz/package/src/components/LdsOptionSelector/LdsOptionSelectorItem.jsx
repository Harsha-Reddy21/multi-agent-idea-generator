import { forwardRef } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

// JSDoc type definitions
/**
 * @typedef LdsOptionSelectorItemProps
 * @property {string} id - The ID of the input element
 * @property {string} name - The name of the input element
 * @property {string} value - The value of the input element
 * @property {string} label - The text label of the input element
 * @property {boolean} [required] - Whether the input element is required
 * @property {boolean} [disabled] - Whether the input element is disabled
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 */
const LdsOptionSelectorItem = forwardRef(
  /**
   * LdsOptionSelectorItem component
   * @param {LdsOptionSelectorItemProps & React.InputHTMLAttributes<HTMLInputElement>} props
   * @returns {React.JSX.Element}
   */
  function LdsOptionSelectorItem(
    {
      id,
      name,
      value,
      label,
      required = false,
      disabled = false,
      className,
      ...rest
    },
    ref
  ) {
    return (
    <span
      className={cn(
        'lds-option-selector-item',
        'col-12',
        'col-md',
        {
          disabled,
        },
        className
      )}
    >
      <input
        className={cn(
          'lds-option-selector',
          {
            disabled,
          }
        )}
        id={`${id}-optionSelector`}
        type="radio"
        name={name}
        value={value}
        disabled={disabled}
        required={required}
        {...rest}
        ref={ref}
      />
      <label
        className="lds-option-selector-label"
        htmlFor={`${id}-optionSelector`}
      >
        {label}
      </label>
    </span>
    );
  }
);

LdsOptionSelectorItem.propTypes = {
  id: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  value: PropTypes.string.isRequired,
  label: PropTypes.string.isRequired,
  required: PropTypes.bool,
  disabled: PropTypes.bool,
};

export default LdsOptionSelectorItem;
