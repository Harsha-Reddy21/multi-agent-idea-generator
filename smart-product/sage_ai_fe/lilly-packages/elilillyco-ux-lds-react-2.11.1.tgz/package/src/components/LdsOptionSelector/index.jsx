import cn from 'classnames';
import PropTypes from 'prop-types';

// JSDoc type definitions
/**
 * @typedef LdsOptionSelectorProps
 * @property {string} label - Text to display in the Option Selector's fieldset legend element
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {React.ReactNode} children - React child slot object
 * @property {string} [densityClass] - Optional; set one of the density size classes for the component; only one valid value is 'compact' or leave undefined for the default density
 * @property {string} [radiusClass] - Optional; set one of the border radius size classes for the component; valid values are 'radius-sm', 'radius-md', 'radus-lg' or leave undefined to use the theme radius default
/**
 * LdsOptionSelector component
 * @param {LdsOptionSelectorProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsOptionSelector({
  label,
  className,
  children,
  densityClass,
  radiusClass,
  ...rest
}) {
  return (
    <div
      role="application"
      className={cn(
        'lds-option-selector-container',
        className,
        densityClass,
        radiusClass
      )}
      {...rest}
    >
      <fieldset
        role="radiogroup"
        className="lds-option-selector-group"
      >
        {label && <legend className="lds-option-selector-list-label">
          {label}
        </legend>}
        <div className="row m-0">
          {children}
        </div>
      </fieldset>
    </div>
  );
}

LdsOptionSelector.propTypes = {
  children: PropTypes.node.isRequired,
  label: PropTypes.string,
  densityClass: PropTypes.oneOf(['compact', undefined]),
  radiusClass: PropTypes.oneOf(['radius-sm', 'radius-md', 'radius-lg', undefined]),
  className: PropTypes.string,
};
