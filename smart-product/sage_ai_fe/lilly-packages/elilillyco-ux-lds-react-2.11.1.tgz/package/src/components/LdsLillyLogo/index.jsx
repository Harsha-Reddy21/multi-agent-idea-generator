import cn from 'classnames';
import PropTypes from 'prop-types';

/* Private Sub-Components */
import LillyLogoSvg from './private/LillyLogoSvg.jsx';

/* Component Utilities */
import {
  validLogoOptions,
  validSizeOptions,
  validColorOptions,
  getValidLogoOption,
  defaultLogoOption
} from './util.js';

// MARK: Definition

// JSDoc type definitions
/**
 * @typedef LdsLillyLogoProps
 * @property {string} [logo] - OPTIONAL; Which Lilly Logo; default when undefined is 'lilly'; accepts: 'lilly', 'lilly-tag-below', 'lilly-tag-aside', 'monogram' and the undefined primitive
 * @property {string} [ariaLabel] - REQUIRED; Provide an accessible description of the logo; when undefined defaults are: 'lilly' = 'lilly', 'tag-below' = 'lilly a medicine company', 'tag-aside' = 'lilly a medicine company', 'monogram' = 'lilly'
 * @property {string} [sizeClass] - OPTIONAL; Specify one of the size classes to set the logo's size and padding density; default when undefined is "medium" size; accepts: 'min', 'xs', 'sm', 'md', 'lg', 'xl' and the undefined primitive
 * @property {string} [colorClass] - OPTIONAL; Specify one of the valid color classes to set the logo's fill color; default when undefined is the lilly "red" color; accepts: 'black', 'white', 'red' and the undefined primitive
 * @property {string} [className] - OPTIONAL; Specify a space delimited list of any other component class names or user defined custom class names
 * @property {string} [href] - OPTIONAL; Provide a URL to render the logo as an image hyperlink; when undefined the logo defaults to a divider element with role="img"
 * @property {string} [svgClassName] - OPTIONAL; Specify a space delimited list of any other class names to add to the logo SVG element's class list
 * @property {string} [svgTitle] - OPTIONAL; If the logo SVG should have a title element provide a string to define the value; default usage does not render a title element
 * @property {object} [svgProps] - OPTIONAL; object of properties to apply as non-prop attributes to the logo SVG element
 * @property {boolean} [utilityLogo] - INTERNAL USE ONLY; set to true to render the logo in the LDS utility menu, not to be used in any other context
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - OPTIONAL, define any additional non-prop attributes on the component element to be rendered on the component markup pattern's root container element.
 */
/**
 * LdsLillyLogo component
 * @param {React.InputHTMLAttributes<HTMLInputElement> & LdsLillyLogoProps} props
 * @returns {React.JSX.Element}
 */
function LdsLillyLogo({
  logo = 'lilly',
  ariaLabel = '',
  sizeClass = undefined,
  colorClass = undefined,
  className = '',
  href = undefined,
  svgClassName = undefined,
  svgTitle = undefined,
  svgProps = undefined,
  utilityLogo = false,
  ...rest
}) {
  // MARK: Methods

  // Get valid logo option properties for the requested logo option
  let thisValidLogoOption = getValidLogoOption(logo);

  // Get the ARIA label, either use the logo option's default or the user defined value
  let thisAriaLabel = thisValidLogoOption.defaultLabel;
  if (ariaLabel) thisAriaLabel = ariaLabel;

  // Set a valid size class if one was passed
  let thisSizeClass = '';
  if (sizeClass && validSizeOptions.includes(sizeClass)) thisSizeClass = sizeClass;

  // Set a valid color class if one was passed
  let thisColorClass = '';
  if (colorClass && validColorOptions.includes(colorClass)) thisColorClass = colorClass;

  // Build element class list
  let elementClasses = cn(
    'lds-lilly-logo',
    thisValidLogoOption.className,
    thisSizeClass,
    thisColorClass,
    className
  );

  // Internal Utility Logo Use Case
  if (utilityLogo) {
    thisValidLogoOption = defaultLogoOption;
    thisAriaLabel = thisValidLogoOption.defaultLabel;
    if (ariaLabel) thisAriaLabel = ariaLabel;
    elementClasses = 'utility-logo';
  }

  // MARK: Renders

  // Hyperlinked Logo
  if (href) {
    return (
      <a
        href={href}
        className={elementClasses}
        aria-label={thisAriaLabel}
        {...rest}
      >
        <LillyLogoSvg
          logoOption={thisValidLogoOption}
          title={svgTitle}
          className={svgClassName}
          {...svgProps}
        />
      </a>
    );
  }

  // Default "image" Logo
  return (
    <div
      role="img"
      className={elementClasses}
      aria-label={thisAriaLabel}
      {...rest}
    >
      <LillyLogoSvg
        logoOption={thisValidLogoOption}
        title={svgTitle}
        className={svgClassName}
        {...svgProps}
      />
    </div>
  );
}
export default LdsLillyLogo;

// MARK: Props Validation
LdsLillyLogo.propTypes = {
  logo: PropTypes.oneOf(validLogoOptions),
  ariaLabel: PropTypes.string,
  sizeClass: PropTypes.oneOf(validSizeOptions),
  colorClass: PropTypes.oneOf(validColorOptions),
  className: PropTypes.string,
  href: PropTypes.string,
  svgClassName: PropTypes.string,
  svgTitle: PropTypes.string,
  svgProps: PropTypes.object,
  rest: PropTypes.any,
};
