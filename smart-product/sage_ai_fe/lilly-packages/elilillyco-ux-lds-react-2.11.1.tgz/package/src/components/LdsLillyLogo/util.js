/**
 * @returns {string} the default logo option string value
 *
 * The current default is `'lilly'`
 */
const defaultLogo = 'lilly';

/**
 * @returns {Array.<string>} valid logo option string values
 *
 * NOTE: The logo option strings are also the CSS class names required on the logo container element
 * to properly render the logo option.
 */
const validLogoOptions = [
  undefined,
  'lilly',
  'lilly-tag-below',
  'lilly-tag-aside',
  'monogram',
];

/**
 * Get the default label for a valid logo option
 *
 * @param {string} validLogoOption a valid logo option name
 *
 * @returns {string} the default logo option label
 */
const getValidLogoOptionDefaultLabel = (validLogoOption) => {
  switch (validLogoOption) {
    case 'lilly-tag-below':
    case 'lilly-tag-aside':
      return 'lilly a medicine company';
    case 'monogram':
      return 'lilly monogram';
    case 'lilly':
    default:
      return 'lilly';
  }
};

/**
 * Get the `<svg>` element `viewBox` attribute value for a valid logo option
 *
 * @param {string} validLogoOption a valid logo option name
 *
 * @returns {string} the correct SVG `viewBox` attribute value
 */
const getValidLogoOptionSvgViewBox = (validLogoOption) => {
  switch (validLogoOption) {
    case 'lilly-tag-below':
      return '0 0 200 92';
    case 'lilly-tag-aside':
      return '0 0 200 38';
    case 'monogram':
      return '0 0 120 120';
    case 'lilly':
    default:
      return '0 0 131 70';
  }
};

/**
 * @returns {object} the default logo option properties object
 */
const defaultLogoOption = {
  logo: defaultLogo,
  className: defaultLogo,
  defaultLabel: getValidLogoOptionDefaultLabel(defaultLogo),
  svgViewBox: getValidLogoOptionSvgViewBox(defaultLogo),
};

/**
 * Checks and gets the best valid logo option based on a requested logo string input value
 *
 * @param {string} logo the requested logo option
 *
 * @returns {object} an object which defines the properties of a valid logo
 *
 * When the requested logo option value is invalid the default option will be used
 *
 * The returned logo object properties are:
 * - `logo` = the validated option value
 * - `className` = the logo container element's required logo option CSS class
 * - `defaultLabel` = the default ARIA label (or "alt text") description of the logo image
 * - `svgViewBox` = the logo `<svg>` element's `viewBox` attribute value
 */
const getValidLogoOption = (logoOption) => {
  // If the requested option is a undefined or otherwise a falsey value, return default
  if (!logoOption) return defaultLogoOption;

  // Assume the requsted option is probably valid (if all letters are lowercase)
  const requestedLogo = logoOption.toLowerCase();
  // Verify that the requested logo is valid and if so, return it
  if (validLogoOptions.includes(requestedLogo)) {
    return {
      logo: requestedLogo,
      className: requestedLogo,
      defaultLabel: getValidLogoOptionDefaultLabel(requestedLogo),
      svgViewBox: getValidLogoOptionSvgViewBox(requestedLogo),
    };
  }

  // In any other case, typically an invalid logo option string value, return the default
  return defaultLogoOption;
};

/**
 * @returns {Array.<string>} valid logo size option string values
 *
 * NOTE: The size option strings (other than undefined) are also the CSS class names required on the logo container element
 * to properly set the size option.
 */
const validSizeOptions = [
  undefined,
  'min',
  'xs',
  'sm',
  'md',
  'lg',
  'xl',
];

/**
 * @returns {Array.<string>} valid logo color option string values
 *
 * NOTE: The color option strings (other than undefined) are also the CSS class names required on the logo container element
 * to properly set the color option.
 */
const validColorOptions = [
  undefined,
  'red',
  'black',
  'white',
];

export {
  defaultLogo,
  validLogoOptions,
  getValidLogoOptionDefaultLabel,
  getValidLogoOptionSvgViewBox,
  defaultLogoOption,
  getValidLogoOption,
  validSizeOptions,
  validColorOptions
};
