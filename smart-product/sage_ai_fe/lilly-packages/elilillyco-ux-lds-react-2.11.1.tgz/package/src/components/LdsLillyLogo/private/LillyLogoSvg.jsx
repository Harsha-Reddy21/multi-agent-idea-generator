import PropTypes from 'prop-types';
import cn from 'classnames';

/* Private Sub-Components */
import LillyLogoSvgInner from './LillyLogoSvgInner.jsx';

/* Component Utilities */
import {
  defaultLogoOption
} from '../util.js';

// MARK: Definition

/**
 * PRIVATE SUB-COMPONENT
 *
 * It renders the inline SVG markup for a Lilly Logo option
 */
export default function LillyLogoSvg({
  logoOption = undefined,
  title = undefined,
  className = undefined,
  ...rest
}) {
  // MARK: Methods

  // Verify the logo option is not falsey and if so, use default
  let thisLogoOption = logoOption;
  if (!thisLogoOption) thisLogoOption = defaultLogoOption;

  // MARK: Renderer
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox={thisLogoOption.svgViewBox}
      fill="none"
      className={cn(className)}
      {...rest}
    >
      {title && <title>{title}</title>}
      <LillyLogoSvgInner logo={thisLogoOption.logo} />
    </svg>
  );
}

// MARK: Props Validation
LillyLogoSvg.propTypes = {
  logoOption: PropTypes.shape({
    logo: PropTypes.string,
    className: PropTypes.string,
    defaultLabel: PropTypes.string,
    svgViewBox: PropTypes.string,
  }),
  title: PropTypes.string,
  rest: PropTypes.any,
};
