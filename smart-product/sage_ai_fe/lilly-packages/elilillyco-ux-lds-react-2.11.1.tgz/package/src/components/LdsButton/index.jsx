import { forwardRef } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import usePrefersReducedMotion from '../../hooks/usePrefersReducedMotion.js';
import createRipple from '../../util/createRipple.js';

import LdsIcon from '../LdsIcon/index.jsx';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsButtonProps
 * @property {string} [classes] - Add a space-delimited list of LDS button classes using this prop
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {boolean} [clearDefaultClasses] - Whether the default LDS styling classes should be applied to the button
 * @property {boolean} [disabled] - Whether the button is in the disabled state; disabled buttons cannot be interacted with
 * @property {boolean} [disableIconSpace] - Whether the "Easy Icon" will have an automatic non-breaking space injected between it and the link text
 * @property {string} [icon] - Setting a truthy string value enables the "Easy Icon" function; the value must be the name of a valid LDS Icon
 * @property {string} [iconLabel] - The value of the icon's title attribute; defaults to the icon name; use on non-decorative icons
 * @property {boolean} [iconOnly] - Whether the button will only have an icon as the content; when true the button has reduced horizontal density and icon position classes do not function
 * @property {string} [iconPosition] - Whether the "Easy Icon" should be rendered before or after the default content; must be "before" or "after"
 * @property {boolean} [linkButton] - Whether the button will be rendered to look like a text link
 * @property {function} [onClick] - Function to be called when the button is clicked
 * @property {string} [type] - The value of the HTML button element\'s "type" attribute; must be "button", "submit", or "reset"
 * @property {React.ReactNode} [children] - React component children
 */
const LdsButton = forwardRef(
  /**
   * LdsButton component
   * @param {LdsButtonProps & React.InputHTMLAttributes<HTMLInputElement>} props
   * @returns {React.JSX.Element} - LdsButton component
   */
  function LdsButton({
    children,
    classes = undefined,
    className = '',
    clearDefaultClasses = false,
    disabled = false,
    disableIconSpace = false,
    disableRipple = false,
    icon = undefined,
    iconLabel = undefined,
    iconOnly = false,
    iconPosition = 'after',
    linkButton = false,
    onClick,
    type = 'button',
    ...rest
  }, ref) {
    const prefersReducedMotion = usePrefersReducedMotion();

    const IconElement = () => {
      if (!icon) return '';
      return (
      <LdsIcon
        name={icon}
        className={cn(
          'button-icon',
          {
            [`${iconPosition}`]: children,
          }
        )}
        inline
        label={iconLabel}
        decorative
      />
      );
    };

    // Creates a spacer element to add a single text non-breaking space character
    // between the "Easy Icon" and the text of the link
    const IconSpacer = () => {
    // If the developer explicity disabled the icon spacer, do it
      if (disableIconSpace) return '';
      // If it's an "icon only" link (or button link) there should never be an additional space character
      if (iconOnly) return '';
      // Otherwise there should usually be a space character between the link content and the easy icon
      return (<span className="lds-button-icon-spacer">&nbsp;</span>);
    };

    const handleClick = (event) => {
      // If the user prefers reduced motion, the button is a link button, or the dev has disabled the ripple, don't create the ripple effect
      if (!prefersReducedMotion && !linkButton && !disableRipple) {
        createRipple(event);
      }
      onClick(event);
    };

    return (
    <button
      ref={ref}
      onClick={handleClick}
      type={type}
      className={cn(
        {
          'lds-button': !linkButton && !clearDefaultClasses,
          'lds-link': linkButton,
          [`${classes}`]: classes,
          'icon-only': iconOnly,
          disabled,
        },
        className
      )}
      disabled={disabled}
      {...rest}
    >
      {icon && iconPosition === 'before' && <IconElement />}
      {icon && iconPosition === 'before' && <IconSpacer />}
      {children}
      {icon && iconPosition === 'after' && <IconSpacer />}
      {icon && iconPosition === 'after' && <IconElement />}
    </button>
    );
  }
);

export default LdsButton;

LdsButton.propTypes = {
  classes: PropTypes.string,
  clearDefaultClasses: PropTypes.bool,
  disabled: PropTypes.bool,
  disableIconSpace: PropTypes.bool,
  disableRipple: PropTypes.bool,
  icon: PropTypes.string,
  iconLabel: PropTypes.string,
  iconOnly: PropTypes.bool,
  iconPosition: PropTypes.oneOf(['before', 'after']),
  linkButton: PropTypes.bool,
  type: PropTypes.oneOf(['button', 'submit', 'reset']),
};
