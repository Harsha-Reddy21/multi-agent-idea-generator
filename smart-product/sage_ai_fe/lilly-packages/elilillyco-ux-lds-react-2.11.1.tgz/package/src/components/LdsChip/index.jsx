import { forwardRef, useState } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsIcon from '../LdsIcon/index.jsx';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsButtonProps
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {boolean} [clearDefaultClasses] - Whether the default LDS styling classes should be applied to the button
 * @property {boolean} [disabled] - Whether the button is in the disabled state; disabled buttons cannot be interacted with
 * @property {boolean} [disableIconSpace] - Whether the "Easy Icon" will have an automatic non-breaking space injected between it and the link text
 * @property {string} [icon] - Setting a truthy string value enables the "Easy Icon" function; the value must be the name of a valid LDS Icon
 * * @property {string} [iconFill] - The value of the icon's fill attribute; defaults to the icon name; use on non-decorative icons
 * @property {string} [iconLabel] - The value of the icon's title attribute; defaults to the icon name; use on non-decorative icons
 * @property {boolean} [iconOnly] - Whether the button will only have an icon as the content; when true the button has reduced horizontal density and icon position classes do not function
 * @property {string} [iconPosition] - Whether the "Easy Icon" should be rendered before or after the default content; must be "before" or "after"
 * @property {boolean} [linkButton] - Whether the button will be rendered to look like a text link
 * @property {function} [onClick] - Function to be called when the button is clicked
 * @property {string} [type] - The value of the HTML button element\'s "type" attribute; must be "button", "submit", or "reset"
 * @property {React.ReactNode} [children] - React component children
 */
const LdsChip = forwardRef(
  /**
   * LdsButton component
   * @param {LdsButtonProps & React.InputHTMLAttributes<HTMLInputElement>} props
   * @returns {React.JSX.Element} - LdsButton component
   */
  function LdsChip({
    children,
    className = undefined,
    clearDefaultClasses = false,
    disabled = false,
    hasClose = false,
    icon = undefined,
    iconFill = undefined,
    iconLabel = undefined,
    iconOnly = false,
    iconPosition,
    onClick = () => {},
    selected,
    type = 'button',
    ...rest
  }, ref) {
    const [isActive, setIsActive] = useState(false);

    const handleMouseDown = () => {
      setIsActive(true);
    };

    const handleMouseUp = () => {
      setIsActive(false);
    };

    const handleMouseLeave = () => {
      // Ensure the state resets if the mouse leaves the button
      setIsActive(false);
    };

    const handleClick = (event) => {
      onClick(event);
    };

    return (
    <button
      ref={ref}
      onClick={handleClick}
      onMouseDown={handleMouseDown}
      onMouseLeave={handleMouseLeave}
      onMouseUp={handleMouseUp}
      type={type}
      className={cn(
        {
          'lds-chip': !clearDefaultClasses,
          [`${className}`]: className,
          'icon-only': iconOnly,
          'has-icon-before': iconPosition === 'before',
          'has-icon-after': iconPosition === 'after',
          'has-close': hasClose,
          'is-selected': selected,
          'is-active': isActive,
        }
      )}
      disabled={disabled}
      {...rest}
    >
      {(icon && (iconOnly || iconPosition === 'before')) && <LdsIcon
        label={iconLabel}
        name={(selected || isActive) && iconFill ? iconFill : icon}
        className={cn(
          'chip-icon',
          'icon-before'
        )}
        inline
        decorative
      />}
      {children}
      {(icon && iconPosition === 'after') && <LdsIcon
        label={iconLabel}
        name={(selected || isActive) && iconFill ? iconFill : icon}
        className={cn(
          'chip-icon',
          'icon-after'
        )}
        inline
        decorative
      />}
      {hasClose && <LdsIcon
        label={iconLabel}
        name="X"
        className={cn(
          'chip-icon-close'
        )}
        inline
        decorative
      />}
    </button>
    );
  }
);

export default LdsChip;

LdsChip.propTypes = {
  className: PropTypes.string,
  clearDefaultClasses: PropTypes.bool,
  disabled: PropTypes.bool,
  disableIconSpace: PropTypes.bool,
  disableRipple: PropTypes.bool,
  icon: PropTypes.string,
  iconFill: PropTypes.string,
  iconLabel: PropTypes.string,
  iconOnly: PropTypes.bool,
  iconPosition: PropTypes.oneOf(['before', 'after']),
  linkButton: PropTypes.bool,
  type: PropTypes.oneOf(['button', 'submit', 'reset']),
};
