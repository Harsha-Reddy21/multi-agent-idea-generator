import { forwardRef } from 'react';
import cn from 'classnames';

export default forwardRef(function IsiColumn({
  expandedMobileIsi,
  attached,
  isMobile,
  toggleContentMobileIsi,
  toggleIconCollapse = 'minus-circle',
  toggleIconExpand = 'plus-circle',
  hiddenIsiContentCollapseText,
  hiddenIsiContentExpandText,
  isiHeading,
  warningBlockHeading,
  warningBlockParagraph = '',
  warningBlockContent = '',
  defaultContent = '',
}, ref) {
  return (
    <div
      id="isiMainColumnISI"
      className={cn(
        'lds-isi-main-column',
        'isi',
        {
          'mobile-panel': isMobile,
          'desktop-column': !isMobile,
        },
        'col',
        'col-12',
        'col-md-6',
        'order-md-1',
        {
          expanded: expandedMobileIsi,
          attached: attached,
        }
      )}
    >

      { /* <!-- CONTENT COLUMN PANEL CONTAINER: This element expands/collapses below the large breakpoint --> */}
      <div
        id="isiMainPanelISI"
        role="region"
        aria-labelledby="isiContentHeadingISI"
        className={cn(
          'lds-isi-main-content-panel',
          'isi',
          {
            expanded: expandedMobileIsi,
            attached: attached,
          }
        )}
      >

        { /* <!-- CONTENT COLUMN BANNER TOGGLE: Only used below the large breakpoint to expand/collapse this content column --> */}
        <button
          id="isiMobileToggleISI"
          aria-controls="isiPanel isiMainPanelISI"
          aria-expanded={expandedMobileIsi}
          className={cn(
            'lds-button-clear-style',
            'lds-isi-content-banner',
            'isi',
            {
              expanded: expandedMobileIsi,
              attached: attached,
            }
          )}
          onClick={toggleContentMobileIsi}
          tabIndex={attached ? '-1' : null}
        >
          <span className="lds-isi-banner-wrapper pg-sm-dn">
            { /* <!-- This non-visible span contains expanded-state conditional button text with action context for screen readers --> */}
            <span
              id={expandedMobileIsi ? 'isiMobileToggleA11yTextCollapseISI' : 'isiMobileToggleA11yTextExpandISI'}
              className="visually-hidden"
            >
              {expandedMobileIsi ? hiddenIsiContentCollapseText : hiddenIsiContentExpandText}
            </span>
            { /* <!-- This span holds the actual ISI heading content but is only displayed when expanded; the heading text is ignored by screen readers --> */}
            <span
              className="lds-isi-banner-column isi col col-11"
              aria-hidden="true"
            >
              <span className="lds-isi-banner-text isi">
                {isiHeading}
              </span>
            </span>
            { /* <!-- This span holds a visual indicator icon of the ISI expansion state; it has no screen reader value --> */}
            <span
              className="lds-isi-banner-column toggle col col-1"
              aria-hidden="true"
            >
              { /* Element is set to display:none when attached in setAttached function */}
              { !attached
                && <span
                  id="isiMobileToggleIconsISI"
                  className="lds-isi-toggle"
                >
                  <svg
                    id={expandedMobileIsi ? 'isiMobileToggleIconCollapseISI' : 'isiMobileToggleIconExpandISI' }
                    className={cn(
                      'lds-icon',
                      'inline',
                      `${expandedMobileIsi ? toggleIconCollapse : toggleIconExpand }`
                    )}
                    aria-hidden="true"
                  >
                  </svg>
                </span>
              }
            </span>
          </span>
        </button>

        { /* CONTENT COLUMN CONTENT CONTAINER: This is used to allow the content to scroll below the large breakpoint */}
        <div
          id="isiContentContainerISI"
          className={cn(
            'lds-isi-content-container',
            'isi',
            {
              expanded: expandedMobileIsi,
              attached: attached,
            }
          )}
          ref={ref}
        >
          { /* <!-- This wrapper adds the correct page layout gutter spacing BELOW the large breakpoint */ }
          <div className="lds-isi-content-wrapper pg-sm-dn">
            <div className="lds-isi-content-row row justify-content-start">
              <h2
                id="isiContentHeadingISI"
                className="lds-isi-heading isi"
              >
                {isiHeading}
              </h2>
              <div className="lds-isi-content isi col col-11 col-md-12">
                <div
                  className="content-block lds-isi-warning-block"
                >
                  <div className="lds-isi-warning-paragraph p">
                    <h3
                      className="lds-isi-warning-block-heading"
                    >
                      {warningBlockHeading}
                    </h3>
                    <p className="lds-isi-warning-block-paragraph">
                      {warningBlockParagraph}
                    </p>
                  </div>

                  {warningBlockContent}
                </div>

                {/* Default content */}
                {defaultContent}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});
