import cn from 'classnames';

export default function IsiSpacer({ attached }) {
  return (
    <div
      id="isiSpacer"
      className={cn(
        'lds-isi-spacer',
        {
          attached,
        }
      )}
    ></div>
  );
}
