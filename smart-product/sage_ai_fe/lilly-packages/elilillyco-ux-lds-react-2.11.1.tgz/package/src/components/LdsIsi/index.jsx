import { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import { isiElementIds, getIsiElementById } from './util.js';

const isiEls = isiElementIds();

// import IsiIntersectionObserver from './IsiIntersectionObserver.jsx';
// import IsiSpacer from './IsiSpacer.jsx';
import IsiSpacerScrollPoller from './IsiSpacerScrollPoller.jsx';
import IsiDesktopToggle from './IsiDesktopToggle.jsx';
import IsiColumn from './IsiColumn.jsx';
import IndicationsColumn from './IndicationsColumn.jsx';
import useIsMobile from '../../hooks/useIsMobile.js';
import getFocusableElements from '../../util/getFocusableElements.js';

// JSDoc type definitions
/**
 * @typedef LdsIsiProps
 * @property {string} isiHeading - Heading text for the ISI column
 * @property {string} indicationHeading - Heading text for the Indications column
 * @property {string} warningBlockHeading - Heading text for the warning block
 * @property {string} [hiddenIsiPanelCollapseText] - Screen reader text for Important Safety Information and Indication or Indications panel (desktop) collapse button
 * @property {string} [hiddenIsiPanelExpandText] - Screen reader text for Important Safety Information and Indication or Indications panel (desktop) expand button
 * @property {string} [hiddenIsiContentCollapseText] - Screen reader text for Important Safety Information column collapse button (mobile)
 * @property {string} [hiddenIsiContentExpandText] - Screen reader text for Important Safety Information column expand button (mobile)
 * @property {string} [hiddenIsiIndicationsCollapseText] - Screen reader text for Indications column collapse button (mobile)
 * @property {string} [hiddenIsiIndicationsExpandText] - Screen reader text for Indications column expand button (mobile)
 * @property {string} [warningBlockParagraph] - HTML for the warning block paragraph
 * @property {string} [warningBlockContent] - HTML warning block content
 * @property {string} [defaultContent] - HTML default content slot
 * @property {string} [indicationsContent] - HTML content for indications column
 * @property {boolean} [expanded] - When set to true the ISI will be expanded, if in the detached state.
 * @property {boolean} [hidePeekAfterInteraction] - When set to true the ISI will hide the 4 line peek after it has been interacted with one time.
 * @property {string} toggleIconCollapse - The name of the LDS Icon to use to indicate that an ISI panel can be collapsed
 * @property {string} toggleIconExpand - The name of the LDS Icon to use to indicate that an ISI panel can be expanded
 * @property {string} [className] - Optional custom user-defined CSS class(es) to add to the component root container element; will be appended to the list of any other component classes
 * @property {boolean} [disableFriendlyMessages] - Optional disable friendly console messages that are not feature breaking errors.
 */
/**
 * LdsIsi component
 * @param {LdsIsiProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsIsi({
  isiHeading = '',
  indicationHeading = '',
  warningBlockHeading = '',
  warningBlockParagraph = '',
  warningBlockContent = '',
  defaultContent = '',
  indicationsContent = '',
  hiddenIsiPanelCollapseText = 'Important Safety Information and Indication or Indications. Select to Collapse.',
  hiddenIsiPanelExpandText = 'Important Safety Information and Indication or Indications. Select to Expand.',
  hiddenIsiContentCollapseText = 'Important Safety Information. Select to Collapse.',
  hiddenIsiContentExpandText = 'Important Safety Information. Select to Expand.',
  hiddenIsiIndicationsCollapseText = 'Indication or Indications. Select to Collapse.',
  hiddenIsiIndicationsExpandText = 'Indication or Indications. Select to Expand.',
  expanded = false,
  hidePeekAfterInteraction = false,
  toggleIconCollapse = 'minus-circle',
  toggleIconExpand = 'plus-circle',
  expandedTopOffset = 0,
  defaultSideNavDesktopExpandedTopOffset = 150,
  disableFriendlyMessages = false,
  className = '',
  ...rest
}) {
  const [expandedDesktop, setExpandedDesktop] = useState(expanded);
  const [attached, setAttached] = useState(false);
  const [expandedMobileIndications, setExpandedMobileIndications] = useState(false);
  const [expandedMobileIsi, setExpandedMobileIsi] = useState(expanded);
  const [offsetTop, setOffsetTop] = useState('0px');
  const [pagePosition, setPagePosition] = useState(null);
  const [forceAttachment] = useState(false);
  const [isCollapsing, setIsCollapsing] = useState(false);
  const [isPreDetach, setIsPreDetach] = useState(false);
  const [isiLoaded, setIsiLoaded] = useState(false);

  const isMobile = useIsMobile(768);

  // .touched class can be used on isi to set the peek height after isi has been interacted with
  const [hasBeenTouched, setHasBeenTouched] = useState(false);

  const mainRef = useRef(null);
  const contentContainerIsiRef = useRef(null);
  const contentContainerIndicationsRef = useRef(null);

  // Init JS Enabled
  useEffect(() => {
    // TODO: Need to do more testing in no-js environments to see how to ensure no-js isi works
    setIsiLoaded(true);
  }, []);

  // Hide Peek feature
  useEffect(() => {
    if (hidePeekAfterInteraction && (expandedDesktop || attached) && !hasBeenTouched) setHasBeenTouched(true);

    if (!hidePeekAfterInteraction && hasBeenTouched) setHasBeenTouched(false);
  }, [hidePeekAfterInteraction, expandedDesktop, attached, hasBeenTouched, setHasBeenTouched]);

  /**
   * Handles keydown events fired by the isiPanel
   *
   * @param e keydown event object
   */
  const isiPanelKeyDownHandler = (e) => {
    if (!attached) {
      if (e.shiftKey && e.key === 'Tab') {
        // User is tab navigating "backwards" or "up" towards the top of the document
        handlePanelTabBackward(e);
      } else if (e.key === 'Tab') {
        // User is tab navigating "forwards" or "down" towards the bottom of the document
        handlePanelTabForward(e);
      }
    }
  };

  /**
   * Handles [Tab] keypress navigation "forwards" through the expanded ISI panel(s)
   *
   * @param {Object} e keydown event object (https://developer.mozilla.org/en-US/docs/Web/API/Element/keydown_event)
   */
  const handlePanelTabForward = (e) => {
    // Always do nothing when the ISI is attached (failsafe)
    if (attached) return;

    if (!expandedDesktop) {
      // If the ISI is not expanded and we tab forward from any ISI focusable element, attach the ISI
      attach();
    } else {
      // Get all the ISI panel's focusable elements
      const isiPanel = getIsiElementById(isiEls.isiPanel);
      const isiFELs = getFocusableElements(isiPanel);

      // Get the last (or only) focusable element in the ISI panel
      let isiLastFELindex = isiFELs.length - 1;
      if (isiLastFELindex < 0) isiLastFELindex = 0;
      const isiLastFEL = isiFELs[isiLastFELindex];

      /* When the focus is on the mobile ISI panel toggle and the mobile indications panel is expanded
      * When [Tab] is pressed, stop, expand the mobile ISI panel, collapse the mobile Indications panel.
      */
      if ((e.target.id === isiEls.isiMobileToggleISI) && (expandedMobileIndications)) {
        e.preventDefault();
        resetScrollablePanelsToTop();
        toggleContentMobileIsi();
        return;
      }

      /* When the focus is on the mobile Indications panel toggle and the mobile ISI panel is expanded
      * When [Tab] is pressed, stop, expand the mobile Indications panel, collapse the mobile ISI panel.
      */
      if ((e.target.id === isiEls.isiMobileToggleIND) && (expandedMobileIsi)) {
        e.preventDefault();
        resetScrollablePanelsToTop();
        toggleContentMobileIndications();
        return;
      }

      /* When the focus is on the last focusable item in the ISI
      * stop and return the user to the first focusable item in the ISI
      * User must explicitly collapse the entire ISI to tab through it
      */
      if (e.target === isiLastFEL) {
        e.preventDefault();
        resetScrollablePanelsToTop();
        isiFELs[0].focus();
      }
    }
  };

  /**
   * Handles [Shift]+[Tab] keypress navigation "backwards" through the expanded ISI panels
   *
   * @param {Object} e keydown event object (https://developer.mozilla.org/en-US/docs/Web/API/Element/keydown_event)
   */
  const handlePanelTabBackward = (e) => {
    // Always do nothing when the ISI is attached (failsafe)
    if (attached) return;

    // Get all the ISI panel's focusable elements
    const isiPanel = getIsiElementById(isiEls.isiPanel);
    const isiFELs = getFocusableElements(isiPanel);

    // Get the last (or only) focusable element in the ISI panel
    let isiLastFELindex = isiFELs.length - 1;
    if (isiLastFELindex < 0) isiLastFELindex = 0;
    const isiLastFEL = isiFELs[isiLastFELindex];

    if (!expandedDesktop) {
      /* If the first focusable item is focused or either the ISI Banner toggle or the mobile
      * indications panel toggle are focused (which should usually be the first focusable
      * items when focusable), do nothing. This avoids unintentionally attaching the ISI.
      */
      if ((e.target === isiFELs[0])
          || (e.target.id === isiEls.isiBanner)
          || (e.target.id === isiEls.isiMobileToggleIND)
      ) {
        return;
      }

      /* If backwards tabbing into the collapsed detached ISI from the bottom, stop and attach
       * the ISI and then focus on the last focusable element in it.
       * This is an edge case that only occurs if there are no focusable elements below the ISI.
       */
      if (e.target === isiLastFEL) {
        e.preventDefault();
        attach();
        isiLastFEL.focus();
      }

      /* If the ISI is collapsed and focus is on the mobile ISI panel toggle
       * and [Shift]+[Tab] is pressed, move focus to the mobile Indications panel toggle
       * this is an edge case
       */
      if (e.target === isiEls.isiMobileToggleISI) {
        const isiMobileToggleIND = getIsiElementById(isiEls.isiMobileToggleIND);
        e.preventDefault();
        resetScrollablePanelsToTop();
        isiMobileToggleIND.focus();
        return;
      }

      // Otherwise just attach the ISI if focus is somewhere random in the panel
      attach();
    } else {
      /* When the focus is on the mobile ISI panel toggle and the mobile ISI panel is expanded
       * When [Shift]+[Tab] is pressed, stop, expand the mobile Indications panel, collapsing
       * the mobile ISI panel.
       */
      if ((e.target.id === isiEls.isiMobileToggleISI) && (expandedMobileIsi)) {
        e.preventDefault();
        resetScrollablePanelsToTop();
        toggleContentMobileIndications();
        return;
      }

      /* When the focus is on the mobile Indications panel toggle and the mobile Indications panel is expanded
      * When [Shift]+[Tab] is pressed, stop, expand the mobile ISI panel, collapsing
      * the mobile ISI panel.
      */
      if ((e.target.id === isiEls.isiMobileToggleIND) && (expandedMobileIndications)) {
        e.preventDefault();
        resetScrollablePanelsToTop();
        toggleContentMobileIsi();
        return;
      }

      /* When the focus is on the first focusable item in the ISI
      * stop and return the user to the last focusable item in the ISI
      * User must explicitly collapse the entire ISI to tab through it
      */
      if (e.target === isiFELs[0]) {
        e.preventDefault();
        resetScrollablePanelsToTop();
        isiLastFEL.focus();
      }
    }
  };

  /**
   * Set the ISI affix position as attached and execute any other attachment subroutine logic
   */
  const attach = () => {
    setAttached(true);
  };

  /**
   * Set the ISI affix position as detached and execute any other attachment subroutine logic
   */
  // This detach routine is required if any detach function call needs to be made in the future
  // eslint-disable-next-line no-unused-vars
  const detach = () => {
    if (forceAttachment) return;
    setIsPreDetach(true);
    setAttached(false);
    // Wait a bit to remove the preDetach class
    // This prevents ugly animation "jitter" if you move up and down too slowly near the attach/detach point
    // However this prevents the "slide up" of the banner after detaching
    setTimeout(() => setIsPreDetach(false), 500);
  };

  /**
   * Reset any scrollable ISI panels to the top
   */
  const resetScrollablePanelsToTop = () => {
    mainRef.current.scrollTop = 0;
    contentContainerIsiRef.current.scrollTop = 0;
    contentContainerIndicationsRef.current.scrollTop = 0;
  };

  /**
   * Compute a "top offset margin" value to define a height to subtract from the height of the
   * viewport to prevent the ISI from going over or under persistent content at the top of the viewport
   */
  const computeExpandedTopOffset = () => {
    let topOffset = 0;

    // Try to add any arbitrary user-defined top offset
    try {
      if (expandedTopOffset) topOffset += expandedTopOffset;
    } catch (ex1) {
      // eslint-disable-next-line no-console
      console.error(`LDS ISI >>> Unexpected exception computing the expanded top offset with the user-defined additional margin.
      Attempted to add the truthy value of the prop expandedTopOffset = '${expandedTopOffset}' to the topOffset.
      Exception:`, ex1.message);
    }

    // Try to get the LDS Sticky element if it exists and add it's height to the top offset
    try {
      const stickyElement = document.querySelector('.lds-sticky');
      if (stickyElement) topOffset += stickyElement.offsetHeight;
    } catch (ex2) {
      // eslint-disable-next-line no-console
      console.error(`LDS ISI >>> Unexpected exception computing the expanded top offset sticky container adjustment.
      Exception:`, ex2.message);
    }

    // Try to get the LDS Side Nav top container element which indicates that layout is being used
    try {
      const sideNav = document.querySelector('.lds-side-nav-top-container');
      // When in desktop mode, add the LDS design preferred additional margin
      if (sideNav && !isMobile) topOffset += defaultSideNavDesktopExpandedTopOffset;
      // When in mobile mode, add the sticky side nav top container height
      if (sideNav && isMobile) topOffset += sideNav.offsetHeight;
    } catch (ex3) {
      // eslint-disable-next-line no-console
      console.error(`LDS ISI >>> Unexpected exception computing the expanded top offset side nav layout adjustment.
      Exception:`, ex3.message);
    }

    return topOffset;
  };

  /**
   * Set the ISI detached state to expanded and execute any other expand subroutine logic
   */
  const expand = () => {
    setOffsetTop(computeExpandedTopOffset());

    const htmlTag = document.documentElement;
    setExpandedDesktop(true);
    setPagePosition(htmlTag.scrollTop);
    htmlTag.setAttribute('data-isi-expanded', 'true');
    htmlTag.style.top = `-${pagePosition}px`;
  };

  /**
   * Set the ISI detached state to collapsed and execute any other collapse subroutine logic
   */
  const collapse = async () => {
    const htmlTag = document.documentElement;

    setExpandedDesktop(false);

    // Begin collapsing
    setIsCollapsing(true);

    // Make sure that all scrollable-when-expanded ISI panels are "scrolled to top" while collapsing!
    resetScrollablePanelsToTop();

    // Update root HTML tag attributes
    htmlTag.style.top = null;
    htmlTag.removeAttribute('data-isi-expanded');

    // Use a timer to ensure "collapsing" state clears after a second
    setTimeout(() => setIsCollapsing(false), 1000);

    // Finally, return the user to where they were on the page before the ISI was expanded (if possible)
    window.scrollTo(0, pagePosition);
  };

  /**
   * onClick handler to be triggered by the main ISI banner toggle button
   *
   * Expands/Collapses the detached desktop ISI and manages the mobile states in case of viewport resize
   */
  const toggleContent = () => {
    if (attached) return;
    setExpandedMobileIndications(false);

    if (expandedDesktop) {
      // ISI panel is collapsing so collapse the mobile ISI panel too
      setExpandedMobileIsi(false);
      collapse();
    } else {
      // ISI panel is exapanding so expand the mobile ISI panel too
      setExpandedMobileIsi(true);
      expand();
    }
  };

  /**
   * onClick handler to be triggered by the ISI content header toggle button
   */
  const toggleContentMobileIsi = () => {
    if (attached) return;

    if (expandedDesktop) {
      // The ISI panel is expanded
      if (expandedMobileIsi) {
        // The ISI block is expanded so we need to close it AND the ISI panel
        setExpandedMobileIndications(false);
        setExpandedMobileIsi(false);
        collapse();
      } else {
        // The Indications block is expanded so we will ONLY collapse that block and expand the ISI block
        setExpandedMobileIndications(false);
        setExpandedMobileIsi(true);
      }
    } else {
      // The ISI panel is collapsed, expand it AND the ISI content block
      setExpandedMobileIsi(true);
      setExpandedMobileIndications(false);
      expand();
    }
  };

  /**
   * onClick handler to be triggered by the Indications content header toggle button
   */
  const toggleContentMobileIndications = () => {
    if (attached) return;

    if (expandedDesktop) {
      // The ISI panel is expanded
      if (expandedMobileIndications) {
        // The Indications block is expanded so we need to close it AND the ISI panel
        setExpandedMobileIsi(true);
        collapse();
        // For smoother transitions
        setTimeout(() => {
          setExpandedMobileIndications(false);
          setExpandedMobileIsi(false);
        }, 125);
      } else {
        // The ISI block is expanded so we will ONLY collapse that block and expand the Indications block
        setExpandedMobileIndications(true);
        setExpandedMobileIsi(false);
      }
    } else {
      // The ISI panel is collapsed, expand it AND the Indications content block
      setExpandedMobileIsi(false);
      setExpandedMobileIndications(true);
      expand();
    }
  };

  // Handle Expand Prop Updates
  useEffect(() => {
    if (expandedDesktop !== expanded) toggleContent();
  // This useEffect should run on every render but only if the expanded prop changed and nothing else
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [expanded]);

  return (
    <>
    {/* The intersection observer component uses that JS method to toggle the affix position of the ISI */}
    {/* Disabled for now, until a more robust IO solution can be found */}
    {/* <IsiIntersectionObserver
      setAttached={setAttached}
      forceAttachment={forceAttachment}
      setIsPreDetach={setIsPreDetach}
      hasBeenTouched={hasBeenTouched}
    /> */}
    <section
      id="isiSection"
      className={cn(
        'lds-isi-v2',
        'lds-isi-section',
        {
          'no-js': !isiLoaded,
          touched: hasBeenTouched,
        },
        className
      )}
      role="region"
      aria-labelledby="isiBanner"
      {...rest}
    >
      {/* The spacer component polls document.onscroll to toggle the affix position of the ISI */}
      <IsiSpacerScrollPoller
        attached={attached}
        setAttached={setAttached}
        forceAttachment={forceAttachment}
        setIsPreDetach={setIsPreDetach}
        disableFriendlyMessages={disableFriendlyMessages}
      />
      {/* <IsiSpacer attached={attached} /> */}
      <div
        id="isiPanel"
        className={cn(
          'lds-isi',
          {
            'lds-isi-loaded': isiLoaded,
            'lds-isi-expanded': expandedDesktop,
            'lds-isi-collapsing': isCollapsing,
            'lds-isi-attached': attached,
            'lds-isi-pre-detach': isPreDetach,
          }
        )}
        style={{
          top: expandedDesktop ? offsetTop : '0px',
          height: expandedDesktop ? `calc(100% - ${offsetTop}px)` : null,
        }}
        onKeyDown={isiPanelKeyDownHandler}
      >
        <div className="lds-isi-container lds-layout-container">
          {/* THIS IS THE SINGLE/PRIMARY "DETACHED" ISI TOGGLE BUTTON "BANNER" */}
          {/* It is always in the DOM but is only visible/functional above the LDS large breakpoint */}
          <IsiDesktopToggle
            expandedDesktop={expandedDesktop}
            attached={attached}
            hiddenIsiPanelCollapseText={hiddenIsiPanelCollapseText}
            hiddenIsiPanelExpandText={hiddenIsiPanelExpandText}
            toggleContent={toggleContent}
            toggleIconCollapse={toggleIconCollapse}
            toggleIconExpand={toggleIconExpand}
            isiHeading={isiHeading}
            indicationHeading={indicationHeading}
          />

          {/* <!-- THIS IS THE MAIN CONTENT SECTION OF THE ISI --> */}
          {/* <!-- This is the detached and expanded scrollable container in desktop width for the entire ISI contents --> */}
          <div
            id="isiMain"
            className={cn(
              'lds-isi-main',
              {
                expanded: expandedDesktop,
                attached: attached,
              }
            )}
            ref={mainRef}
          >

            { /* This wrapper adds the correct page layout gutter spacing ABOVE the large breakpoint */}
            <div
              id="isiMainWrapper"
              className={cn(
                'lds-isi-main-wrapper',
                'pg-md-up',
                {
                  expanded: expandedDesktop,
                  'expanded-isi': expandedMobileIsi,
                  'expanded-indications': expandedMobileIndications,
                  attached: attached,
                }
              )}
            >
              <div className="lds-isi-main-row">

                { /* <!-- MAIN CONTENT COLUMN: Indications (Mobile Render) --> */}
                {isMobile
                && <IndicationsColumn
                  expandedMobileIndications={expandedMobileIndications}
                  attached={attached}
                  isMobile={isMobile}
                  toggleContentMobileIndications={toggleContentMobileIndications}
                  toggleIconCollapse={toggleIconCollapse}
                  toggleIconExpand={toggleIconExpand}
                  hiddenIsiIndicationsCollapseText={hiddenIsiIndicationsCollapseText}
                  hiddenIsiIndicationsExpandText={hiddenIsiIndicationsExpandText}
                  indicationHeading={indicationHeading}
                  indicationsContent={indicationsContent}
                  ref={contentContainerIndicationsRef}
                />}

                { /* <!-- MAIN CONTENT COLUMN: Important Safety Information */}
                <IsiColumn
                  expandedMobileIsi={expandedMobileIsi}
                  attached={attached}
                  isMobile={isMobile}
                  toggleContentMobileIsi={toggleContentMobileIsi}
                  toggleIconCollapse={toggleIconCollapse}
                  toggleIconExpand={toggleIconExpand}
                  hiddenIsiContentCollapseText={hiddenIsiContentCollapseText}
                  hiddenIsiContentExpandText={hiddenIsiContentExpandText}
                  isiHeading={isiHeading}
                  warningBlockHeading={warningBlockHeading}
                  warningBlockParagraph={warningBlockParagraph}
                  warningBlockContent={warningBlockContent}
                  defaultContent={defaultContent}
                  ref={contentContainerIsiRef}
                />

                { /* <!-- MAIN CONTENT COLUMN: Indications (Tablet/Desktop Render) --> */}
                {!isMobile
                && <IndicationsColumn
                  expandedMobileIndications={expandedMobileIndications}
                  attached={attached}
                  isMobile={isMobile}
                  toggleContentMobileIndications={toggleContentMobileIndications}
                  toggleIconCollapse={toggleIconCollapse}
                  toggleIconExpand={toggleIconExpand}
                  hiddenIsiIndicationsCollapseText={hiddenIsiIndicationsCollapseText}
                  hiddenIsiIndicationsExpandText={hiddenIsiIndicationsExpandText}
                  indicationHeading={indicationHeading}
                  indicationsContent={indicationsContent}
                  ref={contentContainerIndicationsRef}
                />}

              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    </>
  );
}

LdsIsi.propTypes = {
  isiHeading: PropTypes.string.isRequired,
  warningBlockHeading: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.object,
  ]).isRequired,
  warningBlockParagraph: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.object,
  ]).isRequired,
  warningBlockContent: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.object,
  ]),
  defaultContent: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.object,
  ]),
  indicationHeading: PropTypes.string.isRequired,
  indicationsContent: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.object,
  ]),
  hiddenIsiPanelCollapseText: PropTypes.string,
  hiddenIsiPanelExpandText: PropTypes.string,
  hiddenIsiContentCollapseText: PropTypes.string,
  hiddenIsiContentExpandText: PropTypes.string,
  hiddenIsiIndicationsCollapseText: PropTypes.string,
  hiddenIsiIndicationsExpandText: PropTypes.string,
  expanded: PropTypes.bool,
  hidePeekAfterInteraction: PropTypes.bool,
  toggleIconCollapse: PropTypes.string,
  toggleIconExpand: PropTypes.string,
  expandedTopOffset: PropTypes.number,
  defaultSideNavDesktopExpandedTopOffset: PropTypes.number,
  className: PropTypes.string,
  disableFriendlyMessages: PropTypes.bool,
};
