import { forwardRef } from 'react';
import cn from 'classnames';

export default forwardRef(function IndicationsColumn({
  expandedMobileIndications,
  attached,
  isMobile,
  toggleContentMobileIndications,
  toggleIconCollapse = 'minus-circle',
  toggleIconExpand = 'plus-circle',
  hiddenIsiIndicationsCollapseText,
  hiddenIsiIndicationsExpandText,
  indicationHeading,
  indicationsContent,
}, ref) {
  return (
    <div
      id="isiMainColumnIND"
      className={cn(
        'lds-isi-main-column',
        'indications',
        {
          'mobile-panel': isMobile,
          'desktop-column': !isMobile,
        },
        'col-12',
        'col-md-5',
        'order-md-2',
        {
          expanded: expandedMobileIndications,
          attached: attached,
        }
      )}
    >
      { /* <!-- CONTENT COLUMN PANEL CONTAINER: This element expands/collapses the column below the large breakpoint --> */}
      <div
        id="isiMainPanelIND"
        role="region"
        aria-labelledby="isiContentHeadingIND"
        className={cn(
          'lds-isi-main-content-panel',
          'indications',
          {
            expanded: expandedMobileIndications,
            attached: attached,
          }
        )}
      >
        { /* <!-- CONTENT COLUMN BANNER TOGGLE: Only used below the large breakpoint to expand/collapse this content column --> */}
        <button
          id="isiMobileToggleIND"
          aria-controls="isiPanel isiMainPanelIND"
          aria-expanded={expandedMobileIndications}
          className={cn(
            'lds-button-clear-style',
            'lds-isi-content-banner',
            'indications',
            {
              expanded: expandedMobileIndications,
              attached: attached,
            }
          )}
          tabIndex={attached ? '-1' : null}
          onClick={toggleContentMobileIndications}
        >
          <span className="lds-isi-banner-wrapper pg-md-dn">
            { /* <!-- This non-visible span contains expanded-state conditional button text with action context for screen readers --> */}
            <span
              id={expandedMobileIndications ? 'isiMobileToggleA11yTextCollapseIND' : 'isiMobileToggleA11yTextExpandIND' }
              className="visually-hidden"
            >
              {expandedMobileIndications ? hiddenIsiIndicationsCollapseText : hiddenIsiIndicationsExpandText}
            </span>
            { /* <!-- This span holds the actual Indications heading content but is only displayed when expanded; the heading text is ignored by screen readers --> */}
            <span
              className="lds-isi-banner-column indications col col-11"
              aria-hidden="true"
            >
              <span className="lds-isi-banner-text indications">
                {indicationHeading}
              </span>
            </span>
            { /* <!-- This span holds a visual indicator icon of the ISI expansion state; it has no screen reader value --> */}
            <span
              className="lds-isi-banner-column toggle col-1"
              aria-hidden="true"
            >
              { !attached
                && <span
                  id="isiMobileToggleIconsIND"
                  className="lds-isi-toggle"
                >
                  <svg
                    id={expandedMobileIndications ? 'isiMobileToggleIconCollapseIND' : 'isiMobileToggleIconExpandIND' }
                    className={cn(
                      'lds-icon',
                      'inline',
                      `${expandedMobileIndications ? toggleIconCollapse : toggleIconExpand }`
                    )}
                    aria-hidden="true"
                  >
                  </svg>
                </span>
              }
            </span>
          </span>
        </button>
        { /* <!-- CONTENT COLUMN CONTENT CONTAINER: This is used to allow the content to scroll below the large breakpoint --> */}
        <div
          id="isiContentContainerIND"
          className={cn(
            'lds-isi-content-container',
            'indications',
            {
              expanded: expandedMobileIndications,
              attached: attached,
            }
          )}
          ref={ref}
        >
          { /* <!-- This wrapper adds the correct page layout gutter spacing BELOW the large breakpoint --> */}
          <div className="lds-isi-content-wrapper pg-sm-dn">
            <div className="lds-isi-content-row row justify-content-start">
              <h2
                id="isiContentHeadingIND"
                className="lds-isi-heading indications"
              >
                {indicationHeading}
              </h2>
              <div className="lds-isi-content indications col col-11 col-md-12">
                {indicationsContent}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});
