import { useEffect } from 'react';
import cn from 'classnames';

import { isiElementIds, getIsiElementById } from './util.js';

/**
 * Implements the ISI spacer element with a document.onscroll affix position poller
 *
 * If you don't need the poller, just inject the spacer DOM into index.jsx without this overhead
 */
export default function IsiSpacer({
  attached,
  setAttached,
  forceAttachment,
  setIsPreDetach,
  disableFriendlyMessages = false,
}) {
  useEffect(() => {
    const handleScroll = (e) => {
      setTimeout(() => {
        if (forceAttachment) {
          if (!attached) {
            e.preventDefault();
            setAttached(true);
            if (e.target !== document) e.target.focus();

            if (!disableFriendlyMessages) {
              // eslint-disable-next-line no-console
              console.warn('LDS ISI >>> The ISI is being forcefully attached to the page; this may violate regulatory policy in a production environment.');
            }
          }
        } else {
          const els = isiElementIds();
          const isiPanel = getIsiElementById(els.isiPanel);
          const isiSpacer = getIsiElementById(els.isiSpacer);

          const isiPanelTop = isiPanel.getBoundingClientRect().top;

          if (attached) {
            // Detach the ISI when the location of the top of the attached ISI is greater than the
            // absolute location of where on the viewport its top is located when detatched.
            const isiDetachedTopOffset = window.innerHeight - isiSpacer.getBoundingClientRect().height;
            if (isiPanelTop > isiDetachedTopOffset) {
              e.preventDefault();
              if (forceAttachment) return;
              setIsPreDetach(true);
              setAttached(false);
              // Wait a bit to remove the preDetach class
              // This prevents ugly animation "jitter" if you move up and down too slowly near the attach/detach point
              // However this prevents the "slide up" of the banner after detaching
              setTimeout(() => setIsPreDetach(false), 500);
              if (e.target !== document) e.target.focus();
            }
          } else {
            // Attach the ISI when the location of the ISI spacer top is less than or equal to the
            // absolute location of the top of the detached ISI.
            const isiSpacerTop = isiSpacer.getBoundingClientRect().top;
            if (isiSpacerTop <= isiPanelTop) {
              e.preventDefault();
              setAttached(true);
              if (e.target !== document) e.target.focus();
            }
          }
        }
      }, 50);
    };

    window.addEventListener('scroll', handleScroll);

    return () => window.removeEventListener('scroll', handleScroll);
  }, [attached, disableFriendlyMessages, forceAttachment, setAttached, setIsPreDetach]);

  return (
    <div
      id="isiSpacer"
      className={cn(
        'lds-isi-spacer',
        {
          attached,
        }
      )}
    ></div>
  );
}
