/**
 * The intersection observer does not trip when the page is scrolled programatically.
 * Whether by a specific feature calling a scrollTo event
 * Or the browser processing an anchor tag jump link
 * Or the browser scrolling to a focused element via keyboard navigation
 * This can cause the ISI to get stuck in an attached or detached state
 * For the ISI this is untenable because of the various strict regulations around
 * how, why and when it must be visible.
 *
 * This feature is being abandoned for now until it can be made more reliable.
 */

import { useEffect, useRef, useCallback } from 'react';

export default function IsiIntersectionObserver({ forceAttachment, setAttached, setIsPreDetach }) {
  const elmRef = useRef(null);

  const handleObserver = useCallback((entries) => {
    if (entries && Array.isArray(entries) && entries[0].isIntersecting) {
      setAttached(true);
    } else if (!entries[0].isIntersecting && entries[0].boundingClientRect.top > 0) {
      if (forceAttachment) return;

      setIsPreDetach(true);
      setAttached(false);
      // Wait a bit to remove the preDetach class
      // This prevents ugly animation "jitter" if you move up and down too slowly near the attach/detach point
      // However this prevents the "slide up" of the banner after detaching
      setTimeout(() => setIsPreDetach(false), 500);
    }
  }, [forceAttachment, setAttached, setIsPreDetach]);

  useEffect(() => {
    /* Get the height of the ISI indicated by the isiSpacer element so we know when to detach */
    /* We add 4px to the computed offset height to adjust for some Apple VO screen reader funk */
    let bottomIntersectMargin = 200;
    try {
      bottomIntersectMargin = document.getElementById('isiSpacer').offsetHeight + 4;
    } catch {
      // eslint-disable-next-line no-console
      console.warn(`LDS ISI >>> The attach/detach intersection observer could not get the offsetHeight for the isiMain or isiWrapper elements.
      The ISI script is falling back to the hard-coded default value of '${bottomIntersectMargin}px' so that the effect will happen but it may not be optimal.
      Is your ISI markup well formed and correct?`);
    }
    // DEBUG
    // console.log('LDS ISI >>> bottomIntersectMargin:', bottomIntersectMargin);
    const options = {
      root: null,
      rootMargin: `0px 0px -${bottomIntersectMargin}px 0px`,
      threshold: 1.0,
    };

    const observer = new IntersectionObserver(handleObserver, options);
    if (elmRef.current) observer.observe(elmRef.current);

    // return () => {
    //   if (elmRef.current) observer.unobserve(elmRef.current);
    // };
  }, [elmRef, handleObserver]);

  return (
    <div ref={elmRef} style={{ height: '1px', marginTop: '2px' }} id="isiIntersectionObserver"></div>
  );
}
