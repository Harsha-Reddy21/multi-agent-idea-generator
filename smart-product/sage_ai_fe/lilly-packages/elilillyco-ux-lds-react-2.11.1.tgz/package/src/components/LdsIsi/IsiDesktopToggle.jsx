import cn from 'classnames';

export default function IsiDesktopToggle({
  expandedDesktop,
  attached,
  hiddenIsiPanelCollapseText,
  hiddenIsiPanelExpandText,
  toggleIconCollapse = 'minus-circle',
  toggleIconExpand = 'plus-circle',
  toggleContent,
  isiHeading,
  indicationHeading,
}) {
  return (
    <button
      id="isiBanner"
      type="button"
      aria-controls="isiSection"
      onClick={toggleContent}
      aria-expanded={expandedDesktop}
      tabIndex={attached ? '-1' : null}
      className={cn(
        'lds-button-clear-style',
        'lds-isi-banner',
        {
          expanded: expandedDesktop,
          attached: attached,
        }
      )}
    >
      <span className="lds-isi-banner-wrapper pg justify-content-start">
        {/* For screen readers, one of the following contextual button text elements is conditionally added */}
        {/* It should say either "expand" or "collapse" the important safety information and indication(s) */}

        <span id="isiHiddenPanelCollapseText" className="visually-hidden">
          {expandedDesktop ? hiddenIsiPanelCollapseText : hiddenIsiPanelExpandText}
        </span>
        {/* This heading is conditionally shown only when detached banners are "expanded"; never read by screen readers */}
        <span
          className="lds-isi-banner-column isi col-11 col-md-6 order-md-1"
          aria-hidden="true"
        >
          <span
            className="lds-isi-banner-text isi"
            aria-hidden="true"
          >
            {isiHeading}
          </span>
        </span>
        { /* This heading is conditionally shown only when detached banners are "expanded"; never read by screen readers */}
        <span
          className="lds-isi-banner-column indications col-11 col-md-5 order-md-2"
          aria-hidden="true"
        >
          <span
            className="lds-isi-banner-text indications"
            aria-hidden="true"
          >
            {indicationHeading}
          </span>
        </span>
        <span className="lds-isi-banner-column toggle col-1 order-md-last">
          { /* Element is set to display:none when attached in setAttached function */}
          {!attached && <span
            id="isiBannerToggle"
            className="lds-isi-toggle"
            >
              <svg
                id={expandedDesktop ? 'isiBannerToggleIconCollapse' : 'isiBannerToggleIconExpand' }
                className={cn(
                  'lds-icon',
                  'inline',
                  `${expandedDesktop ? toggleIconCollapse : toggleIconExpand }`
                )}
                aria-hidden="true"
              >
              </svg>
          </span>}
        </span>
      </span>
    </button>
  );
}
