export const isiElementIds = () => {
  return {
    /* Utility Elements */
    isiIntersectionObserver: 'isiIntersectionObserver',
    isiSpacer: 'isiSpacer',
    /* Primary Containers */
    isiSection: 'isiSection',
    isiPanel: 'isiPanel',
    /* Banner Button (Desktop) */
    isiBanner: 'isiBanner',
    isiBannerToggleIcons: 'isiBannerToggleIcons',
    isiBannerToggleIconCollapse: 'isiBannerToggleIconCollapse',
    isiBannerToggleIconExpand: 'isiBannerToggleIconExpand',
    isiBannerA11yTextCollapse: 'isiBannerA11yTextCollapse',
    isiBannerA11yTextExpand: 'isiBannerA11yTextExpand',
    /* Main Content Container */
    isiMain: 'isiMain',
    isiMainWrapper: 'isiMainWrapper',
    /* ISI Content */
    isiMainColumnISI: 'isiMainColumnISI',
    isiMainPanelISI: 'isiMainPanelISI',
    isiMobileToggleISI: 'isiMobileToggleISI',
    isiMobileToggleIconsISI: 'isiMobileToggleIconsISI',
    isiMobileToggleIconCollapseISI: 'isiMobileToggleIconCollapseISI',
    isiMobileToggleIconExpandISI: 'isiMobileToggleIconExpandISI',
    isiMobileToggleA11yTextCollapseISI: 'isiMobileToggleA11yTextCollapseISI',
    isiMobileToggleA11yTextExpandISI: 'isiMobileToggleA11yTextExpandISI',
    isiContentContainerISI: 'isiContentContainerISI',
    /* INDICATION Content */
    isiMainColumnIND: 'isiMainColumnIND',
    isiMainPanelIND: 'isiMainPanelIND',
    isiMobileToggleIND: 'isiMobileToggleIND',
    isiMobileToggleIconsIND: 'isiMobileToggleIconsIND',
    isiMobileToggleIconCollapseIND: 'isiMobileToggleIconCollapseIND',
    isiMobileToggleIconExpandIND: 'isiMobileToggleIconExpandIND',
    isiMobileToggleA11yTextCollapseIND: 'isiMobileToggleA11yTextCollapseIND',
    isiMobileToggleA11yTextExpandIND: 'isiMobileToggleA11yTextExpandIND',
    isiContentContainerIND: 'isiContentContainerIND',
  };
};

export const getIsiElementById = (elementId) => {
  try {
    const element = document.getElementById(elementId);
    if (!element) {
      // eslint-disable-next-line no-console
      console.error(`LDS ISI >>> [×] Element ID '${elementId}' NOT found, ISI may not function correctly, document.getElementById returned:`, element);
      return null;
    }

    // DEBUG -- Enable to make sure you're getting the DOM element you think you are; Disable in production
    // console.log(`ISI >>> [√] Element ID '${elementId}' found:`, element);

    return element;
  } catch (ex) {
    // eslint-disable-next-line no-console
    console.error(`LDS ISI >>> A fatal exception occurred attempting to get the Element ID '${elementId}': ${ex.message}`);
    return null;
  }
};
