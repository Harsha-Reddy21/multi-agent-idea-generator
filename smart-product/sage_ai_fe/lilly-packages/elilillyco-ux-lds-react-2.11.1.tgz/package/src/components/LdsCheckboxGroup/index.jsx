import { useId } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsValidationError from '../LdsValidationError/index.jsx';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsCheckboxGroupProps
 * @property {any} label - Text to display as label for checkbox group
 * @property {React.ReactNode} children - Children
 * @property {boolean} [checked] - Property to set checked state on checkbox
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {boolean} [error] - Property to set error state on checkbox
 * @property {string} [errorMessage] - Error message to display
 * @property {boolean} [mixed] - Property to set mixed state on checkbox
 * @property {function} [onChange] - Function to handle change event
 * @property {boolean} [required] - HTML input required property
 * @property {boolean} [selectAll] - Property to set select all checkbox
 * @property {string} [selectAllText] - Text to display for select all checkbox
 * @property {string} [srRequiredText] - Text to display for screen readers when checkbox is required
 * @property {string} [ariaControls] - Value for `aria-controls` property
 * @property {boolean} [indent] - indents checkboxes underneath the group label
 * @property {string} [densityClass] - adjusts density of checkbox group  by adjusting the padding between checkboxes. Accepts either 'small' or 'medium'
 */
/**
 * LdsCheckboxGroup component
 * @param {LdsCheckboxGroupProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsCheckboxGroup component
 */
export default function LdsCheckboxGroup({
  label,
  children,
  checked = null,
  className,
  error = false,
  errorMessage = '',
  mixed = null,
  onChange = () => {},
  required = false,
  selectAll = false,
  selectAllText = 'Select All',
  srRequiredText = 'This field is required',
  ariaControls = null,
  indent = false,
  densityClass = 'small',
  ...rest
}) {
  const validationId = useId();
  /*
    Checked state sets the aria-checked property.
    This is set up to follow this convention:
    https://www.w3.org/WAI/ARIA/apg/patterns/checkbox/examples/checkbox-mixed/

    State is determined by the following:
     - If all checkboxes are checked, checkedState is true
     - If no checkboxes are checked, checkedState is false
     - If some checkboxes are checked, checkedState is mixed

    User will be responsible for setting the 'mixed' and 'checked' props
  */
  let checkedState = 'false';
  if (checked) checkedState = 'true';
  if (mixed) checkedState = 'mixed';

  const handleSelectAllKeyDown = (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      onChange({ checked, mixed });
    }
  };

  return (
    <fieldset
      className={cn(
        'lds-checkbox-group',
        {
          indent: indent || selectAll,
          error,
        },
        densityClass,
        className
      )}
      aria-invalid={error ? 'true' : null}
      aria-describedby={error ? validationId : null}
      {...rest}
    >
      <legend>
        {label}
        {required && <span className="sr-only">{srRequiredText}</span>}
      </legend>

      {
        error && errorMessage
        && <LdsValidationError id={validationId}>{errorMessage}</LdsValidationError>
      }

      {
        selectAll
        && <div
          className={cn(
            'select-all',
            {
              'checked-state-checked': checkedState === 'true',
              'checked-state-unchecked': checkedState === 'false',
              'checked-state-mixed': checkedState === 'mixed',
              'checked-state-error': error || null,
            }
          )}
          role="checkbox"
          aria-checked={checkedState}
          tabIndex="0"
          onClick={() => onChange({ checked, mixed })}
          aria-controls={ariaControls}
          onKeyDown={handleSelectAllKeyDown}
        >
          <div className="box" aria-hidden="true" />
          {selectAllText}
        </div>
      }
      {children}
    </fieldset>
  );
}

LdsCheckboxGroup.propTypes = {
  label: PropTypes.any.isRequired,
  children: PropTypes.node.isRequired,
  checked: (props, propName, componentName) => { // eslint-disable-line
    if (props.selectAll === true && (props[propName] === null || props[propName] === undefined)) {
      return new Error(`LDS ERROR >> Invalid prop "${propName}" supplied to ${componentName}.
        Prop "${propName}" is a required boolean when "selectAll" is used. This prop is used to show the state of the select all box.
      `);
    }
  },
  className: PropTypes.string,
  error: PropTypes.bool,
  errorMessage: PropTypes.string,
  mixed: PropTypes.bool,
  onChange: (props, propName, componentName) => { // eslint-disable-line
    if (props.selectAll === true && (!props[propName] || typeof (props[propName]) !== 'function')) {
      return new Error(`LDS ERROR >> Invalid prop "${propName}" supplied to ${componentName}.
        Prop "${propName}" is a required function when "selectAll" is used. This prop is used to set the state of the select all box when clicked.
      `);
    }
  },
  required: PropTypes.bool,
  selectAll: PropTypes.bool,
  selectAllText: PropTypes.string,
  srRequiredText: PropTypes.string,
  ariaControls: (props, propName, componentName) => { // eslint-disable-line
    if (props.selectAll === true && !props[propName]) {
      return new Error(`LDS ERROR >> Invalid prop "${propName}" supplied to ${componentName}.
        Prop "${propName}" is a required string when "selectAll" is used. Pass a string of space separated ids of the checkboxes in the group.
      `);
    }
  },
  indent: PropTypes.bool,
  densityClass: PropTypes.oneOf(['small', 'medium']),
};
