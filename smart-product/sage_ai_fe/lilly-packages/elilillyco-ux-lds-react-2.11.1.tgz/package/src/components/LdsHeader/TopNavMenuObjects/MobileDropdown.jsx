import cn from 'classnames';
import {
  useEffect,
  useId,
  useRef
} from 'react';

import LdsIcon from '../../LdsIcon/index.jsx';
import MobileExpandPanel from '../../LdsMobileExpandPanel/index.jsx';

import getFocusableElements from '../../../util/getFocusableElements.js';
import useIsMobile from '../../../hooks/useIsMobile.js';

export default function MobileDropdown({
  isOpen,
  handleClick,
  label,
  children,
}) {
  const mobileListRef = useRef(null);
  const isMobile = useIsMobile(992);
  const dropdownId = useId();

  const focusFirstMenuItem = () => {
    if (!mobileListRef.current) return;

    const focusableElements = getFocusableElements(mobileListRef.current);
    if (!focusableElements.length) return;

    focusableElements[0].focus();
  };

  // In mobile - focus the first item in the dropdown when it opens
  useEffect(() => {
    if (isOpen && isMobile) focusFirstMenuItem();
  }, [isOpen, isMobile]);

  return (
    <MobileExpandPanel
      expanded={isOpen}
      className="header-dropdown-mobile"
      inert={isOpen ? null : ''}
      aria-hidden={!isOpen}
    >
      <button
        className="lds-button-base menu-button"
        aria-expanded={isOpen}
        onClick={handleClick}
        aria-controls={dropdownId}
      >
        <LdsIcon decorative name="caret-left" className="dropdown-close-arrow" />
        {label}
      </button>

      <div
        role="region"
        className={cn(
          'lds-mobile-dropdown-list',
          'mobile',
          {
            expanded: isOpen,
          }
        )}
        id={dropdownId}
        ref={mobileListRef}
      >
        <ul className="">
          {children}
        </ul>
      </div>
    </MobileExpandPanel>
  );
}
