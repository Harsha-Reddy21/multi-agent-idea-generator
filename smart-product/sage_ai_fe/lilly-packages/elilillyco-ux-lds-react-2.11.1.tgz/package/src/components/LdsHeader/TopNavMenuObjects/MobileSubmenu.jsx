import cn from 'classnames';
import {
  useContext,
  useId,
  useState,
  useEffect
} from 'react';

import { LdsHeaderContext } from '../LdsHeaderProvider.jsx';
import LdsIcon from '../../LdsIcon/index.jsx';

export default function MobileSubmenu({
  icon,
  label,
  children,
  isActive,
  className,
}) {
  const subMenuId = useId();
  const labelId = useId();

  const {
    openMobileMenuId,
    setOpenMobileMenuId,
  } = useContext(LdsHeaderContext);

  const [isOpen, setIsOpen] = useState(false);

  // Close other menus if they do not contain this one
  useEffect(() => {
    // Not open or hover open not enabled - do nothing
    if (!isOpen) return;
    // The open flyout is this one - do nothing
    if (openMobileMenuId === subMenuId) return;

    const thisFlyoutEl = document.querySelector(`#${CSS.escape(subMenuId)}`);
    const openChild = thisFlyoutEl.querySelector(`#${CSS.escape(openMobileMenuId)}`);

    if (!openChild) setIsOpen(false);
  }, [isOpen, subMenuId, openMobileMenuId]);

  const handleMobileClick = () => {
    if (isOpen) {
      setIsOpen(false);
    } else {
      setIsOpen(true);
      setOpenMobileMenuId(subMenuId);
    }
  };

  return (
    <>
      <button
        className={cn(
          'lds-button-base',
          'mobile-submenu-button',
          className,
          {
            open: isOpen,
            active: isActive,
            // In mobile only the most recently opened menu gets the red bg applied
            'red-bg': openMobileMenuId === subMenuId,
          }
        )}
        aria-expanded={isOpen}
        onClick={handleMobileClick}
        aria-controls={subMenuId}
        id={labelId}
      >
        {icon && <LdsIcon inline name={icon} className="dropdown-icon" />}
        {label}
        <LdsIcon name="caret-down mobile-submenu-caret will-rotate" />
      </button>

      <div
        role="region"
        className={cn(
          'mobile-submenu',
          {
            expanded: isOpen,
            // In mobile only the most recently opened flyout gets the red bg applied
            'red-bg': openMobileMenuId === subMenuId,
          }
        )}
        id={subMenuId}
        inert={isOpen ? null : ''}
        aria-hidden={!isOpen}
      >
        <ul
          aria-describedby={labelId}
          className="inner-expandable ">
          {children}
        </ul>
      </div>
    </>
  );
}
