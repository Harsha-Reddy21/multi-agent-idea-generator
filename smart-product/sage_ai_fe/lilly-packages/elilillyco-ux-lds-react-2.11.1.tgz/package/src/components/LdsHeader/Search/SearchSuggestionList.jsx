import { useEffect, useState } from 'react';

import LdsDivider from '../../LdsDivider/index.jsx';
import SearchSuggestion from './SearchSuggestion.jsx';
import LdsLoadingSpinner from '../../LdsLoadingSpinner/index.jsx';
import NoResultsMsg from './NoResultsMsg.jsx';
import useIsMobile from '../../../hooks/useIsMobile.js';

export default function SearchSuggestionList({
  searchSuggestions,
  searchCustomResult,
  searchNoResultsText,
  searchAnotherSearchText,
  searchTerm,
  searchLoading,
  isSearchOpen,
  currentFocusPosition,
  searchOnSuggestionClick,
}) {
  const isMobile = useIsMobile(992);
  const [showNoResults, setShowNoResults] = useState(false);
  const [showLoading, setShowLoading] = useState(false);
  const [maxSearchHeight, setMaxSearchHeight] = useState('100vh');

  const hasSearchSuggestions = searchSuggestions
    && Array.isArray(searchSuggestions)
    && searchSuggestions.length > 0;

  useEffect(() => {
    if (!searchTerm) {
      setShowNoResults(false);
      setShowLoading(false);
    } else if (searchTerm && !hasSearchSuggestions && !searchLoading) {
      // Only show no results message if there are no results and it is done loading
      setShowNoResults(true);
      setShowLoading(false);
    } else if (searchTerm && searchLoading) {
      setShowNoResults(false);
      setShowLoading(true);
    } else if (searchTerm && hasSearchSuggestions) {
      setShowNoResults(false);
      setShowLoading(false);
    }
  }, [hasSearchSuggestions, searchTerm, searchLoading]);

  /*
    Need to calculate the max-height of the scroll container every time the modal opens.
    Max height should be 500px in desktop OR 100vh - rest of elem height. Whichever is smaller

    In mobile max height should just be 100vh - rest of elems.
  */
  useEffect(() => {
    // search controls height can be a max of 72px if 2 rows - less if only one line
    const searchControls = document.querySelector('.search-controls');
    const header = document.querySelector('#header');
    const divider = document.querySelector('.search-divider');

    const headerHeight = header ? header.offsetHeight : 0;
    const searchControlsHeight = searchControls ? searchControls.offsetHeight : 0;
    const dividerHeight = divider ? divider.offsetHeight : 0;

    const containerPaddings = 80; // padding of whole modal + search results div 80px or 5rem
    const mobileContainerBottomMargin = 40; // 40px or 2.5rem bottom margin in mobile
    // Total height of all the elements above the search scroll container
    const mobileTotalHeight = headerHeight
      + searchControlsHeight
      + dividerHeight
      + containerPaddings
      + mobileContainerBottomMargin;

    const desktopTotalHeight = 500
      - searchControlsHeight
      - dividerHeight
      - containerPaddings;

    if (isMobile) {
      // In mobile max height can be the whole screen
      const calcStr = `calc(100vh - ${mobileTotalHeight}px)`;
      setMaxSearchHeight(calcStr);
    } else {
      setMaxSearchHeight(`${desktopTotalHeight}px`);
    }
  }, [searchTerm, isMobile, isSearchOpen]);

  if (!hasSearchSuggestions && !searchTerm) return '';

  const RenderSearchResult = () => {
    if (!hasSearchSuggestions) return '';

    if (searchCustomResult) {
      return (
        <div
          role="listbox"
        >
          {searchSuggestions.map((result, idx) => searchCustomResult({
            ...result,
            currentFocusPosition,
            focusIndex: idx,
          }))}
        </div>
      );
    }

    return (
      <div
        role="listbox"
      >
        {searchSuggestions.map((result, idx) => (
          <SearchSuggestion
            key={result.title}
            suggestion={result}
            searchTerm={searchTerm}
            currentFocusPosition={currentFocusPosition}
            focusIndex={idx}
            onClick={searchOnSuggestionClick}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="search-results">
      <div className="search-divider">
        <LdsDivider type="secondary" />
      </div>

      <div
        className="search-results-scroll-container"
        style={{ maxHeight: maxSearchHeight }}
      >
        <RenderSearchResult />

        <NoResultsMsg
          show={showNoResults}
          searchTerm={searchTerm}
          searchNoResultsText={searchNoResultsText}
          searchAnotherSearchText={searchAnotherSearchText}
        />
      </div>

      { showLoading && <div className="loading-container"><LdsLoadingSpinner size={72} /></div> }
    </div>
  );
}
