import cn from 'classnames';

import UtilityLogo from './Logo.jsx';

export default function UtilityMenuMobile({
  languageSelector,
  contactLilly,
  showUtilityLogo,
  utilityMenuLinks = [],
  customLinkItems = [],
  customLinkItemsPosition = 'after',
}) {
  const hasCustomLinkItems = customLinkItems && Array.isArray(customLinkItems) && customLinkItems.length > 0;

  const MenuItem = ({ className = '', children, onClick = null }) => {
    return (
      <li
        tabIndex="-1"
        className="lds-header-utility-menu-item-mobile"
      >
        <div
          className={cn(
            'lds-header-menu-item-content',
            className
          )}
          onClick={onClick}
        >
          {children}
        </div>
      </li>
    );
  };

  const LinkList = ({ links }) => (
    links.map((link, index) => (<MenuItem key={index} >{link}</MenuItem>))
  );

  return (
    <nav
      aria-label="Global"
      className="lds-header-utility-mobile"
    >
      <ul className="lds-header-utility-menu-mobile">
        {contactLilly
          && <MenuItem className="selector">
            {contactLilly}
          </MenuItem>
        }
        { languageSelector
          && <MenuItem className="selector">
            {languageSelector}
          </MenuItem>
        }

        { hasCustomLinkItems && customLinkItemsPosition === 'before'
          && <LinkList links={customLinkItems} />
        }

        {
          (utilityMenuLinks && utilityMenuLinks.length > 0)
          && <LinkList links={utilityMenuLinks} />
        }

        { hasCustomLinkItems && customLinkItemsPosition === 'after'
          && <LinkList links={customLinkItems} />
        }
      </ul>

      {/* Logo */}
      { showUtilityLogo
        && <UtilityLogo />
      }
    </nav>
  );
}
