// JSDoc type definitions
/**
 * @typedef {Object} LdsUtilityMenuLinkProps
 * @property {string} href
 * @property {string} [ariaLabel]
 * @property {string} [className]
 * @property {React.ReactNode} children
 * @property {string} [target]
 */
/**
 * @param {LdsUtilityMenuLinkProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function MenuLink({
  href,
  ariaLabel,
  className,
  children,
  target = '_self',
  ...rest
}) {
  return (
    <div className="lds-header-menu-item-link">
      <a
        tabIndex="0"
        className={className}
        aria-label={ariaLabel}
        href={href}
        target={target}
        {...rest}
      >
        {children}
      </a>
    </div>
  );
}
