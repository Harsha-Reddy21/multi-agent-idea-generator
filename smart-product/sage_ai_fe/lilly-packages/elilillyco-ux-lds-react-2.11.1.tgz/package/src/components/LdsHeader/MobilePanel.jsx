import { useContext, useEffect, useRef } from 'react';

import { LdsHeaderContext } from './LdsHeaderProvider.jsx';

import UtilityMenuMobile from './UtilityMenu/Mobile.jsx';
import LdsIcon from '../LdsIcon/index.jsx';
import LdsLillyLogo from '../LdsLillyLogo/index.jsx';
import handleTabAway from '../../util/handleTabAway.js';
import getFocusableElements from '../../util/getFocusableElements.js';

export default function MobilePanel({
  // Utility menu props
  showUtilityMenu,
  showUtilityLogo,
  contactLilly,
  languageSelector,
  utilityMenuLinks,
  utilityMenuAriaLabel,
  utilityMenuCustomLinkItems,
  utilityMenuCustomLinkItemsPosition,
  // Logo & hamburglar
  customLogo,
  lillyLogo,
  labelCloseMenu,
  //
  topNavAriaLabel,
  isMobileMenuOpen,
  toggleMobileMenu,
  children,
}) {
  const closeMenuButtonRef = useRef(null);
  const topBarRef = useRef(null);
  const menuNavRef = useRef(null);

  const {
    mobileTopBarHeight,
  } = useContext(LdsHeaderContext);

  const handleKeyDown = (e) => {
    // focus the close menu button when the user tries to tab outside of the mobile menu
    const callback = (firstOrLast) => {
      e.preventDefault();

      if (firstOrLast === 'first') {
        // focus last element
        const focusableElements = getFocusableElements(menuNavRef.current);
        const lastElement = focusableElements[focusableElements.length - 1];
        if (lastElement) {
          lastElement.focus();
        }
      } else {
        closeMenuButtonRef.current.focus();
      }
    };
    return handleTabAway(e, menuNavRef, callback);
  };

  // if "isMobileMenuOpen" is set to "true", focus the closeMenuButtonRef element
  useEffect(() => {
    if (isMobileMenuOpen && closeMenuButtonRef && closeMenuButtonRef.current) {
      closeMenuButtonRef.current.focus();
    }
  }, [closeMenuButtonRef, isMobileMenuOpen]);

  return (
    <div
      className="lds-header-menu-container  header-mobile"
      inert={!isMobileMenuOpen ? '' : null}
    >
      <nav
        aria-label={topNavAriaLabel || 'Primary'}
        className={`lds-header-menu-wrapper ${
          isMobileMenuOpen ? 'toggle-mobile-menu' : ''
        }`}
        onKeyDown={isMobileMenuOpen ? handleKeyDown : undefined}
        ref={menuNavRef}
      >
        {/* Top bar with logo and close button */}
        <div className="header-mobile-panel-bar lds-header-logo-wrapper" ref={topBarRef}>
          <button
            ref={closeMenuButtonRef}
            id="lds-close-menu-button"
            data-testid="lds-close-menu-button"
            onClick={toggleMobileMenu}
            type="button"
            className="lds-button-base lds-header-toggle toggleMobileMenu"
          >
            <LdsIcon decorative name="X" inline className="lds-hamburger-menu-icon" />
            <span className="lds-header-toggle-text">{labelCloseMenu || 'Close'}</span>
          </button>

          {customLogo || <LdsLillyLogo {...lillyLogo} />}
        </div>

        {/* Scroll container with nav items */}
        <div className="lds-header-menu-scroll-container" style={{ height: `calc(100vh - ${mobileTopBarHeight}px)` }}>
          <ul
            className="lds-header-menu lds-header-menu-primary"
          >

            {children}

            { showUtilityMenu
              && <UtilityMenuMobile
                showUtilityLogo={showUtilityLogo}
                contactLilly={contactLilly}
                languageSelector={languageSelector}
                utilityMenuLinks={utilityMenuLinks}
                utilityMenuAriaLabel={utilityMenuAriaLabel}
                customLinkItems={utilityMenuCustomLinkItems}
                customLinkItemsPosition={utilityMenuCustomLinkItemsPosition}
                toggleMobileMenu={toggleMobileMenu}
              />
            }
          </ul>
        </div>
      </nav>
    </div>
  );
}
