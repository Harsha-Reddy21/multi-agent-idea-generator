import { useEffect } from 'react';

export default function useStopTransitionsOnResize() {
  useEffect(() => {
    const classes = document.body.classList;
    let timer = 0;

    function handleResize() {
      if (timer) {
        clearTimeout(timer);
      } else {
        classes.add('stop-transitions');
      }

      timer = setTimeout(() => {
        classes.remove('stop-transitions');
        timer = null;
      }, 100);
    }

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (timer) {
        clearTimeout(timer);
      }
    };
  }, []);
}
