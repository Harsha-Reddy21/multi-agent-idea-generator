import cn from 'classnames';
import PropTypes from 'prop-types';
import {
  useContext,
  useState,
  useId,
  useRef,
  useEffect,
  useCallback
} from 'react';

import LdsIcon from '../../LdsIcon/index.jsx';
import { LdsHeaderContext } from '../LdsHeaderProvider.jsx';
import useClickOutside from '../../../hooks/useClickOutside.js';
import MobileSubmenu from './MobileSubmenu.jsx';
import useIsActiveRoute from './useIsActiveRoute.jsx';
import handleTabAway from '../../../util/handleTabAway.js';

// JSDoc type definitions
/**
 * @typedef LdsFlyoutProps
 * @property {React.ReactNode} children - The children of the component
 * @property {array} [basePaths] - basePath urls for making the dropdown active
 * @property {boolean} [hoverOpen] - Whether the dropdown should open on hover
 * @property {string} [icon] - Icon name to show before label
 * @property {string} [openPositionOverride] - Optional override to force the flyout to open left or right
 * @property {number} [hoverDelay] - The delay in milliseconds before the flyout opens on hover
 */
/**
 * LdsFlyoutProps component
 * @param {LdsFlyoutProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function Flyout({
  icon,
  children,
  label,
  hoverOpen = false,
  openPositionOverride = null,
  basePaths = [],
  hoverDelay = 500,
  ...rest
}) {
  const {
    openFlyoutId,
    setOpenFlyoutId,
    openDropdownId,
  } = useContext(LdsHeaderContext);
  const flyoutId = useId();

  const [isOpen, setIsOpen] = useState(false);
  const [menuPosition, setMenuPosition] = useState('right');
  const [isHovering, setIsHovering] = useState(false);

  const isActive = useIsActiveRoute(basePaths);

  // Track if user clicked the flyout. Used for hover open so does not open back up
  const [isClicked, setIsClicked] = useState(false);

  const flyoutListRef = useRef(null);
  const flyoutBtnRef = useClickOutside(() => setIsOpen(false));

  const handleClick = () => {
    setIsClicked(true);
    if (isOpen) {
      setIsOpen(false);
    } else {
      openFlyout();
    }
  };

  const openFlyout = useCallback(() => {
    /*
      Flyout open direction logic:
      1. By default flyouts open to the right.
      2. Check the direction the last flyout opened. Open in the same direction if set. This helps to prevent
        overlap by going right left right.
      3. Check to see if the flyout would go off the edge of the screen when opened. If it will - open in the other direction
      4. See if the user has set a manual override. Use the override
    */
    const flyoutRect = flyoutListRef.current.getBoundingClientRect();
    const flyoutWidth = flyoutListRef.current.offsetWidth;
    const screenWidth = document.body.clientWidth;

    const wasPreviousLeft = !!document.querySelector(`.flyout-list.left #${CSS.escape(flyoutId)}`);
    let pos = wasPreviousLeft ? 'left' : 'right';
    const doesFlyoutOverlapRightEdge = (flyoutRect.right + flyoutWidth) > screenWidth;
    if (doesFlyoutOverlapRightEdge) {
      pos = 'left';
    }

    // Hard coded override prop from user
    if (openPositionOverride) pos = openPositionOverride;

    setMenuPosition(pos);
    setIsOpen(true);
    setOpenFlyoutId(flyoutId);
  }, [flyoutId, openPositionOverride, setOpenFlyoutId]);

  useEffect(() => {
    /*
      When dropdowns open we need to check to see if it is a dropdown that does not contain
      this flyout so we can close the flyout. This happens when using the hoverOpen option
    */
    if (!openDropdownId) {
      setIsClicked(false);
      return;
    }

    const flyoutEl = document.querySelector(`#${CSS.escape(openDropdownId)} #${CSS.escape(flyoutId)}`);
    if (!flyoutEl) {
      setIsOpen(false);
      setIsClicked(false);
    }
  }, [openDropdownId, flyoutId]);

  /* When hoverOpen is enabled we need to check when a flyout opens.
    If a flyout opens that is not a child of this flyout we need to close this one.
  */
  useEffect(() => {
    // Not open or hover open not enabled - do nothing
    if (!isOpen || !hoverOpen) return;
    // The open flyout is this one - do nothing
    if (openFlyoutId === flyoutId) return;

    const thisFlyoutEl = document.querySelector(`#${CSS.escape(flyoutId)}`);
    const openChild = thisFlyoutEl.querySelector(`#${CSS.escape(openFlyoutId)}`);

    if (!openChild) setIsOpen(false);
  }, [isOpen, flyoutId, hoverOpen, openFlyoutId]);

  /*
    Hover open logic.
    If hoverOpen is set we need to delay the opening incase the user is just passing over.
    Do not open if the user hovers away, or the user has previously clicked on the button
    to open or close the menu.
  */
  useEffect(() => {
    let timeout;
    const cleanup = () => clearTimeout(timeout);

    if (!hoverOpen || isOpen || isClicked) return cleanup;

    if (isHovering) {
      timeout = setTimeout(() => {
        openFlyout();
      }, [hoverDelay]);
    }

    return cleanup;
  }, [
    hoverOpen,
    isOpen,
    isClicked,
    isHovering,
    hoverDelay,
    openFlyout,
  ]);

  const handleKeyDown = (e) => {
    const callback = () => setIsOpen(false);
    return handleTabAway(e, flyoutListRef, callback);
  };

  return (
    <li
      ref={flyoutBtnRef}
      className={cn(
        'dropdown-item',
        'flyout',
        {
          active: isActive,
          open: isOpen,
        }
      )}
      {...rest}
    >
      <button
        className={cn(
          'lds-button-base',
          'flyout-button',
          {
            open: isOpen,
            active: isActive,
          }
        )}
        aria-expanded={isOpen}
        onClick={handleClick}
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={() => setIsHovering(false)}
        aria-controls={flyoutId}
      >
        {icon && <LdsIcon inline name={icon} className="dropdown-icon" />}
        {label}
        <LdsIcon name="caret-right flyout-caret" />
      </button>

      {/* Desktop only flyout menu */}
      <div
        ref={flyoutListRef}
        role="region"
        aria-hidden={!isOpen}
        className={cn(
          'lds-header-dropdown-list',
          'flyout-list',
          {
            expanded: isOpen,
            left: menuPosition === 'left',
            right: menuPosition === 'right',
          }
        )}
        id={flyoutId}
        onKeyDown={handleKeyDown}
      >
        <ul className="">
          {children}
        </ul>
      </div>

      <MobileSubmenu
        label={label}
        icon={icon}
        isActive={isActive}
      >
        {children}
      </MobileSubmenu>
    </li>
  );
}

Flyout.propTypes = {
  basePaths: PropTypes.arrayOf(PropTypes.string).isRequired,
  hoverOpen: PropTypes.bool,
  label: PropTypes.any.isRequired,
  openPositionOverride: PropTypes.oneOf(['left', 'right']),
  icon: PropTypes.string,
  hoverDelay: PropTypes.number,
};
