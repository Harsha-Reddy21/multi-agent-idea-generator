import LdsDivider from '../../LdsDivider/index.jsx';

export default function Divider() {
  return (
    <li className="top-nav-item divider">
      <LdsDivider orientation="vertical" type="secondary" />
    </li>
  );
}
