import {
  useContext,
  useEffect,
  useRef,
  useState
} from 'react';
import cn from 'classnames';

import LdsIcon from '../../LdsIcon/index.jsx';
import MegaMenuModal from '../MegaMenuModal.jsx';
import SearchSuggestionList from './SearchSuggestionList.jsx';

import { LdsHeaderContext } from '../LdsHeaderProvider.jsx';
import { SideNavContext } from '../../LdsSideNav/SideNavContext.jsx';
import useClickOutside from '../../../hooks/useClickOutside.js';
import handleTabAway from '../../../util/handleTabAway.js';
import getFocusableElements from '../../../util/getFocusableElements.js';

export default function SearchModal({
  searchInputPlaceholder = 'Search',
  searchTerm,
  setSearchTerm,
  searchCustomResult,
  searchSuggestions = [],
  searchNoResultsText = 'No results for',
  searchAnotherSearchText = 'Please try another search term or keyword',
  searchLoading = false,
  searchClearBtnAriaLabel = 'Clear search term',
  searchSubmitBtnAriaLabel = 'Submit search',
  searchInputAriaDescription = 'Suggestions will update as you type',
  searchInputAriaLabel = 'Search the site',
  searchOnBtnClick = () => {},
  searchOnSuggestionClick = () => {},
  isSideNav = false,
}) {
  const inputRef = useRef(null);
  const hiddenRef = useRef(null);
  const menuContentRef = useRef(null);
  const [inputRows, setInputRows] = useState(1);

  // Manages focus index inside the search suggestion list
  const [currentFocusPosition, setCurrentFocusPosition] = useState(null);

  const contextObj = isSideNav ? SideNavContext : LdsHeaderContext;
  const {
    isSearchOpen,
    setIsSearchOpen,
  } = useContext(contextObj);

  useEffect(() => {
    if (isSearchOpen) {
      menuContentRef.current.scrollTop = 0;
      inputRef.current.focus();
    }
  }, [isSearchOpen]);

  /*
    Use a hidden input with the same text content as the visible text area.
    If the scroll width of the hidden input becomes greater than the width of the input
    increase the rows of the text area to 2

    This is in place to solve the magic height adjustment based on wrapped text as provided by design
  */
  useEffect(() => {
    if (!hiddenRef.current) return;

    if (hiddenRef.current.scrollWidth > hiddenRef.current.offsetWidth) {
      setInputRows(2);
    } else {
      setInputRows(1);
    }
  }, [searchTerm]);

  const megaRef = useClickOutside(() => {
    if (isSearchOpen) setIsSearchOpen(false);
  }, ['.search-btn', '.mobile-search-button']);

  const handleKeyDown = (e) => {
    const callback = (firstOrLast) => {
      e.preventDefault();
      /*
        Since the modal is outside of utility nav we need to
        set focus appropriatley when tabbing away from the modal
      */

      // Focus on the search button in utility nav
      if (firstOrLast === 'first') {
        const utilSearchBtn = document.querySelector('.utility-nav-search button');
        if (utilSearchBtn) utilSearchBtn.focus();
      }

      // focus on next item after the utility search button
      if (firstOrLast === 'last') {
        const headerMenus = document.querySelector('.header-menus-container');
        const focusable = getFocusableElements(headerMenus);
        for (let i = 0; i < focusable.length; i += 1) {
          const elem = focusable[i];
          if (elem?.classList.contains('search-btn')) {
            const nextElem = focusable[i + 1];
            nextElem.focus();
            break;
          }
        }
      }
      setIsSearchOpen(false);
      setCurrentFocusPosition(null);
    };
    return handleTabAway(e, megaRef, callback);
  };

  useEffect(() => {
    if (currentFocusPosition === null) return;

    // if using arrow keys to navigate we need to scroll to the suggestion if it is offscreen.
    // block: end will make this only scroll if it is not currently in view
    const results = menuContentRef.current.querySelectorAll('.search-anchor');
    results[currentFocusPosition].scrollIntoView({ block: 'end' });
  }, [currentFocusPosition]);

  const handleKeyboardNavigation = (e) => {
    if (e.key === 'ArrowUp') {
      if (currentFocusPosition === null) {
        // nothing has been focused yet - do nothing
        return;
      }

      if (currentFocusPosition === 0) {
        // first result is focused - go to the end
        setCurrentFocusPosition(searchSuggestions.length - 1);
        return;
      }

      // focus next result up
      const nextIndex = currentFocusPosition - 1;
      setCurrentFocusPosition(nextIndex);
    }

    if (e.key === 'ArrowDown') {
      if (currentFocusPosition === null) {
        // nothing has been focused yet - focus first result
        setCurrentFocusPosition(0);
        return;
      }

      if (currentFocusPosition === searchSuggestions.length - 1) {
        // last result is focused - go back to the top
        setCurrentFocusPosition(0);
        return;
      }

      // focus next result down
      setCurrentFocusPosition(currentFocusPosition + 1);
    }

    if (e.key === 'Escape') {
      // close search list
      setIsSearchOpen(false);
      setCurrentFocusPosition(null);
    }
  };

  const handleInputKeyDown = (e) => {
    const isEnter = e.key === 'Enter';
    const isSpace = e.key === ' ';

    if (e.key === 'Enter' && currentFocusPosition === null) {
      // Enter is clicked in search bar without any focus on suggestion - click the search button
      e.preventDefault();
      searchOnBtnClick();
    } else if ((isEnter || isSpace) && currentFocusPosition !== null) {
      // Enter or Space is clicked on a focused suggestion - click the suggestion
      e.preventDefault();
      searchOnSuggestionClick(searchSuggestions[currentFocusPosition]);
    }

    handleKeyboardNavigation(e);
  };

  const handleClear = () => {
    setCurrentFocusPosition(null);
    setSearchTerm('');
  };

  return (
    <MegaMenuModal
      ref={megaRef}
      isOpen={isSearchOpen}
      onKeyDown={handleKeyDown}
      className="search-modal"
      parentSelector={isSideNav ? '.lds-side-nav-content-col' : '.lds-header-wrapper' }
      topSelector="#header"
    >
      <div
        ref={menuContentRef}
        className={cn(
          'search-menu-content',
          {
            'rows-2': inputRows === 2,
          }
        )}
        key="header-search"
      >
        <div className="search-controls">
          <div className="search-input-wrapper">
            <textarea
              ref={inputRef}
              autoFocus
              type="search"
              placeholder={searchInputPlaceholder}
              className="search-input"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              rows={inputRows}
              onKeyDown={handleInputKeyDown}
              aria-label={searchInputAriaLabel}
              aria-activedescendant={currentFocusPosition !== null ? `suggestion-${currentFocusPosition}` : null}
              aria-describedby="search-helper"
            />
            <span id="search-helper" className="sr-only">{searchInputAriaDescription}</span>
            <input
              ref={hiddenRef}
              aria-hidden="true"
              className="search-input hidden-input"
              type="text"
              value={searchTerm}
              readOnly
              tabIndex="-1"
            />

            <button
              className="clear-button lds-button-base"
              aria-label={searchClearBtnAriaLabel}
              onClick={handleClear}
              onKeyDown={handleKeyboardNavigation}
            >
              <LdsIcon decorative inline name="x" />
            </button>
          </div>

          <button
            className="lds-button search-submit"
            onClick={searchOnBtnClick}
            onKeyDown={handleKeyboardNavigation}
            aria-label={searchSubmitBtnAriaLabel}
          >
            <LdsIcon inline name="magnifying-glass" />
          </button>
        </div>

        <SearchSuggestionList
          searchSuggestions={searchSuggestions}
          searchCustomResult={searchCustomResult}
          searchNoResultsText={searchNoResultsText}
          searchAnotherSearchText={searchAnotherSearchText}
          searchTerm={searchTerm}
          searchLoading={searchLoading}
          isSearchOpen={isSearchOpen}
          setIsSearchOpen={setIsSearchOpen}
          currentFocusPosition={currentFocusPosition}
          searchOnSuggestionClick={searchOnSuggestionClick}
        />
      </div>
    </MegaMenuModal>
  );
}
