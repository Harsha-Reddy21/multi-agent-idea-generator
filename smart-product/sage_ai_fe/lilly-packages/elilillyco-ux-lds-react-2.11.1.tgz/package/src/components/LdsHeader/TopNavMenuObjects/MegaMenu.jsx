import {
  useState,
  useContext,
  useId,
  useCallback
} from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import removeBodyScroll from '../../../util/removeBodyScroll.js';
import resetBodyScroll from '../../../util/resetBodyScroll.js';

import { LdsHeaderContext } from '../LdsHeaderProvider.jsx';
import LdsIcon from '../../LdsIcon/index.jsx';

import useClickOutside from '../../../hooks/useClickOutside.js';
import handleTabAway from '../../../util/handleTabAway.js';
import MobileDropdown from './MobileDropdown.jsx';
import useIsActiveRoute from './useIsActiveRoute.jsx';
import MegaMenuModal from '../MegaMenuModal.jsx';

export default function MegaMenu({
  children,
  label,
  menuHeading,
  basePaths = [],
  ...rest
}) {
  const megaId = useId();

  const isActive = useIsActiveRoute(basePaths);

  const [isOpen, setIsOpen] = useState(false);

  const {
    setOpenDropdownId,
    openDropdownId,
  } = useContext(LdsHeaderContext);

  const closeMega = useCallback(() => {
    setIsOpen(false);

    /*
      This function to close the MM may be triggered when opening another MM
      Because of this we only clear the DD ID and body scroll
      if the MM being closed is the one that is currently open
    */
    if (openDropdownId === megaId) {
      setOpenDropdownId(null);
      resetBodyScroll();
    }
  }, [setOpenDropdownId, openDropdownId, megaId]);

  const handleClick = () => {
    if (!isOpen) {
      removeBodyScroll();
      setIsOpen(true);
      setOpenDropdownId(megaId);
    } else {
      closeMega();
    }
  };

  const megaRef = useClickOutside(() => {
    if (isOpen) closeMega();
  }, null, ['.lds-header-mega-menu-backdrop']);

  const handleKeyDown = (e) => {
    const callback = () => closeMega();
    return handleTabAway(e, megaRef, callback);
  };

  return (
    <>
      <li
        ref={megaRef}
        onKeyDown={handleKeyDown}
        className={cn(
          'top-nav-item',
          'dropdown',
          {
            active: isActive,
            expanded: isOpen,
          }
        )}
        {...rest}
      >
        <button
          className="lds-button-base menu-button"
          aria-expanded={isOpen}
          onClick={handleClick}
          aria-controls={megaId}
        >
          <LdsIcon decorative name="caret-left" className="dropdown-close-arrow will-rotate" />
          {label}
          <LdsIcon decorative name="caret-down" className="dropdown-arrow will-rotate" inline />
        </button>

        {/* Desktop MM */}
        <MegaMenuModal
          isOpen={isOpen}
        >
          <div className="mega-menu-content">
            {
              menuHeading && (
                <div className="mega-menu-heading">
                  {menuHeading}
                </div>
              )
            }
            {children}
          </div>
        </MegaMenuModal>

        {/* Mobile MM */}
        <MobileDropdown
          isOpen={isOpen}
          handleClick={handleClick}
          label={label}
        >
          {children}
        </MobileDropdown>
      </li>
    </>
  );
}

MegaMenu.propTypes = {
  basePaths: PropTypes.arrayOf(PropTypes.string).isRequired,
  label: PropTypes.any.isRequired,
};
