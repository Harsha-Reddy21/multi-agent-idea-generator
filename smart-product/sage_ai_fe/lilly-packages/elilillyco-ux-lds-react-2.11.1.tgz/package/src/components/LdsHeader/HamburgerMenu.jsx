import LdsIcon from '../LdsIcon/index.jsx';

export default function HamburgerMenu({
  labelMenu = 'Menu',
  toggleMobileMenu,
  openMenuButtonRef,
  isMobileMenuOpen,
  labelMobileMenuOpened,
  labelMobileMenuClosed,
}) {
  return (
    <div className="lds-header-mobile-actions">
      <button
        ref={openMenuButtonRef}
        data-testid="lds-open-menu-button"
        id="lds-open-menu-button"
        type="button"
        className="lds-button-base lds-header-toggle toggleMobileMenu"
        onClick={toggleMobileMenu}
      >
        <LdsIcon
          decorative
          className="lds-hamburger-menu-icon"
          name="list"
          inline
        />
        <span className="lds-header-toggle-text">{labelMenu}</span>
        <div aria-live="polite" className="screen-reader-text">
          {isMobileMenuOpen ? labelMobileMenuOpened : labelMobileMenuClosed}
        </div>
      </button>
    </div>
  );
}
