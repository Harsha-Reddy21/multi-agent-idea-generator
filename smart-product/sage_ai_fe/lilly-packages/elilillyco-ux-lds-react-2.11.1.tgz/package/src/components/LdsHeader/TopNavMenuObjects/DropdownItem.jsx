import cn from 'classnames';
import PropTypes from 'prop-types';
import { useContext } from 'react';

import LdsIcon from '../../LdsIcon/index.jsx';
import { LdsHeaderContext } from '../LdsHeaderProvider.jsx';

// JSDoc type definitions
/**
 * @typedef LdsDropdownItemProps
 * @property {React.ReactNode} children - The children of the component
 * @property {string} [href] - href for the menu link
 * @property {string} [icon] - The name of the LDS icon to show next to the menu item
 * @property {object} [linkProps] - Additional props to pass to the anchor tag
 * @property {boolean} [external] - marks the link as external. shows an external link icon
 */
/**
 * LdsDropdownItem component
 * @param {LdsDropdownItemProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function DropdownItem({
  children,
  external = false,
  href,
  icon,
  linkProps = {},
  ...rest
}) {
  const { currentRoute } = useContext(LdsHeaderContext);

  return (
    <li
      className={cn(
        'dropdown-item',
        {
          active: currentRoute === href,
        }
      )}
      {...rest}
    >
      <a
        href={href}
        {...linkProps}
      >
        {icon && <LdsIcon inline name={icon} className="dropdown-icon" />}
        {children}
        {
          external && <>&nbsp;<LdsIcon inline name="arrow-square-out" /></>
        }
      </a>
    </li>
  );
}

DropdownItem.propTypes = {
  href: PropTypes.string.isRequired,
};
