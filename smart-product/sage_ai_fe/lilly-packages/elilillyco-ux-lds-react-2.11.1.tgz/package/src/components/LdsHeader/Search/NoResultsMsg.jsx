export default function NoResultsMsg({
  show,
  searchNoResultsText,
  searchAnotherSearchText,
  searchTerm,
}) {
  if (!show) return '';

  return (
    <div className="search-no-results-msg">
      <span className="fz-h2 no-results-text">{searchNoResultsText} &quot;{searchTerm}&quot;</span>
      <span className="another-search-text">{searchAnotherSearchText}</span>
    </div>
  );
}
