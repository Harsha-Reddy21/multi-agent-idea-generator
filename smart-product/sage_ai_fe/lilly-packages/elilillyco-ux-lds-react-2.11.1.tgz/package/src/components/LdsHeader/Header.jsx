import { useContext, useState, forwardRef } from 'react';

import cn from 'classnames';

import { LdsHeaderContext } from './LdsHeaderProvider.jsx';

// import child components
import UtilityMenu from './UtilityMenu/Desktop.jsx';
import TopNav from './TopNav.jsx';
import MobilePanel from './MobilePanel.jsx';
import SearchModal from './Search/SearchModal.jsx';
import HeaderIcons from './HeaderIcons.jsx';
import SSOModal from './UtilityMenu/SSO/SSOModal.jsx';

// import LDS components
import LdsLillyLogo from '../LdsLillyLogo/index.jsx';

export default forwardRef(function LdsHeader({
  // PRIMARY MENU
  topNavAriaLabel = 'Primary',
  children,
  // Utility MENU
  showUtilityLogo = true,
  utilityMenuLinks = [],
  utilityMenuAriaLabel = 'Global',
  utilityMenuCustomLinkItems,
  utilityMenuCustomLinkItemsPosition = 'after',
  contactLilly = null,
  languageSelector = null,
  // SSO
  showSSO,
  ssoSignInLinkProps,
  ssoRegisterLinkProps,
  ssoUserIcon,
  ssoIsLoggedIn,
  ssoWelcomeText,
  ssoDisplayName,
  ssoFullName,
  ssoSignOutText,
  ssoSignOutButtonProps,
  ssoMyProfileText,
  ssoMyProfileLinkProps,
  ssoEmail,
  ssoContent,
  ssoIconOnly,
  ssoMobileCloseAriaLabel,
  ssoMobileCloseLabel,
  ssoOpenedAnnouncement,
  ssoClosedAnnouncement,
  ssoMobileAccountAriaLabel,
  ssoSignInText,
  ssoOrText,
  ssoRegisterText,
  ssoIconAriaLabel,
  // LOGO
  lillyLogo = {
    className: 'no-padding',
    href: 'https://lilly.com',
    ariaLabel: 'visit lilly.com',
  },
  customLogo = undefined,
  // TEXT LABELS
  labelMenu = 'Menu',
  labelMobileMenuOpened = 'menu opened',
  labelMobileMenuClosed = 'menu closed',
  labelCloseMenu = 'Close',
  // SEARCH
  search = false,
  searchTerm,
  setSearchTerm,
  searchSuggestions,
  searchCustomResult,
  searchInputPlaceholder,
  searchBtnLabel,
  searchNoResultsText,
  searchAnotherSearchText,
  searchLoading,
  searchClearBtnAriaLabel,
  searchMobileBtnAriaLabel,
  searchMobileCloseAriaLabel,
  searchMobileCloseLabel,
  searchOnBtnClick,
  searchOnSuggestionClick,
  searchSubmitBtnAriaLabel,
  searchInputAriaDescription,
  searchOpenedAnnouncement = 'Search open',
  searchClosedAnnouncement = 'Search closed',
  searchInputAriaLabel,
  // UTILITIES
  sticky = false,
  className = '',
  ...rest
}, ref) {
  const { openMenuButtonRef } = useContext(LdsHeaderContext);

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const showUtilityMenu = !!contactLilly
    || !!languageSelector
    || (utilityMenuLinks && Array.isArray(utilityMenuLinks) && utilityMenuLinks.length > 0);

  function toggleMobileMenu() {
    if (isMobileMenuOpen) {
      setIsMobileMenuOpen(false);
      // If the menu is open, we focus the open menu button after closing it.
      if (openMenuButtonRef && openMenuButtonRef.current) {
        openMenuButtonRef.current.focus();
      }
    } else {
      setIsMobileMenuOpen(true);
    }
  }

  return (
    <div
      ref={ref}
      className="lds-header-wrapper"
      style={{ position: sticky ? 'sticky' : 'relative', top: 0 }}
    >
      <header
        id="header"
        className={cn(
          'lds-header',
          className
        )}
        style={{ position: sticky ? 'sticky' : 'relative' }}
        {...rest}
      >
        <span
          id="a11y-state-announcer"
          role="status"
          className="visually-hidden"
        ></span>

        <div className="lds-header-main">

          {/* HEADER BAR */}
          <div className="lds-header-logo-wrapper">
            {customLogo || <LdsLillyLogo {...lillyLogo} />}

            <HeaderIcons
              labelMenu={labelMenu}
              labelMobileMenuClosed={labelMobileMenuClosed}
              labelMobileMenuOpened={labelMobileMenuOpened}
              toggleMobileMenu={toggleMobileMenu}
              isMobileMenuOpen={isMobileMenuOpen}
              // search
              search={search}
              searchMobileBtnAriaLabel={searchMobileBtnAriaLabel}
              searchMobileCloseAriaLabel={searchMobileCloseAriaLabel}
              searchMobileCloseLabel={searchMobileCloseLabel}
              searchOpenedAnnouncement={searchOpenedAnnouncement}
              searchClosedAnnouncement={searchClosedAnnouncement}
              // sso
              showSSO={showSSO}
              ssoUserIcon={ssoUserIcon}
              ssoIsLoggedIn={ssoIsLoggedIn}
              ssoSignInLinkProps={ssoSignInLinkProps}
              ssoMobileCloseAriaLabel={ssoMobileCloseAriaLabel}
              ssoMobileCloseLabel={ssoMobileCloseLabel}
              ssoOpenedAnnouncement={ssoOpenedAnnouncement}
              ssoClosedAnnouncement={ssoClosedAnnouncement}
              ssoMobileAccountAriaLabel={ssoMobileAccountAriaLabel}
            />
          </div>

          <div className="header-menus-container flex-1">
            { showUtilityMenu
              && <UtilityMenu
                showUtilityLogo={showUtilityLogo}
                languageSelector={languageSelector}
                utilityMenuLinks={utilityMenuLinks}
                utilityMenuAriaLabel={utilityMenuAriaLabel}
                customLinkItems={utilityMenuCustomLinkItems}
                customLinkItemsPosition={utilityMenuCustomLinkItemsPosition}
                contactLilly={contactLilly}
                search={search}
                searchBtnLabel={searchBtnLabel}
                // SSO
                showSSO={showSSO}
                ssoSignInLinkProps={ssoSignInLinkProps}
                ssoRegisterLinkProps={ssoRegisterLinkProps}
                ssoUserIcon={ssoUserIcon}
                ssoIsLoggedIn={ssoIsLoggedIn}
                ssoWelcomeText={ssoWelcomeText}
                ssoDisplayName={ssoDisplayName}
                ssoFullName={ssoFullName}
                ssoSignOutText={ssoSignOutText}
                ssoSignOutButtonProps={ssoSignOutButtonProps}
                ssoMyProfileText={ssoMyProfileText}
                ssoMyProfileLinkProps={ssoMyProfileLinkProps}
                ssoEmail={ssoEmail}
                ssoContent={ssoContent}
                ssoIconOnly={ssoIconOnly}
                ssoSignInText={ssoSignInText}
                ssoOrText={ssoOrText}
                ssoRegisterText={ssoRegisterText}
                ssoIconAriaLabel={ssoIconAriaLabel}
              />
            }

            <TopNav
              topNavAriaLabel={topNavAriaLabel}
            >
              {children}
            </TopNav>

            <MobilePanel
              // Utility menu
              showUtilityMenu={showUtilityMenu}
              showUtilityLogo={showUtilityLogo}
              contactLilly={contactLilly}
              languageSelector={languageSelector}
              utilityMenuLinks={utilityMenuLinks}
              utilityMenuAriaLabel={utilityMenuAriaLabel}
              utilityMenuCustomLinkItems={utilityMenuCustomLinkItems}
              utilityMenuCustomLinkItemsPosition={utilityMenuCustomLinkItemsPosition}
              // Mobile top header bar props
              customLogo={customLogo}
              lillyLogo={lillyLogo}
              labelCloseMenu={labelCloseMenu}
              //
              topNavAriaLabel={topNavAriaLabel}
              toggleMobileMenu={toggleMobileMenu}
              isMobileMenuOpen={isMobileMenuOpen}
            >
              {children}
            </MobilePanel>
          </div>
        </div>
      </header>

      {/*
        Modals needs to live in the top level of the header. Deeply nesting this can cause re-rendering issues
       */}
      <SearchModal
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        searchSuggestions={searchSuggestions}
        searchCustomResult={searchCustomResult}
        searchInputPlaceholder={searchInputPlaceholder}
        searchNoResultsText={searchNoResultsText}
        searchAnotherSearchText={searchAnotherSearchText}
        searchLoading={searchLoading}
        searchClearBtnAriaLabel={searchClearBtnAriaLabel}
        searchOnBtnClick={searchOnBtnClick}
        searchOnSuggestionClick={searchOnSuggestionClick}
        searchSubmitBtnAriaLabel={searchSubmitBtnAriaLabel}
        searchInputAriaDescription={searchInputAriaDescription}
        searchInputAriaLabel={searchInputAriaLabel}
      />

      {/* SSO Modal only appears in mobile */}
      {
        showSSO
          && <SSOModal
          ssoFullName={ssoFullName}
          ssoUserIcon={ssoUserIcon}
          ssoSignOutText={ssoSignOutText}
          ssoSignOutButtonProps={ssoSignOutButtonProps}
          ssoMyProfileText={ssoMyProfileText}
          ssoMyProfileLinkProps={ssoMyProfileLinkProps}
          ssoEmail={ssoEmail}
          ssoContent={ssoContent}
        />
      }
    </div>
  );
});
