import { useContext } from 'react';

import HamburgerMenu from './HamburgerMenu.jsx';
import LdsIcon from '../LdsIcon/index.jsx';
import { LdsHeaderContext } from './LdsHeaderProvider.jsx';

export default function HeaderIcons({
  // Search props
  search,
  searchMobileBtnAriaLabel,
  searchMobileCloseAriaLabel = 'Close search',
  searchMobileCloseLabel = 'Close',
  searchOpenedAnnouncement = 'Search open',
  searchClosedAnnouncement = 'Search closed',
  // Hamburger Menu props
  labelMenu,
  labelMobileMenuClosed,
  labelMobileMenuOpened,
  toggleMobileMenu,
  isMobileMenuOpen,
  // SSO props
  showSSO,
  ssoUserIcon,
  ssoIsLoggedIn,
  ssoSignInLinkProps,
  ssoMobileAccountAriaLabel = 'Account',
  ssoMobileCloseAriaLabel = 'Close Account',
  ssoMobileCloseLabel = 'Close',
  ssoOpenedAnnouncement = 'Account open',
  ssoClosedAnnouncement = 'Account closed',
}) {
  const {
    openMenuButtonRef,
    isSearchOpen,
    setIsSearchOpen,
    isSSOOpen,
    setIsSSOOpen,
  } = useContext(LdsHeaderContext);

  return (
    <div className="header-icons-wrapper">
      {/* Search */}

      {/* Search - open */}
      {
        search && !isSearchOpen && !isSSOOpen
        && <button
          className="lds-button-base mobile-search-button d-flex flex-column justify-content-center"
          aria-label={searchMobileBtnAriaLabel}
          onClick={() => setIsSearchOpen(true)}
        >
          <LdsIcon decorative inline name="magnifying-glass" />
        </button>
      }

      {/* Search - close */}
      {
        isSearchOpen && !isSSOOpen
        && <button
          className="lds-button-base mobile-search-button d-flex flex-column"
          aria-label={searchMobileCloseAriaLabel}
          onClick={() => setIsSearchOpen(false)}
        >
          <LdsIcon decorative inline name="x" />
          <span className="lds-header-toggle-text">{searchMobileCloseLabel}</span>
        </button>
      }

      {/* SSO - Login page link */}
      {/* In mobile when logged out this will just be a link to the sign in page - no dropdown */}
      {
        showSSO && !ssoIsLoggedIn && !isSearchOpen && !isSSOOpen
        && <a
          className="lds-button-base mobile-search-button d-flex flex-column justify-content-center"
          {...ssoSignInLinkProps}
        >
          <LdsIcon decorative inline name="user-circle-fill" />
        </a>
      }

      {/* SSO - logged in */}
      {
        showSSO && ssoIsLoggedIn && !isSearchOpen && !isSSOOpen
        && <button
          className="lds-button-base mobile-sso-button d-flex flex-column justify-content-center"
          aria-label={ssoMobileAccountAriaLabel}
          onClick={() => setIsSSOOpen(true)}
        >
          <img className="sso-user-icon" src={ssoUserIcon} />
        </button>
      }

      {/* SSO - Close */}
      {
        isSSOOpen && <button
          className="lds-button-base mobile-search-button d-flex flex-column"
          aria-label={ssoMobileCloseAriaLabel}
          onClick={() => setIsSSOOpen(false)}
        >
          <LdsIcon decorative inline name="x" />
          <span className="lds-header-toggle-text">{ssoMobileCloseLabel}</span>
        </button>
      }

      {/*
        Hamburger Menu
        Does not display if search modal is open
      */}
      {
        !isSearchOpen && !isSSOOpen && <HamburgerMenu
          labelMenu={labelMenu || 'Menu'}
          toggleMobileMenu={toggleMobileMenu}
          openMenuButtonRef={openMenuButtonRef}
          isMobileMenuOpen={isMobileMenuOpen}
          labelMobileMenuOpened={labelMobileMenuOpened}
          labelMobileMenuClosed={labelMobileMenuClosed}
        />
      }
      <div aria-live="polite" className="screen-reader-text">
        {isSearchOpen ? searchOpenedAnnouncement : searchClosedAnnouncement}
      </div>
      <div aria-live="polite" className="screen-reader-text">
        {isSSOOpen ? ssoOpenedAnnouncement : ssoClosedAnnouncement}
      </div>
    </div>
  );
}
