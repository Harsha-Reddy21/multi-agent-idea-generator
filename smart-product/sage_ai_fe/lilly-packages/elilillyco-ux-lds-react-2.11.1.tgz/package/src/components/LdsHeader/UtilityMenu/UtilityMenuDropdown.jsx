import { useState } from 'react';
import PropTypes from 'prop-types';

import LdsDropdown from '../../LdsDropdown/index.jsx';

import useIsMobile from '../../../hooks/useIsMobile.js';

export default function UtilityMenuDropdown({
  label,
  children,
}) {
  const [isOpen, setIsOpen] = useState(false);
  const isMobile = useIsMobile(992);

  return (
    <>
      {/* Desktop only dropdown */}
      <LdsDropdown
        isOpen={isOpen}
        setIsOpen={setIsOpen}
        label={label}
        enableTabAway={!isMobile}
        autoFocusFirstItem={!isMobile}
        wrapperProps={{
          className: 'utility-menu-dropdown lds-header-menu-item-link',
        }}
        buttonProps={{
          className: 'utility-menu-dropdown',
        }}
        dropdownProps={{
          className: 'utility-menu-dropdown',
        }}
      >
        {children}
      </LdsDropdown>
    </>
  );
}

UtilityMenuDropdown.Link = LdsDropdown.Link;
UtilityMenuDropdown.Button = LdsDropdown.Button;

UtilityMenuDropdown.propTypes = {
  label: PropTypes.any.isRequired,
};
