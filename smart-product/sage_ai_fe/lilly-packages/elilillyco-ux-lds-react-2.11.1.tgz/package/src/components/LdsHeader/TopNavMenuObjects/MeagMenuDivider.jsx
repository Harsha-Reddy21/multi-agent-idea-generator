import LdsDivider from '../../LdsDivider/index.jsx';

export default function MegaMenuDivider() {
  return (
    <div className="mega-menu-divider">
      <LdsDivider type="secondary" />
    </div>
  );
}
