import { createContext, useState, useEffect } from 'react';

export const LdsHeaderContext = createContext();

export function LdsHeaderProvider({
  headerRef,
  openMenuButtonRef,
  currentRoute,
  children,
}) {
  /* Store the open dropdown id so we can apply specific stylings and functionality
    like closing other dropdowns when another is hover opened.
    This is a little different between dropdowns, flyouts, and mobile menus so we
    track each individually.
  */
  const [openDropdownId, setOpenDropdownId] = useState(null);
  const [openFlyoutId, setOpenFlyoutId] = useState(null);
  const [openMobileMenuId, setOpenMobileMenuId] = useState(null);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isSSOOpen, setIsSSOOpen] = useState(false);
  const [forceCompactHeader, setForceCompactHeader] = useState(false);
  // Track the top bar height; default is 96px
  const [mobileTopBarHeight, setMobileTopBarHeight] = useState(96);

  // Check the length of the header when the window resizes. If it gets to big
  // we have to make it more compact by hiding things like the search text and user name
  useEffect(() => {
    let timeout;
    const handleWindowResize = () => {
      clearTimeout(timeout);

      timeout = setTimeout(() => {
        const refCopy = headerRef.current;
        if (refCopy.scrollWidth > refCopy.clientWidth) {
          setForceCompactHeader(true);
        }

        // The mobile navigation panels need to correct for the top bar height which is variable
        // Due to the content which may exist within it, in particular the height of a custom logo can vary
        const mobileTopBar = refCopy.querySelector('.header-mobile-panel-bar');
        setMobileTopBarHeight(mobileTopBar.getBoundingClientRect().height);
      }, 200);
    };

    window.addEventListener('resize', handleWindowResize);
    handleWindowResize();
    return () => window.removeEventListener('resize', handleWindowResize);
  }, [headerRef]);

  return (
    <LdsHeaderContext.Provider
      value={{
        currentRoute,
        openMenuButtonRef,
        openDropdownId,
        setOpenDropdownId,
        openFlyoutId,
        setOpenFlyoutId,
        openMobileMenuId,
        setOpenMobileMenuId,
        isSearchOpen,
        setIsSearchOpen,
        isSSOOpen,
        setIsSSOOpen,
        forceCompactHeader,
        mobileTopBarHeight,
      }}
    >
      {children}
    </LdsHeaderContext.Provider>
  );
}
