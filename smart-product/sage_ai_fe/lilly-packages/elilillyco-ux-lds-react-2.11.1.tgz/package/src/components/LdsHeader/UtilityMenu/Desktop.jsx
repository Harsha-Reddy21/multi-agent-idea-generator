import cn from 'classnames';

import UtilityLogo from './Logo.jsx';
import SearchMenuBtn from '../Search/SearchMenuBtn.jsx';
import SSO from './SSO/index.jsx';

export default function UtilityMenu({
  languageSelector,
  contactLilly,
  showUtilityLogo,
  utilityMenuAriaLabel = 'Global',
  customLinkItemsPosition = 'after',
  utilityMenuLinks = [],
  customLinkItems = [],
  search = false,
  searchBtnLabel,
  isSideNav = false,
  // SSO Props
  showSSO,
  ssoSignInLinkProps,
  ssoRegisterLinkProps,
  ssoUserIcon,
  ssoIsLoggedIn,
  ssoWelcomeText,
  ssoDisplayName,
  ssoFullName,
  ssoSignOutText,
  ssoSignOutButtonProps,
  ssoMyProfileText,
  ssoMyProfileLinkProps,
  ssoEmail,
  ssoContent,
  ssoIconOnly,
  ssoSignInText,
  ssoOrText,
  ssoIconAriaLabel,
  ssoRegisterText,
  ...rest
}) {
  const hasCustomLinkItems = customLinkItems && Array.isArray(customLinkItems) && customLinkItems.length > 0;
  const hasMenuLinks = utilityMenuLinks && Array.isArray(utilityMenuLinks) && utilityMenuLinks.length > 0;

  const MenuItem = ({ children }) => {
    return (
      <li
        tabIndex="-1"
        className="lds-header-utility-menu-item"
      >
        <div
          className="lds-header-menu-item-content"
        >
          {children}
        </div>
      </li>
    );
  };

  const LinkList = ({ links }) => (
    links.map((link, index) => (<MenuItem key={index}>{link}</MenuItem>))
  );

  return (
    <nav
      aria-label={utilityMenuAriaLabel}
      className="lds-header-utility"
      {...rest}
    >
      <div
        className={cn(
          'lds-header-utility-menu',
          {
            'no-logo': !showUtilityLogo,
            'side-nav-utility': isSideNav,
          }
        )}
      >
        {/* Logo */}
        { showUtilityLogo
          && <UtilityLogo />
        }

        <div className="utility-content">

          {/* Links section
              displays if there are utilityMenuLinks or items in customLinkItems
          */}
          { (hasMenuLinks || hasCustomLinkItems)
            && <ul className="utility-links">
              { hasCustomLinkItems && customLinkItemsPosition === 'before'
                && <LinkList links={customLinkItems} />
              }

              {
                hasMenuLinks && <LinkList links={utilityMenuLinks} />
              }

              { hasCustomLinkItems && customLinkItemsPosition === 'after'
                && <LinkList links={customLinkItems} />
              }
            </ul>
          }

          {/* Selectors group - applies padding */}
          { (contactLilly || languageSelector || search)
            && <ul className="utility-selectors">
              <div className="selectors-divider"></div>
              { contactLilly && <MenuItem>{contactLilly}</MenuItem>}
              { languageSelector && <MenuItem>{languageSelector}</MenuItem>}
              { search
                && <MenuItem>
                  <SearchMenuBtn isSideNav={isSideNav} searchBtnLabel={searchBtnLabel} />
                </MenuItem>
              }
            </ul>
          }

          { showSSO
            && <SSO
              ssoIsLoggedIn={ssoIsLoggedIn}
              ssoSignInLinkProps={ssoSignInLinkProps}
              ssoRegisterLinkProps={ssoRegisterLinkProps}
              ssoUserIcon={ssoUserIcon}
              ssoWelcomeText={ssoWelcomeText}
              ssoDisplayName={ssoDisplayName}
              ssoFullName={ssoFullName}
              ssoSignOutText={ssoSignOutText}
              ssoSignOutButtonProps={ssoSignOutButtonProps}
              ssoMyProfileText={ssoMyProfileText}
              ssoMyProfileLinkProps={ssoMyProfileLinkProps}
              ssoEmail={ssoEmail}
              ssoContent={ssoContent}
              ssoIconOnly={ssoIconOnly}
              ssoSignInText={ssoSignInText}
              ssoOrText={ssoOrText}
              ssoRegisterText={ssoRegisterText}
              ssoIconAriaLabel={ssoIconAriaLabel}
            />
          }
        </div>
      </div>
    </nav>
  );
}
