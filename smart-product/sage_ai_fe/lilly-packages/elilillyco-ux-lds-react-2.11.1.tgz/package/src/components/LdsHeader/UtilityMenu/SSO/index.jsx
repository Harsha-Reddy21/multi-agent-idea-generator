import {
  useRef,
  useEffect,
  useState
} from 'react';

import PropTypes from 'prop-types';
import cn from 'classnames';

import LdsDropdown from '../../../LdsDropdown/index.jsx';
import LdsIcon from '../../../LdsIcon/index.jsx';
import LdsLink from '../../../LdsLink/index.jsx';
import LdsDivider from '../../../LdsDivider/index.jsx';

export default function SSO({
  ssoSignInText = 'Sign in',
  ssoSignInLinkProps = {},
  ssoOrText = 'or',
  ssoRegisterText = 'Register',
  ssoRegisterLinkProps = {},
  ssoUserIcon,
  ssoIconAriaLabel = 'Account',
  ssoIsLoggedIn = false,
  ssoWelcomeText = 'Hi,',
  ssoDisplayName = '',
  ssoFullName,
  ssoSignOutText = 'Sign out',
  ssoSignOutButtonProps = {},
  ssoMyProfileText = 'My Profile',
  ssoMyProfileLinkProps = {},
  ssoEmail,
  ssoContent,
  ssoIconOnly = false,
}) {
  const ssoRef = useRef(null);
  const [isOpen, setIsOpen] = useState(false);

  const [top, setTop] = useState(0);

  useEffect(() => {
    // Calculate the position of the dropdown when it opens. It should appear
    // just below the right edge of the utility menu
    const ssoElem = ssoRef.current;
    if (!isOpen || !ssoElem) return;

    const utilityMenu = ssoElem.closest('.lds-header-utility-menu');
    const utilTop = utilityMenu.offsetHeight;
    setTop(utilTop);
  }, [isOpen]);

  return (
    <div
      ref={ssoRef}
      className="utility-nav-sso"
    >
      <div className="sso-divider"></div>

      <div
        className={cn(
          'sso-signed-out',
          {
            hidden: ssoIsLoggedIn,
          }
        )}
      >
        <span>
          {/* According to design the icon needs to be a link to sign in as well
            even when sign in and register are present
          */}
          {
            ssoSignInText
            && <a
              className="lds-header-utility-menu-item"
              {...ssoSignInLinkProps}
              aria-label={ssoSignInLinkProps['aria-label'] || ssoSignInText }
            >
              <LdsIcon
                name="user-circle-fill"
                inline
                className="sso-signed-out-icon before"
                aria-label={ssoIconAriaLabel}
              />
            </a>
          }

          {
            ssoSignInText
            && <a
              className="lds-header-utility-menu-item sign-in-text"
              {...ssoSignInLinkProps}
              aria-label={ssoSignInLinkProps['aria-label'] || ssoSignInText }
            >
              <span className="sso-utility-text">{ssoSignInText}</span>
            </a>
          }

          {
            ssoOrText
            && <span
              className="sso-utility-text utility-or-text"
            >
              &nbsp;{ssoOrText}&nbsp;
            </span>
          }

          {
            ssoRegisterText
            && <a
              className="lds-header-utility-menu-item sso-utility-text utility-register-text"
              {...ssoRegisterLinkProps}
            >
              {ssoRegisterText}
            </a>
          }
        </span>
      </div>

      <LdsDropdown
        isOpen={isOpen}
        setIsOpen={setIsOpen}
        showExpandIcon={false}
        autoFocusFirstItem={false}
        label={<>
          {
            ssoUserIcon
            && <img
              className="sso-user-icon before"
              src={ssoUserIcon}
              alt={ssoIconAriaLabel}
            />
          }

          {
            ssoWelcomeText && !ssoIconOnly
            && <span className="sso-utility-text utility-signed-in-text">{ssoWelcomeText}&nbsp;</span>
          }

          {
            ssoDisplayName && !ssoIconOnly
            && <strong className="sso-utility-text utility-signed-in-text">{ssoDisplayName}</strong>
          }
        </>}
        buttonProps={{
          className: cn(
            'lds-button-base',
            'sso-signed-in',
            {
              hidden: !ssoIsLoggedIn,
            }
          ),
          'aria-label': ssoIconAriaLabel,
        }}
        dropdownProps={{
          className: 'sso-dropdown',
          style: {
            top,
          },
        }}
      >
        <div className="sso-user-wrapper">
          <img className="sso-modal-user-icon" src={ssoUserIcon} />
          <div className="sso-user-info">
            {/* These are all optional presets - any custom content can be inserted with ssoContent */}
            {ssoFullName && <span
              className="sso-full-name"
            >
              {ssoFullName}
            </span>}

            {ssoEmail && <span
              className="sso-email"
            >
              {ssoEmail}
            </span>}

            {ssoMyProfileText && <LdsLink
              {...ssoMyProfileLinkProps}
              className="sso-my-profile-link"
            >
              {ssoMyProfileText}
            </LdsLink>}

            {ssoContent}
          </div>
        </div>

        <div className="user-info-divider-wrapper">
          <LdsDivider type="secondary" className="sign-out-divider" />
        </div>

        <button
          className="lds-button-base sso-sign-out-btn"
          {...ssoSignOutButtonProps}
        >
          {ssoSignOutText}
        </button>
      </LdsDropdown>
    </div>
  );
}

SSO.propTypes = {
  ssoSignInText: PropTypes.string,
  ssoSignInLinkProps: PropTypes.object.isRequired,
  ssoOrText: PropTypes.string,
  ssoRegisterText: PropTypes.string,
  ssoRegisterLinkProps: PropTypes.object.isRequired,
  ssoIsLoggedIn: PropTypes.bool,
};
