import cn from 'classnames';
import LdsIcon from '../../LdsIcon/index.jsx';

export default function LdsSearchSuggestion({
  suggestion,
  searchTerm,
  focusIndex = null,
  currentFocusPosition,
  onClick = () => {},
}) {
  const boldMatchText = (text) => {
    return text.replace(new RegExp(searchTerm, 'gi'), (match) => `<strong>${match}</strong>`);
  };

  return (
    <button
      id={`suggestion-${focusIndex}`}
      className={cn(
        'lds-button-base',
        'search-anchor',
        {
          active: (focusIndex !== null) && currentFocusPosition === focusIndex,
        }
      )}
      role="option"
      aria-selected={(focusIndex !== null) && currentFocusPosition === focusIndex ? true : null}
      tabIndex="-1"
      onClick={() => onClick(suggestion)}
      aria-labelledby={`details-${focusIndex}`}
    >
      <LdsIcon name="arrow-right" decorative inline className="search-icon" />
      <div
        id={`details-${focusIndex}`}
        className="search-details"
      >
        <span className="search-title">{suggestion.title}</span>
        <span
          className="search-description"
          aria-hidden="true"
          dangerouslySetInnerHTML={{ __html: boldMatchText(suggestion.description) }}
        />
        <span
          className="sr-only"
        >{suggestion.description}</span>
      </div>
    </button>
  );
}
