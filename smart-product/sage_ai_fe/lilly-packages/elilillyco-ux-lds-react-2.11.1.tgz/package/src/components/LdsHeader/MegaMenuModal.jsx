import cn from 'classnames';
import {
  useState,
  useId,
  useEffect,
  forwardRef,
  useRef
} from 'react';

import removeBodyScroll from '../../util/removeBodyScroll.js';
import resetBodyScroll from '../../util/resetBodyScroll.js';

/*
  Mega menu modal is used in both the mega menu and the Utility nav search.
  This component can be used anywhere a MM style dropdown needs to appear below the header
*/

/*
  Because of the way the virtual dom works react needs to use refs to select elements to determine
  the position of the modal.

  This component has two properties used for getting elements. parentSelector is used to get the overall parent of the modal. We will take the modal ref and get the .closest(parentSelector) to get the parent element. This will typically be the header wrapper.

  Then we do a select on the parent element using topSelector to get the child element that we want to position the modal below.

  const wrapper = contentRef.current.closest(parentSelector);
  const topElement = wrapper.querySelector(topSelector);
*/
export default forwardRef(function MegaMenuModal({
  isOpen,
  children,
  onKeyDown = null,
  parentSelector = '.lds-header-wrapper',
  topSelector = '.lds-header',
  leftPosition = null,
  className = '',
}, ref) {
  const contentRef = useRef(null);
  const [leftPos, setLeftPos] = useState(leftPosition);
  const [topPos, setTopPos] = useState(0);
  const [maxHeight, setMaxHeight] = useState('');

  const megaId = useId();

  // We calc the top of the modal based on the position of the header
  // Header can be sticky or not sticky
  useEffect(() => {
    if (isOpen) {
      const containerElem = contentRef.current.closest(parentSelector);
      if (!containerElem) {
        console.error(`MegaMenuModal: parentSelector ${parentSelector} not found`); // eslint-disable-line
      }

      const topElem = containerElem.querySelector(topSelector);
      if (!topElem) {
        console.error(`MegaMenuModal: topSelector ${topSelector} not found`); // eslint-disable-line
      }

      const menuButtonTop = topElem.getBoundingClientRect().top;
      const menuButtonHeight = topElem.offsetHeight;
      const top = menuButtonTop + menuButtonHeight;
      setTopPos(top);

      if (leftPosition === null) {
        const left = topElem.getBoundingClientRect().left;
        setLeftPos(left);
      }
      // Set max height of the expandible content so it is scrollable if there is overflow
      setMaxHeight(`calc(100vh - ${top}px)`);
      removeBodyScroll();
    } else {
      resetBodyScroll();
    }
  }, [isOpen, parentSelector, topSelector, leftPosition]);

  return (
    <>
      <div
        role="region"
        aria-hidden={!isOpen}
        className={cn(
          'lds-header-mega-menu-backdrop',
          {
            expanded: isOpen,
          },
          className
        )}
        style={{ top: topPos, left: leftPos }}
        id={megaId}
      >
      </div>

      <div
        ref={ref}
        className={cn(
          'mega-menu-wrapper',
          {
            expanded: isOpen,
          },
          className
        )}
        style={{ top: topPos, left: leftPos, maxHeight }}
        inert={isOpen ? null : ''}
        onKeyDown={onKeyDown}
      >
        <div
          ref={contentRef}
          className="mega-menu-expandible"
        >
          {children}
        </div>
      </div>
    </>
  );
});
