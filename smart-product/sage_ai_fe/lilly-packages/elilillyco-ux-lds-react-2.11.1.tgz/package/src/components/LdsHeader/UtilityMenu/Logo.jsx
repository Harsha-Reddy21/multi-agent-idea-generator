import LdsLillyLogo from '../../LdsLillyLogo/index.jsx';

export default function UtilityLogo() {
  return (
    <LdsLillyLogo utilityLogo svgClassName="lds-header-utility-logo" />
  );
}
