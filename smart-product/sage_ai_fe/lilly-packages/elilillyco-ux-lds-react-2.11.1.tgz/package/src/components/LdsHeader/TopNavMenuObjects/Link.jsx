import cn from 'classnames';
import { useContext } from 'react';

import LdsIcon from '../../LdsIcon/index.jsx';
import { LdsHeaderContext } from '../LdsHeaderProvider.jsx';

export default function Link({
  children,
  external = false,
  href,
  linkProps = {},
  ...rest
}) {
  const { currentRoute } = useContext(LdsHeaderContext);
  return (
    <li
      className={cn(
        'top-nav-item',
        'link',
        {
          active: currentRoute === href,
        }
      )}
      {...rest}
    >
      <a
        className="lds-button-base menu-button top-nav-link"
        href={href}
        {...linkProps}
      >
        {children}
        {
          external && <>&nbsp;<LdsIcon inline name="arrow-square-out" /></>
        }
      </a>
    </li>
  );
}
