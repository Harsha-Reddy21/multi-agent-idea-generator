export default function TopNav({
  topNavAriaLabel,
  children,
}) {
  return (
    <nav
      className="top-nav"
      aria-label={topNavAriaLabel || 'Primary'}
    >
      <ul className="top-nav-list">
        {children}
      </ul>
    </nav>
  );
}
