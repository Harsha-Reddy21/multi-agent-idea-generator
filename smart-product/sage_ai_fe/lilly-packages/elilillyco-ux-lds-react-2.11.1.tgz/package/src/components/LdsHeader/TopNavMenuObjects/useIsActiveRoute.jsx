import {
  useContext,
  useState,
  useEffect
} from 'react';

import { LdsHeaderContext } from '../LdsHeaderProvider.jsx';

export default function useIsActiveRoute(basePaths = []) {
  const [isActive, setIsActive] = useState(false);

  const {
    currentRoute,
  } = useContext(LdsHeaderContext);

  useEffect(() => {
    if (!currentRoute || !basePaths.length) return;

    const matchingPath = basePaths.find((path) => currentRoute.startsWith(path));
    if (matchingPath) {
      setIsActive(true);
    } else {
      setIsActive(false);
    }
  }, [currentRoute, basePaths]);

  return isActive;
}
