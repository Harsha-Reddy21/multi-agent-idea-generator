import cn from 'classnames';
import PropTypes from 'prop-types';
import { useContext } from 'react';

import LdsIcon from '../../LdsIcon/index.jsx';
import { LdsHeaderContext } from '../LdsHeaderProvider.jsx';

export default function MegaMenuItem({
  children,
  external = false,
  href,
  icon,
  linkProps = {},
  ...rest
}) {
  const { currentRoute } = useContext(LdsHeaderContext);

  return (
    <li
      className={cn(
        'mega-menu-item',
        'dropdown-item',
        {
          active: currentRoute === href,
        }
      )}
      {...rest}
    >
      <a
        href={href}
        {...linkProps}
      >
        {icon && <LdsIcon inline name={icon} className="dropdown-icon" />}
        {children}
        {
          external && <>&nbsp;<LdsIcon inline name="arrow-square-out" /></>
        }
      </a>
    </li>
  );
}

MegaMenuItem.propTypes = {
  href: PropTypes.string.isRequired,
};
