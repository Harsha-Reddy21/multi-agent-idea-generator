import {
  useContext,
  useId,
  useCallback
} from 'react';
import cn from 'classnames';

import LdsIcon from '../../LdsIcon/index.jsx';
import { LdsHeaderContext } from '../LdsHeaderProvider.jsx';
import { SideNavContext } from '../../LdsSideNav/SideNavContext.jsx';

export default function SearchMenuBtn({
  searchBtnLabel = 'Search',
  isSideNav = false,
}) {
  const dropdownId = useId();

  const contextObj = isSideNav ? SideNavContext : LdsHeaderContext;
  const {
    setOpenDropdownId,
    openDropdownId,
    isSearchOpen,
    setIsSearchOpen,
  } = useContext(contextObj);

  const closeMega = useCallback(() => {
    setIsSearchOpen(false);

    /*
      This function to close the MM may be triggered when opening another MM
      Because of this we only clear the DD ID and body scroll
      if the MM being closed is the one that is currently open
    */
    if (openDropdownId === dropdownId) {
      setOpenDropdownId(null);
    }
  }, [setIsSearchOpen, openDropdownId, dropdownId, setOpenDropdownId]);

  const handleClick = () => {
    if (!isSearchOpen) {
      setIsSearchOpen(true);
      setOpenDropdownId(dropdownId);
    } else {
      closeMega();
    }
  };

  return (
    <div className="utility-nav-search">
      <button
        className={cn(
          'lds-button-base',
          'search-btn',
          'utility-button'
        )}
        onClick={handleClick}
        aria-label={searchBtnLabel}
      >
        <LdsIcon inline name="magnifying-glass" decorative />
        <span className="search-utility-text">{searchBtnLabel}</span>
      </button>
    </div>
  );
}
