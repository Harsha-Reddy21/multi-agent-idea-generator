import {
  useState,
  useContext,
  useEffect,
  useId,
  useCallback
} from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import { LdsHeaderContext } from '../LdsHeaderProvider.jsx';
import LdsIcon from '../../LdsIcon/index.jsx';
import useClickOutside from '../../../hooks/useClickOutside.js';
import MobileDropdown from './MobileDropdown.jsx';
import useIsActiveRoute from './useIsActiveRoute.jsx';
import getFocusableElements from '../../../util/getFocusableElements.js';

// JSDoc type definitions
/**
 * @typedef LdsDropdownProps
 * @property {React.ReactNode} children - The children of the component
 * @property {array} [basePaths] - basePath urls for making the dropdown active
 * @property {boolean} [hoverOpen] - Whether the dropdown should open on hover
 * @property {number} [hoverDelay] - The delay in milliseconds before the dropdown opens on hover
 */
/**
 * LdsDropdownProps component
 * @param {LdsDropdownProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function Dropdown({
  label,
  children,
  basePaths = [],
  hoverOpen = false,
  hoverDelay = 500,
  ...rest
}) {
  const dropdownId = useId();

  const {
    openDropdownId,
    setOpenDropdownId,
  } = useContext(LdsHeaderContext);

  const [isOpen, setIsOpen] = useState(false);
  const [isHovering, setIsHovering] = useState(false);

  const isActive = useIsActiveRoute(basePaths);

  // Track if user clicked the flyout. Used for hover open so does not open back up
  const [isClicked, setIsClicked] = useState(false);

  const closeDropdown = useCallback(() => {
    setIsOpen(false);
    setOpenDropdownId(null);
  }, [setOpenDropdownId]);

  const handleClick = () => {
    setIsClicked(true);
    if (!isOpen) {
      setIsOpen(true);
      setOpenDropdownId(dropdownId);
    } else {
      closeDropdown();
      setOpenDropdownId(null);
    }
  };

  const dropdownRef = useClickOutside(() => {
    if (isOpen) closeDropdown();
  });

  // Close dropdown if another one is opened externally
  useEffect(() => {
    if ((openDropdownId && isOpen) && (openDropdownId !== dropdownId)) closeDropdown();
  }, [openDropdownId, dropdownId, isOpen, closeDropdown]);

  /*
    Hover open logic.
    If hoverOpen is set we need to delay the opening incase the user is just passing over.
    Do not open if the user hovers away, or the user has previously clicked on the button
    to open or close the menu.
  */
  useEffect(() => {
    let timeout;
    const cleanup = () => clearTimeout(timeout);

    if (!hoverOpen || isOpen || isClicked) return cleanup;

    if (isHovering) {
      timeout = setTimeout(() => {
        setIsOpen(true);
        setOpenDropdownId(dropdownId);
      }, [hoverDelay]);
    }

    return cleanup;
  }, [
    hoverOpen,
    isOpen,
    isHovering,
    hoverDelay,
    dropdownId,
    setOpenDropdownId,
    setIsOpen,
    isClicked,
  ]);

  // On mouse leave clear the hover timeout and reset clicked state
  const handleMouseLeave = () => {
    setIsHovering(false);
    setIsClicked(false);
  };

  const handleKeyDown = (e) => {
    /* This function handles tabbing away from the dd
      Flyouts will close themselves when tabbing out of them.

      Close the dropdown when:
      - Shift tabbing out of the first item

      - Tabbing away from the last non-nested focusable element in the dropdown.
        However if we are tabbing from the last non-nested item into a flyout we need to keep the dd open.

      - Tabbing away from the very last focusable element in the dropdown.
        This can be the last non-nested item, or if the final non-nested item is a flyout it will be the last tabble item inside the flyout itself if it is open.
    */
    const isShift = e.shiftKey;
    const isTabKey = e.key === 'Tab';

    if (!isTabKey) return;

    // Select only direct link or flyout children of the dropdown
    // Do not select any nested children of the flyout
    const directChildSelector = '.lds-header-dropdown-list ul.top-level > .dropdown-item';
    const dropdownItems = dropdownRef.current.querySelectorAll(`
      ${directChildSelector} > a[href],
      ${directChildSelector} > button.flyout-button
    `);
    const isFirstItemFocused = e.target === dropdownItems[0];
    const isLastItemFocused = e.target === dropdownItems[dropdownItems.length - 1];

    // If backwards tabbing and not the first item - do nothing
    if (isTabKey && isShift && !isFirstItemFocused) return;

    // Shift tabbing out of the DD from the first item
    const isTabBackOut = isTabKey && isShift && isFirstItemFocused;
    // Normal tabbing out of the DD away from last item
    const isTabForwardOut = isTabKey && !isShift && isLastItemFocused;

    // If very last focusable element in the dd - close it
    // This includes last item in a flyout at the end of the DD
    const allFocusableElements = getFocusableElements(dropdownRef.current);
    const isLastFocusableElement = e.target === allFocusableElements[allFocusableElements.length - 1];

    const isTargetAFlyout = e.target.classList.contains('flyout-button');
    const isFlyoutOpen = e.target.classList.contains('open');

    // Do not close the DD if we are still inside of it (moving into an open flyout)
    if (isTabKey && isTargetAFlyout && isFlyoutOpen) return;

    if (isTabBackOut || isTabForwardOut || isLastFocusableElement) {
      closeDropdown();
    }
  };

  return (
    <>
      <li
        ref={dropdownRef}
        className={cn(
          'top-nav-item',
          'dropdown',
          {
            active: isActive,
            expanded: isOpen,
          }
        )}
        onKeyDown={handleKeyDown}
        {...rest}
      >
        <button
          className="lds-button-base menu-button"
          aria-expanded={isOpen}
          onClick={handleClick}
          onMouseEnter={() => setIsHovering(true)}
          onMouseLeave={handleMouseLeave}
          aria-controls={dropdownId}
        >
          <LdsIcon decorative name="caret-left" className="dropdown-close-arrow will-rotate" />
          {label}
          <LdsIcon decorative name="caret-down" className="dropdown-arrow will-rotate" inline />
        </button>

        {/* Header list displayed only in desktop */}
        <div
          role="region"
          aria-hidden={!isOpen}
          className={cn(
            'lds-header-dropdown-list',
            {
              expanded: isOpen,
            }
          )}
          id={dropdownId}
        >
          <ul className="top-level">
            {children}
          </ul>
        </div>

        <MobileDropdown
          isOpen={isOpen}
          handleClick={handleClick}
          label={label}
        >
          {children}
        </MobileDropdown>
      </li>
    </>
  );
}

Dropdown.propTypes = {
  basePaths: PropTypes.arrayOf(PropTypes.string).isRequired,
  label: PropTypes.any.isRequired,
  hoverDelay: PropTypes.number,
};
