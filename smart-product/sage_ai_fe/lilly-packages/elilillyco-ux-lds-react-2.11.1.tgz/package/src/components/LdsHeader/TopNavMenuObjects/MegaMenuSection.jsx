import { useId } from 'react';
import MobileSubmenu from './MobileSubmenu.jsx';
import useIsActiveRoute from './useIsActiveRoute.jsx';

export default function MegaMenuSection({
  label,
  children,
  basePaths = [],
}) {
  const headingId = useId();
  const isActive = useIsActiveRoute(basePaths);

  return (
    <>
      {/* Desktop section */}
      <div
        className="mega-menu-section"
        data-section-heading-id={label ? headingId : null}
      >
        { label && <div id={headingId} className="subsection-heading">{label}</div> }

        <div className="row">
          {children}
        </div>
      </div>

      {/* Mobile sections */}

      {/* No label - not a subsection - does not become a dropdown in mobile */}
      { !label
        && <div className="mega-menu-section-mobile">
          {children}
        </div>
      }

      {/* Has a label - is a sub section - becomes a dropdown in mobile */}
      { label
        && <MobileSubmenu
          label={label}
          isActive={isActive}
        >
          {children}
        </MobileSubmenu>
      }
    </>
  );
}
