import {
  useId,
  useEffect,
  useRef,
  useState
} from 'react';
import cn from 'classnames';

import MobileSubmenu from './MobileSubmenu.jsx';
import useIsActiveRoute from './useIsActiveRoute.jsx';
import MegaMenuItem from './MegaMenuItem.jsx';

export default function MegaMenuColumn({
  label,
  children,
  colSize = '3',
  basePaths = [],
  href,
  linkProps = {},
}) {
  const columnId = useId();
  const isActive = useIsActiveRoute(basePaths);
  const columnRef = useRef(null);

  const [subSectionId, setSubSectionId] = useState(null);

  // Detects if the column has a sub-section heading.
  // If it does applies id to the aria-describedby
  useEffect(() => {
    if (!columnRef.current) return;

    const sectionWrapper = columnRef.current.closest('.mega-menu-section');
    if (!sectionWrapper) return;
    const sectionId = sectionWrapper.getAttribute('data-section-heading-id');
    if (!sectionId) return;

    setSubSectionId(sectionId);
  }, []);

  const ColumnLabel = () => {
    if (!label) return '';

    if (href) {
      return (
        <li
          className="mega-menu-item column-label">
          <a id={columnId} href={href} {...linkProps}>{label}</a>
        </li>
      );
    }

    return (
      <li
        id={columnId}
        className="mega-menu-item column-label mm-col-padding">
        {label}
      </li>
    );
  };

  return (
    <>
      <div
        ref={columnRef}
        className={cn(
          'mega-menu-column',
          'col',
          `col-md-${colSize}`
        )}
      >
        <ul
          aria-describedby={`${subSectionId || ''} ${columnId}`}
        >
          <ColumnLabel />
          {children}
        </ul>
      </div>

      {/* In Mobile mega menu columns become dropdowns using the mobile submenu component */}
      <MobileSubmenu
        label={label}
        isActive={isActive}
      >
        {/* If column header is a link - add it as a link in mobile */}
        { href && <MegaMenuItem href={href} {...linkProps}>{label}</MegaMenuItem> }
        {children}
      </MobileSubmenu>
    </>
  );
}
