import {
  useContext
} from 'react';
// import cn from 'classnames';

// import LdsIcon from '../../../LdsIcon/index.jsx';
import MegaMenuModal from '../../MegaMenuModal.jsx';

import { LdsHeaderContext } from '../../LdsHeaderProvider.jsx';
import { SideNavContext } from '../../../LdsSideNav/SideNavContext.jsx';
import useClickOutside from '../../../../hooks/useClickOutside.js';
import handleTabAway from '../../../../util/handleTabAway.js';
import LdsLink from '../../../LdsLink/index.jsx';
import LdsDivider from '../../../LdsDivider/index.jsx';

export default function SSOModal({
  isSideNav = false,
  ssoFullName,
  ssoUserIcon,
  ssoSignOutText,
  ssoSignOutButtonProps,
  ssoMyProfileText,
  ssoMyProfileLinkProps,
  ssoEmail,
  ssoContent,
}) {
  const contextObj = isSideNav ? SideNavContext : LdsHeaderContext;
  const {
    isSSOOpen,
    setIsSSOOpen,
  } = useContext(contextObj);

  const megaRef = useClickOutside(() => {
    if (isSSOOpen) setIsSSOOpen(false);
  }, ['.sso-signed-in', '.mobile-sso-button']);

  const handleKeyDown = (e) => {
    return handleTabAway(e, megaRef, () => setIsSSOOpen(false));
  };

  return (
    <MegaMenuModal
      ref={megaRef}
      isOpen={isSSOOpen}
      onKeyDown={handleKeyDown}
      className="sso-modal"
      parentSelector={isSideNav ? '.lds-side-nav-content-col' : '.lds-header-wrapper' }
      topSelector="#header"
    >
      <div className="sso-user-wrapper">
        <img className="sso-modal-user-icon" src={ssoUserIcon} />
        <div className="sso-user-info">
          {/* These are all optional presets - any custom content can be inserted with ssoContent */}
          {ssoFullName && <span
            className="sso-full-name"
          >
            {ssoFullName}
          </span>}

          {ssoEmail && <span
            className="sso-email"
          >
            {ssoEmail}
          </span>}

          {ssoMyProfileText && <LdsLink
            {...ssoMyProfileLinkProps}
            className="sso-my-profile-link"
          >
            {ssoMyProfileText}
          </LdsLink>}

          {ssoContent}
        </div>
      </div>

      <div className="user-info-divider-wrapper">
        <LdsDivider type="secondary" className="sign-out-divider" />
      </div>

      <button
        className="lds-button-base sso-sign-out-btn"
        {...ssoSignOutButtonProps}
      >
        {ssoSignOutText}
      </button>
    </MegaMenuModal>
  );
}
