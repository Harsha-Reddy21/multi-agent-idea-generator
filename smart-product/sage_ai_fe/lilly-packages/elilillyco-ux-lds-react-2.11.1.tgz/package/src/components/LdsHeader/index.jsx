import PropTypes from 'prop-types';
import { useRef } from 'react';

import { LdsHeaderProvider } from './LdsHeaderProvider.jsx';

import Header from './Header.jsx';

// Header sub components for export
import Divider from './TopNavMenuObjects/Divider.jsx';
import Dropdown from './TopNavMenuObjects/Dropdown.jsx';
import DropdownItem from './TopNavMenuObjects/DropdownItem.jsx';
import Link from './TopNavMenuObjects/Link.jsx';
import Flyout from './TopNavMenuObjects/Flyout.jsx';
import MegaMenu from './TopNavMenuObjects/MegaMenu.jsx';
import MegaMenuSection from './TopNavMenuObjects/MegaMenuSection.jsx';
import MegaMenuColumn from './TopNavMenuObjects/MegaMenuColumn.jsx';
import MegaMenuItem from './TopNavMenuObjects/MegaMenuItem.jsx';
import MegaMenuDivider from './TopNavMenuObjects/MeagMenuDivider.jsx';
import SearchSuggestion from './Search/SearchSuggestion.jsx';

// JSdoc type definitions
/**
 * @typedef LdsHeaderProps
 * @property {string} [currentRoute] - The current route (used for active link highlighting)
 * @property {string} [menuAriaLabel] - The aria label for the menu
 * @property {React.ReactNode} [children] - The children of the component. Used to define custom content.
 * @property {boolean} [showUtilityLogo] - Whether to show the utility logo
 * @property {Array.<Object>} [utilityMenuLinks] - The utility menu links
 * @property {string} [utilityMenuAriaLabel] - The aria label for the utility menu
 * @property {React.ReactNode[]} [utilityMenuCustomLinkItems] - The custom utility menu link items
 * @property {string} [utilityMenuCustomLinkItemsPosition] - The position of the custom utility menu link items. Accepts: before, after
 * @property {React.JSX.Element} [contactLilly] - The contact lilly component
 * @property {React.JSX.Element} [languageSelector] - The language selector component
 * @property {import('../LdsLillyLogo/index.jsx').LdsLillyLogoProps} [lillyLogo] - The lilly logo configuration
 * @property {Object} [customLogo] - The custom logo configuration
 * @property {string} [labelMenu] - The label for the menu
 * @property {string} [labelMobileMenuOpened] - The label for the opened mobile menu
 * @property {string} [labelMobileMenuClosed] - The label for the closed mobile menu
 * @property {string} [labelCloseMenu] - The label for the close menu
 * @property {boolean} [sticky] - Whether the header should be sticky
 * @property {boolean} [showSSO] - Whether the header should show SSO content
 * @property {boolean} [ssoIsLoggedIn] - Whether the user is logged in and info can be displayed in sso dropdown
 * @property {string} [ssoSignInText] - Sign in text for the SSO dropdown
 * @property {Object} [ssoSignInLinkProps] - Object of props to apply to the sign in link. (href, aria-label...)
 * @property {string} [ssoOrText] - Text to display between sign in and register links
 * @property {string} [ssoRegisterText] - Text to show for register link
 * @property {Object} [ssoRegisterLinkProps] - Object of props to apply to the sign in link.
 * @property {string} [ssoWelcomeText] - Welcome message to display next to logged in users name in the utility nav
 * @property {string} [ssoDisplayName] - Name of logged in user to display in utility nav. Should be set as First Name
 * @property {boolean} [ssoIconOnly] - Set to true to make the sso area in the utility menu only show an icon and no user name
 * @property {string} [ssoSignOutText] - Text to show for sign out button
 * @property {Object} [ssoSignOutButtonProps] - Object of props to apply to the sign out button (onClick)
 * @property {string} [ssoMyProfileText] - Text to show for the my profile link
 * @property {Object} [ssoMyProfileLinkProps] - Object of props to apply to the my profile link.
 * @property {string} [ssoEmail] - Email address of the signed in user
 * @property {string} [ssoFullName] - Full name of logged in user to display in the open SSO menu
 * @property {React.JSX.Element} [ssoContent] - Optional custom JSX content to insert into the SSO dropdown
 * @property {string} [ssoMobileCloseAriaLabel] - String for aria-label on the mobile close button for the sso dropdown
 * @property {string} [ssoMobileCloseLabel] - Visible text to show next to close button for the mobile sso dropdown
 * @property {string} [ssoOpenedAnnouncement] - Hidden accessibility text to announce that sso dropdown has opened in mobile
 * @property {string} [ssoClosedAnnouncement] - Hidden accessibility text to announce that sso dropdown has closed in mobile
 * @property {string} [ssoUserIcon] - Image src to use for user icon
 * @property {string} [ssoMobileAccountAriaLabel] - Aria label for mobile account open button
 * @property {string} [ssoIconAriaLabel] - Aria label for the SSO icon
 * @property {boolean} [search] - Whether to show the search bar
 * @property {string} [searchTerm] - The current search term
 * @property {function} [setSearchTerm] - Function to set the search term
 * @property {Array} [searchSuggestions] - Array of search suggestions
 * @property {function} [searchCustomResult] - Custom render function for search results
 * @property {string} [searchInputPlaceholder] - Placeholder text for the search input
 * @property {string} [searchBtnLabel] - Label for the search button
 * @property {string} [searchNoResultsText] - Text to display when no search results are found
 * @property {string} [searchAnotherSearchText] - Text to prompt another search
 * @property {boolean} [searchLoading] - Whether the search is loading
 * @property {string} [searchClearBtnAriaLabel] - Aria label for the clear search button
 * @property {string} [searchMobileBtnAriaLabel] - Aria label for the mobile search button
 * @property {string} [searchMobileCloseAriaLabel] - Aria label for the mobile close button
 * @property {string} [searchMobileCloseLabel] - Label for the mobile close button
 * @property {function} [searchOnBtnClick] - Function to handle search button click
 * @property {function} [searchOnSuggestionClick] - Function to handle suggestion click
 * @property {string} [searchSubmitBtnAriaLabel] - Aria label for the search submit button
 * @property {string} [searchInputAriaDescription] - Description for the search input (for accessibility)
 * @property {string} [searchOpenedAnnouncement] - Announcement text when search is opened
 * @property {string} [searchClosedAnnouncement] - Announcement text when search is closed
 * @property {string} [searchInputAriaLabel] - Aria label for the search input
 * @property {string} [className] - Additional classes to add to the component
 */
/**
 * LdsHeader component
 * @param {LdsHeaderProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsHeader({
  currentRoute = null,
  // Top Nav MENU
  topNavAriaLabel = 'Primary',
  children,
  // Utility MENU
  showUtilityLogo = true,
  utilityMenuLinks = [],
  utilityMenuAriaLabel = 'Global',
  utilityMenuCustomLinkItems,
  utilityMenuCustomLinkItemsPosition = 'after',
  contactLilly = null,
  languageSelector = null,
  // SSO
  showSSO = false,
  ssoClosedAnnouncement,
  ssoContent,
  ssoDisplayName = '',
  ssoEmail,
  ssoFullName,
  ssoIconAriaLabel = 'Account',
  ssoIconOnly = false,
  ssoIsLoggedIn = false,
  ssoMobileAccountAriaLabel = 'Account',
  ssoMobileCloseAriaLabel = 'Close account',
  ssoMobileCloseLabel = 'Close',
  ssoMyProfileLinkProps = {},
  ssoMyProfileText = 'My Profile',
  ssoOpenedAnnouncement,
  ssoOrText = 'or',
  ssoRegisterLinkProps = {},
  ssoRegisterText = 'Register',
  ssoSignInLinkProps = {},
  ssoSignInText = 'Sign in',
  ssoSignOutButtonProps = {},
  ssoSignOutText = 'Sign out',
  ssoUserIcon,
  ssoWelcomeText = 'Hi,',
  // LOGO
  lillyLogo = {
    className: 'no-padding',
    href: 'https://lilly.com',
    ariaLabel: 'visit lilly.com',
  },
  customLogo = undefined,
  // TEXT LABELS
  labelMenu = 'Menu',
  labelMobileMenuOpened = 'menu opened',
  labelMobileMenuClosed = 'menu closed',
  labelCloseMenu = 'Close',
  // SEARCH
  search = false,
  searchTerm,
  setSearchTerm,
  searchSuggestions,
  searchCustomResult,
  searchInputPlaceholder,
  searchBtnLabel,
  searchNoResultsText,
  searchAnotherSearchText,
  searchLoading,
  searchClearBtnAriaLabel,
  searchMobileBtnAriaLabel,
  searchMobileCloseAriaLabel,
  searchMobileCloseLabel,
  searchOnBtnClick,
  searchOnSuggestionClick,
  searchSubmitBtnAriaLabel,
  searchInputAriaDescription = 'Suggestions will update as you type',
  searchOpenedAnnouncement = 'Search open',
  searchClosedAnnouncement = 'Search closed',
  searchInputAriaLabel,
  // UTILITIES
  sticky = false,
  className = '',
  ...rest
}) {
  const headerRef = useRef(null);
  const openMenuButtonRef = useRef(null);

  return (
    <LdsHeaderProvider
      currentRoute={currentRoute}
      headerRef={headerRef}
      openMenuButtonRef={openMenuButtonRef}
    >
      <Header
        ref={headerRef}
        sticky={sticky}
        topNavAriaLabel={topNavAriaLabel}
        className={className}
        contactLilly={contactLilly}
        customLogo={customLogo}
        labelCloseMenu={labelCloseMenu}
        labelMenu={labelMenu}
        labelMobileMenuClosed={labelMobileMenuClosed}
        labelMobileMenuOpened={labelMobileMenuOpened}
        languageSelector={languageSelector}
        lillyLogo={lillyLogo}
        // search
        search={search}
        searchAnotherSearchText={searchAnotherSearchText}
        searchBtnLabel={searchBtnLabel}
        searchClearBtnAriaLabel={searchClearBtnAriaLabel}
        searchCustomResult={searchCustomResult}
        searchInputPlaceholder={searchInputPlaceholder}
        searchLoading={searchLoading}
        searchMobileBtnAriaLabel={searchMobileBtnAriaLabel}
        searchNoResultsText={searchNoResultsText}
        searchSuggestions={searchSuggestions}
        searchTerm={searchTerm}
        searchOnBtnClick={searchOnBtnClick}
        searchSubmitBtnAriaLabel={searchSubmitBtnAriaLabel}
        searchInputAriaDescription={searchInputAriaDescription}
        setSearchTerm={setSearchTerm}
        searchMobileCloseAriaLabel={searchMobileCloseAriaLabel}
        searchMobileCloseLabel={searchMobileCloseLabel}
        searchOnSuggestionClick={searchOnSuggestionClick}
        // Utility menu
        showUtilityLogo={showUtilityLogo}
        utilityMenuAriaLabel={utilityMenuAriaLabel}
        utilityMenuCustomLinkItems={utilityMenuCustomLinkItems}
        utilityMenuCustomLinkItemsPosition={utilityMenuCustomLinkItemsPosition}
        utilityMenuLinks={utilityMenuLinks}
        searchOpenedAnnouncement={searchOpenedAnnouncement}
        searchClosedAnnouncement={searchClosedAnnouncement}
        searchInputAriaLabel={searchInputAriaLabel}
        // SSO
        showSSO={showSSO}
        ssoSignInLinkProps={ssoSignInLinkProps}
        ssoRegisterLinkProps={ssoRegisterLinkProps}
        ssoUserIcon={ssoUserIcon}
        ssoIsLoggedIn={ssoIsLoggedIn}
        ssoWelcomeText={ssoWelcomeText}
        ssoDisplayName={ssoDisplayName}
        ssoFullName={ssoFullName}
        ssoSignOutText={ssoSignOutText}
        ssoSignOutButtonProps={ssoSignOutButtonProps}
        ssoMyProfileText={ssoMyProfileText}
        ssoMyProfileLinkProps={ssoMyProfileLinkProps}
        ssoEmail={ssoEmail}
        ssoContent={ssoContent}
        ssoIconOnly={ssoIconOnly}
        ssoMobileCloseAriaLabel={ssoMobileCloseAriaLabel}
        ssoMobileCloseLabel={ssoMobileCloseLabel}
        ssoOpenedAnnouncement={ssoOpenedAnnouncement}
        ssoClosedAnnouncement={ssoClosedAnnouncement}
        ssoMobileAccountAriaLabel={ssoMobileAccountAriaLabel}
        ssoSignInText={ssoSignInText}
        ssoOrText={ssoOrText}
        ssoRegisterText={ssoRegisterText}
        ssoIconAriaLabel={ssoIconAriaLabel}
        {...rest}
      >
        {children}
      </Header>
    </LdsHeaderProvider>
  );
}

LdsHeader.propTypes = {
  currentRoute: PropTypes.string,
  menuAriaLabel: PropTypes.string,
  lillyLogo: PropTypes.object,
  customLogo: PropTypes.object,
  sticky: PropTypes.bool,
  labelMenu: PropTypes.string,
  labelMobileMenuOpened: PropTypes.string,
  labelMobileMenuClosed: PropTypes.string,
  labelCloseMenu: PropTypes.string,
  className: PropTypes.string,
  search: PropTypes.bool,
  searchTerm: PropTypes.string,
  setSearchTerm: PropTypes.func,
  searchSuggestions: PropTypes.array,
  searchCustomResult: PropTypes.func,
  searchInputPlaceholder: PropTypes.string,
  searchBtnLabel: PropTypes.string,
  searchNoResultsText: PropTypes.string,
  searchAnotherSearchText: PropTypes.string,
  searchLoading: PropTypes.bool,
  searchClearBtnAriaLabel: PropTypes.string,
  searchMobileBtnAriaLabel: PropTypes.string,
  searchMobileCloseAriaLabel: PropTypes.string,
  searchMobileCloseLabel: PropTypes.string,
  searchOnBtnClick: PropTypes.func,
  searchOnSuggestionClick: PropTypes.func,
  searchSubmitBtnAriaLabel: PropTypes.string,
  searchInputAriaDescription: PropTypes.string,
  searchOpenedAnnouncement: PropTypes.string,
  searchClosedAnnouncement: PropTypes.string,
  searchInputAriaLabel: PropTypes.string,
  showUtilityLogo: PropTypes.bool,
  utilityMenuLinks: PropTypes.array,
  utilityMenuAriaLabel: PropTypes.string,
  utilityMenuCustomLinkItems: PropTypes.array,
  utilityMenuCustomLinkItemsPosition: PropTypes.oneOf(['before', 'after']),
  contactLilly: PropTypes.node,
  languageSelector: PropTypes.node,
  showSSO: PropTypes.bool,
  ssoIsLoggedIn: PropTypes.bool,
  ssoSignInText: PropTypes.string,
  ssoSignInLinkProps: PropTypes.object,
  ssoOrText: PropTypes.string,
  ssoRegisterText: PropTypes.string,
  ssoRegisterLinkProps: PropTypes.object,
  ssoWelcomeText: PropTypes.string,
  ssoDisplayName: PropTypes.string,
  ssoIconOnly: PropTypes.bool,
  ssoSignOutText: PropTypes.string,
  ssoSignOutButtonProps: PropTypes.object,
  ssoMyProfileText: PropTypes.string,
  ssoMyProfileLinkProps: PropTypes.object,
  ssoEmail: PropTypes.string,
  ssoFullName: PropTypes.string,
  ssoContent: PropTypes.node,
  ssoMobileCloseAriaLabel: PropTypes.string,
  ssoMobileCloseLabel: PropTypes.string,
  ssoOpenedAnnouncement: PropTypes.string,
  ssoClosedAnnouncement: PropTypes.string,
  ssoUserIcon: PropTypes.string,
  ssoMobileAccountAriaLabel: PropTypes.string,
  ssoIconAriaLabel: PropTypes.string,
};

LdsHeader.Divider = Divider;
LdsHeader.Dropdown = Dropdown;
LdsHeader.DropdownItem = DropdownItem;
LdsHeader.Link = Link;
LdsHeader.Flyout = Flyout;

LdsHeader.MegaMenu = MegaMenu;
LdsHeader.MegaMenuSection = MegaMenuSection;
LdsHeader.MegaMenuColumn = MegaMenuColumn;
LdsHeader.MegaMenuItem = MegaMenuItem;
LdsHeader.MegaMenuDivider = MegaMenuDivider;

LdsHeader.SearchSuggestion = SearchSuggestion;
