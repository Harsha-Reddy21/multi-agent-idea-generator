import PropTypes from 'prop-types';

export default function PrivacyControls({
  privacyChoicesLink,
  cookieConsentButton,
}) {
  return (
    <div className="lds-footer-legal-privacy">
      <div className="lds-privacy-link">
        <div className="privacy-link-icon">
          <svg className="lds-icon check-toggle" aria-hidden="true" role="img" />
        </div>
        <div className="privacy-link-anchor">
          {privacyChoicesLink}
        </div>
      </div>
      <div className="lds-privacy-cookies">
          {cookieConsentButton}
      </div>
    </div>
  );
}

PrivacyControls.propTypes = {
  privacyChoicesLink: PropTypes.node.isRequired,
  cookieConsentButton: PropTypes.node.isRequired,
};
