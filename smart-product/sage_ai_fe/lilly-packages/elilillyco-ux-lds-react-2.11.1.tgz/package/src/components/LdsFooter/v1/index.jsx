/* eslint-disable no-console */
// MARK: IMPORTS
import React from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

// LDS Atomic Components
import LdsLillyLogo from '../../LdsLillyLogo/index.jsx';

// Public Sub-Components
import CustomOverride from './public/CustomOverride.jsx';
import GlobalLinks from './public/GlobalLinks.jsx';
import LanguageSelector from './public/LanguageSelector.jsx';
import LogoOverride from './public/LogoOverride.jsx';
import MetaContent from './public/MetaContent.jsx';
import PrimaryLinks from './public/PrimaryLinks.jsx';
import PrimaryLinksColumnHeading from './public/PrimaryLinksColumnHeading.jsx';
import PrimaryLinksItem from './public/PrimaryLinksItem.jsx';
import PrimaryLinksList from './public/PrimaryLinksList.jsx';
import PrivacyControls from './public/PrivacyControls.jsx';
import SocialMedia from './public/SocialMedia.jsx';
import SupportInfo from './public/SupportInfo.jsx';

// MARK: COMPONENT DEF
export function LdsFooterV1({
  primaryLinksColumnFlow = 'even',
  lillyLogo = {
    logo: 'lilly-tag-below',
    size: 'md',
    className: 'no-pad-left no-pad-right no-pad-bottom',
    href: 'https://lilly.com',
    target: '_blank',
    ariaLabel: 'visit lilly.com a medicine company (opens in a new tab)',
  },
  className = '',
  children,
  ...rest
}) {
  // MARK: METHODS
  const childComponents = React.Children.toArray(children);

  let primaryNavFlow = 'even';
  if (primaryLinksColumnFlow.toLowerCase() === 'auto') primaryNavFlow = 'auto';

  let hasSocial = false;
  try {
    hasSocial = childComponents.some(
      (child) => child.type === LdsFooterV1.SocialMedia
    );
  } catch (ex) {
    console.error('LdsFooter - Cannot determine if footer contains LdsFooterV1.SocialMedia sub-component(s)\nException:', ex.message);
    hasSocial = false;
  }

  let hasPrimaryLinks = false;
  try {
    hasPrimaryLinks = childComponents.some(
      (child) => child.type === LdsFooterV1.PrimaryLinks
    );
  } catch (ex) {
    console.error('LdsFooter - Cannot determine if footer contains LdsFooterV1.PrimaryLinks sub-component(s)\nException:', ex.message);
    hasPrimaryLinks = false;
  }

  let hasSupportInfo = false;
  try {
    hasSupportInfo = childComponents.some(
      (child) => child.type === LdsFooterV1.SupportInfo
    );
  } catch (ex) {
    console.error('LdsFooter - Cannot determine if footer contains LdsFooterV1.SocialMedia sub-component(s)\nException:', ex.message);
    hasSupportInfo = false;
  }

  let hasMetaContent = false;
  try {
    hasMetaContent = childComponents.some(
      (child) => child.type === LdsFooterV1.MetaContent
    );
  } catch (ex) {
    console.error('LdsFooter - Cannot determine if footer contains LdsFooterV1.SocialMedia sub-component(s)\nException:', ex.message);
    hasMetaContent = false;
  }

  let hasGlobalLinks = false;
  try {
    hasGlobalLinks = childComponents.some(
      (child) => child.type === LdsFooterV1.GlobalLinks
    );
  } catch (ex) {
    console.error('LdsFooter - Cannot determine if footer contains LdsFooterV1.SocialMedia sub-component(s)\nException:', ex.message);
    hasGlobalLinks = false;
  }

  let hasLogoOverride = false;
  try {
    hasLogoOverride = childComponents.some(
      (child) => child.type === LdsFooterV1.LogoOverride
    );
  } catch (ex) {
    console.error('LdsFooter - Cannot determine if footer contains LdsFooterV1.SocialMedia sub-component(s)\nException:', ex.message);
    hasLogoOverride = false;
  }

  let hasCustomOverride = false;
  try {
    hasCustomOverride = childComponents.some(
      (child) => child.type === LdsFooterV1.CustomOverride
    );
  } catch (ex) {
    console.error('LdsFooter - Cannot determine if footer contains LdsFooterV1.SocialMedia sub-component(s)\nException:', ex.message);
    hasCustomOverride = false;
  }

  let classTopRow = 'justify-content-center justify-content-md-between';
  if (!hasPrimaryLinks && hasSupportInfo) {
    classTopRow = 'justify-content-center justify-content-md-end';
  }

  const topRowGlobalLinks = (children) => {
    return children.map((child, index) => {
      return (
        <li
          key={index}
          className="col-12 col-md d-md-none"
        >
          {child}
        </li>
      );
    });
  };

  // MARK: RENDER
  return (
    <footer
      className={cn(
        'lds-footer-v1',
        className
      )}
      {...rest}
    >
      <div className='wrapper'>
        {hasCustomOverride && (
          <div className="lds-footer-custom-content">
            {childComponents
              .filter((child) => child.type === LdsFooterV1.CustomOverride)
              .map((child) => child.props.children)}
          </div>
        )}
        {(hasPrimaryLinks || hasGlobalLinks || hasSupportInfo) && (
        <div className={cn(
          'lds-footer-row-top',
          'row',
          classTopRow
        )}
        >
          {/* Primary links section */}
          {(hasPrimaryLinks || hasGlobalLinks) && (
            <div className={cn(
              'lds-footer-main-links',
              'col-12',
              'col-md-9'
            )}>
              <ul className={cn(
                'lds-footer-list',
                `lds-footer-list-${primaryNavFlow}`
              )}>
                {childComponents
                  .filter((child) => child.type === LdsFooterV1.PrimaryLinks)
                  .map((child) => child.props.children)}
              </ul>
              {/* Global links section - mobile only */}
              { hasGlobalLinks && (
                <ul className={cn(
                  'global-content'
                )}>
                  {childComponents
                    .filter((child) => child.type === LdsFooterV1.GlobalLinks)
                    .map((child) => topRowGlobalLinks(child.props.children))}
                </ul>
              )}
            </div>
          )}
          {/* Support section */}
          {hasSupportInfo && (
            <div className={cn(
              'col-12',
              'col-md-3',
              'lds-footer-support'
            )}>
              {childComponents
                .filter((child) => child.type === LdsFooterV1.SupportInfo)
                .map((child) => child.props.children)}
            </div>
          )}
        </div>
        )}
        <div className={cn(
          'lds-footer-row-meta',
          'row'
        )}
        >
          {/* Legal/meta section */}
          {hasMetaContent && (
            <div className={cn(
              'lds-footer-meta',
              'col-12'
            )}>
              {childComponents
                .filter((child) => child.type === LdsFooterV1.MetaContent)
                .map((child) => child.props.children)}
            </div>
          )}
        </div>
        <div className={cn(
          'lds-footer-row-bottom',
          'row'
        )}
        >
          <div className={cn(
            'col-12',
            'col-md-auto',
            'order-md-2',
            'lds-footer-social-container'
          )}>
            {/* Social section */}
            {hasSocial && (
              <div className="lds-footer-social-icons">
                {childComponents
                  .filter((child) => child.type === LdsFooterV1.SocialMedia)
                  .map((child) => child.props.children)}
              </div>
            )}
            {/* Global links section */}
            {hasGlobalLinks && (
              <div className={cn(
                'lds-footer-global-links',
                'd-none',
                'd-md-block'
              )}>
                {childComponents
                  .filter((child) => child.type === LdsFooterV1.GlobalLinks)
                  .map((child) => child.props.children)}
              </div>
            )}
          </div>
          {/* Logo section */}
          <div
            className={cn(
              'col-12',
              'col-md-auto',
              'order-md-1',
              'lds-footer-logo'
            )}
          >
              { hasLogoOverride ? (
                <div className="footer-override">
                  {childComponents
                    .filter((child) => child.type === LdsFooterV1.LogoOverride)
                    .map((child) => child.props.children)}
                </div>
              ) : (
                <LdsLillyLogo {...lillyLogo} />
              )}
          </div>
        </div>
      </div>
    </footer>
  );
}

// MARK: PROP TYPES
LdsFooterV1.propTypes = {
  primaryLinksColumnFlow: PropTypes.oneOf(['even', 'auto']),
  lillyLogo: PropTypes.object,
  className: PropTypes.string,
  children: PropTypes.node,
};

// MARK: EXPORTS

// Public Sub-Component Definitions
LdsFooterV1.CustomOverride = CustomOverride;
LdsFooterV1.GlobalLinks = GlobalLinks;
LdsFooterV1.LanguageSelector = LanguageSelector;
LdsFooterV1.LogoOverride = LogoOverride;
LdsFooterV1.MetaContent = MetaContent;
LdsFooterV1.PrimaryLinks = PrimaryLinks;
LdsFooterV1.PrimaryLinks.ColumnHeading = PrimaryLinksColumnHeading;
LdsFooterV1.PrimaryLinks.Item = PrimaryLinksItem;
LdsFooterV1.PrimaryLinks.List = PrimaryLinksList;
LdsFooterV1.PrivacyControls = PrivacyControls;
LdsFooterV1.SocialMedia = SocialMedia;
LdsFooterV1.SupportInfo = SupportInfo;

export default LdsFooterV1;
