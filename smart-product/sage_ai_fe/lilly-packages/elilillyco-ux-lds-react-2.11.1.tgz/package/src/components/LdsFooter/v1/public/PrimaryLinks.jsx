import PropTypes from 'prop-types';

export default function PrimaryLinks({
  children,
  ...rest
}) {
  return (
    <div
      className="row"
      {...rest}
    >
      {children}
    </div>
  );
}

PrimaryLinks.propTypes = {
  children: PropTypes.node,
};
