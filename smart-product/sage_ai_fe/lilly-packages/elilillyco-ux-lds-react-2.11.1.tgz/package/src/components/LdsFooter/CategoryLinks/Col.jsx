// @ts-check
/**
 * @typedef LdsFooterCategoryLinksColProps
 * @property {React.ReactNode} [children] - The children of the component
 */
/**
 * @param {LdsFooterCategoryLinksColProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function CategoryLinksCol({ children }) {
  return (
    <div className="lds-footer-list-col col-sm-3 col-lg-auto">
      {children}
    </div>
  );
}
