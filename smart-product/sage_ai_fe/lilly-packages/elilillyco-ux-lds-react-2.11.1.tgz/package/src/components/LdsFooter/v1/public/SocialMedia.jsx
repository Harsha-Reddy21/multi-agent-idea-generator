import PropTypes from 'prop-types';

export default function SocialMedia({ children }) {
  return <>{children}</>;
}

SocialMedia.propTypes = {
  children: PropTypes.node,
};
