import PropTypes from 'prop-types';

export default function LogoOverride({ children }) {
  return <>{children}</>;
}

LogoOverride.propTypes = {
  children: PropTypes.node,
};
