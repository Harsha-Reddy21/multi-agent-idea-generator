import PropTypes from 'prop-types';

export default function GlobalLinks({ children }) {
  return <>{children}</>;
}

GlobalLinks.propTypes = {
  children: PropTypes.node,
};
