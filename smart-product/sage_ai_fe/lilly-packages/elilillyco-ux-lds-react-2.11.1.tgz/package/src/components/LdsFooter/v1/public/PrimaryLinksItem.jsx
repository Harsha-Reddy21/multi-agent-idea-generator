import PropTypes from 'prop-types';
import cn from 'classnames';

export default function PrimaryLinksItem({
  className = '',
  children,
  ...rest
}) {
  return (
    <li
      className={cn(
        'lds-footer-links-item',
        className
      )}
      {...rest}
    >
      {children}
    </li>
  );
}

PrimaryLinksItem.propTypes = {
  className: PropTypes.string,
  children: PropTypes.node,
  rest: PropTypes.any,
};
