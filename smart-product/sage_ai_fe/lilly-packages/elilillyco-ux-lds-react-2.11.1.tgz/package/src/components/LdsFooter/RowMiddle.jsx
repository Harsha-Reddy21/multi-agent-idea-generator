// @ts-check
import cn from 'classnames';

// JSDoc type definitions
/**
 * @typedef RowMiddleProps
 * @property {React.ReactNode} [children] - The children of the component
 * @property {React.JSX.Element} [customerSupportContent] - The customer support content
 * @property {React.JSX.Element} [languageSelector] - The language selector component
 * @property {React.JSX.Element} [privacyControls] - The privacy choices component
 * @property {boolean} [showSupportCard] - Whether to show the support card
 */
/**
 * RowMiddle component
 * @param {RowMiddleProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - RowMiddle component
 */
export default function RowMiddle({
  children,
  customerSupportContent,
  languageSelector,
  privacyControls,
  showSupportCard,
}) {
  return (
    <div className="lds-footer-row-middle row">
      <div
        className={cn(
          'lds-footer-meta',
          {
            'col-sm-6': showSupportCard,
            'col-12 col-md-11 col-lg-9 col-xl-8 col-xxl-6': !showSupportCard,
            'col-xl-5 col-xxl-6': customerSupportContent,
          }
        )}
      >
        {children}
      </div>
      {showSupportCard
        && <div
          className={cn(
            'lds-footer-support',
            'col-sm-6',
            { // adjust column width based on existence of support card content
              'col-xl-7 col-xxl-6': customerSupportContent && privacyControls,
              'col-lg-5 col-xl-4 col-xxl-3': !customerSupportContent || !privacyControls,
            }
          )}
        >
          {
            // render support card content only if it exists
          }
          {customerSupportContent
            && <div className="lds-footer-support-top">
              {customerSupportContent}
            </div>
          }
          {(languageSelector || privacyControls)
            && <div className="lds-footer-support-bottom">
              {languageSelector
                && <>
                  {languageSelector}
                  {privacyControls && <hr className="lds-footer-divider" />}
                </>
              }
              {privacyControls}
            </div>
          }
        </div>
      }
    </div>
  );
}
