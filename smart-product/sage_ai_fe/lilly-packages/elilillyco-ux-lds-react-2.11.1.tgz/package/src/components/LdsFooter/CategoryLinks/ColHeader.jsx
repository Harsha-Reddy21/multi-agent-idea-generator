// @ts-check
/**
 * @typedef CategoryLinksColHeaderProps
 * @property {React.ReactNode} [children] - The children of the component
 * @property {string} [headerTag] - The HTML tag to use for wrapping the header
 */
/**
 * @param {CategoryLinksColHeaderProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function CategoryLinksColHeader({
  children,
  headerTag = 'p',
}) {
  const Tag = headerTag;

  return (
    // @ts-ignore
    <Tag className="h5">
      {children}
    </Tag>
  );
}
