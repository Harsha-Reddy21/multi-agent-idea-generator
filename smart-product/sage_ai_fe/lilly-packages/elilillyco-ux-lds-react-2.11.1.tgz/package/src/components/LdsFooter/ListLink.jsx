// @ts-check
import LdsLink from '../LdsLink/index.jsx';

/**
 * @typedef ListLinkProps
 * @property {React.ReactNode} [children] - The children of the component
 */
/**
 * @param {ListLinkProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function ListLink({ children, ...rest }) {
  return (
    <li className="lds-footer-list-item">
      <LdsLink {...rest}>{children}</LdsLink>
    </li>
  );
}
