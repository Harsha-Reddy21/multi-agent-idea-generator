import PropTypes from 'prop-types';

export default function MetaContent({ children }) {
  return <>{children}</>;
}

MetaContent.propTypes = {
  children: PropTypes.node,
};
