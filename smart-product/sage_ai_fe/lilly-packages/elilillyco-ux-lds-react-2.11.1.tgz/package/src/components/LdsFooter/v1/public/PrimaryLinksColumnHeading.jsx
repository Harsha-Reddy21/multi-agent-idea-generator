import PropTypes from 'prop-types';
import cn from 'classnames';

export default function PrimaryLinksColumnHeading({
  className = '',
  children,
  ...rest
}) {
  return (
    <p
      className={cn(
        'column-heading',
        className
      )}
      {...rest}
    >
      {children}
    </p>
  );
}

PrimaryLinksColumnHeading.propTypes = {
  className: PropTypes.string,
  children: PropTypes.node,
  rest: PropTypes.any,
};
