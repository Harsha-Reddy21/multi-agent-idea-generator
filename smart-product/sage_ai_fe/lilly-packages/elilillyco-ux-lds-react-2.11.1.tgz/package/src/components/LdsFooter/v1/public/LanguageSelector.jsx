import PropTypes from 'prop-types';

// eslint-disable-next-line no-unused-vars
export default function LanguageSelector({ children }) {
  // eslint-disable-next-line no-console
  console.error('LDS Footer V1: The Language Select sub-component LdsFooterV1.LanguageSelector should not be used due to legal compliance issues; please remove it from your footer\'s JSX markup.');
  return (<>{/* Language Select is unavailable due to legal compliance issues */}</>);
  // return (
  //   <div className="lds-footer-language-select">
  //     <div className="lds-footer-language-select-inner">
  //       {children}
  //     </div>
  //   </div>
  // );
}

LanguageSelector.propTypes = {
  children: PropTypes.node,
};
