import PropTypes from 'prop-types';

export default function SupportInfo({ children }) {
  return <>{children}</>;
}

SupportInfo.propTypes = {
  children: PropTypes.node,
};
