import PropTypes from 'prop-types';

export default function CustomOverride({ children }) {
  return <>{children}</>;
}

CustomOverride.propTypes = {
  children: PropTypes.node,
};
