// @ts-check
/**
 * @typedef CategoryLinksColListProps
 * @property {React.ReactNode} [children] - The children of the component
 */
/**
 * @param {CategoryLinksColListProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function CategoryLinksColList({ children }) {
  return (
    <ul className="lds-footer-list">
      {children}
    </ul>
  );
}
