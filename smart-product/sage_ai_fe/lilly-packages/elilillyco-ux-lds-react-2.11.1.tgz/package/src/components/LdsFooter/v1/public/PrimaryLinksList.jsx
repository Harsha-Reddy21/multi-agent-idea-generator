import PropTypes from 'prop-types';
import cn from 'classnames';

export default function PrimaryLinksList({
  className = '',
  children,
  ...rest
}) {
  return (
    <ul
      className={cn(
        className
      )}
      {...rest}
    >
      {children}
    </ul>
  );
}

PrimaryLinksList.propTypes = {
  className: PropTypes.string,
  children: PropTypes.node,
  rest: PropTypes.any,
};
