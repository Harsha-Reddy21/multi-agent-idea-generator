// @ts-check
import cn from 'classnames';

// JSDoc type definitions
/**
 * @typedef RowBottomProps
 * @property {React.JSX.Element} [globalLinks] - The global links component
 * @property {React.JSX.Element} [socialMediaLinks] - The social media links component
 */
/**
 * RowBottom component
 * @param {RowBottomProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - RowBottom component
 */
export default function RowBottom({
  globalLinks,
  socialMediaLinks,
}) {
  return (
    <div className="lds-footer-row-bottom row flex-row-reverse">
      {socialMediaLinks
        && <div
            className={cn(
              'lds-footer-social-icons',
              {
                'col-sm-5 col-lg-4 col-xl-3': globalLinks,
              }
            )}
        >
          {socialMediaLinks}
        </div>
      }
      <div
        className={cn(
          'lds-footer-global-links',
          {
            'col-sm-7 col-lg-8 col-xl-9': socialMediaLinks,
          }
        )}
      >
        <ul className="lds-footer-list lds-footer-list-even">
          {globalLinks}
        </ul>
      </div>
    </div>
  );
}
