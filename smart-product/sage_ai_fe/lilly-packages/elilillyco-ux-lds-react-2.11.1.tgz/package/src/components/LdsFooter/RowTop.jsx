// @ts-check
import cn from 'classnames';

import LdsLillyLogo from '../LdsLillyLogo/index.jsx';

// JSDoc type definitions
/**
 * @typedef RowTopProps
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {Object} [customLogo] - The custom logo configuration
 * @property {import('../LdsLillyLogo/index.jsx').LdsLillyLogoProps} [lillyLogo] - Object passed to the default Lilly Logo component to set that component's react props and/or HTML attributes
 * @property {React.JSX.Element} [mainCategoryLinks] - The main category links component
 * @property {React.JSX.Element} [mainLinks] - The main links component
 * @property {boolean} [noLogo] - Whether to show the logo
 */
/**
 * RowTop component
 * @param {RowTopProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - RowTop component
 */
export default function RowTop({
  className,
  customLogo,
  lillyLogo,
  mainCategoryLinks,
  mainLinks,
  noLogo,
}) {
  return (
    <div
      className={cn(
        'lds-footer-row-top',
        {
          'has-list-links': mainLinks,
          'has-category-links': mainCategoryLinks,
        },
        className
      )}
    >
      {noLogo
        || <div className="lds-footer-logo">
          {customLogo || <LdsLillyLogo {...lillyLogo} />}
        </div>
      }
      {mainLinks
        && <div className="lds-footer-main-links">
          <ul className="lds-footer-list lds-footer-list-even">
            {mainLinks}
          </ul>
        </div>
      }
      {mainCategoryLinks
        && <div className="lds-footer-main-links lds-footer-list-cols row">
          {mainCategoryLinks}
        </div>
      }
    </div>
  );
}
