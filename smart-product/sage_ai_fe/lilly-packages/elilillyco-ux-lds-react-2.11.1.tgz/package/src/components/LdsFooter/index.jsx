// @ts-check
import cn from 'classnames';

// Other components used in this component
import RowTop from './RowTop.jsx';
import RowMiddle from './RowMiddle.jsx';
import RowBottom from './RowBottom.jsx';

// Footer subcomponents for export
import CategoryLinksCol from './CategoryLinks/Col.jsx';
import CategoryLinksColHeader from './CategoryLinks/ColHeader.jsx';
import CategoryLinksColList from './CategoryLinks/ColList.jsx';
import ListLink from './ListLink.jsx';

// JSDoc type definitions
/**
 * @typedef LdsFooterProps
 * @property {React.ReactNode} [children] - The children of the component
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {React.JSX.Element} [customerSupportContent] - The customer support content
 * @property {Object} [customLogo] - The custom logo configuration
 * @property {React.JSX.Element} [globalLinks] - The global links component
 * @property {boolean} [isBlack] - Whether the header should be black themed
 * @property {React.JSX.Element} [languageSelector] - The language selector component
 * @property {import('../LdsLillyLogo/index.jsx').LdsLillyLogoProps} [lillyLogo] - Object passed to the default Lilly Logo component to set that component's react props and/or HTML attributes
 * @property {React.JSX.Element} [mainCategoryLinks] - The main category links component
 * @property {React.JSX.Element} [mainLinks] - The main links component
 * @property {boolean} [noLogo] - Whether to show the logo
 * @property {React.JSX.Element} [privacyControls] - The privacy choices component
 * @property {React.JSX.Element} [socialMediaLinks] - The social media links component
 */
/**
 * LdsFooter component
 * @param {LdsFooterProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsFooter component
 */
export function LdsFooter({
  children,
  className = '',
  customerSupportContent = null,
  customLogo = undefined,
  globalLinks = null,
  isBlack = false,
  languageSelector = null,
  lillyLogo = {
    logo: 'lilly-tag-below',
    sizeClass: 'lg',
    colorClass: isBlack ? 'white' : 'red',
    href: 'https://lilly.com',
    // @ts-ignore
    target: '_blank',
    ariaLabel: 'visit lilly.com a medicine company (opens in a new tab)',
  },
  mainCategoryLinks = null,
  mainLinks = null,
  noLogo = false,
  privacyControls = null,
  socialMediaLinks = null,
}) {
  const showSupportCard = !!(customerSupportContent || languageSelector || privacyControls);
  const showTopRow = !!(!noLogo || mainLinks || mainCategoryLinks);
  const showMiddleRow = !!(children || customerSupportContent || languageSelector || privacyControls || showSupportCard);
  const showBottomRow = !!(socialMediaLinks || globalLinks);
  const showDivider = !!(showTopRow && showMiddleRow) || !!(showTopRow && showBottomRow);

  return (
    <footer
      className={cn(
        'lds-footer-v2',
        {
          'lds-footer-black': isBlack,
        },
        className
      )}
    >
      <div className="wrapper">
        {// TOP ROW: contains the logo and main links
          showTopRow && <RowTop
            className={className}
            customLogo={customLogo}
            lillyLogo={lillyLogo}
            mainCategoryLinks={mainCategoryLinks}
            mainLinks={mainLinks}
            noLogo={noLogo}
          />
        }
        { // DIVIDER: horizontal line between top and middle rows
          showDivider && <hr className='lds-footer-divider' />
        }
        {// MIDDLE ROW: contains the main content and support card
          showMiddleRow && <RowMiddle
            customerSupportContent={customerSupportContent}
            languageSelector={languageSelector}
            privacyControls={privacyControls}
            showSupportCard={showSupportCard}
          >
            {children}
          </RowMiddle>
        }
        {// BOTTOM ROW: contains social media links and global links
          showBottomRow && <RowBottom
            globalLinks={globalLinks}
            socialMediaLinks={socialMediaLinks}
          />
        }
      </div>
    </footer>
  );
}

LdsFooter.CategoryLinksCol = CategoryLinksCol;
LdsFooter.CategoryLinksColHeader = CategoryLinksColHeader;
LdsFooter.CategoryLinksColList = CategoryLinksColList;
LdsFooter.Link = ListLink;

export default LdsFooter;
