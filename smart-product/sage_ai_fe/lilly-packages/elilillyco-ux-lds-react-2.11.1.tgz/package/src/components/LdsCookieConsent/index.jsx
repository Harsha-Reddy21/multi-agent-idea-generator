import { useEffect, useState } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsButton from '../LdsButton/index.jsx';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsCookieConsentProps
 * @property {Object} cookieStatus - Current value for cookie consent acceptance. Should be passed `cookieConsentStatus` from `useLdsCookieConsent` hook
 * @property {function} onAccept - Function that is performed when accept button is clicked. Should be passed the `acceptCookies` function from `useLdsCookieConsent` hook
 * @property {function} onDecline - Function that is performed when decline button is clicked. Should be passed the `declineCookies` function from `useLdsCookieConsent` hook
 * @property {string} [acceptBtnText] - Text to display in the accept button
 * @property {string} [acceptBtnClass] - CSS class for the accept button
 * @property {string} [acceptBtnAriaLabel] - ARIA Label value to set on the accept button to enhance the UX for assistive technology
 * @property {string} [declineBtnText] - Text to display in the disagree button
 * @property {string} [declineBtnClass] - CSS class for the decline button
 * @property {string} [declineBtnAriaLabel] - ARIA Label value to set on the decline button to enhance the UX for assistive technology
 * @property {string} [className] - Optional custom user-defined CSS class(es) for the cookie consent root container element, will be appended to the list of any other component classes
 * @property {React.ReactNode} children - The content to display in the cookie consent message
 */
/**
 * LdsCookieConsent component
 * @param {LdsCookieConsentProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsCookieConsent component
 */
export default function LdsCookieConsent({
  cookieStatus,
  onAccept,
  onDecline,
  acceptBtnText = 'I Agree',
  acceptBtnClass = 'outlined',
  acceptBtnAriaLabel,
  declineBtnText = 'I Disagree',
  declineBtnClass = 'outlined',
  declineBtnAriaLabel,
  className,
  children,
  ...rest
}) {
  const [isActive, setIsActive] = useState(false);

  useEffect(() => {
    setIsActive(!cookieStatus);
  }, [cookieStatus]);

  return (
    <div
      className={cn(
        'lds-cookie-consent',
        {
          active: isActive,
        },
        className
      )}
      aria-label="Cookie consent"
      {...rest}
    >
      <div className="lds-cookie-consent-content-container wrapper">
        <div className="row align-items-center">
          <div className="col lds-cookie-message-container">
            {children}
          </div>
          <div className="col-12 col-md-auto lds-cookie-consent-btn-container">
            <LdsButton
              className={`lds-button btn-close ${declineBtnClass}`}
              aria-label={declineBtnAriaLabel}
              onClick={onDecline}
            >
              {declineBtnText}
            </LdsButton>
            <LdsButton
              className={`lds-button btn-accept ${acceptBtnClass}`}
              aria-label={acceptBtnAriaLabel}
              onClick={onAccept}
            >
              {acceptBtnText}
            </LdsButton>
          </div>
        </div>
      </div>
    </div>
  );
}

LdsCookieConsent.propTypes = {
  acceptBtnText: PropTypes.string,
  acceptBtnClass: PropTypes.string,
  acceptBtnAriaLabel: PropTypes.string,
  declineBtnText: PropTypes.string,
  declineBtnClass: PropTypes.string,
  declineBtnAriaLabel: PropTypes.string,
  onAccept: PropTypes.func.isRequired,
  onDecline: PropTypes.func.isRequired,
};
