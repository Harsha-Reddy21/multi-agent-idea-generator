import { useContext, useEffect, useState } from 'react';

import { LdsModalContext } from '../../LdsModal/LdsModalProvider.jsx';
import LdsButton from '../../LdsButton/index.jsx';
import LdsIcon from '../../LdsIcon/index.jsx';
import LdsSwitch from '../../LdsSwitch/index.jsx';

export default function ModalPreferencesPanel({
  show = false,
  saveBtnText,
  saveBtnAriaLabel,
  modalOpen,
  callback,
  preferenceCookieNotice,
  necessaryHeading,
  alwaysOnText,
  necessaryDescription,
  functionalHeading,
  functionalDescription,
  analyticsHeading,
  analyticsDescription,
  advertisingHeading,
  advertisingDescription,
}) {
  const { getCookieConsentStatus, closeModal, saveCookieConsentPrefs } = useContext(LdsModalContext);

  const [acceptedFunctional, setAcceptedFunctional] = useState(false);
  const [acceptedAnalytics, setAcceptedAnalytics] = useState(false);
  const [acceptedAdv, setAcceptedAdv] = useState(false);

  useEffect(() => {
    const { functional, analytics, advertising } = getCookieConsentStatus();
    setAcceptedFunctional(functional === 'true');
    setAcceptedAnalytics(analytics === 'true');
    setAcceptedAdv(advertising === 'true');
  }, [getCookieConsentStatus, modalOpen]);

  const handleSave = (e) => {
    e.preventDefault();

    saveCookieConsentPrefs({
      functional: acceptedFunctional,
      analytics: acceptedAnalytics,
      advertising: acceptedAdv,
    });
    closeModal();
    callback();
  };

  if (!show) return '';

  return (
    <form method="POST" onSubmit={handleSave}>
      <hr />
      <p>
        <span className="caption">
          {preferenceCookieNotice}
        </span>
      </p>

      <div className="row mb-2">
        <div className="col col-7 col-sm-8 col-lg-9">
          <h3 className="h5">{necessaryHeading}</h3>
        </div>
        <div className="col col-5 col-sm-4 col-lg-3 d-flex justify-content-end">
          <span className="">
            {alwaysOnText} <LdsIcon inline name="CheckCircleFill" style={{ fill: 'var(--lds-color-success-dark)' }} />
          </span>
        </div>
      </div>

      <div className="row">
        <div className="col col-11">
          <p className="caption">
            {necessaryDescription}
          </p>
        </div>
      </div>

      <div className="row mb-2">
        <div className="col col-7 col-sm-8 col-lg-9">
          <h3 className="h5" onClick={() => setAcceptedFunctional(!acceptedFunctional)}>{functionalHeading}</h3>
        </div>
        <div className="col col-5 col-sm-4 col-lg-3 d-flex justify-content-end">
          <span className="">
            <LdsSwitch
              id="functionalSwitch"
              checked={acceptedFunctional}
              onChange={() => setAcceptedFunctional(!acceptedFunctional)}
            />
          </span>
        </div>
      </div>

      <div className="row">
        <div className="col col-11">
          <p className="caption">
            {functionalDescription}
          </p>
        </div>
      </div>

      <div className="row mb-2">
        <div className="col col-7 col-sm-8 col-lg-9">
          <h3 className="h5" onClick={() => setAcceptedAnalytics(!acceptedAnalytics)}>{analyticsHeading}</h3>
        </div>
        <div className="col col-5 col-sm-4 col-lg-3 d-flex justify-content-end">
          <span className="">
            <LdsSwitch
              id="analyticsSwitch"
              checked={acceptedAnalytics}
              onChange={() => setAcceptedAnalytics(!acceptedAnalytics)}
            />
          </span>
        </div>
      </div>

      <div className="row">
        <div className="col col-11">
          <p className="caption">
            {analyticsDescription}
          </p>
        </div>
      </div>

      <div className="row mb-2">
        <div className="col col-7 col-sm-8 col-lg-9">
          <h3 className="h5" onClick={() => setAcceptedAdv(!acceptedAdv)}>{advertisingHeading}</h3>
        </div>
        <div className="col col-5 col-sm-4 col-lg-3 d-flex justify-content-end">
          <span className="">
            <LdsSwitch
              id="advertisingSwitch"
              checked={acceptedAdv}
              onChange={() => setAcceptedAdv(!acceptedAdv)}
            />
          </span>
        </div>
      </div>

      <div className="row">
        <div className="col col-11">
          <p className="caption">
            {advertisingDescription}
          </p>
        </div>
      </div>

      <hr />

      <LdsButton type="submit" aria-label={saveBtnAriaLabel} className="mt-2">{saveBtnText}</LdsButton>
    </form>
  );
}
