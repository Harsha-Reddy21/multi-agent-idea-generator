import { useEffect, useContext } from 'react';

import LdsLink from '../../LdsLink/index.jsx';
import LdsModal from '../../LdsModal/index.jsx';
import { LdsModalContext } from '../../LdsModal/LdsModalProvider.jsx';

import AcceptancePanel from './AcceptancePanel.jsx';
import ModalPreferencesPanel from './ModalPreferencesPanel.jsx';
import DefaultText from './DefaultText.jsx';

export default function CookieConsentModal({
  acceptBtnAriaLabel,
  acceptBtnClass = '',
  acceptBtnText = 'Accept All',
  className,
  declineBtnAriaLabel,
  declineBtnClass = '',
  declineBtnText = 'Decline All',
  headingText = 'Privacy Preferences',
  manageBtnAriaLabel = null,
  manageBtnText = 'Manage Cookie Settings',
  // Preference Panel
  advertisingDescription = 'These cookies and similar technologies enable our advertising and marketing partners to provide behavioral advertising and use functionalities like social media pixels to track your online activity across social platforms and websites, which can identify you , as described in the Privacy Statement and Consumer Health Privacy Notice. These methods create a profile of your activity for our business and commercial purposes and enable Lilly to customize offers and information (online or in person) to you based on your profile, and profiles of persons with similar interests, that may enhance your interactions with Lilly.',
  advertisingHeading = 'Advertising and Marketing Cookies',
  alwaysOnText = 'Always on',
  analyticsDescription = "These cookies allow Lilly to analyze visits and traffic sources so we can measure and improve the performance of our sites. They help us to know which pages are the most and least popular, and see how visitors move around the site to improve the site's performance.",
  analyticsHeading = 'Performance Cookies (Analytics)',
  functionalDescription = 'These cookies and similar technologies remember choices you make such as language or search parameters. We use these cookies to improve your user experience and to make your use of the websites more tailored. If you do not allow these cookies, then some or all of these services may not function as designed.',
  functionalHeading = 'Functional Cookies',
  necessaryDescription = 'These cookies are necessary for the website to function properly and cannot be switched off in our systems. Strictly necessary cookies cannot be disabled.',
  necessaryHeading = 'Strictly Necessary Cookies',
  preferenceCookieNotice = <>For more information about Lilly&apos;s cookies and third-party cookies, see our <LdsLink href="https://www.lillyhub.com/legal/lillyusa/cookienotice.html">Cookie Notice</LdsLink>.</>,
  preferenceHeadingText = 'Manage Your Cookie Settings',
  saveBtnText = 'Save Settings',
  saveBtnAriaLabel = null,
  // General props
  callback = () => {},
  modalId = 'cookieConsentModal',
  children,
  modalSizeClass = 'col-12 col-md-9',
  ...rest
}) {
  const {
    openModal,
    closeModal,
    activeModal,
    acceptAllCookies,
    declineCookies,
    getCookieConsentStatus,
    showCookieModalPrefs,
    setShowCookieModalPrefs,
    modalQueue,
  } = useContext(LdsModalContext);

  /**
   * LDS Cookie Consent Initial Open State Effect
   *
   * If cookie consent is required using this feature, if the user has not consented to the usage
   * of "necessary" cookies then this modal MUST open on page load.
   *
   * Therefore, the LDS Modal Provider openModal function to add this modal to the modal queue
   * should only be called if...
   *   1. The "necessary cookies" cookie is NOT set (existence or value is falsey)
   *   2. The modal is NOT already the activeModal
   *   3. The modal is NOT already in the modalQueue
   * Furthermore, the modal must be forced to the top of the Queue as it takes prioirty when open
   */
  useEffect(() => {
    const necessary = getCookieConsentStatus().necessary;
    const alreadyQueued = modalQueue.includes(modalId);
    const alreadyActive = (modalId === activeModal);

    if (!necessary && !alreadyActive && !alreadyQueued) openModal(modalId, true);
  }, [activeModal, getCookieConsentStatus, modalId, modalQueue, openModal]);

  /**
   * Lds Cookie Consnent Modal - Accept All Button Handler
   *
   * When the user chooses to "accept all" cookies via the CTA button on the main (first) panel
   * this function is invoked to:
   *   - set the necessary cookies cookie (if not set)
   *   - set/update all preference cookies to have a truthy value
   *   - close the modal
   *   - invoke any user-defined callbacks
   */
  const handleAccept = () => {
    acceptAllCookies();
    closeModal();
    callback();
  };

  /**
   * LDS Cookie Consent Modal - Decline All Button Handler
   *
   * When the user chooses to "decline all" cookies via the CTA button on the main (first) panel
   * this function is invoked to:
   *   - set the necessary cookies cookie (if not set)
   *   - set/update all preference cookies to have a falsey value
   *   - close the modal
   *   - invoke any user-defined callbacks
   */
  const handleDecline = () => {
    declineCookies();
    closeModal();
    callback();
  };

  /**
   * LDS Cookie Consent Modal - Toggle Modal Panel Handler
   *
   * Switches the displayed UI of the modal to the "manage preferences" panel
   */
  const toggleModalPanel = () => {
    setShowCookieModalPrefs(true);
  };

  return (
    <LdsModal
      modalId={modalId}
      persistent
      open={activeModal === modalId}
      heading={showCookieModalPrefs ? preferenceHeadingText : headingText}
      closeModal={() => {}}
      className={className}
      modalSizeClass={modalSizeClass}
      {...rest}
    >
      <AcceptancePanel
        acceptBtnClass={acceptBtnClass}
        acceptBtnAriaLabel={acceptBtnAriaLabel}
        acceptBtnText={acceptBtnText}
        declineBtnAriaLabel={declineBtnAriaLabel}
        declineBtnClass={declineBtnClass}
        declineBtnText={declineBtnText}
        toggleModalPanel={toggleModalPanel}
        handleAccept={handleAccept}
        handleDecline={handleDecline}
        manageBtnText={manageBtnText}
        manageBtnAriaLabel={manageBtnAriaLabel}
        show={!showCookieModalPrefs}
      >
        {children}
      </AcceptancePanel>

      <ModalPreferencesPanel
        show={showCookieModalPrefs}
        callback={callback}
        saveBtnText={saveBtnText}
        modalOpen={activeModal === modalId}
        preferenceCookieNotice={preferenceCookieNotice}
        necessaryHeading={necessaryHeading}
        alwaysOnText={alwaysOnText}
        necessaryDescription={necessaryDescription}
        functionalHeading={functionalHeading}
        functionalDescription={functionalDescription}
        analyticsHeading={analyticsHeading}
        analyticsDescription={analyticsDescription}
        advertisingHeading={advertisingHeading}
        advertisingDescription={advertisingDescription}
        saveBtnAriaLabel={saveBtnAriaLabel}
      />
    </LdsModal>
  );
}

CookieConsentModal.DefaultText = DefaultText;
