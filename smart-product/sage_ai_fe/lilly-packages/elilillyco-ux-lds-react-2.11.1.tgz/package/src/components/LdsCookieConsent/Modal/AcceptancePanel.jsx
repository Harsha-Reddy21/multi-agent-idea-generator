import LdsButton from '../../LdsButton/index.jsx';

export default function AcceptancePanel({
  acceptBtnClass,
  acceptBtnAriaLabel,
  acceptBtnText,
  declineBtnAriaLabel,
  declineBtnClass,
  declineBtnText,
  toggleModalPanel,
  show = true,
  handleAccept,
  handleDecline,
  manageBtnText,
  manageBtnAriaLabel,
  children,
}) {
  if (!show) return '';

  return (
    <div>
      {children}

      <div className="d-flex justify-content-center">
        <LdsButton
          aria-label={acceptBtnAriaLabel}
          style={{ marginInlineEnd: '1rem' }}
          className={acceptBtnClass}
          onClick={handleAccept}
        >
          {acceptBtnText}
        </LdsButton>
        <LdsButton
          aria-label={declineBtnAriaLabel}
          className={declineBtnClass}
          onClick={handleDecline}
        >
          {declineBtnText}
        </LdsButton>
      </div>
      <p className="caption mb-0">
        <LdsButton linkButton aria-label={manageBtnAriaLabel} onClick={toggleModalPanel}>{manageBtnText}</LdsButton>
      </p>
    </div>
  );
}
