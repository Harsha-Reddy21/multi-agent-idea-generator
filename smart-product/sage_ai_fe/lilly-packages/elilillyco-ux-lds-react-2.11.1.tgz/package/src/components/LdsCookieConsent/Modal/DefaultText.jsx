import { useContext } from 'react';

import { LdsModalContext } from '../../LdsModal/LdsModalProvider.jsx';

import LdsLink from '../../LdsLink/index.jsx';

export default function DefaultText() {
  const {
    closeModal,
    declineCookies,
    callback = () => {},
  } = useContext(LdsModalContext);

  const handleDecline = () => {
    declineCookies();
    closeModal();
    callback();
  };

  return (
    <>
      <p className="caption">
        With your consent, Lilly collects information about your online interactions, such as user ID, browsing history, geolocation and IP address, through tracking technologies, such as third-party cookies. We use this information to personalize content, save your preferences, and track website performance. We share information with our analytics, marketing, and advertising partners for purposes of targeted advertising and analyzing website metrics. Please visit our <LdsLink href="https://www.lillyhub.com/legal/lillyusa/cookienotice.html" target="_blank">Cookie Notice</LdsLink>, <LdsLink href="https://privacynotice.lilly.com/" target="_blank">Privacy statement</LdsLink>, and <LdsLink href="https://www.lillyhub.com/legal/lillyusa/chpn.html" target="_blank">Consumer Health Privacy Notice</LdsLink> for more information, Certain laws require consent to collect and share information. You can withdraw your consent at any time through the <LdsLink href="#">Cookie Settings</LdsLink> or <LdsLink href="https://privacynotice.lilly.com/#california-residents" target="_blank">Your Privacy Choices</LdsLink> in our website footer.
      </p>

      <p className="caption">
        <LdsLink onClick={handleDecline}>Users located in Washington or Nevada must use this link to Decline All</LdsLink>
      </p>
    </>
  );
}
