import { forwardRef } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

// JSDoc type definitions
/**
 * @typedef LdsRadioProps
 * @property {string} id - HTML input element ID
 * @property {string} name - HTML input name
 * @property {string} value - HTML input value
 * @property {string|object} label - Text or a React fragment of inline HTML or JSX markup to display as label for the radio
 * @property {boolean} [required] - HTML input required property
 * @property {boolean} [disabled] - HTML input disabled property
 * @property {boolean} [error] - Property to set error state on radio. If radio is in a radio group the radio group error state should be set instead of the individual radios inside it.
 * @property {string} [labelClassName] - Optional custom user-defined CSS class(es) for the <label> element, will be appended to the list of any other component classes
 * @property {object} [labelAttributes] - Optional, define any additional non-prop attributes as object properties with values to be rendered on the component's <label> element.
 * @property {string} [className] - Optional custom user-defined CSS class(es) for the <input type="radio"> element, will be appended to the list of any other component classes
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Optional, define any additional non-prop attributes to be rendered on the component's <input type="radio"> element.
 */
const LdsRadio = forwardRef(
  /**
   * LdsRadio component
   * @param {LdsRadioProps & React.InputHTMLAttributes<HTMLInputElement>} props
   * @returns {React.JSX.Element}
   */
  function LdsRadio(
    {
      id,
      name,
      value,
      label,
      required = false,
      disabled = false,
      error = false,
      labelClassName,
      labelAttributes,
      className,
      ...rest
    },
    ref
  ) {
    return (
    <label
      id={`${id}_label`}
      htmlFor={id}
      className={cn(
        'lds-radio-label',
        {
          disabled,
        },
        labelClassName
      )}
      {...labelAttributes}
    >
      <input
        className={cn(
          'lds-radio',
          {
            disabled,
            error,
          },
          className
        )}
        id={id}
        required={required}
        type="radio"
        name={name}
        value={value}
        disabled={disabled}
        aria-invalid={error || null}
        aria-required={required || null}
        {...rest}
        ref={ref}
      />
      {label}
    </label>
    );
  }
);

LdsRadio.propTypes = {
  id: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  value: PropTypes.string.isRequired,
  label: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.object,
  ]).isRequired,
  required: PropTypes.bool,
  disabled: PropTypes.bool,
  error: PropTypes.bool,
  labelClassName: PropTypes.string,
  labelAttributes: PropTypes.object,
  className: PropTypes.string,
  rest: PropTypes.any,
};

export default LdsRadio;
