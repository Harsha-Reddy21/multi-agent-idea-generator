import { createContext } from 'react';

export const LdsDropdownContext = createContext({
  onItemSelect: () => {},
});

export default LdsDropdownContext;
