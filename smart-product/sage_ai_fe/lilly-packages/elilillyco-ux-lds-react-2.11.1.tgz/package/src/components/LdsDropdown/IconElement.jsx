import cn from 'classnames';
import LdsIcon from '../LdsIcon/index.jsx';

export default function IconElement({
  classes,
  icon,
  iconLabel,
  iconOnly,
  iconPosition,
}) {
  if (!icon) return '';

  return (
    <LdsIcon
      name={icon}
      className={cn(
        classes,
        {
          [`${iconPosition}`]: iconPosition && !iconOnly,
          'icon-only': iconOnly,
        }
      )}
      decorative
      inline
      label={iconLabel}
    />
  );
}
