import { useContext } from 'react';
import cn from 'classnames';
import { LdsDropdownContext } from './context.js';
import IconElement from './IconElement.jsx';

export default function Link({
  children,
  href,
  icon = undefined,
  iconLabel = undefined,
  iconOnly = false,
  iconPosition = 'after',
  onClick = () => {},
  className,
  ...rest
}) {
  const { onItemSelect } = useContext(LdsDropdownContext);
  const handleClick = (e) => {
    onClick(e);
    onItemSelect();
  };
  return (
    <a
      href={href}
      className={cn(
        'lds-dropdown-item',
        'lds-dropdown-item-link',
        className
      )}
      onClick={handleClick}
      {...rest}
    >
      {icon && iconPosition === 'before' && <IconElement
        classes="link-icon"
        icon={icon}
        iconLabel={iconLabel}
        iconOnly={iconOnly}
        iconPosition={iconPosition}
      />}
      {children}
      {icon && iconPosition === 'after' && <IconElement
        classes="link-icon"
        icon={icon}
        iconLabel={iconLabel}
        iconOnly={iconOnly}
        iconPosition={iconPosition}
      />}
    </a>
  );
}
