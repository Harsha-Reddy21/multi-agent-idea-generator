import cn from 'classnames';
import PropTypes from 'prop-types';
import {
  useId,
  useRef,
  useEffect,
  useState,
  useCallback
} from 'react';

import LdsIcon from '../LdsIcon/index.jsx';
import LdsDropdownContext from './context.js';

import handleTabAway from '../../util/handleTabAway.js';
import useClickOutside from '../../hooks/useClickOutside.js';
import getFocusableElements from '../../util/getFocusableElements.js';

import Link from './Link.jsx';
import Button from './Button.jsx';

// JSDoc type definitions
/**
 * @typedef LdsDropdownProps
 * @property {React.JSX.Element} [label] - Label to display on the dropdown button
 * @property {Object} buttonProps - Optional object of html attributes to apply to the button
 * @property {Object} dropdownProps - Optional object of html attributes to apply to the dropdown
 * @property {String} [icon] - Icon to display on the dropdown button
 * @property {boolean} [iconOnly] - Boolean value to set if the dropdown button should only display an icon
 * @property {boolean} [iconRotate] - Boolean value to set if the dropdown icon should be rotated when the dropdown is open
 * @property {Function} [onExpand] - Event that will be fired after the dropdown opens and its animation is complete
 * @property {Function} [onCollapse] - Event that will be fired after the dropdown closes and its animation is complete
 * @property {boolean} [autoFocusFirstItem] - Boolean value to to set if first focusable item in the dropdown should automatically be focused when the dropdown opens. Defaults to true.
 * @property {boolean} [showExpandIcon] - Boolean value to to show the expand chevron icon in the dropdown button. Defaults to true.
 * @property {boolean} [isOpen] - Boolean state value to set if the dropdown is open or closed.
 * @property {Function} [setIsOpen] - State function to set the isOpen value.
 * @property {string} [dropdownAlignment] - Optional override to force the dropdown to open left or right
 * @property {boolean} [keepOpenOnSelect] - Boolean value to set if the dropdown should close when an item is selected
 * @property {boolean} [arrowNavigation] - Boolean value to set if arrow key navigation should be enabled in the dropdown
 * @property {React.ReactNode} [children] - The children of the component to be displayed in the dropdown
 */
/**
 * LdsDropdown component
 * @param {LdsDropdownProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsDropdown({
  label,
  buttonProps = {},
  dropdownProps = {},
  icon = 'caret-down',
  iconOnly = false,
  iconRotate = true,
  wrapperProps = {},
  autoFocusFirstItem = true,
  showExpandIcon = true,
  enableTabAway = true,
  onExpand,
  onCollapse,
  dropdownAlignment,
  children,
  isOpen = false,
  setIsOpen = () => { },
  keepOpenOnSelect = false,
  arrowNavigation = false,
}) {
  // Filter className out of generic props oject to avoid potential overwrites
  const filteredButtonProps = { ...buttonProps };
  delete filteredButtonProps.className;
  delete filteredButtonProps.onClick;

  const filteredDropdownProps = { ...dropdownProps };
  delete filteredDropdownProps.className;

  const filteredWrapperProps = { ...wrapperProps };
  delete filteredWrapperProps.className;

  const dropdownId = useId();
  const [menuPosition, setMenuPosition] = useState('');

  const dropdownRef = useRef(null);
  const dropdownButtonRef = useRef(null);
  const wrapperRef = useClickOutside(() => {
    if (isOpen) setIsOpen(false);
  });

  const [isTransitionEnd, setIsTransitionEnd] = useState(false);

  /**
   * Keyboard navigation for dropdown options.
   *
   * When arrowNavigation is true:
   * - ArrowDown: Moves focus to the next option (loops to first if at end).
   * - ArrowUp: Moves focus to the previous option (loops to last if at start).
   * - Home: Moves focus to the first option.
   * - End: Moves focus to the last option.
   * - Enter/Space: Selects the focused option (triggers click) and closes the dropdown.
   * - Escape: Closes the dropdown and returns focus to the trigger.
   * - Tab: Closes the dropdown and allows focus to move to the next tabbable element in the DOM.
   *
   * This matches the WAI-ARIA Listbox pattern and ensures accessibility.
   *
   * When arrowNavigation is false, keyboard navigation is not handled, so
   * default tabbing behavior is preserved.
   */
  const handleKeyDown = (e) => {
    if (arrowNavigation) {
      const focusable = getFocusableElements(dropdownRef.current);
      const currentIndex = focusable.indexOf(document.activeElement);

      switch (e.key) {
        case 'ArrowDown':
          e.preventDefault();
          if (currentIndex === -1) {
            focusable[0]?.focus();
          } else {
            focusable[(currentIndex + 1) % focusable.length].focus();
          }
          break;
        case 'ArrowUp':
          e.preventDefault();
          if (currentIndex === -1) {
            focusable[0]?.focus();
          } else {
            focusable[(currentIndex - 1 + focusable.length) % focusable.length].focus();
          }
          break;
        case 'Home':
          e.preventDefault();
          focusable[0]?.focus();
          break;
        case 'End':
          e.preventDefault();
          focusable[focusable.length - 1]?.focus();
          break;
        case 'Enter':
        case ' ':
          if (currentIndex !== -1) {
            document.activeElement.click();
            e.preventDefault();
          }
          break;
        case 'Escape':
          setIsOpen(false);
          dropdownButtonRef.current?.focus();
          break;
        case 'Tab':
          setIsOpen(false);
          break;
        default:
          break;
      }
      return;
    }

    if (enableTabAway) {
      const callback = () => setIsOpen(false);
      handleTabAway(e, dropdownRef, callback);
    }
  };

  /*
    onExpand and onCollapse are optional function props that will be called after the
    dropdown opens or closes. Because the dropdown has an animation delay we wait for the
    transition to end before calling the functions. This can be used for something like focusing
    an element when the dd opens or closes.
  */
  useEffect(() => {
    const dropdownRefCurrent = dropdownRef.current;
    if (!dropdownRefCurrent) {
      return () => {};
    }

    const transitionCallback = () => {
      // Focus first focusable item in the dropdown if autoFocusFirstItem is enabled
      // This has to be done after the transition ends in order to work properly
      if (isOpen && autoFocusFirstItem) {
        const focusable = getFocusableElements(dropdownRef.current);
        if (!focusable || focusable.length === 0) return;

        focusable[0].focus();
      }

      if (isOpen && onExpand) onExpand();
      if (!isOpen && onCollapse) onCollapse();
      setIsTransitionEnd(isOpen);
    };

    dropdownRefCurrent.addEventListener('transitionend', transitionCallback);
    return () => {
      dropdownRefCurrent.removeEventListener('transitionend', transitionCallback);
    };
  }, [isOpen, onExpand, onCollapse, autoFocusFirstItem]);

  const detectEdges = useCallback(() => {
    /*
      Dropdown open direction logic:
      1. By default dropdowns open to the right.
      2. Check to see if the dropdown would go off the edge of the screen when opened. If it will - open in the other direction.
      4. See if the user has set a manual override. Use the override
    */
    const ddWrapper = wrapperRef.current;

    const ddBtn = ddWrapper.querySelector('.lds-dropdown-button');
    const dd = ddWrapper.querySelector('.lds-dropdown');

    const dropdownRect = ddBtn.getBoundingClientRect();
    const dropdownWidth = dd.offsetWidth;
    const screenWidth = document.body.clientWidth;

    const doesDropDownOverlapRightEdge = (dropdownRect.left + dropdownWidth) > screenWidth;
    let pos = 'right'; // default dropdown direction
    if (doesDropDownOverlapRightEdge) {
      pos = 'left';
    }
    // Hard coded override prop from user
    if (dropdownAlignment) pos = dropdownAlignment;
    setMenuPosition(pos);
  }, [dropdownAlignment, wrapperRef]);

  useEffect(() => {
    detectEdges();
  }, [detectEdges]);

  const openDropdown = () => {
    detectEdges();
    setIsOpen(true);
  };

  const handleClick = (e) => {
    if (isOpen) {
      setIsOpen(false);
    } else {
      openDropdown(e);
    }
    if (buttonProps.onClick) buttonProps.onClick(e, isOpen);
  };

  const handleItemSelect = () => {
    if (!keepOpenOnSelect) {
      setIsOpen(false);
      if (dropdownButtonRef.current) {
        dropdownButtonRef.current.focus();
      }
    }
  };

  return (
    <LdsDropdownContext.Provider value={{ onItemSelect: handleItemSelect }}>
      <div
        ref={wrapperRef}
        className={cn(
          'lds-dropdown-wrapper',
          wrapperProps?.className,
          {
            open: isOpen,
          }
        )}
        {...filteredWrapperProps}
      >
        <button
          type="button"
          ref={dropdownButtonRef}
          className={cn(
            'lds-button-base',
            'lds-dropdown-button',
            buttonProps?.className,
            {
              'icon-only': iconOnly,
            },
            {
              'icon-rotate': iconRotate,
            },
            {
              open: isOpen,
            }
          )}
          aria-expanded={isOpen}
          aria-controls={dropdownId}
          aria-haspopup={arrowNavigation ? 'listbox' : null}
          onClick={handleClick}
          {...filteredButtonProps}
        >
          {iconOnly
            ? showExpandIcon
              && <LdsIcon
                className="lds-dropdown-expand-icon"
                label={label}
                name={icon}
                inline
                decorative
              />
            : <>
              {label}
              {showExpandIcon
                && <LdsIcon
                  className="lds-dropdown-expand-icon"
                  name={icon}
                  inline
                  decorative
                />
              }
            </>
          }
        </button>
        <div
          id={dropdownId}
          ref={dropdownRef}
          className={cn(
            'lds-dropdown',
            dropdownProps?.className,
            {
              open: isOpen,
              left: menuPosition === 'left',
              right: menuPosition === 'right',
              'transition-end': isTransitionEnd,
            }
          )}
          inert={isOpen ? null : ''}
          aria-hidden={!isOpen}
          role={arrowNavigation ? 'listbox' : null}
          onKeyDown={handleKeyDown}
          {...filteredDropdownProps}
        >
          <div
            className="dropdown-inner-expandable"
          >
            {children}
          </div>
        </div>
      </div>
    </LdsDropdownContext.Provider>
  );
}

LdsDropdown.Link = Link;
LdsDropdown.Button = Button;

LdsDropdown.propTypes = {
  label: PropTypes.any.isRequired,
  buttonProps: PropTypes.object,
  dropdownProps: PropTypes.object,
  icon: PropTypes.string,
  iconOnly: PropTypes.bool,
  iconRotate: PropTypes.bool,
  wrapperProps: PropTypes.object,
  onExpand: PropTypes.func,
  onCollapse: PropTypes.func,
  dropdownAlignment: PropTypes.oneOf(['left', 'right']),
  keepOpenOnSelect: PropTypes.bool,
  arrowNavigation: PropTypes.bool,
};
