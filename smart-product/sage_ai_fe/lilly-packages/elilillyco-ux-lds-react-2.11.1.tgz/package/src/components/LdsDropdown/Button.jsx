import { useContext } from 'react';
import cn from 'classnames';
import { LdsDropdownContext } from './context.js';
import IconElement from './IconElement.jsx';

export default function Button({
  children,
  icon = undefined,
  iconLabel = undefined,
  iconOnly = false,
  iconPosition = 'after',
  onClick = () => {},
  className,
  ...rest
}) {
  const { onItemSelect } = useContext(LdsDropdownContext);
  const handleClick = (e) => {
    onClick(e);
    onItemSelect();
  };
  return (
    <button
      className={cn(
        'lds-button-base',
        'lds-dropdown-item',
        'lds-dropdown-item-button',
        className
      )}
      onClick={handleClick}
      {...rest}
    >
      {icon && iconPosition === 'before' && <IconElement
        classes="button-icon"
        icon={icon}
        iconLabel={iconLabel}
        iconOnly={iconOnly}
        iconPosition={iconPosition}
      />}
      {children}
      {icon && iconPosition === 'after' && <IconElement
        classes="button-icon"
        icon={icon}
        iconLabel={iconLabel}
        iconOnly={iconOnly}
        iconPosition={iconPosition}
      />}
    </button>
  );
}
