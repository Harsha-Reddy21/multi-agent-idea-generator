import PropTypes from 'prop-types';
import cn from 'classnames';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsDividerProps
 * @property {string} [type] - Type of divider. Options are 'primary' or 'secondary'
 * @property {string} [orientation] - Orientation of the divider. Options are 'horizontal' or 'vertical'
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 */
/**
 * LdsDivider component
 * @param {LdsDividerProps & React.InputHTMLAttributes<HTMLInputElement>} props - Component props
 * @returns {React.JSX.Element} - LdsDivider component
 */
function LdsDivider({
  type = 'primary',
  orientation = 'horizontal',
  className = undefined,
  ...rest
}) {
  if (type === 'secondary' || orientation === 'vertical') {
    return (
      <div
        className={cn(
          'lds-divider',
          type,
          orientation,
          className
        )}
        {...rest}
      ></div>
    );
  }
  return (
    <hr
      className={cn(
        'lds-divider',
        type,
        orientation,
        className
      )}
      {...rest}
    />
  );
}

export default LdsDivider;

LdsDivider.propTypes = {
  type: PropTypes.oneOf(['primary', 'secondary']),
  orientation: PropTypes.oneOf(['horizontal', 'vertical']),
  className: PropTypes.string,
};
