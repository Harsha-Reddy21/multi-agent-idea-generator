import { Children } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsIcon from '../LdsIcon/index.jsx';

// JSDoc type definitions
/**
 * @typedef LdsLinkProps
 * @property {React.ReactNode} children - The children of the component
 * @property {string} [targetAriaLabelContent] - The text that will be appended to the "automatic ARIA label" when the target attribute is set to describe the behavior for screen readers
 * @property {string} [ariaLabel] - Used to optionally specify the text value for the Link\'s aria-label attribute; overrides the "automatic ARIA label" feature
 * @property {string} [classes] - Add an optional space-delimited list of LDS button classes or any custom classes using this prop
 * @property {boolean} [clearDefaultClasses] - Whether the default LDS styling classes should be applied to the link
 * @property {boolean} [contextualIcon] - Whether the "Easy Icon" should have non-decorative context
 * @property {boolean} [disableAutoAriaLabel] - Whether the "automatic ARIA label" function should be disabled
 * @property {boolean} [disableAutoIcon] - Whether the automatic "Easy Icon" function should be disabled for "external" or "downloadable" flagged links
 * @property {boolean} [downloadable] - If the link HREF is set to a downloadble file URI, optionally set to true to enable the "Easy Icon" feature to render a "download" icon; also the "automatic ARIA label" feature will attempt to add the file's extension in parenthesis to the ARIA label content
 * @property {boolean} [external] - If the link HREF goes "off site" to another location on the web, optionally set to true to enable the "Easy Icon" feature to render an "external link" icon
 * @property {string} [href] - The value of the rendered anchor element\'s "href" attribute
 * @property {string} [icon] - Optionally set a truthy string value to enable the "Easy Icon" function; the value must be the name of a valid LDS Icon; overrides all automatic Easy Icon defaults
 * @property {string} [iconClasses] - Used to add an optional space-delimited list of CSS classes to add to the "Easy Icon" LDS Icon element
 * @property {string} [iconDescription] - Used to add an optional text description of the icon in context to be added to the "Easy Icon" SVG element's "desc" tag
 * @property {string} [iconFill] - Used to add an optional CSS color value to change the fill color of the "Easy Icon"; when not set the icon inherits the link's color value
 * @property {string} [iconLabel] - Used to add an optional label of the icon in context to be added to the "Easy Icon" SVG element's "title" tag; when not set the icon name is used
 * @property {boolean} [iconOnly] - Whether the "Easy Icon" will be the only content in the link
 * @property {string} [iconPosition] - Whether the "Easy Icon" should be rendered before or after the default content; must be one 'after' or 'before'
 * @property {string} [mode] - Configures whether the link's rendered style will be as an inline text link or an inline-block LDS Button; must be one 'link' or 'button'
 * @property {function} [onClick] - The click event handler
 * @property {string} [target] - The value of the target attribute of the link; default when undefined is actually '_self', but no attribute is rendered unless set explicitly by prop; per HTML spec the value of the prop must be '_self', '_blank', '_parent', or '_top'
 * @property {string} [styleClass] - Optional; Set a string value for the style classes; valid values are 'standalone' and 'no-underline'.
 * @property {boolean} [useIcon] - Whether to explcitly enable the "Easy Icon" feature; overrides the "disableAutoIcon" prop
 * @property {string} [className] - Optional custom user-defined CSS class(es) to add to the component root container element; will be appended to the list of any other component classes
 */
/**
 * LdsLink component
 * @param {LdsLinkProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsLink({
  children,
  ariaLabel = undefined,
  classes = undefined,
  clearDefaultClasses = false,
  contextualIcon = false,
  disableAutoAriaLabel = false,
  disableAutoIcon = false,
  downloadable = false,
  external = false,
  href = undefined,
  icon = undefined,
  iconClasses = undefined,
  iconDescription = undefined,
  iconFill = undefined,
  iconLabel = undefined,
  iconOnly = false,
  iconPosition = 'after',
  mode = 'link',
  onClick,
  target = undefined,
  targetAriaLabelContent = '(opens in a new tab)',
  useIcon = false,
  styleClass = '',
  className,
  ...rest
}) {
  // Determine whether to display an "Easy Icon"
  // Note that "disableAutoIcon" only functions when downloadable or external are set
  // Using the "useIcon" prop should force the icon to appear
  let displayIcon = false;
  if (useIcon || (downloadable && !disableAutoIcon) || (external && !disableAutoIcon)) displayIcon = true;

  const IconElement = () => {
    // Render nothing if no icon should be displayed
    if (!displayIcon) return '';

    // Otherwise, Get icon to use
    // Default to Link so that something always renders
    let name = 'Link';
    // If the link is flagged external, default to the "external link" icon
    if (external) name = 'ArrowSquareOut';
    // If the link is fladded downloadable, default to the "download" icon (supersedes "external")
    if (downloadable) name = 'DownloadSimple';
    // If the icon name is specified, use that (supersedes all defaults)
    if (icon) name = icon;

    let usePositionClass = true;
    if (iconOnly) usePositionClass = false;

    // Render the LDS Icon element (uses the base package web component)
    return (
      <LdsIcon
        name={name}
        className={cn(
          mode === 'button' ? 'button-icon' : 'link-icon',
          {
            [`${iconPosition}`]: usePositionClass,
            [`${iconClasses}`]: iconClasses,
          }
        )}
        decorative={contextualIcon}
        description={iconDescription}
        fill={iconFill}
        inline
        label={iconLabel}
      />
    );
  };

  // Discern a file type extension value from the link HREF when flagged as downloadable
  let downloadableFileType;
  if (downloadable) {
    const filePathParts = href.split('.');
    if (filePathParts.length > 1) {
      downloadableFileType = `(${filePathParts.pop().toUpperCase()})`;
    }
  }

  const DownloadableExtension = () => {
    if (!downloadable || !downloadableFileType) return '';
    return (
      <span className="lds-link-downloadable-file-ext">
        &nbsp;{downloadableFileType}
      </span>
    );
  };

  // Attempt to auto-generate a good aria-label attribute from the React children object
  // And any other relevant component prop settings
  // If no linkText is found, no auto aria-label value will be set and the aria-label attribute will not be rendered
  // Also if, by explicit props the auto aria-label function is disabled OR the developer specifies ARIA label content, this will be skipped
  let autoMagicAriaLabel;
  if (!disableAutoAriaLabel && !ariaLabel) {
    // Attempt to get the link text
    // Loops through each element of the React "children" object
    // Plain text children have no type (undefined) so this assumes a falsey child type is plain text
    // Concatenates all found plain text elements together
    let linkText;
    Children.forEach(children, (child) => {
      if (!child.type) {
        if (!linkText) {
          linkText = child;
        } else {
          linkText += ` ${child}`;
        }
      }
    });
    // If there was discernable Link Text then handle other relevant prop modifiers
    if (linkText) {
      // Set the text content
      autoMagicAriaLabel = linkText;
      // Append the downloadable file's extension from the HREF if it can be discerned
      if (downloadable && downloadableFileType) {
        autoMagicAriaLabel += ` ${downloadableFileType}`;
      }
      // Append the target context content when the target is set
      if (target) autoMagicAriaLabel += ` ${targetAriaLabelContent}`;
    }
  }
  // If explcit ARIA label content is defined by the user, always render that instead
  if (ariaLabel) autoMagicAriaLabel = ariaLabel;

  // Render the link
  return (
    <a
      onClick={onClick}
      href={href}
      className={cn(
        {
          'lds-link': mode !== 'button' && !clearDefaultClasses,
          'lds-button': mode === 'button' && !clearDefaultClasses,
          [`${classes}`]: classes,
          'icon-only': iconOnly,
        },
        styleClass,
        className
      )}
      target={target}
      aria-label={autoMagicAriaLabel}
      {...rest}
    >
      {displayIcon && iconPosition === 'before' && <IconElement />}
      {children}
      {downloadable && <DownloadableExtension />}
      {displayIcon && iconPosition === 'after' && <IconElement />}
    </a>
  );
}

LdsLink.propTypes = {
  ariaLabel: PropTypes.string,
  classes: PropTypes.string,
  clearDefaultClasses: PropTypes.bool,
  contextualIcon: PropTypes.bool,
  disableAutoAriaLabel: PropTypes.bool,
  disableAutoIcon: PropTypes.bool,
  downloadable: PropTypes.bool,
  external: PropTypes.bool,
  href: PropTypes.string,
  icon: PropTypes.string,
  iconClasses: PropTypes.string,
  iconDescription: PropTypes.string,
  iconFill: PropTypes.string,
  iconLabel: PropTypes.string,
  iconPosition: PropTypes.oneOf(['before', 'after']),
  mode: PropTypes.oneOf(['link', 'button']),
  styleClass: PropTypes.string,
  target: PropTypes.oneOf(['_self', '_blank', '_parent', '_top']),
  targetAriaLabelContent: PropTypes.string,
  useIcon: PropTypes.bool,
};
