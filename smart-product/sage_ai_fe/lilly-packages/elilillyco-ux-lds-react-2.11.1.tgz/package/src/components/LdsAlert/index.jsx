import { useState, useRef, useId } from 'react';
import { CSSTransition } from 'react-transition-group';
import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsIcon from '../LdsIcon/index.jsx';
import { kebabToPascal } from '../../util/caseUtils.js';
import { duration } from '../../util/motion.js';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsAlertProps
 * @property {string} level - Set the alert "level" which determines the color and icon which will be used. Accepts: info, success, warning, error
 * @property {React.ReactNode} [children] - Optional children
 * @property {boolean} [dismissible] - Whether an inline alert will be dismissible (have the close icon)
 * @property {string} [iconName] - Name of the phosphor icon; instead of the default icon for the specified level of the alert
 * @property {string} [id] - ID to assign to alert
 * @property {boolean} [inline] - Whether the alerts display inline
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {function} [onClose] - Function to be called after alert is dismissed
*/
/**
 * LdsAlert component
 * @param {LdsAlertProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsAlert component
 */
function LdsAlert({
  level = 'info',
  children,
  dismissible = false,
  iconName,
  id,
  inline = false,
  className = '',
  onClose = () => {},
  ...rest
}) {
  const [isShowing, setIsShowing] = useState(true);
  const nodeRef = useRef(null);
  const alertId = useId();

  const getAlertIconName = () => {
    let icon = '';
    switch (level) {
      case ('warning'):
        icon = 'warning-fill';
        break;
      case ('success'):
        icon = 'check-circle-fill';
        break;
      case ('error'):
        icon = 'warning-circle-fill';
        break;
      default:
        icon = 'info-fill';
    }
    return iconName || icon;
  };

  const handleClose = () => {
    setIsShowing(false);
    onClose();
  };

  const AlertIconElement = () => {
    if (!level) return '';
    return (
      <LdsIcon
        className="lds-alert-icon"
        name={getAlertIconName()}
        label={`${kebabToPascal(level)}`}
        inline
      />
    );
  };

  const AlertCloseIcon = () => {
    if (!inline || dismissible) {
      return (
        <button className="lds-button-base lds-alert-button" onClick={handleClose}>
          <LdsIcon label="close" name="X" inline />
        </button>
      );
    }
    return '';
  };

  return (
    <CSSTransition
      in={isShowing}
      nodeRef={nodeRef}
      timeout={duration.medium}
      classNames="disappear"
      unmountOnExit
    >
      <div
        id={id || `alert-${alertId}`}
        className={cn(
          'lds-alert',
          `${level}`,
          {
            inline,
          },
          className
        )}
        ref={nodeRef}
        role="alert"
        aria-live="polite"
        {...rest}
      >
        <div className="lds-alert-content">
          <AlertIconElement />
          <div className="lds-alert-message">
            {children}
          </div>
          <AlertCloseIcon />
        </div>
      </div>
    </CSSTransition>
  );
}

export default LdsAlert;

LdsAlert.propTypes = {
  dismissible: PropTypes.bool,
  iconName: PropTypes.string,
  id: PropTypes.string,
  inline: PropTypes.bool,
  level: PropTypes.oneOf(['info', 'warning', 'error', 'success']),
};
