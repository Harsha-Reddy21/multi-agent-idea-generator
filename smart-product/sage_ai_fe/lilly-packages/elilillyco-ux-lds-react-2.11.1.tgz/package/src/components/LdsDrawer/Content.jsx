import { forwardRef, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import useMergeRefs from '../../hooks/useMergeRefs.js';
import { useOverflow } from './hook/useOverflow.jsx';

// JSdoc type definitions
/**
 * @typedef ContentProps
 * @property {React.ReactNode} children - Child elements
 * @property {string} [className] - Additional CSS classes
 */
const Content = forwardRef(
  /**
  * Content sub-component for LdsDrawer
  * @param {ContentProps} props - Component props
  * @param {React.ForwardedRef<HTMLDivElement>} ref - Forwarded ref
  * @returns {React.JSX.Element} - The rendered drawer HTML
  */
  function Content({
    children,
    className,
    ...props
  }, ref) {
    const localRef = useRef(null);
    const composedRef = useMergeRefs(ref, localRef);

    const {
      refYOverflowing,
      refYScrollStart,
      refYScrollEnd,
    } = useOverflow(localRef);

    useEffect(() => {
      const node = localRef.current;
      if (!node) return;
      const sidenav = node.closest('.lds-sidenav-product');
      if (!sidenav) return;

      // Calculate scrollbar width once on mount
      const calculateScrollbarWidth = () => {
        const outer = document.createElement('div');
        outer.style.visibility = 'hidden';
        outer.style.overflow = 'scroll';
        outer.style.width = '100px';
        document.body.appendChild(outer);

        const inner = document.createElement('div');
        inner.style.width = '100%';
        outer.appendChild(inner);

        const scrollbarWidth = outer.offsetWidth - inner.offsetWidth;
        document.body.removeChild(outer);

        sidenav.style.setProperty('--lds-spacing-sidenav-mobile-scrollbar-width', `${scrollbarWidth}px`);
      };

      calculateScrollbarWidth();
    }, []);

    return (
      <div
        ref={composedRef}
        className={cn(
          'lds-drawer-product-content',
          className
        )}
        data-y-overflow={refYOverflowing}
        data-y-overflow-start={refYScrollStart}
        data-y-overflow-end={refYScrollEnd}
        {...props}
      >
        {children}
      </div>
    );
  }
);

Content.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
};

export default Content;
