import { useContext } from 'react';
import { DrawerContext } from '../context/DrawerContext.jsx';

// JSdoc type definitions
/**
 * Hook to access and control the drawer state
 * @returns {import('../context/DrawerContext').DrawerContext}
 * @throws {Error} When used outside of LdsDrawer.Provider on client-side
 */
export const useDrawerContext = () => {
  const context = useContext(DrawerContext);

  if (!context) {
    throw new Error('useDrawer must be used within a LdsDrawer.Provider');
  }

  return context;
};
