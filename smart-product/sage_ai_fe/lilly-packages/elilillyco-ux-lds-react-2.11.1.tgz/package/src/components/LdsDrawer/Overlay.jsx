import { forwardRef, useCallback } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import { useDrawerContext } from './hook/useDrawerContext.jsx';
import useMergeRefs from '../../hooks/useMergeRefs.js';

// JSdoc type definitions
/**
 * @typedef OverlayProps
 * @property {string} [className] - Additional CSS classes
 * @property {(event: React.MouseEvent<HTMLButtonElement>) => void} [onClick] - Click handler
 */
const Overlay = forwardRef(
  /**
  * Overlay sub-component for LdsDrawer
  * @param {OverlayProps} props - Component props
  * @param {React.ForwardedRef<HTMLDivElement>} ref - Forwarded ref
  * @returns {React.JSX.Element} - The rendered drawer overlay HTML
  */
  function Overlay({
    className,
    onClick,
    ...props
  }, ref) {
    const {
      overlayRef,
      variant,
      open,
      toggleDrawer,
      isMounted,
    } = useDrawerContext();
    const composedRef = useMergeRefs(ref, overlayRef);

    const handleClose = useCallback((e) => {
      if (onClick) onClick(e);
      toggleDrawer();
    }, [onClick, toggleDrawer]);

    if (variant !== 'modal') return null;
    if (!open && !isMounted) return null;

    return isMounted && (
      <div
        ref={composedRef}
        className={cn(
          'lds-drawer-product-overlay',
          className
        )}
        onClick={handleClose}
        data-state={open ? 'open' : 'closed'}
        aria-hidden="true"
        {...props}
      />
    );
  }
);

Overlay.propTypes = {
  className: PropTypes.string,
  onClick: PropTypes.func,
};

export default Overlay;
