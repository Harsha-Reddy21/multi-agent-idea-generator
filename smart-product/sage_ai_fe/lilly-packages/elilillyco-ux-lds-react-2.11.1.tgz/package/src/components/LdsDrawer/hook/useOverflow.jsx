import { useState, useEffect } from 'react';

/**
 * A custom hook to detect overflow and scroll positions of a referenced element.
 * @param {React.RefObject<HTMLElement>} ref - The ref of the element to check for overflow.
 * @returns {{
 *   refXOverflowing: boolean,
 *   refYOverflowing: boolean,
 *   refXScrollStart: boolean,
 *   refXScrollEnd: boolean,
 *   refYScrollStart: boolean,
 *   refYScrollEnd: boolean
 * }} - The overflow and scroll status of the element.
 */
export function useOverflow(ref) {
  const [refXOverflowing, setRefXOverflowing] = useState(false);
  const [refYOverflowing, setRefYOverflowing] = useState(false);
  const [refXScrollStart, setRefXScrollStart] = useState(true);
  const [refXScrollEnd, setRefXScrollEnd] = useState(false);
  const [refYScrollStart, setRefYScrollStart] = useState(true);
  const [refYScrollEnd, setRefYScrollEnd] = useState(false);

  useEffect(() => {
    if (!ref?.current) {
      return () => {};
    }

    const node = ref.current;

    const checkOverflow = () => {
      const isXOverflowing = node.scrollWidth > node.clientWidth;
      const isYOverflowing = node.scrollHeight > node.clientHeight;

      setRefXOverflowing(isXOverflowing);
      setRefYOverflowing(isYOverflowing);

      const offsetRight = node.scrollWidth - node.clientWidth;
      const offsetBottom = node.scrollHeight - node.clientHeight;

      setRefXScrollEnd(node.scrollLeft >= offsetRight);
      setRefXScrollStart(node.scrollLeft === 0);

      setRefYScrollEnd(node.scrollTop >= offsetBottom);
      setRefYScrollStart(node.scrollTop === 0);
    };

    const handleScroll = () => {
      checkOverflow();
    };

    const resizeObserver = new ResizeObserver(() => {
      checkOverflow();
    });

    resizeObserver.observe(node);
    node.addEventListener('scroll', handleScroll);
    checkOverflow();

    return () => {
      resizeObserver.disconnect();
      node.removeEventListener('scroll', handleScroll);
    };
  }, [ref]);

  return {
    refXOverflowing,
    refYOverflowing,
    refXScrollStart,
    refXScrollEnd,
    refYScrollStart,
    refYScrollEnd,
  };
}

export default useOverflow;
