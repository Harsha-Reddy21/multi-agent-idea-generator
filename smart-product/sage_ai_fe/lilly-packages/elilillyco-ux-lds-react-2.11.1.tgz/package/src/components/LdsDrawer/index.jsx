import Provider from './Provider.jsx';
import PushContent from './PushContent.jsx';
import ToggleButton from './ToggleButton.jsx';
import Portal from './Portal.jsx';
import Overlay from './Overlay.jsx';
import Drawer from './Drawer.jsx';
import Header from './Header.jsx';
import Footer from './Footer.jsx';
import Content from './Content.jsx';
import CloseButton from './CloseButton.jsx';
import Title from './Title.jsx';
import Description from './Description.jsx';

const LdsDrawer = Drawer;

Drawer.Provider = Provider;
Drawer.ToggleButton = ToggleButton;
Drawer.PushContent = PushContent;
Drawer.Portal = Portal;
Drawer.Overlay = Overlay;
Drawer.Header = Header;
Drawer.Footer = Footer;
Drawer.Content = Content;
Drawer.CloseButton = CloseButton;
Drawer.Title = Title;
Drawer.Description = Description;

Drawer.displayName = 'LdsDrawer';
Drawer.Provider.displayName = 'LdsDrawer.Provider';
Drawer.ToggleButton.displayName = 'LdsDrawer.ToggleButton';
Drawer.PushContent.displayName = 'LdsDrawer.PushContent';
Drawer.Portal.displayName = 'LdsDrawer.Portal';
Drawer.Overlay.displayName = 'LdsDrawer.Overlay';
Drawer.Header.displayName = 'LdsDrawer.Header';
Drawer.Footer.displayName = 'LdsDrawer.Footer';
Drawer.Content.displayName = 'LdsDrawer.Content';
Drawer.CloseButton.displayName = 'LdsDrawer.CloseButton';
Drawer.Title.displayName = 'LdsDrawer.Title';
Drawer.Description.displayName = 'LdsDrawer.Description';

export default LdsDrawer;
