import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
import { useDrawerContext } from './hook/useDrawerContext.jsx';

// JSdoc type definitions
/**
 * Portal sub-component for LdsDrawer
 * @param {React.ReactNode} children - The content to be portaled
 * @returns {React.ReactPortal | null} - The portal or null if no container is found
 */
const Portal = ({ children }) => {
  const { container } = useDrawerContext();

  const portalContainer = container || document.body;

  if (!portalContainer) {
    return null;
  }

  return ReactDOM.createPortal(children, portalContainer);
};

Portal.propTypes = {
  children: PropTypes.node.isRequired,
};

export default Portal;
