import {
  useState, useCallback, useEffect, useMemo, useRef, useId
} from 'react';
import PropTypes from 'prop-types';
import { DrawerContext } from './context/DrawerContext.jsx';

// JSdoc type definitions
/**
 * @typedef ProviderProps
 * @property {React.ReactNode} children - Child elements
 * @property {boolean} [defaultOpen=false] - Default open state
 * @property {boolean} [open] - Controlled open state of the drawer
 * @property {(open: boolean) => void} [onOpenChange] - Controlled open state change handler
 * @property {React.RefObject<HTMLElement>} container - Specify a container element to portal the drawer into
 * @property {'overlay'|'modal'} [variant='modal'] - The modality of the drawer
 * @property {'top'|'right'|'bottom'|'left'} [direction='left'] - Direction of the drawer
 * @property {(open: boolean) => void} [onAnimationEnd] - Gets triggered after the open or close animation ends
 * @property {string} [drawerId] - Id of the drawer container
 * @property {string} [labelledById] - Id of the drawer title/label
 * @property {string} [describedById] - Id of the drawer description
 */
/**
 * Provider sub-component for LdsDrawer
 * @param {ProviderProps} props - Component props
 */
const Provider = ({
  children,
  defaultOpen = false,
  open: controlledOpen,
  onOpenChange,
  container,
  variant = 'modal',
  direction = 'left',
  onAnimationEnd,
  drawerId: propDrawerId,
  labelledById: propLabelledById,
  describedById: propDescribedById,
}) => {
  const overlayRef = useRef(null);
  const drawerRef = useRef(null);

  const generatedDrawerId = useId();
  const generatedLabelledById = useId();
  const generatedDescribedById = useId();

  const drawerId = propDrawerId || generatedDrawerId;
  const labelledById = propLabelledById || generatedLabelledById;
  const describedById = propDescribedById || generatedDescribedById;

  const [uncontrolledOpen, setUncontrolledOpen] = useState(defaultOpen);
  const [isMounted, setIsMounted] = useState(defaultOpen);
  const open = controlledOpen ?? uncontrolledOpen;

  useEffect(() => {
    if (open && variant === 'modal') {
      document.body.setAttribute('data-scroll-locked', 'true');
    } else {
      document.body.removeAttribute('data-scroll-locked');
    }

    return () => {
      document.body.removeAttribute('data-scroll-locked');
    };
  }, [open, variant]);

  useEffect(() => {
    if (open && !isMounted) {
      if (onAnimationEnd) onAnimationEnd(open);
      setIsMounted(true);
      return undefined;
    }

    if (!open && isMounted) {
      const handleAnimationEnd = () => {
        if (onAnimationEnd) onAnimationEnd(open);
        setIsMounted(false);
      };

      const drawerElement = drawerRef.current;
      if (drawerElement) {
        drawerElement.addEventListener('animationend', handleAnimationEnd);
      }

      return () => {
        if (drawerElement) {
          drawerElement.removeEventListener('animationend', handleAnimationEnd);
        }
      };
    }

    return undefined;
  }, [open, isMounted, onAnimationEnd]);

  const setOpen = useCallback((newOpen) => {
    if (onOpenChange) {
      onOpenChange(newOpen);
    } else {
      setUncontrolledOpen(newOpen);
    }
  }, [onOpenChange]);

  const toggleDrawer = useCallback(() => {
    setUncontrolledOpen((prevOpen) => {
      const newOpen = !prevOpen;
      setOpen(newOpen);
      return newOpen;
    });
  }, [setOpen]);

  const value = useMemo(() => ({
    open,
    onOpenChange: setOpen,
    variant,
    container,
    direction,
    drawerRef,
    overlayRef,
    toggleDrawer,
    isMounted,
    drawerId,
    labelledById,
    describedById,
  }), [
    open,
    setOpen,
    variant,
    direction,
    container,
    describedById,
    drawerId,
    labelledById,
    toggleDrawer,
    isMounted,
  ]);

  return (
    <DrawerContext.Provider value={value}>
      {children}
    </DrawerContext.Provider>
  );
};

Provider.propTypes = {
  children: PropTypes.node.isRequired,
  defaultOpen: PropTypes.bool,
  open: PropTypes.bool,
  onOpenChange: PropTypes.func,
  container: PropTypes.oneOfType([
    (props, propName, componentName) => {
      const value = props[propName];
      if (value !== null && typeof window !== 'undefined' && !(value instanceof HTMLElement)) {
        return new Error(
          `Invalid prop '${propName}' supplied to '${componentName}'. Expected HTMLElement or null.`
        );
      }
      return undefined;
    },
    PropTypes.oneOf([null]),
  ]),
  variant: PropTypes.oneOf(['overlay', 'modal']),
  direction: PropTypes.oneOf(['top', 'right', 'bottom', 'left']),
  onAnimationEnd: PropTypes.func,
  drawerId: PropTypes.string,
  labelledById: PropTypes.string,
  describedById: PropTypes.string,
};

export default Provider;
