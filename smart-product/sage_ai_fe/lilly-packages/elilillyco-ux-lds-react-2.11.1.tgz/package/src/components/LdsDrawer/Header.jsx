import { forwardRef } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

// JSdoc type definitions
/**
 * @typedef HeaderProps
 * @property {React.ReactNode} children - Child elements
 * @property {string} [className] - Additional CSS classes
 */
const Header = forwardRef(
  /**
  * Header sub-component for LdsDrawer
  * @param {HeaderProps} props - Component props
  * @param {React.ForwardedRef<HTMLDivElement>} ref - Forwarded ref
  * @returns {React.JSX.Element} - The rendered drawer HTML
  */
  function Header({
    children,
    className,
    ...props
  }, ref) {
    return (
      <div
        ref={ref}
        className={cn(
          'lds-drawer-product-header',
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);

Header.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
};

export default Header;
