import {
  useEffect, useRef, cloneElement, forwardRef
} from 'react';
import PropTypes from 'prop-types';
import { useDrawerContext } from '../hook/useDrawerContext.jsx';

// JSdoc type definitions
/**
 * @typedef FocusTrapProps
 * @property {React.ReactNode} children - Child elements to trap focus within
 * @property {boolean} [active=true] - Whether the focus trap is active
 * @property {React.RefObject<HTMLElement>} [initialFocus] - Element to focus when trap activates
 */
const FocusTrap = forwardRef(
  /**
   * FocusTrap component that keeps focus within its children when active
   * @param {FocusTrapProps} props - Component props
   */
  function FocusTrap({
    children,
    active = true,
    initialFocus,
  }, ref) {
    const { open, toggleDrawer } = useDrawerContext();
    const rootRef = useRef(null);
    const previousFocusRef = useRef(null);

    useEffect(() => {
      if (!open || !active) return undefined;

      previousFocusRef.current = document.activeElement;

      const focusTarget = initialFocus?.current || getFocusableElements(rootRef.current)[0];
      if (focusTarget) focusTarget.focus();

      return () => {
        if (previousFocusRef.current instanceof HTMLElement) {
          previousFocusRef.current.focus();
        }
      };
    }, [open, active, initialFocus]);

    useEffect(() => {
      if (!open || !active) return undefined;

      const handleKeyDown = (event) => {
        if (event.key === 'Escape') toggleDrawer();
      };

      document.addEventListener('keydown', handleKeyDown);
      return () => document.removeEventListener('keydown', handleKeyDown);
    }, [open, active, toggleDrawer]);

    const setComposedRef = (node) => {
      rootRef.current = node;

      if (typeof ref === 'function') {
        ref(node);
      } else if (ref) {
        Object.defineProperty(ref, 'current', {
          value: node,
          configurable: true,
        });
      }

      if (children.ref) {
        if (typeof children.ref === 'function') {
          children.ref(node);
        } else {
          Object.defineProperty(children.ref, 'current', {
            value: node,
            configurable: true,
          });
        }
      }
    };

    return (
      <>
        {cloneElement(children, { ref: setComposedRef })}
      </>
    );
  }
);

FocusTrap.propTypes = {
  children: PropTypes.node.isRequired,
  active: PropTypes.bool,
  initialFocus: PropTypes.shape({
    current: (props, propName, componentName) => {
      const value = props[propName];
      if (value !== null && typeof window !== 'undefined' && !(value instanceof Element)) {
        return new Error(
          `Invalid prop '${propName}' supplied to '${componentName}'. Expected Element or null.`
        );
      }
      return undefined;
    },
  }),
};

/**
 * Gets all focusable elements within a container element
 * @param {HTMLElement} container - Container element to search within
 * @returns {HTMLElement[]} Array of focusable elements
 */
function getFocusableElements(container) {
  if (!container) return [];

  const focusableSelectors = [
    'button:not([disabled])',
    '[href]',
    'input:not([disabled])',
    'select:not([disabled])',
    'textarea:not([disabled])',
    '[tabindex]:not([tabindex="-1"])',
    '[contenteditable]',
  ];

  const elements = container.querySelectorAll(focusableSelectors.join(','));
  return Array.from(elements).filter(el => {
    let current = el;
    while (current) {
      if (window.getComputedStyle(current).display === 'none') return false;
      current = current.parentElement;
    }
    return true;
  });
}

export default FocusTrap;
