import { forwardRef } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import LdsButton from '../LdsButton/index.jsx';
import { useDrawerContext } from './hook/useDrawerContext.jsx';

// JSdoc type definitions
/**
 * @typedef ToggleButtonProps
 * @property {string} [className] - Additional CSS classes
 * @property {string} [iconCollapsed] - Icon (phosphor set) to show when drawer is collapsed
 * @property {string} [iconExpanded] - Icon (phosphor set) to show when drawer is expanded
 * @property {string} label - Accessible name for button
 * @property {string} [onClick] - Click handler
 */
const ToggleButton = forwardRef(
  /**
  * ToggleButton sub-component for LdsDrawer
  * @param {ToggleButtonProps} props - Component props
  * @param {React.ForwardedRef<HTMLDivElement>} ref - Forwarded ref
  * @returns {React.JSX.Element} - The rendered drawer HTML
  */
  function ToggleButton({
    className,
    iconCollapsed = 'list',
    iconExpanded = 'star',
    label,
    onClick,
    ...props
  }, ref) {
    const { open, toggleDrawer, drawerId } = useDrawerContext();

    const handleClick = (e) => {
      if (onClick) onClick(e);
      toggleDrawer();
    };

    return (
      <LdsButton
        ref={ref}
        className={cn(
          'action-ghost compact',
          'lds-drawer-product-toggle-button',
          className
        )}
        icon={open ? iconExpanded : iconCollapsed}
        iconOnly
        onClick={handleClick}
        aria-label={label || undefined}
        aria-haspopup="dialog"
        aria-expanded={open ? 'expanded' : 'collapsed'}
        aria-controls={drawerId}
        {...props}
      />
    );
  }
);

ToggleButton.propTypes = {
  className: PropTypes.string,
  iconCollapsed: PropTypes.string,
  iconExpanded: PropTypes.string,
  label: PropTypes.string.isRequired,
  onClick: PropTypes.func,
};

export default ToggleButton;
