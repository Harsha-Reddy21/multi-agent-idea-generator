import { createContext } from 'react';

// JSdoc type definitions
/**
 * @typedef {object} DrawerContextValue
 * @property {React.RefObject<HTMLDivElement>} drawerRef - Ref for the drawer element
 * @property {React.RefObject<HTMLDivElement>} overlayRef - Ref for the overlay element
 * @property {boolean} open - Current open state of the drawer
 * @property {(open: boolean) => void} onOpenChange - Function to update open state
 * @property {React.RefObject<HTMLElement>} container - Specify a container element to portal the drawer into
 * @property {'top'|'right'|'bottom'|'left'} direction='left' - Direction of the drawer
 * @property {'floating'|'modal'} variant='modal' - The modality of the drawer
 * @property {() => void} toggleDrawer - Function to toggle the drawer state
 * @property {boolean} isMounted - Id of the drawer container
 * @property {string} drawerId - Id of the drawer container
 * @property {string} labelledById - Id of the drawer title/label
 * @property {string} describedById - Id of the drawer description
 */
/** @type {React.Context<DrawerContextValue>} */
export const DrawerContext = createContext({
  drawerRef: { current: null },
  overlayRef: { current: null },
  open: false,
  onOpenChange: () => {},
  container: null,
  direction: 'left',
  variant: 'modal',
  toggleDrawer: () => {},
  isMounted: false,
  drawerId: null,
  labelledById: null,
  describedById: null,
});
