import { forwardRef } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import LdsButton from '../LdsButton/index.jsx';
import { useDrawerContext } from './hook/useDrawerContext.jsx';

// JSdoc type definitions
/**
 * @typedef CloseButtonProps
 * @property {string} [className] - Additional CSS classes
 * @property {string} [closeIcon] - Icon (phosphor set) to show when drawer is expanded
 * @property {string} label - Accessible name for button
 * @property {string} [onClick] - Click handler
 */
const CloseButton = forwardRef(
  /**
  * CloseButton sub-component for LdsDrawer
  * @param {CloseButtonProps} props - Component props
  * @param {React.ForwardedRef<HTMLDivElement>} ref - Forwarded ref
  * @returns {React.JSX.Element} - The rendered drawer HTML
  */
  function CloseButton({
    className,
    closeIcon = 'x',
    label,
    onClick,
    ...props
  }, ref) {
    const { toggleDrawer, drawerId } = useDrawerContext();

    const handleClick = (e) => {
      if (onClick) onClick(e);
      toggleDrawer();
    };

    return (
      <LdsButton
        ref={ref}
        className={cn(
          'action-ghost compact',
          'lds-drawer-product-close-button',
          className
        )}
        icon={closeIcon}
        iconOnly
        onClick={handleClick}
        aria-label={label || undefined}
        aria-controls={drawerId}
        {...props}
      />
    );
  }
);

CloseButton.propTypes = {
  className: PropTypes.string,
  closeIcon: PropTypes.string,
  label: PropTypes.string.isRequired,
  onClick: PropTypes.func,
};

export default CloseButton;
