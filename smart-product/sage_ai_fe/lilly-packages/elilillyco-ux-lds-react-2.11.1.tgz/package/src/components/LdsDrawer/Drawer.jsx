import { forwardRef } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';
import { useDrawerContext } from './hook/useDrawerContext.jsx';
import useMergeRefs from '../../hooks/useMergeRefs.js';
import FocusTrap from './util/FocusTrap.jsx';

// JSdoc type definitions
/**
 * @typedef DrawerProps
 * @property {React.ReactNode} children - Child elements
 * @property {string} [className] - Additional CSS classes
 */
const Drawer = forwardRef(
  /**
  * LdsDrawer component
  * @param {DrawerProps} props - Component props
  * @param {React.ForwardedRef<HTMLDivElement>} ref - Forwarded ref
  * @returns {React.JSX.Element} - The rendered drawer HTML
  */
  function Drawer({
    children,
    className,
    ...props
  }, ref) {
    const {
      drawerRef,
      open,
      variant,
      direction,
      isMounted,
      drawerId,
      labelledById,
      describedById,
    } = useDrawerContext();
    const composedRef = useMergeRefs(ref, drawerRef);

    if (!open && !isMounted) return null;

    return isMounted && (
      <FocusTrap active={open}>
        <div
          ref={composedRef}
          id={drawerId}
          className={cn(
            'lds-drawer-product',
            className
          )}
          data-direction={direction}
          data-state={open ? 'open' : 'closed'}
          role="dialog"
          aria-labelledby={labelledById}
          aria-describedby={describedById}
          aria-modal={variant === 'modal'}
          tabIndex='-1'
          {...props}
        >
          <div className='lds-drawer-product-container'>
            {children}
          </div>
        </div>
      </FocusTrap>
    );
  }
);

Drawer.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
};

export default Drawer;
