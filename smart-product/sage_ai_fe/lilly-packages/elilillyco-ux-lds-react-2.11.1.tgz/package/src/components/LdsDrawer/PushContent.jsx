import { useEffect, useRef, cloneElement } from 'react';
import PropTypes from 'prop-types';
import { useDrawerContext } from './hook/useDrawerContext.jsx';

/**
 * PushContent sub-component for LdsDrawer
 * Applies push behavior to its child
 * @param {Object} props - Component props
 * @param {React.ReactElement} props.children - Single child element to be pushed
 * @returns {React.ReactElement} - The child element with push behavior
 */
const PushContent = ({ children }) => {
  const { direction, drawerRef, isMounted } = useDrawerContext();
  const pushContentRef = useRef(null);

  useEffect(() => {
    if (!drawerRef.current || !pushContentRef.current || !isMounted) return;

    const drawer = drawerRef.current;
    const dimension = ['left', 'right'].includes(direction)
      ? drawer.offsetWidth
      : drawer.offsetHeight;

    pushContentRef.current.style.setProperty('--lds-spacing-drawer-wrapper-push', `${dimension}px`);
  }, [direction, drawerRef, isMounted]);

  return cloneElement(children, {
    'data-drawer-push-content': '',
    ref: (node) => {
      pushContentRef.current = node;
      const originalChildRef = children.ref;
      if (originalChildRef) {
        if (typeof originalChildRef === 'function') {
          originalChildRef(node);
        } else {
          originalChildRef.current = node;
        }
      }
    },
  });
};

PushContent.propTypes = {
  children: PropTypes.element.isRequired,
};

export default PushContent;
