import { cloneElement } from 'react';
import PropTypes from 'prop-types';
import { useDrawerContext } from './hook/useDrawerContext.jsx';

/**
 * Title sub-component for LdsDrawer
 * Applies a unique ID to its child.
 * @param {Object} props - Component props
 * @param {React.ReactElement} props.children - The child element to which the ID will be applied
 * @returns {React.ReactElement} - The child element with an ID
 */
const Title = ({ children }) => {
  const { labelledById } = useDrawerContext();
  return cloneElement(children, { id: labelledById });
};

Title.propTypes = {
  children: PropTypes.element.isRequired,
};

export default Title;
