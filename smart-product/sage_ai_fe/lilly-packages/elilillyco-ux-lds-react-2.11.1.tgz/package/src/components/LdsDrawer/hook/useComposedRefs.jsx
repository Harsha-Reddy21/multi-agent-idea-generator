import { useCallback } from 'react';

/**
 * A custom hook to compose multiple refs into a single ref callback.
 *
 * @param {...React.Ref} refs - The refs to be composed. Can be a function ref or an object ref.
 * @returns {React.RefCallback} - A ref callback that assigns the DOM node to all provided refs.
 */
const useComposedRefs = (...refs) => {
  return useCallback((node) => {
    refs.forEach((ref) => {
      if (ref) {
        if (typeof ref === 'function') {
          ref(node);
          return;
        }
        Object.defineProperty(ref, 'current', {
          value: node,
          configurable: true,
        });
      }
    });
  }, [refs]);
};

export default useComposedRefs;
