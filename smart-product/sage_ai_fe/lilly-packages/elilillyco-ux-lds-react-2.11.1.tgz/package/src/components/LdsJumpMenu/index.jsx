import cn from 'classnames';
import React, {
  useState, useEffect, useRef, useId
} from 'react';
import PropTypes from 'prop-types';

import offsetTopDocument from '../../util/offsetTopDocument.js';

// JSDoc type definitions
/**
 * @typedef LdsJumpMenuProps
 * @property {Array} menu - Array of menu item objects that populates the Jump Menu
 * @property {string} menuTitle - Optional menu title for the Jump Menu
 * @property {string} stickyCeiling - The ID of the sticky ceiling element that acts as the top limit for the Jump Menu to be sticky
 * @property {string} stickyFloor - The ID of the sticky floor element that acts as the bottom limit for the Jump Menu to be sticky
 * @property {string} [ariaLabel] - ARIA-LABEL text for nav element of Jump Menu
 * @property {number} [topPadding] - Distance between the top of the screen and the Jump Menu when sticky (in px)
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 */
/**
 * LdsJumpMenu component
 * @param {LdsJumpMenuProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsJumpMenu({
  ariaLabel = 'in-page',
  menu,
  menuTitle = undefined,
  stickyCeiling = undefined,
  stickyFloor = undefined,
  topPadding = 0,
  className = '',
  ...rest
}) {
  const [activeAnchor, setActiveAnchor] = useState('');
  const [sticky, setSticky] = useState(false);
  const [menuItems, setMenuItems] = useState([]);
  const [jumpMenuStyle, setJumpMenuStyle] = useState({
    top: `${topPadding}px`,
  });

  const navRef = useRef(null);

  const uniqueId = useId().slice(1, -1); // remove colons
  const jumpOffset = 16;

  const getStickyTop = () => {
    const stickyElement = document.querySelector('.lds-sticky');
    let offset = 0;
    if (stickyElement) offset += stickyElement.offsetHeight;
    return offset;
  };

  const getStickyCeilingY = () => {
    const windowY = window.pageYOffset;
    const stickyCeilingElm = document.getElementById(stickyCeiling);
    return stickyCeilingElm.getBoundingClientRect().top + windowY - getStickyTop();
  };

  const getStickyFloorY = () => {
    const windowY = window.pageYOffset;
    const stickyFloorElm = document.getElementById(stickyFloor);
    return stickyFloorElm.getBoundingClientRect().top + windowY;
  };

  const getNavHeight = () => {
    return navRef.current.getBoundingClientRect().height;
  };

  const isBelowTopAnchor = () => {
    const windowY = window.pageYOffset;
    const anchorTopY = getStickyCeilingY();
    return windowY > (anchorTopY - topPadding);
  };

  const isAboveBottomAnchor = () => {
    const windowY = window.pageYOffset;
    const anchorBottomY = getStickyFloorY() - getStickyTop();
    return windowY + getNavHeight() < anchorBottomY;
  };

  const isSticky = () => {
    return isBelowTopAnchor() && isAboveBottomAnchor();
  };

  const getNavOffsetTop = () => {
    const offset = getStickyFloorY()
      - getStickyCeilingY()
      - getNavHeight()
      - getStickyTop();
    return isBelowTopAnchor() ? offset : topPadding;
  };

  const handleUpdateSticky = ({ stickyValue } = {}) => {
    if (stickyValue) {
      setSticky(true);
      setJumpMenuStyle({
        top: `${topPadding + getStickyTop()}px`,
        maxHeight: `${window.innerHeight - (topPadding * 2) - getStickyTop()}px`,
      });
    } else {
      const offsetTop = getNavOffsetTop();
      setSticky(false);
      setJumpMenuStyle({
        top: `${offsetTop}px`,
        maxHeight: `${window.innerHeight - (topPadding * 2) - getStickyTop()}px`,
      });
    }
  };

  const checkSticky = () => {
    if (isSticky()) {
      handleUpdateSticky({ stickyValue: true });
    } else if (!isSticky()) {
      handleUpdateSticky({ stickyValue: false });
    }
  };

  const getPageAnchors = () => {
    const anchors = menu.map((item) => {
      const element = item.anchor ? document.getElementById(item.anchor) : null;
      if (!element && item.anchor) {
        /* eslint-disable-next-line no-console */
        console.error(`LDS ERROR [Unexpected Failure]: Jump menu anchors must match elements existing in the
        DOM. Check the anchor for a jump menu item with the text "${item.text}"`, '\n>>> in LdsJumpMenu');
      }
      return {
        anchor: item.anchor,
        element,
      };
    });
    return anchors;
  };

  const setUrlHash = (anchor) => {
    const url = new URL(window.location);
    url.hash = anchor;
    history.pushState({}, '', url);
  };

  const jumpToAnchor = (e, anchor) => {
    e.preventDefault();
    const target = document.getElementById(anchor);

    if (target) {
      window.scrollTo({ top: offsetTopDocument(target) - parseInt(jumpOffset, 10), behavior: 'smooth' });
      setUrlHash(anchor);
      setTimeout(() => target.focus({ focusVisible: true }), 500);
    }
  };

  const getActiveAnchor = () => {
    const pageAnchors = getPageAnchors();
    return [...pageAnchors].reverse()
      .reduce((active, item) => {
        if (active !== false || !item.element) return active;
        const offsetTop = offsetTopDocument(item.element)
          - 1
          - parseInt(jumpOffset, 10);
        const windowScroll = document.documentElement.scrollTop || window.pageYOffset;
        return offsetTop < windowScroll ? item : active;
      }, false);
  };

  const onPageScroll = () => {
    const actAnchor = getActiveAnchor();
    if (actAnchor) {
      setActiveAnchor(actAnchor.anchor);
      setUrlHash(actAnchor.anchor);
    }
    checkSticky();
  };

  const JumpMenuLink = ({ linkItem }) => {
    return (
      <li
        className={cn(
          'lds-jump-menu-list-item',
          {
            'lds-jump-menu-list-item-active': activeAnchor && linkItem.anchor === activeAnchor,
          }
        )}
      >
        <a
          href={`#${linkItem.anchor}`}
          onClick={(e) => jumpToAnchor(e, linkItem.anchor)}
        >
          {linkItem.text}
        </a>
      </li>
    );
  };

  const JumpMenuGroupItem = ({ groupItem, index }) => {
    return (
      <li className="lds-jump-menu-list-item-group">
        <p
          id={`lds-jump-menu-group-title-${index}-${uniqueId}`}
          className="lds-jump-menu-group-title"
        >
          {groupItem.groupText}
        </p>
        <ul
          className="lds-jump-menu-list-item-group-links"
          aria-describedby={`lds-jump-menu-title-${uniqueId}`}
          aria-labelledby={`lds-jump-menu-group-title-${index}-${uniqueId}`}
        >
          {
            groupItem.links.map((link, idx) => (
              <JumpMenuLink key={idx} linkItem={link} />
            ))
          }
        </ul>
      </li>
    );
  };

  useEffect(() => {
    const checkGroups = () => {
      let isGroup = false; let groupIndex = 0; let linkIndex = 0;
      const menuGroups = [];
      menu.forEach((element, index) => {
        if (!element.anchor) {
          isGroup = true;
          if (index !== 0) { groupIndex += 1; linkIndex = 0; }
          menuGroups[groupIndex] = { groupText: element.text, links: [] };
        } else if (isGroup) {
          menuGroups[groupIndex].links[linkIndex] = { ...element };
          linkIndex += 1;
        }
      });
      if (isGroup) setMenuItems(menuGroups);
      else setMenuItems(menu);
    };
    checkGroups();
  }, [menu]);

  useEffect(() => {
    window.addEventListener('scroll', onPageScroll);
    return () => window.removeEventListener('scroll', onPageScroll);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <nav
      aria-label={ariaLabel}
      ref={navRef}
      className={cn(
        'lds-jump-menu',
        {
          'lds-jump-menu-sticky': sticky,
        },
        className
      )}
      style={jumpMenuStyle}
      {...rest}
    >
      {
        menuTitle
        && <p
            id={`lds-jump-menu-title-${uniqueId}`}
            className="lds-jump-menu-title"
          >
            {menuTitle}
          </p>
      }
      <ul
        className="lds-jump-menu-list"
        aria-describedby={menuTitle ? `lds-jump-menu-title-${uniqueId}` : null }
      >
        {
          menuItems.map((item, idx) => (
            <React.Fragment key={idx}>
              {item.anchor && <JumpMenuLink linkItem={item} />}
              {item.groupText && <JumpMenuGroupItem groupItem={item} index={idx} />}
            </React.Fragment>
          ))
        }
      </ul>
    </nav>
  );
}

LdsJumpMenu.propTypes = {
  ariaLabel: PropTypes.string,
  menu: PropTypes.array.isRequired,
  stickyCeiling: PropTypes.string.isRequired,
  stickyFloor: PropTypes.string.isRequired,
  menuTitle: PropTypes.string,
  topPadding: PropTypes.number,
};
