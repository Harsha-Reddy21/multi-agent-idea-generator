import { forwardRef } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';
import LdsIcon from '../../LdsIcon/index.jsx';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsChatMessageBot
 * @property {React.ReactNode} [children] - HTML content handled by the React component's `children` property
 * @property {string} [actionsLocation] - Location of the actions in the message
 * @property {boolean} [background] - Sets the background class on the div
 * @property {string} [className] - Optional custom user-defined CSS class names, will
 * be appended to the list of any other component classes
 * @property {string} [icon] - Icon to display in the message
 * @property {boolean} [generating] - Message is generating
 * @property {string} [generatingLabel] - Label for the generating message
 * @property {string} [generatingAnimation] - Animation for the generating message
 * @property {boolean} [shadow] - Sets the shadow class on the div
 * @property {boolean} [stopped] - Sets the stopped class on the div
 * @property {React.HTMLAttributes<HTMLDivElement>} [rest] - Additional props to be spread to the component
 * @property {React.Ref<HTMLDivElement>} [ref] - React ref to be passed to the component
 */
/**
 * LdsBadge component
 * @param {LdsChatMessageBot & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsChatMessageBot component
 */

const LdsChatMessageBot = forwardRef(
  function LdsChatMessageBot({
    children,
    actionsLocation = 'bottom',
    background = false,
    className = undefined,
    generating = false,
    generatingLabel = 'Generating response...',
    generatingAnimation = 'none',
    icon = 'SparkleFill',
    shadow = false,
    stopped = false,
    ...rest
  }, ref) {
    return (
      <div
        className={cn(
          'lds-chat-message-bot',
          {
            [`${className}`]: className,
          },
          `actions-${actionsLocation}`
        )}
        ref={ref}
        {...rest}
      >
        <div className="message-avatar">
          {(generating && generatingAnimation === 'spinner') && <div className="spinner">
            <svg className="spinner-svg" viewBox="0 0 48 53" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle className="spinner-track" cx="24.2484" cy="26.9443" r="20.4777" strokeWidth="4.73865"/>
              <path className="spinner-indicator" d="M24.2504 6.21275C24.2504 4.57708 25.5814 3.23203 27.2043 3.43596C29.3008 3.6994 31.3571 4.24266 33.3174 5.05464C36.192 6.24534 38.8039 7.99057 41.004 10.1907C43.2041 12.3908 44.9494 15.0027 46.1401 17.8773C46.952 19.8376 47.4953 21.8939 47.7587 23.9904C47.9627 25.6133 46.6176 26.9443 44.9819 26.9443C43.3463 26.9443 42.0454 25.6094 41.7741 23.9964C41.5522 22.6777 41.1818 21.3853 40.6676 20.1441C39.7746 17.9881 38.4657 16.0292 36.8156 14.3791C35.1655 12.729 33.2066 11.4201 31.0506 10.5271C29.8094 10.0129 28.517 9.64247 27.1984 9.42065C25.5853 9.14929 24.2504 7.84843 24.2504 6.21275Z"/>
            </svg>
          </div>}
          <LdsIcon
            name={icon}
            decorative
          />
        </div>
        <div
          className={cn(
            'message-content',
            {
              'has-bg': background,
            },
            {
              'has-shadow': shadow,
            },
            {
              'is-stopped': stopped,
            }
          )}
        >
          {generating ? (
            <Generating
              generatingAnimation={generatingAnimation}
              generatingLabel={generatingLabel}
            />
          ) : children}
        </div>
      </div>
    );
  }
);

LdsChatMessageBot.propTypes = {
  children: PropTypes.node,
  actionsLocation: PropTypes.oneOf(['top', 'bottom', 'side']),
  background: PropTypes.bool,
  className: PropTypes.string,
  generating: PropTypes.bool,
  generatingAnimation: PropTypes.oneOf(['dots', 'spinner', 'none']),
  generatingLabel: PropTypes.string,
  icon: PropTypes.string,
  shadow: PropTypes.bool,
  stopped: PropTypes.bool,
};

function Generating({
  generatingAnimation,
  generatingLabel,
}) {
  return (
    <>
      {generatingAnimation === 'dots' ? (
        <div className="message-generating">
          <div />
          <div />
          <div />
        </div>
      ) : (
        <div className="message-text">{generatingLabel}</div>
      )}
    </>
  );
}

Generating.propTypes = {
  generatingAnimation: PropTypes.oneOf(['dots', 'spinner', 'none']),
  generatingLabel: PropTypes.string,
};

function Label({ children }) {
  return (
    <div className="message-label">
      {children}
    </div>
  );
}

function Text({ children }) {
  return (
    <div className="message-text">
      {children}
    </div>
  );
}

function Utilities({ children }) {
  return (
    <div className="message-utilities">
      {children}
    </div>
  );
}

function Actions({ children }) {
  return (
    <div className="message-actions">
      {children}
    </div>
  );
}

LdsChatMessageBot.Label = Label;
LdsChatMessageBot.Text = Text;
LdsChatMessageBot.Utilities = Utilities;
LdsChatMessageBot.Actions = Actions;

export default LdsChatMessageBot;
