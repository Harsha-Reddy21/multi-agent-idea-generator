import { forwardRef } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';
import LdsIcon from '../../LdsIcon/index.jsx';
import Text from './Text.jsx';
import Quote from './Quote.jsx';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsChatMessage
 * @property {React.ReactNode} [children] - HTML content handled by the React component's `children` property
 * @property {string} [align] - Message alignment
 * @property {string} [authorLabel] - Author label
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {string} [icon] - Icon to display in the message
 * @property {boolean} [isRead] - Message is read
 * @property {boolean} [isSent] - Message is sent
 * @property {string} [readLabel] - "Read" label (if present, overrides isRead icon)
 * @property {string} [sentLabel] - "Sent" label (if present, overrides isSent icon)
 * @property {boolean} [showAvatar] - Show avatar
 * @property {boolean} [showTimestamp] - Show timestamp
 * @property {number} [timestamp] - Message timestamp
 * @property {boolean} [typing] - Message is typing
 * @property {string} [typingAnimation] - Typing animation type (e.g., 'none', 'dots', 'spinner')
 * @property {string} [typingLabel] - Label to display when typing (overrides children if present)
 * @property {string} [metaLocation] - Location of the meta information in the message
 * @property {string} [userName] - User name
 * @property {React.HTMLAttributes<HTMLDivElement>} [rest] - Additional props to be spread to the component
 * @property {React.Ref<HTMLDivElement>} [ref] - React ref to be passed to the component
 */
/**
 * LdsChatMessage component
 * @param {LdsChatMessage & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsChatMessage component
 */

const LdsChatMessage = forwardRef(
  function LdsChatMessage({
    children,
    align = 'end',
    authorLabel = undefined,
    className = undefined,
    icon = undefined,
    isRead = false,
    isSent = false,
    readLabel = undefined,
    sentLabel = undefined,
    showAvatar = false,
    showTimestamp = false,
    timestamp = Date.now(),
    typing = false,
    typingAnimation = 'none',
    typingLabel = 'Typing a response...',
    metaLocation = 'bottom',
    userName = 'User',
    ...rest
  }, ref) {
    const readableTime = new Date(timestamp).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: 'numeric',
      hour12: true,
    });

    return (
      <div
        className={cn(
          'lds-chat-message',
          {
            [`${className}`]: className,
            'has-avatar': showAvatar,
          },
          `meta-${metaLocation}`,
          `align-message-${align}`
        )}
        ref={ref}
        {...rest}
      >
        <div
          className={cn(
            'message-wrapper'
          )}
        >
          {showAvatar && (icon ? (
            <div className="message-avatar">
              {(typing && typingAnimation === 'spinner') && <div className="spinner">
                <svg className="spinner-svg" viewBox="0 0 48 53" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle className="spinner-track" cx="24.2484" cy="26.9443" r="20.4777" strokeWidth="4.73865"/>
                  <path className="spinner-indicator" d="M24.2504 6.21275C24.2504 4.57708 25.5814 3.23203 27.2043 3.43596C29.3008 3.6994 31.3571 4.24266 33.3174 5.05464C36.192 6.24534 38.8039 7.99057 41.004 10.1907C43.2041 12.3908 44.9494 15.0027 46.1401 17.8773C46.952 19.8376 47.4953 21.8939 47.7587 23.9904C47.9627 25.6133 46.6176 26.9443 44.9819 26.9443C43.3463 26.9443 42.0454 25.6094 41.7741 23.9964C41.5522 22.6777 41.1818 21.3853 40.6676 20.1441C39.7746 17.9881 38.4657 16.0292 36.8156 14.3791C35.1655 12.729 33.2066 11.4201 31.0506 10.5271C29.8094 10.0129 28.517 9.64247 27.1984 9.42065C25.5853 9.14929 24.2504 7.84843 24.2504 6.21275Z"/>
                </svg>
              </div>}
              <LdsIcon
                name={icon}
                decorative
              />
            </div>
          ) : <div className="message-initial">
              {(typing && typingAnimation === 'spinner') && <div className="spinner">
                <svg className="spinner-svg" viewBox="0 0 48 53" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle className="spinner-track" cx="24.2484" cy="26.9443" r="20.4777" strokeWidth="4.73865"/>
                  <path className="spinner-indicator" d="M24.2504 6.21275C24.2504 4.57708 25.5814 3.23203 27.2043 3.43596C29.3008 3.6994 31.3571 4.24266 33.3174 5.05464C36.192 6.24534 38.8039 7.99057 41.004 10.1907C43.2041 12.3908 44.9494 15.0027 46.1401 17.8773C46.952 19.8376 47.4953 21.8939 47.7587 23.9904C47.9627 25.6133 46.6176 26.9443 44.9819 26.9443C43.3463 26.9443 42.0454 25.6094 41.7741 23.9964C41.5522 22.6777 41.1818 21.3853 40.6676 20.1441C39.7746 17.9881 38.4657 16.0292 36.8156 14.3791C35.1655 12.729 33.2066 11.4201 31.0506 10.5271C29.8094 10.0129 28.517 9.64247 27.1984 9.42065C25.5853 9.14929 24.2504 7.84843 24.2504 6.21275Z"/>
                </svg>
              </div>}
              {userName.charAt(0)}
            </div>
          )}
          <div className='message-group'>
            {typing ? (
              <Typing
              typingAnimation={typingAnimation}
              typingLabel={typingLabel}
              />
            ) : children}
          </div>
        </div>
        {(showTimestamp && !typing) && (
          <div className="message-utility">
            <span className="meta">
              <span className="timestamp">{readableTime}</span>
              {authorLabel && <>
                <LdsIcon
                  name="Dot"
                  decorative
                />
                <span className="author-label">{authorLabel}</span>
              </>}
              {isRead && (
                <ReadLabel
                  readLabel={readLabel}
                />
              )}
              {!isRead && isSent && (
                <SentLabel
                  sentLabel={sentLabel}
                />
              )}
            </span>
          </div>
        )}
      </div>
    );
  }
);

const ReadLabel = ({ readLabel }) => {
  if (readLabel) {
    return (
      <>
        <LdsIcon
          name="Dot"
          decorative
        />
        {readLabel}
      </>
    );
  }
  return (
    <LdsIcon
      className="read-icon"
      name="Checks"
      decorative
    />
  );
};

const SentLabel = ({ sentLabel }) => {
  if (sentLabel) {
    return (
      <>
        <LdsIcon
          name="Dot"
          decorative
        />
        {sentLabel}
      </>
    );
  }
  return (
    <LdsIcon
      className="sent-icon"
      name="Check"
      decorative
    />
  );
};

LdsChatMessage.Text = Text;
LdsChatMessage.Quote = Quote;

export default LdsChatMessage;

LdsChatMessage.propTypes = {
  children: PropTypes.node.isRequired,
  align: PropTypes.oneOf(['start', 'end']),
  authorLabel: PropTypes.string,
  className: PropTypes.string,
  icon: PropTypes.string,
  isRead: PropTypes.bool,
  isSent: PropTypes.bool,
  readLabel: PropTypes.string,
  sentLabel: PropTypes.string,
  showAvatar: PropTypes.bool,
  showTimestamp: PropTypes.bool,
  timestamp: PropTypes.number,
  typing: PropTypes.bool,
  typingAnimation: PropTypes.oneOf(['none', 'dots', 'spinner']),
  typingLabel: PropTypes.string,
  metaLocation: PropTypes.oneOf(['top', 'bottom']),
  userName: PropTypes.string,
};

function Typing({
  typingAnimation,
  typingLabel,
}) {
  return (
    <Text>
      {typingAnimation === 'dots' ? (
        <div className="message-typing">
          <div />
          <div />
          <div />
        </div>
      ) : (
        typingLabel
      )}
    </Text>
  );
}
