import { forwardRef } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsChatDividerProps
 * @property {React.ReactNode} [children] - HTML content handled by the React component's `children` property
 * @property {string} [className] - Optional custom user-defined CSS class names, will
 * be appended to the list of any other component classes
 * @property {boolean} [isNew] - Sets the isNew class on the div
 * @property {React.HTMLAttributes<HTMLDivElement>} [rest] - Additional props to be spread to the component
 * @property {React.Ref<HTMLDivElement>} [ref] - React ref to be passed to the component
 */
/**
 * LdsChatDivider component
 * @param {LdsChatDividerProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsChatDivider component
*/

const LdsChatDivider = forwardRef(
  function LdsChatDivider({
    children = undefined,
    className = undefined,
    isNew = false,
    ...rest
  }, ref) {
    return (
      <div
        className={cn(
          'lds-chat-divider',
          {
            [`${className}`]: className,
          },
          {
            'is-new': isNew,
          }
        )}
        ref={ref}
        role="separator"
        {...rest}
      >
        <div className="hr"></div>
        {children && <>
          <div className="timestamp">{children}</div>
          <div className="hr"></div>
        </>}
      </div>
    );
  }
);

LdsChatDivider.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  isNew: PropTypes.bool,
};

export default LdsChatDivider;
