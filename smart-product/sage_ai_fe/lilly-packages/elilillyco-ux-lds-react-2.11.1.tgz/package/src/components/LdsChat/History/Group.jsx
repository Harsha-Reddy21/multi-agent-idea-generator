import { useState } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsIcon from '../../LdsIcon/index.jsx';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsChatHistoryGroupProps
 * @property {React.ReactNode} [children] - HTML content handled by the React component's `children` property
 * @property {string} [className] - Optional custom user-defined CSS class names, will
 * be appended to the list of any other component classes
 * @property {React.HTMLAttributes<HTMLDivElement>} [rest] - Additional props to be spread to the component
 */
/**
 * LdsChatHistoryGroup component
 * @param {LdsChatHistoryGroupProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsChatHistoryGroup component
 */

export default function Group({
  children = undefined,
  className = undefined,
  header = undefined,
  iconNameClosed = 'caretDown',
  iconAriaLabelClosed = 'expand group',
  iconAriaLabelOpen = 'collapse group',
  open = true,
  ...rest
}) {
  const [isOpen, setIsOpen] = useState(open);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const toggleOpen = () => {
    setIsOpen(!isOpen);
    setIsTransitioning(true);
  };

  const handleTransitionEnd = () => {
    setIsTransitioning(false);
  };

  return (
    <div
      className={cn(
        'lds-chat-history-group',
        (isOpen && isTransitioning) && 'is-opening',
        (isOpen && !isTransitioning) && 'is-open',
        // isOpen && 'is-open',
        isTransitioning && 'is-transitioning',
        {
          [`${className}`]: className,
        }
      )}
      {...rest}
    >
      <button
        className={cn(
          'lds-chat-history-header',
          'lds-button-clear-style',
          'toggle-btn'
        )}
        onClick={toggleOpen}
        type="button"
      >
        <span className="lds-chat-history-header-text">{header}</span>
        <LdsIcon
          className="lds-chat-history-toggle-icon"
          label={`${isOpen ? iconAriaLabelOpen : iconAriaLabelClosed}`}
          name={iconNameClosed}
        />
      </button>
      <div
        className="lds-chat-history-body"
        onTransitionEnd={handleTransitionEnd}
      >
        <ol
          className={cn(
            'lds-chat-history-content'
          )}
        >{children}</ol>
      </div>
    </div>
  );
}

Group.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  header: PropTypes.string,
  iconNameClosed: PropTypes.string,
  iconAriaLabelClosed: PropTypes.string,
  iconAriaLabelOpen: PropTypes.string,
  open: PropTypes.bool,
  rest: PropTypes.any,
};
