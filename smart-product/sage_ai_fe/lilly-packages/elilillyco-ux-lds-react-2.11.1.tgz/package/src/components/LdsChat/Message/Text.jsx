import { forwardRef, useRef, useState } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';
import LdsChip from '../../LdsChip/index.jsx';
import LdsTooltip from '../../LdsTooltip/index.jsx';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef Text
 * @property {string} [btnCancelLabel] - Cancel button label
 * @property {string} [btnEditLabel] - Edit button label
 * @property {string} [btnReplyLabel] - Reply button label
 * @property {string} [btnSaveLabel] - Save button label
 * @property {React.ReactNode} [children] - HTML content handled by the React component's `children` property
 * @property {boolean} [isEditable] - Message is editable
 * @property {boolean} [isEditing] - Message is being edited
 * @property {boolean} [isReplyable] - Message is replyable
 * @property {function} [onReplyBtnClick] - Function to handle reply button click
 * @property {function} [onSubmit] - Function to handle form submission
 */
/**
 * Text component
 * @param {Text & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - Text component
 */

const Text = forwardRef(
  function Text({
    btnCancelLabel = 'Cancel',
    btnEditLabel = 'Edit',
    btnReplyLabel = 'Reply',
    btnSaveLabel = 'Save',
    children,
    isEditable = false,
    isEditing = false,
    isReplyable = false,
    onReplyBtnClick = () => {},
    onSubmit = () => {},
  }, ref) {
    const [editing, setEditing] = useState(isEditing);
    const [editValue, setEditValue] = useState(children || '');
    const textareaWrapRef = useRef(null);

    const handleEditBtnClick = () => {
      setEditing(true);
      setEditValue(children);
    };

    const handleReplyBtnClick = (e) => {
      onReplyBtnClick(e);
    };

    const handleSubmit = (e) => {
      setEditing(false);
      onSubmit(e);
    };

    const handleKeyDown = (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        handleSubmit(e);
      } else if (e.key === 'Escape') {
        setEditing(false);
      }
    };

    const handleInput = (e) => {
      /* "field-sizing: content" is not widely supported yet */
      if (!(CSS.supports('field-sizing', 'content'))) {
        // https://css-tricks.com/the-cleanest-trick-for-autogrowing-textareas/
        textareaWrapRef.current.dataset.replicatedValue = e.target.value;
      }
    };

    return (
      <div
        className={cn(
          'message-form',
          {
            'is-editing': editing,
          },
          {
            'is-valid': editing && (editValue !== children),
          }
        )}
        ref={ref}
      >
        {editing ? (
          <>
            <div
              className="textarea-wrap"
              ref={textareaWrapRef}
            >
              <textarea
                autoFocus
                onChange={(e) => setEditValue(e.target.value)}
                onInput={handleInput}
                onKeyDown={handleKeyDown}
                type="text"
                value={editValue}
              />
            </div>
            <div className="message-editing-btns">
              <LdsChip
                className="edit-cancel-btn outlined compact radius-sm"
                onClick={() => setEditing(false)}
              >
                {btnCancelLabel}
              </LdsChip>
              <LdsChip
                className="edit-save-btn compact radius-sm"
                disabled={editValue === children}
                icon={editValue === children ? undefined : 'Check'}
                iconPosition={'before'}
                onClick={handleSubmit}
              >
                {btnSaveLabel}
              </LdsChip>
            </div>
          </>
        ) : (
          <>
            <div className="message-text">
              {children}
            </div>
            {(isReplyable || isEditable) && (
              <div className="message-actions">
                {isReplyable && (
                  <LdsTooltip
                    className="reply-message-btn-tooltip"
                    hideIcon
                    tooltipMode="link"
                    openDelay={100}
                    position="bottom"
                  >
                    <LdsTooltip.Text>
                      <LdsChip
                        className="ghost pill message-action-btn reply-message-btn"
                        icon="arrow-u-up-left"
                        iconOnly
                        onClick={(e) => handleReplyBtnClick(e)}
                      />
                    </LdsTooltip.Text>
                    <LdsTooltip.Description>{btnReplyLabel}</LdsTooltip.Description>
                  </LdsTooltip>
                )}
                {isEditable && (
                  <LdsTooltip
                    className="edit-message-btn-tooltip"
                    hideIcon
                    tooltipMode="link"
                    openDelay={100}
                    position="bottom"
                  >
                    <LdsTooltip.Text>
                      <LdsChip
                        className="ghost pill message-action-btn edit-message-btn"
                        icon="PencilSimpleLine"
                        iconOnly
                        onClick={() => handleEditBtnClick()}
                      />
                    </LdsTooltip.Text>
                    <LdsTooltip.Description>{btnEditLabel}</LdsTooltip.Description>
                  </LdsTooltip>
                )}
              </div>
            )}
          </>
        )}
      </div>
    );
  }
);

export default Text;

Text.propTypes = {
  btnCancelLabel: PropTypes.string,
  btnEditLabel: PropTypes.string,
  btnReplyLabel: PropTypes.string,
  btnSaveLabel: PropTypes.string,
  children: PropTypes.node.isRequired,
  isEditable: PropTypes.bool,
  isEditing: PropTypes.bool,
  isReplyable: PropTypes.bool,
  onReplyBtnClick: PropTypes.func,
  onSubmit: PropTypes.func,
};
