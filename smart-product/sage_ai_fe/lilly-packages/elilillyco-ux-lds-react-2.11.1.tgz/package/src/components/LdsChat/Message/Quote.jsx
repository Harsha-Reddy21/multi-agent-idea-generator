import PropTypes from 'prop-types';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef Quote
 * @property {React.ReactNode} [children] - HTML content handled by the React component's `children` property
 * @property {string} [label] - Label for the quote
 */
/**
 * Quote component
 * @param {Quote & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - Quote component
 */
function Quote({ children, label }) {
  return (
    <blockquote className="message-quote">
      {label && (
        <cite>
          {label}
        </cite>
      )}
      {children}
    </blockquote>
  );
}

export default Quote;

Quote.propTypes = {
  children: PropTypes.node.isRequired,
  label: PropTypes.string,
};
