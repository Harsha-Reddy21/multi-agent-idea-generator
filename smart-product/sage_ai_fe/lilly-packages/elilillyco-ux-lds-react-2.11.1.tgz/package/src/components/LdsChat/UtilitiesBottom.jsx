import { forwardRef } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef UtilitiesBottomProps
 * @property {React.ReactNode} [children] - HTML content handled by the React component's `children` property
 * @property {string} [className] - Optional custom user-defined CSS class names, will
 * be appended to the list of any other component classes
 * @property {React.HTMLAttributes<HTMLDivElement>} [rest] - Additional props to be spread to the component
 * @property {React.Ref<HTMLDivElement>} [ref] - React ref to be passed to the component
 */
/**
 * UtilitiesBottom component
 * @param {UtilitiesBottomProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @return {React.JSX.Element} - UtilitiesBottom component
 */

const UtilitiesBottom = forwardRef(
  function UtilitiesBottom({
    children = undefined,
    className = undefined,
    ...rest
  }, ref) {
    return (
      <div
        className={cn(
          'utilities-bottom',
          {
            [`${className}`]: className,
          }
        )}
        ref={ref}
        {...rest}
      >
        <div className="utilities-bottom-wrap">
          {children}
        </div>
      </div>
    );
  }
);

UtilitiesBottom.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
};

export default UtilitiesBottom;
