import { useRef, useMemo, memo } from 'react';
import PropTypes from 'prop-types';
import useOverflowDetection from '../../../../hooks/useOverflowDetection.js';

import { LinkBase, RouterLinkBase, ButtonBase } from './Base.jsx';
import CreateTooltip from './CreateTooltip.jsx';

/**
 * Factory function to determine which link component to use
 * @param {Object} props - Component props
 * @returns {React.ComponentType} - The appropriate component
 */
function getLinkComponent({ to, href }) {
  if (to) return EnhancedRouterLink;
  if (href) return EnhancedLink;
  return EnhancedButton;
}

/**
 * LdsChatHistoryLink component
 * @param {LdsChatHistoryLinkProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsChatHistoryLink component
*/
function Link(props) {
  const {
    children,
    onClick,
    href,
    linkProps = {},
    routerLink,
    to,
  } = props;

  const elementRef = useRef(null);
  const isOverflowing = useOverflowDetection(elementRef);

  // Determine which component to render
  const Component = useMemo(() => getLinkComponent({ to, href }), [to, href]);

  // Common props for all component types
  const commonProps = {
    isElemOverflown: isOverflowing,
    elementRef,
    onClick: e => onClick && onClick(e),
    children,
  };

  // Component-specific props
  const specificProps = to
    ? { handleClick: e => onClick && onClick(e), routerLink, to }
    : { href };

  return <Component {...commonProps} {...specificProps} {...linkProps} />;
}

Link.propTypes = {
  children: PropTypes.node.isRequired,
  onClick: PropTypes.func,
  href: PropTypes.string,
  linkProps: PropTypes.object,
  routerLink: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  to: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
};

/**
 * A higher-order component that conditionally wraps the provided component with a tooltip
 * when content overflows.
 *
 * @param {React.ComponentType} Component - The component to wrap with tooltip functionality.
 * @returns {React.ComponentType} A new component that conditionally renders a tooltip based on overflow state.
 */
const withOverflowTooltip = (Component) => {
  // Create the wrapped component
  const WithOverflowTooltip = ({ isElemOverflown, children, ...props }) => {
    if (isElemOverflown) {
      return (
        <CreateTooltip description={children}>
          <Component isElemOverflown={true} {...props}>
            {children}
          </Component>
        </CreateTooltip>
      );
    }

    return (
      <Component isElemOverflown={false} {...props}>
        {children}
      </Component>
    );
  };

  // Set the display name for better debugging
  const componentDisplayName = Component.displayName || Component.name || 'Component';
  WithOverflowTooltip.displayName = `WithOverflowTooltip(${componentDisplayName})`;

  return WithOverflowTooltip;
};

// Enhanced components with tooltip support
const EnhancedRouterLink = withOverflowTooltip(RouterLinkBase);
const EnhancedLink = withOverflowTooltip(LinkBase);
const EnhancedButton = withOverflowTooltip(ButtonBase);

export default memo(Link);
