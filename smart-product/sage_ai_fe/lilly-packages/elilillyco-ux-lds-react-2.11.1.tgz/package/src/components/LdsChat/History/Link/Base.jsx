import cn from 'classnames';
import PropTypes from 'prop-types';

import RouterLink from '../../../LdsSideNav/SideNavMenuObjects/RouterLink.jsx';

// Helper for consistent class names
const getBaseClasses = (isElemOverflown, additionalClasses) => cn(
  'lds-button-base',
  additionalClasses,
  isElemOverflown && 'is-overflown'
);

export const RouterLinkBase = ({
  children,
  handleClick,
  routerLink,
  to,
  isElemOverflown,
  ...props
}) => (
  <RouterLink
    className={getBaseClasses(isElemOverflown, 'lds-chat-history-item-link')}
    handleClick={handleClick}
    routerLink={routerLink}
    to={to}
    {...props}
  >
    <span className="lds-chat-history-item-text">{children}</span>
  </RouterLink>
);

export const LinkBase = ({
  children,
  elementRef,
  href,
  isElemOverflown = false,
  linkProps = {},
}) => (
  <a
    className={getBaseClasses(isElemOverflown, 'lds-chat-history-item-link')}
    href={href}
    ref={elementRef}
    {...linkProps}
  >
    <span className="lds-chat-history-item-text">{children}</span>
  </a>
);

export const ButtonBase = ({
  children,
  elementRef,
  isElemOverflown = false,
  linkProps = {},
  onClick,
}) => (
  <button
    className={getBaseClasses(isElemOverflown, 'lds-chat-history-item-btn')}
    onClick={onClick && ((e) => onClick(e))}
    ref={elementRef}
    {...linkProps}
  >
    <span className="lds-chat-history-item-text">{children}</span>
  </button>
);

// Common prop types for base components
const basePropTypes = {
  children: PropTypes.node.isRequired,
  isElemOverflown: PropTypes.bool,
};

RouterLinkBase.propTypes = {
  ...basePropTypes,
  handleClick: PropTypes.func,
  routerLink: PropTypes.string,
  to: PropTypes.string.isRequired,
};

LinkBase.propTypes = {
  ...basePropTypes,
  elementRef: PropTypes.object,
  href: PropTypes.string.isRequired,
  linkProps: PropTypes.object,
};

ButtonBase.propTypes = {
  ...basePropTypes,
  elementRef: PropTypes.object,
  linkProps: PropTypes.object,
  onClick: PropTypes.func,
};

RouterLinkBase.displayName = 'RouterLinkBase';
LinkBase.displayName = 'LinkBase';
ButtonBase.displayName = 'ButtonBase';
