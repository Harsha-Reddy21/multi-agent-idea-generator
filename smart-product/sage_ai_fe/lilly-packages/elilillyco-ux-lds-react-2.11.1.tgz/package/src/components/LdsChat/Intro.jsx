import { forwardRef } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';
import LdsIcon from '../LdsIcon/index.jsx';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef IntroProps
 * @property {React.ReactNode} [children] - HTML content handled by the React component's `children` property
 * @property {string} [className] - Optional custom user-defined CSS class names, will
 * be appended to the list of any other component classes
 * @property {string} [icon] - Icon to display in the intro
 * @property {React.HTMLAttributes<HTMLDivElement>} [rest] - Additional props to be spread to the component
 * @property {React.Ref<HTMLDivElement>} [ref] - React ref to be passed to the component
 */
/**
 * Intro component
 * @param {IntroProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @return {React.JSX.Element} - Intro component
 */

const Intro = forwardRef(
  function Intro({
    children = undefined,
    className = undefined,
    icon = undefined,
    ...rest
  }, ref) {
    return (
      <div
        className={cn(
          'lds-chat-intro',
          {
            [`${className}`]: className,
          }
        )}
        ref={ref}
        {...rest}
      >
        {icon && <div className="intro-avatar">
          <LdsIcon
            name={icon}
            decorative
          />
        </div>}
        {children}
      </div>
    );
  }
);

Intro.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  icon: PropTypes.string,
};

export default Intro;
