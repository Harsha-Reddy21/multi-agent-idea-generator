import PropTypes from 'prop-types';
import LdsTooltip from '../../../LdsTooltip/index.jsx';

// JSDoc comments to supply typescript compiler with the necessary types
/**
 * @typedef CreateTooltipProps
 * @property {React.ReactNode} [children] - HTML content handled by the React component's `children` property
 * @property {string} [description] - Description to display in the tooltip
 */
/**
 * CreateTooltip component
 * @param {CreateTooltipProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - CreateTooltip component
 */

export default function CreateTooltip({
  children,
  description,
}) {
  return (
    <LdsTooltip
      hideIcon
      tooltipMode="link"
      openDelay={100}
      position="bottom"
    >
      <LdsTooltip.Text>{children}</LdsTooltip.Text>
      <LdsTooltip.Description>{description}</LdsTooltip.Description>
    </LdsTooltip>
  );
}

CreateTooltip.propTypes = {
  children: PropTypes.node,
  description: PropTypes.string,
};
