import { forwardRef } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef UtilitiesTopProps
 * @property {React.ReactNode} [children] - HTML content handled by the React component's `children` property
 * @property {string} [className] - Optional custom user-defined CSS class names, will
 * be appended to the list of any other component classes
 * @property {React.HTMLAttributes<HTMLDivElement>} [rest] - Additional props to be spread to the component
 * @property {React.Ref<HTMLDivElement>} [ref] - React ref to be passed to the component
 */
/**
 * UtilitiesTop component
 * @param {UtilitiesTopProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @return {React.JSX.Element} - UtilitiesTop component
 */

const UtilitiesTop = forwardRef(
  function UtilitiesTop({
    children = undefined,
    className = undefined,
    ...rest
  }, ref) {
    return (
      <div
        className={cn(
          'utilities-top',
          {
            [`${className}`]: className,
          }
        )}
        ref={ref}
        {...rest}
      >
        <div className="utilities-top-wrap">
          {children}
        </div>
      </div>
    );
  }
);

UtilitiesTop.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
};

export default UtilitiesTop;
