import { useState } from 'react';
import PropTypes from 'prop-types';

import LdsDropdown from '../../LdsDropdown/index.jsx';

// JSDoc comments to supply typescript compiler with the necessary types
/**
 * @typedef LdsChatHistoryOptionsProps
 * @property {boolean} [autoFocusFirstItem] - Boolean value to to set if first focusable item in the dropdown should automatically be focused when the dropdown opens. Defaults to true.
 * @property {React.ReactNode} [children] - HTML content handled by the React component's `children` property
 * @property {string} [dropdownAlignment] - Optional override to force the dropdown to open left or right
 * @property {string} [icon] - Icon to display on the dropdown button
 * @property {boolean} [iconRotate] - Boolean value to set if the dropdown icon should be rotated when the dropdown is open
 * @property {string} [iconLabel] - Aria label for the dropdown button
 * @property {Function} [onExpand] - Event that will be fired after the dropdown opens and its animation is complete
 * @property {Function} [onCollapse] - Event that will be fired after the dropdown closes and its animation is complete
 * @property {React.HTMLAttributes<HTMLDivElement>} [rest] - Additional props to be spread to the component
 */
/**
 * LdsChatHistoryOptions component
 * @param {LdsChatHistoryOptionsProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsChatHistoryOptions component
 */

export default function Options({
  autoFocusFirstItem = false,
  children,
  dropdownAlignment = 'left',
  icon = 'dotsThreeOutlineFill',
  iconLabel = 'options',
  iconRotate = false,
  onExpand,
  onCollapse,
  ...rest
}) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <LdsDropdown
      autoFocusFirstItem={autoFocusFirstItem}
      dropdownAlignment={dropdownAlignment}
      icon={icon}
      iconOnly
      iconRotate={iconRotate}
      label={iconLabel}
      onExpand={onExpand}
      onCollapse={onCollapse}
      wrapperProps={{ ...rest }}
      isOpen={isOpen}
      setIsOpen={setIsOpen}
      {...rest}
    >
      {children}
    </LdsDropdown>
  );
}

Options.propTypes = {
  autoFocusFirstItem: PropTypes.bool,
  children: PropTypes.node,
  dropdownAlignment: PropTypes.string,
  icon: PropTypes.string,
  iconLabel: PropTypes.string,
  iconRotate: PropTypes.bool,
  onExpand: PropTypes.func,
  onCollapse: PropTypes.func,
  rest: PropTypes.any,
};

// JSDoc comments to supply typescript compiler with the necessary types
/**
 * @typedef LdsChatHistoryOptionLinkProps
 * @property {React.ReactNode} [children] - HTML content handled by the React component's `children` property
 * @property {string} [className] - Optional custom user-defined CSS class names, will
 * be appended to the list of any other component classes
 * @property {string} [href] - URL to link to
 * @property {string} [icon] - Icon to display on the dropdown button
 * @property {string} [iconLabel] - Aria label for the dropdown button
 * @property {boolean} [iconOnly] - Boolean value to set if the dropdown button should only display the icon
 * @property {string} [iconPosition] - Position of the icon on the dropdown button
 * @property {React.HTMLAttributes<HTMLAnchorElement>} [rest] - Additional props to be spread to the component
 */
/**
 * LdsChatHistoryOptionLink component
 * @param {LdsChatHistoryOptionLinkProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsChatHistoryOptionLink component
 */

export function OptionLink({
  children,
  className,
  href,
  icon,
  iconLabel,
  iconOnly,
  iconPosition,
  ...rest
}) {
  return (
    <LdsDropdown.Link
      className={className}
      href={href}
      icon={icon}
      iconLabel={iconLabel}
      iconOnly={iconOnly}
      iconPosition={iconPosition}
      {...rest}
    >
      {children}
    </LdsDropdown.Link>
  );
}

OptionLink.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  href: PropTypes.string,
  icon: PropTypes.string,
  iconLabel: PropTypes.string,
  iconOnly: PropTypes.bool,
  iconPosition: PropTypes.string,
  rest: PropTypes.any,
};

// JSDoc comments to supply typescript compiler with the necessary types
/**
 * @typedef LdsChatHistoryOptionButtonProps
 * @property {React.ReactNode} [children] - HTML content handled by the React component's `children` property
 * @property {string} [className] - Optional custom user-defined CSS class names, will
 * be appended to the list of any other component classes
 * @property {string} [icon] - Icon to display on the dropdown button
 * @property {string} [iconLabel] - Aria label for the dropdown button
 * @property {boolean} [iconOnly] - Boolean value to set if the dropdown button should only display the icon
 * @property {string} [iconPosition] - Position of the icon on the dropdown button
 * @property {Function} [onClick] - Function to call when the button is clicked
 * be appended to the list of any other component classes
 * @property {React.HTMLAttributes<HTMLButtonElement>} [rest] - Additional props to be spread to the component
 */
/**
 * LdsChatHistoryOptionButton component
 * @param {LdsChatHistoryOptionButtonProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsChatHistoryOptionButton component
 */

export function OptionButton({
  children,
  className,
  icon,
  iconLabel,
  iconOnly,
  iconPosition,
  onClick,
  ...rest
}) {
  return (
    <LdsDropdown.Button
      className={className}
      icon={icon}
      iconLabel={iconLabel}
      iconOnly={iconOnly}
      iconPosition={iconPosition}
      onClick={onClick}
      {...rest}
    >
      {children}
    </LdsDropdown.Button>
  );
}

OptionButton.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  icon: PropTypes.string,
  iconLabel: PropTypes.string,
  iconOnly: PropTypes.bool,
  iconPosition: PropTypes.string,
  onClick: PropTypes.func,
  rest: PropTypes.any,
};
