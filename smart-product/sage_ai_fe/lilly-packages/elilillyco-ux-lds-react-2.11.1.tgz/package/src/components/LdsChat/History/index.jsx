import { forwardRef } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import Group from './Group.jsx';
import Item from './Item.jsx';
import { OptionLink } from './Options.jsx';
import { OptionButton } from './Options.jsx';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsChatHistoryProps
 * @property {React.ReactNode} [children] - HTML content handled by the React component's `children` property
 * @property {string} [className] - Optional custom user-defined CSS class names, will
 * be appended to the list of any other component classes
 * @property {React.HTMLAttributes<HTMLDivElement>} [rest] - Additional props to be spread to the component
 * @property {React.Ref<HTMLDivElement>} [ref] - React ref to be passed to the component
 */
/**
 * LdsChatHistory component
 * @param {LdsChatHistoryProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsChatHistory component
 */

const LdsChatHistory = forwardRef(
  function LdsChatHistory({
    children = undefined,
    className = undefined,
    ...rest
  }, ref) {
    return (
      <div
        className={cn(
          'lds-chat-history',
          {
            [`${className}`]: className,
          }
        )}
        ref={ref}
        {...rest}
      >
        {children}
      </div>
    );
  }
);

LdsChatHistory.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  rest: PropTypes.any,
};

LdsChatHistory.Group = Group;
LdsChatHistory.Item = Item;
LdsChatHistory.OptionLink = OptionLink;
LdsChatHistory.OptionButton = OptionButton;

export default LdsChatHistory;
