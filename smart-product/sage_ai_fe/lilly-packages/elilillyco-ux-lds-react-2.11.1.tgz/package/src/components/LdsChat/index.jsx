import { forwardRef } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

/* subcomponents */
import Header from './Header.jsx';
import Messages from './Messages.jsx';
import Intro from './Intro.jsx';
import UtilitiesTop from './UtilitiesTop.jsx';
import UtilitiesBottom from './UtilitiesBottom.jsx';
import Footer from './Footer.jsx';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsChatProps
 * @property {React.ReactNode} [children] - HTML content handled by the React component's `children` property
 * @property {string} [className] - Optional custom user-defined CSS class names, will
 * be appended to the list of any other component classes
 * @property {string} [maxHeight] - Maximum height of the chat
 * @property {boolean} [showUtilitiesTop] - Whether to show the utilities top
 * @property {boolean} [showUtilitiesBottom] - Whether to show the utilities bottom
 * @property {React.HTMLAttributes<HTMLDivElement>} [rest] - Additional props to be spread to the component
 * @property {React.Ref<HTMLDivElement>} [ref] - React ref to be passed to the component
 */
/**
 * LdsChat component
 * @param {LdsChatProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsChat component
*/

const LdsChat = forwardRef(
  function LdsChat({
    children = undefined,
    className = undefined,
    maxHeight = undefined,
    showUtilitiesTop = false,
    showUtilitiesBottom = false,
    ...rest
  }, ref) {
    let modifiedRest = rest;
    if (maxHeight) {
      modifiedRest = {
        ...rest,
        style: {
          maxHeight: maxHeight,
          ...rest.style,
        },
      };
    }

    return (
      <div
        className={cn(
          'lds-chat',
          {
            [`${className}`]: className,
            'show-utilities-top': showUtilitiesTop,
            'show-utilities-bottom': showUtilitiesBottom,
          }
        )}
        ref={ref}
        {...modifiedRest}
      >
        {children}
      </div>
    );
  }
);

LdsChat.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  maxHeight: PropTypes.string,
  showUtilitiesTop: PropTypes.bool,
  showUtilitiesBottom: PropTypes.bool,
};

LdsChat.Header = Header;
LdsChat.Messages = Messages;
LdsChat.Intro = Intro;
LdsChat.UtilitiesTop = UtilitiesTop;
LdsChat.UtilitiesBottom = UtilitiesBottom;
LdsChat.Footer = Footer;

export default LdsChat;
