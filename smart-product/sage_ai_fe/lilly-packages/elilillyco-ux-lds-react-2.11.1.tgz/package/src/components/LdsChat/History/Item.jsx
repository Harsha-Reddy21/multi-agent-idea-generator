import { useEffect, useRef, useState } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';
import LdsButton from '../../LdsButton/index.jsx';

import Link from './Link/index.jsx';
import Options from './Options.jsx';
import { OptionButton } from './Options.jsx';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsChatHistoryItemProps
 * @property {string} [cancelAriaLabel] - Aria label for the cancel button
 * @property {string} [cancelIcon] - Icon for the cancel button
 * @property {React.ReactNode} [children] - HTML content handled by the React component's `children` property
 * @property {string} [className] - Optional custom user-defined CSS class names, will
 * be appended to the list of any other component classes
 * @property {string} [href] - URL to link to
 * @property {string} [inputAriaLabel] - Aria label for the input field
 * @property {string} [inputId] - ID for the input field
 * @property {string} [itemValue] - Value of the item
 * @property {Object} [linkProps] - Additional props to be spread to the link
 * @property {Function} [onCancelRename] - Function to call when the cancel button is clicked
 * @property {Function} [onChange] - Function to call when the input field value changes
 * @property {Function} [onClick] - Function to call when the link is clicked
 * @property {Function} [onKeyDown] - Function to call when a key is pressed in the input field
 * @property {Function} [onRename] - Function to call when the rename button is clicked
 * @property {React.ReactNode} [options] - Additional options to be displayed in the options menu
 * @property {string} [renameIcon] - Icon for the rename button
 * @property {string} [renameLabel] - Label for the rename button
 * @property {React.ReactNode} [routerLink] - Wrapper component for the router link
 * @property {string} [saveAriaLabel] - Aria label for the save button
 * @property {string} [saveIcon] - Icon for the save button
 * @property {Function} [setItemValue] - Function to call to set the item value
 * @property {string} [to] - Router link to link to
 * @property {React.HTMLAttributes<HTMLDivElement>} [rest] - Additional props to be spread to the component
 */
/**
 * LdsChatHistoryItem component
 * @param {LdsChatHistoryItemProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsChatHistoryItem component
 */

export default function Item({
  cancelAriaLabel = 'Cancel edit',
  cancelIcon = 'x-circle-fill',
  children = undefined,
  className = undefined,
  href = undefined,
  inputAriaLabel = 'Rename item',
  inputId = undefined,
  linkProps = {},
  onCancelRename = () => {},
  onChange = () => {},
  onClick = () => {},
  onKeyDown = () => {},
  onRename = () => {},
  options = undefined,
  renameIcon = 'PencilSimple',
  renameLabel = 'Rename',
  routerLink = undefined,
  saveAriaLabel = 'Save edit',
  saveIcon = 'CheckCircleFill',
  setItemValue = () => {},
  to = undefined,
  itemValue = '',
  ...rest
}) {
  const [isEditing, setIsEditing] = useState(false);
  const [inputValue, setInputValue] = useState(itemValue);
  const inputRef = useRef(null);

  const handleChange = (e) => {
    setInputValue(e.target.value);
    onChange(e);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      setIsEditing(false);
      onRename(inputRef);
    }
    onKeyDown(e);
  };

  const handleLinkClick = (e) => {
    e.preventDefault();
    // if double click, set isEditing to true
    if (e.detail === 2) {
      setIsEditing(true);
    } else if (onClick) {
      // if single click, call onClick
      onClick(e);
    }
  };

  const handleSaveRename = () => {
    setItemValue(inputValue);
    setIsEditing(false);
    onRename(inputRef);
  };

  const handleCancelRename = () => {
    setInputValue(itemValue);
    setIsEditing(false);
    onCancelRename();
  };

  // focus inputRef when isEditing is set to true
  useEffect(() => {
    if (isEditing) {
      inputRef.current.focus();
    }
  }, [isEditing]);

  return (
    <li
      className={cn(
        'lds-chat-history-item',
        {
          [`${className}`]: className,
        }
      )}
      {...rest}
    >
    {isEditing
      ? <>
        <input
          className="lds-chat-history-item-input"
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          ref={inputRef}
          type="text"
          value={inputValue}
          aria-label={inputAriaLabel}
          id={inputId}
          name={inputId}
        />
        <span
          className="lds-chat-history-item-actions"
        >
          <LdsButton
            onClick={handleCancelRename}
            classes="compact action-ghost radius-sm"
            icon={cancelIcon}
            iconLabel={cancelAriaLabel}
            iconOnly
            aria-label={cancelAriaLabel}
          />
          <LdsButton
            onClick={handleSaveRename}
            classes="compact action-ghost radius-sm"
            icon={saveIcon}
            iconLabel={saveAriaLabel}
            iconOnly
            aria-label={saveAriaLabel}
          />
        </span>
      </> : <>
        <Link
          href={href}
          linkProps={linkProps}
          onClick={handleLinkClick}
          routerLink={routerLink}
          to={to}
        >{children}</Link>
        <Options>
          <OptionButton
            icon={renameIcon}
            iconLabel={renameLabel}
            iconPosition="before"
            onClick={() => setIsEditing(true)}
          >{renameLabel}</OptionButton>
          {options}
        </Options>
      </>
    }
  </li>);
}

Item.propTypes = {
  cancelAriaLabel: PropTypes.string,
  cancelIcon: PropTypes.string,
  children: PropTypes.node,
  className: PropTypes.string,
  href: PropTypes.string,
  inputAriaLabel: PropTypes.string,
  inputId: PropTypes.string,
  itemValue: PropTypes.string,
  linkProps: PropTypes.object,
  onCancelRename: PropTypes.func,
  onChange: PropTypes.func,
  onClick: PropTypes.func,
  onKeyDown: PropTypes.func,
  onRename: PropTypes.func,
  options: PropTypes.node,
  renameIcon: PropTypes.string,
  renameLabel: PropTypes.string,
  routerLink: PropTypes.string,
  saveAriaLabel: PropTypes.string,
  saveIcon: PropTypes.string,
  setItemValue: PropTypes.func,
  to: PropTypes.string,
  rest: PropTypes.any,
};
