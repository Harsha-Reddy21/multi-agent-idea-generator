import { forwardRef } from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';
import LdsIcon from '../../LdsIcon/index.jsx';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsPromptCardProps
 * @property {React.ReactNode} [children] - HTML content handled by the React component's `children` property
 * @property {boolean} [animated] - Sets the animated class on the div
 * @property {string} [className] - Optional custom user-defined CSS class names, will
 * be appended to the list of any other component classes
 * @property {string} [icon] - Icon to display in the prompt card
 * @property {function} [onClick] - Function to execute when the prompt card is clicked
 * @property {React.HTMLAttributes<HTMLDivElement>} [rest] - Additional props to be spread to the component
 * @property {React.Ref<HTMLDivElement>} [ref] - React ref to be passed to the component
 */
/**
 * LdsBadge component
 * @param {LdsPromptCardProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsPromptCard component
 */

const LdsPromptCard = forwardRef(
  function LdsPromptCard({
    children,
    animated = false,
    className = undefined,
    icon = 'ArrowRight',
    onClick = () => {},
    ...rest
  }, ref) {
    const handleClick = (event) => {
      onClick(event);
    };

    return (
      <div
        className={cn(
          'lds-prompt-card',
          {
            [`${className}`]: className,
            'is-animated': animated,
          }
        )}
        onClick={handleClick}
        ref={ref}
        role="button"
        tabIndex={0}
        {...rest}
      >
        <div className="prompt-text">
          {children}
        </div>
        <div className="prompt-icon">
          <LdsIcon
            name={icon}
            decorative
          />
        </div>
      </div>
    );
  }
);

LdsPromptCard.propTypes = {
  children: PropTypes.node,
  animated: PropTypes.bool,
  className: PropTypes.string,
  icon: PropTypes.string,
  onClick: PropTypes.func,
};

export default LdsPromptCard;
