import {
  createRef,
  useEffect,
  useRef,
  useState
} from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsDropdown from '../LdsDropdown/index.jsx';
import { setCookie, getCookie } from '../../util/cookies.js';
import LdsIcon from '../LdsIcon/index.jsx';
import { LdsRadioGroup } from '../../index.js';
import LanguageSelectOption from './LanguageSelectOption.jsx';

// JSDoc type definitions
/**
 * @typedef LdsLanguageSelectProps
 * @property {string} id - HTML element ID
 * @property {string} name - HTML element name
 * @property {{ value: string, label: string }[]} options - Array of options. Each option must contain a value and a label
 * @property {string} [label] - Label to display above the select
 * @property {string} [defaultValue] - The default value for the select
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [inputProps] - Optional object of properties to apply to the hidden input
 * @property {Function} [onChange] - Event that will be fired after selected option changes
 * @property {string} [className] - Optional custom user-defined CSS class(es) to add to the component root container element; will be appended to the list of any other component classes
 * @property {string} [ldsTrackingCookieName] - Name of the cookie used to track cookie acceptance
 * @property {string} [ldsLanguageCookieName] - Name of the cookie used to track user language preference
 * @property {boolean} [storeLanguageCookie] - Boolean value to determine if the language cookie should be stored. Should only be used on sites that do not require a cookie acceptance banner. Otherwise selector will check the lds_allowTracking cookie
 * @property {boolean} [useIsoCodeLabel] - Boolean value used to show the isoLangCode as the label. Useful for compact views
 */
/**
 * LdsLanguageSelect component
 * @param {LdsLanguageSelectProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
function LdsLanguageSelect({
  id,
  name,
  label = '',
  defaultValue,
  options,
  inputProps,
  onChange = () => {},
  className,
  ldsTrackingCookieName = 'lds_allowTracking',
  ldsLanguageCookieName = 'lds_selected_language',
  storeLanguageCookie = false, // prop only to be used on sites that do not need a cookie banner
  dropdownAlignment = 'left',
  useIsoCodeLabel = false,
  ...rest
}) {
  const [isOpen, setIsOpen] = useState(false);

  const dropdownRef = useRef(null);
  const optionsRef = useRef(options.map(() => createRef()));

  // This is considered a preference cookie and will not be set if the user has not accepted cookies
  const setSiteLanguageCookie = (value) => {
    const cookieAcceptance = getCookie(ldsTrackingCookieName);
    if (cookieAcceptance === 'enabled' || storeLanguageCookie) {
      setCookie(ldsLanguageCookieName, value, 365);
    }
  };

  const selectDefaultItem = () => {
    if (!options || !Array.isArray(options) || options.length < 1) return { value: undefined, label: undefined };

    if (defaultValue === undefined || defaultValue === null) {
      return options[0];
    }

    const foundItem = options.find((option) => option.value === defaultValue);
    if (!foundItem) {
      // eslint-disable-next-line no-console
      console.error(`
      LdsLanguageSelect - no corresponding option provided for defaultValue: ${defaultValue}
        type: ${typeof defaultValue}
      `);
    }
    return foundItem;
  };

  const setDefaultAriaDescribedBy = (defaultValue) => {
    if (!options || !Array.isArray(options) || options.length < 1) return '';

    if (defaultValue === undefined || defaultValue === null) {
      return '';
    }

    const foundItemIdx = options.findIndex((option) => option.value === defaultValue);
    return `${id}-option-btn-${foundItemIdx}`;
  };

  const setDefaultIsoLangCode = (defaultValue) => {
    if (!options || !Array.isArray(options) || options.length < 1) return '';

    if (defaultValue === undefined || defaultValue === null) {
      return '';
    }

    const foundItem = options.find((option) => option.value === defaultValue);
    if (!foundItem) {
      // eslint-disable-next-line no-console
      console.error(`
      LdsLanguageSelect - no corresponding option provided for defaultValue: ${defaultValue}
        type: ${typeof defaultValue}
      `);
    }
    return foundItem.isoLangCode;
  };

  const [selectedItem, setSelectedItem] = useState(selectDefaultItem(defaultValue));
  const [focusedOption, setFocusedOption] = useState(selectDefaultItem(defaultValue));
  const [ariaDescribedBy, setAriaDescribedBy] = useState(setDefaultAriaDescribedBy(defaultValue));
  const [isoLangCode, setIsoLangCode] = useState(setDefaultIsoLangCode(defaultValue));

  useEffect(() => {
    setSelectedItem(selectDefaultItem(defaultValue));
    setFocusedOption(selectDefaultItem(defaultValue));
    setAriaDescribedBy(setDefaultAriaDescribedBy(defaultValue));
    setIsoLangCode(setDefaultIsoLangCode(defaultValue));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [defaultValue]);

  const handleExpand = () => {
    setFocusedOption(selectedItem);
    const activeIdx = options.findIndex((option) => option.value === selectedItem.value);
    optionsRef.current[activeIdx].current.focus();
  };

  const handleButtonKeyDown = (e) => {
    const isEscape = e.key === 'Escape';

    if (isEscape) {
      setIsOpen(false);
    }
  };

  const handleOptionKeyDown = (e) => {
    const isUp = e.code === 'ArrowUp';
    const isDown = e.code === 'ArrowDown';
    const isEscape = e.code === 'Escape';
    const isEnter = e.code === 'Enter';
    const isTab = e.code === 'Tab';

    if (isEscape) {
      setIsOpen(false);
    }

    if (isEnter) {
      e.preventDefault();
      const activeIdx = options.findIndex((option) => option.value === focusedOption.value);
      setAriaDescribedBy(`${id}-option-btn-${activeIdx}`);
      setIsoLangCode(focusedOption.isoLangCode);
      setSelectedItem(focusedOption);
      setSiteLanguageCookie(focusedOption.value);
      // Call passed in onChange event
      onChange(focusedOption);
      setIsOpen(false);
    }

    if (isTab) {
      setIsOpen(false);
    }

    if (isUp) {
      e.preventDefault(); // prevent page scroll
      const activeIdx = options.findIndex((option) => option.value === focusedOption.value);
      if (activeIdx === 0) return;

      const newIdx = activeIdx - 1;
      optionsRef.current[newIdx].current.focus();
      setFocusedOption(options[newIdx]);
    }

    if (isDown) {
      e.preventDefault(); // prevent page scroll
      const activeIdx = options.findIndex((option) => option.value === focusedOption.value);
      if (activeIdx === options.length - 1) return;

      const newIdx = activeIdx + 1;
      optionsRef.current[newIdx].current.focus();
      setFocusedOption(options[newIdx]);
    }
  };

  const handleSelectOption = (option, optionId) => {
    setAriaDescribedBy(optionId);
    setIsoLangCode(option.isoLangCode);
    setSelectedItem(option);
    setSiteLanguageCookie(option.value);
    // Call passed in onChange event
    onChange(option);
    setIsOpen(false);
  };

  return (
    <div
      className={cn(
        'lds-language-select-wrapper',
        className
      )}
      {...rest}
    >
      { label
        && <label
          className={
            'lds-form-label sr-only'
          }
          htmlFor={`${id}-button`}
        >
          {label}
        </label>
      }

      <div>
        <input
          type="hidden"
          id={id}
          name={name}
          value={selectedItem?.value}
          lang={isoLangCode}
          {...inputProps}
        ></input>
        <LdsDropdown
          isOpen={isOpen}
          setIsOpen={setIsOpen}
          onExpand={handleExpand}
          autoFocusFirstItem={false}
          dropdownAlignment={dropdownAlignment}
          label={<span className="lds-language-select-dd-label">
            <LdsIcon className="globe" name="Globe" inline decorative />
            <span className="ls-full-text">{selectedItem?.label}</span>
            {/* Short text for use in utility navigation. Not normally displayed */}
            <span
              className="ls-short-text"
              aria-hidden="true"
            >
              {selectedItem?.isoLangCode?.toUpperCase()}
            </span>
          </span>}
          buttonProps={{
            className: cn(
              'lds-language-select',
              {
                'ls-compact': useIsoCodeLabel,
              }
            ),
            lang: isoLangCode,
            'aria-describedby': ariaDescribedBy,
            id: `${id}-button`,
            onKeyDown: handleButtonKeyDown,
          }}
        >
          <LdsRadioGroup
            className={cn(
              'lang-select-options'
            )}
            label={label}
            ref={dropdownRef}
          >
            {options
              && Array.isArray(options)
              && options.map((option, idx) => (
                <LanguageSelectOption
                  handleOptionBlur={() => {}}
                  handleOptionKeyDown={handleOptionKeyDown}
                  handleSelectOption={handleSelectOption}
                  id={id}
                  idx={idx}
                  key={idx}
                  name={id}
                  option={option}
                  optionsRef={optionsRef}
                  selectedItem={selectedItem}
                />
              ))
            }
          </LdsRadioGroup>
        </LdsDropdown>
      </div>
    </div>
  );
}

LdsLanguageSelect.propTypes = {
  id: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  inputProps: PropTypes.object,
  options: PropTypes.arrayOf((propValue, key, componentName, propFullName) => { // eslint-disable-line
    if (!propValue[key].value) {
      return new Error(
        `Invalid prop ${propFullName} supplied to ${componentName} at index ${key}. Each option must contain a "value" property.`
      );
    }
    if (!propValue[key].label) {
      return new Error(
        `Invalid prop ${propFullName} supplied to ${componentName} at index ${key}. Each option must contain a "label" property.`
      );
    }
  }),
};

export default LdsLanguageSelect;
