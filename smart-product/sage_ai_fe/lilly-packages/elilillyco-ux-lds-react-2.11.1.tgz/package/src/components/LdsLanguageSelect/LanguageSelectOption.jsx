import cn from 'classnames';
import PropTypes from 'prop-types';
import LdsIcon from '../LdsIcon/index.jsx';

export default function LanguageSelectOption({
  handleOptionBlur,
  handleOptionKeyDown,
  handleSelectOption,
  id,
  idx,
  name,
  disabled = false,
  className,
  labelClassName,
  option,
  optionsRef,
  selectedItem,
  ...rest
}) {
  return (
    <label
      className={cn(
        'lds-check-label',
        'lds-select-option',
        {
          selected: selectedItem.value === option.value,
          disabled,
        },
        labelClassName
      )}
      data-option={`${id}-option-btn-${option.value}`}
      id={`${id}-option-btn-${idx}`}
      onBlur={handleOptionBlur}
      onKeyDown={handleOptionKeyDown}
      ref={optionsRef.current[idx]}
      tabIndex="-1"
    >
      <input
        className={cn(
          'lds-radio',
          {
            disabled,
          },
          className
        )}
        disabled={disabled}
        lang={option.isoLangCode}
        name={`${name}-option`}
        tabIndex="-1"
        type="radio"
        onChange={() => handleSelectOption(option, `${id}-option-btn-${idx}`)}
        value={option.value}
        {...rest}
      />
      <span className="radio-label">{option.label}</span>
      <LdsIcon className="check" name="Check" inline decorative />
    </label>
  );
}

LanguageSelectOption.propTypes = {
  handleOptionBlur: PropTypes.func.isRequired,
  handleOptionKeyDown: PropTypes.func.isRequired,
  handleSelectOption: PropTypes.func.isRequired,
  id: PropTypes.string.isRequired,
  idx: PropTypes.number.isRequired,
  name: PropTypes.string.isRequired,
  option: PropTypes.shape({
    value: PropTypes.string.isRequired,
    label: PropTypes.string.isRequired,
    isoLangCode: PropTypes.string.isRequired,
  }).isRequired,
  optionsRef: PropTypes.object.isRequired,
  selectedItem: PropTypes.shape({
    value: PropTypes.string.isRequired,
    label: PropTypes.string.isRequired,
    isoLangCode: PropTypes.string.isRequired,
  }).isRequired,
  disabled: PropTypes.bool,
};
