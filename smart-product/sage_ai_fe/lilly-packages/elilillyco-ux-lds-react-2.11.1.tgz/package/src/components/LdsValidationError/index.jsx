import PropTypes from 'prop-types';
import cn from 'classnames';

import LdsIcon from '../LdsIcon/index.jsx';

// JSDoc type definitions
/**
 * @typedef LdsValidationErrorProps
 * @property {string} id - HTML `id` attribute value of the component
 * @property {string} [className] - Optional custom user-defined CSS class(es) for the component, will be appended to the list of any other component classes
 * @property {React.ReactNode} [children] - React child slot object
 */
/**
 * LdsValidationError component
 * @param {LdsValidationErrorProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsValidationError({
  id,
  className,
  children,
  ...rest
}) {
  return (
    <span
      id={id}
      className={cn(
        'lds-form-validation-error',
        className
      )}
      {...rest}
    >
      <span className="icon-wrapper">
        <LdsIcon name="WarningCircleFill" inline decorative />
      </span>
      {children}
    </span>
  );
}

LdsValidationError.propTypes = {
  id: PropTypes.string.isRequired,
};
