/* eslint-disable consistent-return */
import { useState } from 'react';
import ToastWrapper from './ToastWrapper.jsx';
import ToastIcon from './ToastIcon.jsx';
import DismissButton from './DismissButton.jsx';
import ActionText from './ActionText.jsx';
import { useToastContext } from './ToastContext.jsx';
import useTimeout from '../../hooks/useTimeout.js';

export default function Toaster() {
  const { toasts, removeToast } = useToastContext();

  return (
    <>
      {toasts.map((toast, index) => (
        <Toast
          key={toast.id}
          {...toast}
          removeToast={removeToast}
          index={index}
        />
      ))}
    </>
  );
}

export function Toast({
  id,
  toastMessage,
  inline,
  position,
  align,
  variant,
  actionText,
  dismissible,
  inverted,
  densityClass,
  radiusClass,
  className,
  timeout = 6000, // 6 seconds as per ARIA guidelines
  actionCallback,
  index,
  autoDismiss,
  iconAltText,
  dismissLabel,
}) {
  const { removeToast } = useToastContext();
  const [isLeaving, setIsLeaving] = useState(false);
  useTimeout(() => {
  // for accessibility, we want to disable auto-dismiss if
  // there is an action button on the toast
    if (autoDismiss && !actionText?.length) {
      dismissToast();
    }
  }, timeout);
  function dismissToast() {
    setIsLeaving(true);
    removeToast(id);
  }

  return (
    <>
      <ToastWrapper
        id={id}
        inline={inline}
        position={position}
        align={align}
        className={className}
        densityClass={densityClass}
        radiusClass={radiusClass}
        inverted={inverted}
        isLeaving={isLeaving}
        index={index}
        variant={variant}
      >
        <ToastIcon altText={iconAltText} variant={variant} />

        <div className="lds-toast-content">{toastMessage}</div>

        <ActionText
          actionText={actionText}
          actionCallback={actionCallback}
        />
        {dismissible && (
          <DismissButton
            id={id}
            dismissLabel={dismissLabel}
            dismissCallback={dismissToast}
          />
        )}
      </ToastWrapper>
    </>
  );
}
