import { useRef, useEffect } from 'react';

import LdsIcon from '../LdsIcon/index.jsx';

export default function DismissButton({
  id,
  dismissCallback,
  dismissLabel,
}) {
  // auto focus on the dismiss button
  const ref = useRef(null);
  useEffect(() => {
    ref.current.focus();
  }, []);

  return (
    <button
      ref={ref}
      className="lds-button-base lds-toast-dismiss lds-toast-actionable-button"
      aria-label={dismissLabel}
      onClick={() => dismissCallback(id)}
    >
      <LdsIcon
        name="X"
        className='button-icon'
        inline
        decorative
      />
    </button>
  );
}
