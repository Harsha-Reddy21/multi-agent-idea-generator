import { useState, useEffect } from 'react';
import { getCSSVariableValue } from './util/index.js';
import useLastFocusedElement from '../../hooks/useLastFocusedElement.js';
export default function useToast(maxToasts) {
  const [toasts, setToasts] = useState([]);
  const [toastQueue, setToastQueue] = useState([]);
  const [transitionTimeNumber, setTransitionTimeNumber] = useState(500 - 50);
  const lastFocusedElementRef = useLastFocusedElement('.lds-toast');

  useEffect(() => {
    const transitionTime = getCSSVariableValue(
      '--lds-animation-toast-transition-duration',
      500
    );
    setTransitionTimeNumber(parseFloat(transitionTime) - 50);
  }, []);

  function clearAllToasts() {
    setToasts([]);
    setToastQueue([]);
  }

  function randomId() {
    return Math.random().toString(36).substring(2, 9) + new Date().getTime().toString(36);
  }
  function addToast(toast) {
    // copy the toast object to avoid mutating the original
    const toastCopy = { ...toast };

    toastCopy.id = toast.id || randomId();

    if (toastCopy.force) {
      // if there are no toasts, add the toast right away
      if (toasts.length === 0) {
        setToasts((currentToasts) => [...currentToasts, toastCopy]);
        return;
      }

      // Set a timeout to update the toasts after the transition duration
      setTimeout(() => {
        // Add the forced toast to the toasts array
        setToasts([toastCopy]);

        // Clear the toast queue
        setToastQueue([]);
      }, transitionTimeNumber);

      return;
    }
    if (toasts.length < maxToasts) {
      setToasts((currentToasts) => [...currentToasts, toastCopy]);
    } else {
      setToastQueue((currentQueue) => [...currentQueue, toastCopy]);
    }
  }

  function removeToast(id) {
    // Return focus to the last focused element
    lastFocusedElementRef.current?.focus();
    setTimeout(() => {
      setToasts((currentToasts) => currentToasts.filter((toast) => toast.id !== id));
    }, transitionTimeNumber - 50);
  }

  useEffect(() => {
    if (toasts.length < maxToasts && toastQueue.length > 0) {
      const nextToast = toastQueue[0] || undefined;
      setToasts((currentToasts) => [...currentToasts, nextToast]);
      setToastQueue([...toastQueue.slice(1)]);
    }
  }, [toasts, toastQueue, maxToasts]);

  return {
    toasts,
    addToast,
    removeToast,
    clearAllToasts,
  };
}
