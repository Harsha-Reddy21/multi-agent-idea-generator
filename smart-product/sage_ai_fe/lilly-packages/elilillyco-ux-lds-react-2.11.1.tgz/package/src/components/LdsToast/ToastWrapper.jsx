import cn from 'classnames';

import { calculateToastMargin } from './util/index.js';

export default function ToastWrapper({
  id,
  inline = false,
  position = 'top',
  align = 'left',
  inverted,
  densityClass,
  radiusClass,
  className,
  children,
  isLeaving,
  index,
  variant,
  spacing = '4rem',
}) {
  const toastClasses = cn(
    {
      inverted: inverted,
      'toast-leave': isLeaving,
      'toast-enter': !isLeaving,
      'lds-toast': true,
      [`${variant}`]: true,
      [`lds-toast-position-${position}`]: true,
      [`lds-toast-align-${align}`]: true,
      inline: inline,
    },
    densityClass,
    radiusClass,
    className
  );
  return (
    <div
      role="alert"
      aria-live="polite"
      id={id}
      style={inline ? {} : calculateToastMargin(index, position, spacing)}
      className={toastClasses}
    >
      {children}
    </div>
  );
}
