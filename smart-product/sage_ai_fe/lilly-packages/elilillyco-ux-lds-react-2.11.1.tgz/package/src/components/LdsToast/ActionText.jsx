export default function ActionText({
  actionText,
  actionCallback,
}) {
  if (actionText?.length) {
    return (
      <>
        <button
          className="lds-button-base lds-toast-action lds-toast-actionable-button"
          onClick={actionCallback}
        >
          {actionText}
        </button>
      </>
    );
  }
  return null;
}
