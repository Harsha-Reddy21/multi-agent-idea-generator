import { createContext, useContext } from 'react';
import PropTypes from 'prop-types';

import useToast from './useToast.js';

const ToastContext = createContext();

// JSDoc type definitions
/**
 * @typedef ToastProviderProps
 * @property {React.ReactNode} children - React child slot object
 * @property {number} [maxToasts] - The maximum number of toasts to display at once
 */
/**
 * ToastProvider component
 * @param {ToastProviderProps} props
 * @returns {React.JSX.Element}
 */
export default function ToastProvider({ children, maxToasts = 1 }) {
  const toastHooks = useToast(maxToasts);

  return (
    <ToastContext.Provider value={toastHooks}>{children}</ToastContext.Provider>
  );
}

export function useToastContext() {
  return useContext(ToastContext);
}

ToastProvider.propTypes = {
  children: PropTypes.node.isRequired,
  maxToasts: PropTypes.number,
};
