import LdsIcon from '../LdsIcon/index.jsx';

export default function ToastIcon({ variant, altText }) {
  if (
    variant === 'error'
    || variant === 'info'
    || variant === 'success'
    || variant === 'warning'
    || variant === 'neutral'
  ) {
    return (
      <>
        <span className="sr-only">{`${altText}`}</span>
        <div className="lds-toast-icon icon inline">
          <LdsIcon
            name={getIcon(variant)}
            className='lds-toast-icon'
            inline
            decorative
          />
        </div>
      </>
    );
  }
  return null;
}
function getIcon(variant) {
  switch (variant) {
    case 'error':
      return 'WarningCircleFill';
    case 'info':
      return 'InfoFill';
    case 'neutral':
      return 'InfoFill';
    case 'success':
      return 'CheckCircleFill';
    case 'warning':
      return 'WarningFill';
    default:
      return '';
  }
}
