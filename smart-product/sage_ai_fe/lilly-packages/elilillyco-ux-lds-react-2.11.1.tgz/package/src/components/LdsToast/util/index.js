import isClientEnvironment from '../../../util/isClientEnvironment.js';

export function getCSSVariableValue(variableName, defaultValue) {
  if (!isClientEnvironment) {
    return defaultValue;
  }
  return (
    window
      .getComputedStyle(document.documentElement)
      .getPropertyValue(variableName) || defaultValue
  );
}

export function calculateToastMargin(index, position, spacing) {
  if (index === 0) {
    return {};
  }
  if (position === 'top') {
    const initialTopMargin = getCSSVariableValue(
      '--lds-spacing-toast-position-top-margin-top',
      '1rem'
    );
    return { marginTop: `calc(${spacing} * ${index} + ${initialTopMargin})` };
  }

  if (position === 'bottom') {
    const initialBottomMargin = getCSSVariableValue(
      '--lds-spacing-toast-position-bottom-margin-bottom',
      '1rem'
    );
    return {
      marginBottom: `calc(${spacing} * ${index} + ${initialBottomMargin})`,
    };
  }

  return {};
}
