import PropTypes from 'prop-types';
import cn from 'classnames';

// import LDS components
import LdsIcon from '../../LdsIcon/index.jsx';

// JSDoc type definitions
/**
 * @typedef LdsInteractiveCardBodyProps
 * @property {Array.<React.ReactNode>|React.ReactNode} [title] - The templated title or "heading" text node content
 * @property {Array.<React.ReactNode>|React.ReactNode} [content] - The the templated content or "subtitle" node text content
 * @property {Array.<React.ReactNode>|React.ReactNode} [link] -  The templated link of "action" text node content
 * @property {boolean} [useLinkIcon] - Whether to display an LDS Icon at the end of the link text, default is 'true' (enabled)
 * @property {string} [linkIcon] - A valid LDS icon name for the link text icon, default is 'arrow-right'
 * @property {string} [linkIconLabel] - Optional; specifies a custom title for the link text icon
 * @property {boolean} [linkIconDecorative] - Whether the link text icon is decorative (to be ignored by assistive technology), default is 'false'
 * @property {Array.<React.ReactNode>|React.ReactNode} [children] - Optional; custom child JSX nodes to add below or to replace the templated content nodes
 * @property {string} [className] - Optional; custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Optional; define any additional non-prop attributes to be rendered on the component's root container element
 */
/**
 * LdsInteractiveCardBody component
 * @param {LdsInteractiveCardBodyProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsInteractiveCardBody({
  title,
  content,
  link,
  useLinkIcon = true,
  linkIcon = 'arrow-right',
  linkIconLabel,
  linkIconDecorative = false,
  children,
  className,
  ...rest
}) {
  return (
    <span
      className={cn(
        'card-body',
        className
      )}
      {...rest}
    >
      { title
        && <span className="card-title">{title}</span>
      }
      { content
        && <span className="card-content">{content}</span>
      }
      { link
        && <span className="card-link">
          {link}{ useLinkIcon
          && <>&#32;<LdsIcon
            name={linkIcon}
            label={linkIconLabel}
            decorative={linkIconDecorative}
            inline
          /></>
          }
        </span>
      }
      { children
        && <span className="card-content">{children}</span>
      }
    </span>
  );
}

LdsInteractiveCardBody.propTypes = {
  title: PropTypes.any,
  content: PropTypes.any,
  link: PropTypes.any,
  useLinkIcon: PropTypes.bool,
  linkIcon: PropTypes.string,
  linkIconLabel: PropTypes.string,
  linkIconDecorative: PropTypes.bool,
  children: PropTypes.any,
  className: PropTypes.string,
  rest: PropTypes.any,
};
