import PropTypes from 'prop-types';
import cn from 'classnames';

// JSDoc type definitions
/**
 * @typedef LdsInteractiveCardImageProps
 * @property {Array.<React.ReactNode>|React.ReactNode} [children] - Optional; custom child JSX nodes to add below or to replace the templated content nodes
 * @property {string} [className] - Optional; custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Optional; define any additional non-prop attributes to be rendered on the component's root container element
 */
/**
 * LdsInteractiveCardImage component
 * @param {LdsInteractiveCardImageProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsInteractiveCardImage({
  children,
  className,
  ...rest
}) {
  return (
    <span
      className={cn(
        'card-image',
        className
      )}
      {...rest}
    >
      {children}
    </span>
  );
}

LdsInteractiveCardImage.propTypes = {
  children: PropTypes.any.isRequired,
  className: PropTypes.string,
  rest: PropTypes.any,
};
