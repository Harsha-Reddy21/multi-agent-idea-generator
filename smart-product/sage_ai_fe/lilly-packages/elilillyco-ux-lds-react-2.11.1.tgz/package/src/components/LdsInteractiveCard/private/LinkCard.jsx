import { forwardRef } from 'react';

export default forwardRef(function LinkCard({
  href,
  className,
  children,
  ...rest
}, ref) {
  return (
    <a
      ref={ref}
      className={className}
      href={href || '#INTERACTIVE_CARD_HREF_NOT_SET'}
      {...rest}
    >
      <span className="card-container">
        {children}
      </span>
    </a>
  );
});
