import { forwardRef } from 'react';

export default forwardRef(function ButtonCard({
  onClick,
  className,
  children,
  ...rest
}, ref) {
  return (
    <button
      ref={ref}
      className={className}
      onClick={onClick}
      {...rest}
    >
       <span className="card-container">
        {children}
      </span>
    </button>
  );
});
