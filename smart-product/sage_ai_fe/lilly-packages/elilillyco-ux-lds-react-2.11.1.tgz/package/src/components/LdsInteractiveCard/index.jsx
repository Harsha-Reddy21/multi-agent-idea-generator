import PropTypes from 'prop-types';
import cn from 'classnames';

/* import Private Sub-Components */
import ButtonCard from './private/ButtonCard.jsx';
import LinkCard from './private/LinkCard.jsx';

/* import Public Sub-Components */
import CardBody from './public/CardBody.jsx';
import CardImage from './public/CardImage.jsx';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsInteractiveCardProps
 * @property {string} [type] - The type of HTML element the card should render as; valid types are either 'link' for <a> or 'button' for <button>; default is 'link'
 * @property {string} [href] - When the type prop is set to 'link' specifies the HTML href attribute of the anchor element which should be a valid URL string; ignored if the type prop is 'button'
 * @property {function} [onClick] - When the type prop is set to 'button' specifies the click event handler function to be invoked; ignored if the type prop is 'link'
 * @property {string} [buttonType] - Whtn the type prop is set to 'button' sets the value of the button element's type attribute; valid type string values are the same as the HTML spec 'button', 'submit', 'reset'; default is 'button'
 * @property {boolean} [useImage] - Whether the card will use the optional image feature; default is false; when true the card image sub-component must be added to the component's children nodes
 * @property {string} [styleClass] - Set a string value for one of the variant component style classes; valid values are 'outlined', 'solid', 'image-background' or leave undefined for the default style
 * @property {string} [densityClass] - Optional; set one of the density size classes for the component; valid values are 'small', 'medium', 'large' or leave undefined for the default small density
 * @property {string} [radiusClass] - Optional; set one of the border radius size classes for the component; valid values are 'radius-sm', 'radius-md', 'radus-lg' or leave undefined to use the theme radius default
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {Array.<React.ReactNode>|React.ReactNode} [children] - Optional, however for correct usage the component expects the card body sub-component and optionally the card image sub-component as children nodes
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Optional, define any additional non-prop attributes to be rendered on the component's root container element.
 */
/**
 * LdsInteractiveCard component
 * @param {LdsInteractiveCardProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element} - LdsInteractiveCard component
 */
function LdsInteractiveCard({
  type = 'link',
  href = undefined,
  onClick,
  buttonType = 'button',
  useImage = false,
  styleClass,
  densityClass,
  radiusClass,
  className,
  children,
  ...rest
}) {
  const classes = cn(
    'lds-interactive-card',
    { image: useImage },
    styleClass,
    radiusClass,
    densityClass,
    className
  );

  if (type === 'button') {
    return (
      <ButtonCard
        className={classes}
        onClick={onClick}
        type={buttonType}
        {...rest}
      >
        {children}
      </ButtonCard>
    );
  }

  return (
    <LinkCard
      className={classes}
      href={href || '#INTERACTIVE_CARD_HREF_NOT_SET'}
      {...rest}
    >
      {children}
    </LinkCard>
  );
}

LdsInteractiveCard.propTypes = {
  type: PropTypes.oneOf(['link', 'button']),
  href: PropTypes.string,
  onClick: PropTypes.any,
  buttonType: PropTypes.oneOf(['button', 'submit', 'reset']),
  children: PropTypes.any,
  useImage: PropTypes.bool,
  styleClass: PropTypes.oneOf(['outlined', 'solid', 'image-background', undefined]),
  densityClass: PropTypes.oneOf(['small', 'medium', 'large', undefined]),
  radiusClass: PropTypes.oneOf(['no-radius', 'radius-xs', 'radius-sm', 'radius-md', 'radius-lg', undefined]),
  className: PropTypes.string,
  rest: PropTypes.any,
};

/* Register Public Sub-components */
LdsInteractiveCard.Body = CardBody;
LdsInteractiveCard.Image = CardImage;

export default LdsInteractiveCard;
