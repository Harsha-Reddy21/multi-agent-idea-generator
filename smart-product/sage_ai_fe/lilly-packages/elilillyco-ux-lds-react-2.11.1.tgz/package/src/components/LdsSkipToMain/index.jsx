import cn from 'classnames';
import PropTypes from 'prop-types';

// JSDoc type definitions
/**
 * @typedef LdsSkipToMainProps
 * @property {string} [contentId] - The HTML ID attribute of the main element; expects to find `<main id="main">` by default
 * @property {boolean} [isSideNav] - When using the Side Nav layout component this prop must be set to `true`
 * @property {string} [className] - Optional custom user-defined CSS class(es) for the component, will be appended to the list of any other component classes
 * @property {React.ReactNode} [children] - React child slot object
 */
/**
 * LdsSkipToMain component
 * @param {LdsSkipToMainProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
function LdsSkipToMain({
  contentId = 'main',
  children = 'Skip to main content',
  isSideNav = false,
  className,
  ...rest
}) {
  return (
    <div
      className={cn(
        'lds-skip-to-main',
        {
          sideNav: isSideNav,
        },
        className
      )}
      {...rest}
    >
      <a
        className="lds-skip-link"
        tabIndex="0"
        href={`#${contentId}`}
      >
        {children}
      </a>
      <div className="lds-skip-placeholder"></div>
    </div>
  );
}

export default LdsSkipToMain;

LdsSkipToMain.propTypes = {
  contentId: PropTypes.string,
  isSideNav: PropTypes.bool,
};
