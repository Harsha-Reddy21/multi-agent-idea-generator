import PropTypes from 'prop-types';
import cn from 'classnames';

// JSDoc type definitions
/**
 * @typedef ImageColumnProps
 * @property {string} [imgObjectFit] - The object-fit property for the image
 * @property {string} [columnSize] - The size of the column
 * @property {string} [caption] - The caption for the image
 * @property {React.ReactNode} children - The children of the component
 * @property {string} [className] - Additional classes to add to the component
 * @property {React.AnchorHTMLAttributes<HTMLAnchorElement>} [link] - The link for the image
 */
/**
 * ImageColumn component
 * @param {ImageColumnProps} props
 * @returns {React.JSX.Element}
 */
export default function ImageColumn({
  imgObjectFit = 'cover',
  columnSize = 'col-12 col-md-6',
  caption = '',
  children,
  link,
  className,
  ...rest
}) {
  const ImgWrapper = () => {
    if (link) {
      return (
        <a {...link}>
          {children}
        </a>
      );
    }

    return <>{children}</>;
  };

  return (
    <div
      className={cn(
        'lds-half-billboard-img',
        columnSize,
        className
      )}
      {...rest}
    >
      <div
        className={cn(
          'lds-half-billboard-img-container',
          `${imgObjectFit}`,
          {
            'has-caption': caption,
          }
        )}
        style={{ backgroundSize: imgObjectFit, backgroundPosition: 'center center' }}
      >
        <ImgWrapper />
        {caption && <p className="h3">{caption}</p>}
      </div>
    </div>
  );
}

ImageColumn.propTypes = {
  imgObjectFit: PropTypes.oneOf(['cover', 'contain']),
  link: PropTypes.shape({ href: PropTypes.string, target: PropTypes.string }),
};
