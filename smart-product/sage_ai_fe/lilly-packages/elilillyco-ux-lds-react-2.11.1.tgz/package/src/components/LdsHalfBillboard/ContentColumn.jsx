import cn from 'classnames';

/**
 * @typedef ContentColumnProps
 * @property {React.ReactNode} children - The children of the component
 * @property {string} [columnSize] - The size of the column
 * @property {string} [className] - Additional classes to add to the component
 */
/**
 * ContentColumn component
 * @param {ContentColumnProps} props
 * @returns {React.JSX.Element}
 */
export default function ContentColumn({
  children,
  columnSize = 'col-12 col-md-6 col-lg-5',
  className,
  ...rest
}) {
  return (
    <div
      className={cn(
        columnSize,
        className
      )}
      {...rest}
    >
      <div className="lds-half-billboard-content">
        {children}
      </div>
    </div>
  );
}
