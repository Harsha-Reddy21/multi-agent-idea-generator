import cn from 'classnames';
import PropTypes from 'prop-types';

import ContentColumn from './ContentColumn.jsx';
import ImageColumn from './ImageColumn.jsx';

// JSDoc type definitions
/**
 * @typedef LdsHalfBillboardProps
 * @property {boolean} [padded] - Whether the billboard should have padding
 * @property {string} [breakpointClass] - The breakpoint class to use
 * @property {boolean} [hasCaption] - Whether the billboard should have a caption
 * @property {string} [className] - Additional classes to add to the component
 * @property {React.ReactNode} children - The children of the component
 */
/**
 * LdsHalfBillboard component
 * @param {LdsHalfBillboardProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsHalfBillboard({
  padded = false,
  breakpointClass = 'medium',
  hasCaption = false,
  className,
  children,
  ...rest
}) {
  return (
    <section
      className={cn(
        'lds-half-billboard',
        className
      )}
      {...rest}
    >
      <div className="wrapper">
        <div
          className={cn(
            'row',
            'justify-content-between',
            `breakpoint-${breakpointClass}`,
            {
              padded,
              'align-items-center': hasCaption,
            }
          )}
        >
          {children}
        </div>
      </div>
    </section>
  );
}

LdsHalfBillboard.ContentColumn = ContentColumn;
LdsHalfBillboard.ImageColumn = ImageColumn;

LdsHalfBillboard.propTypes = {
  padded: PropTypes.bool,
  breakpointClass: PropTypes.oneOf(['xsmall', 'small', 'medium', 'large', 'xlarge']),
};
