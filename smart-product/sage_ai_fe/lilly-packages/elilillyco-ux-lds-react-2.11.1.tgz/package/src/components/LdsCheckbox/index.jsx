// MARK: IMPORT
import { forwardRef } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

// MARK: DEFINITION

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef LdsCheckboxProps
 * @property {string} id - Sets the <input type="checkbox"> element's HTML "id" attribute
 * @property {string} label - Content to display within the the <label> element for the checkbox
 * @property {string} name - Sets the <input type="checkbox"> element's HTML "name" attribute
 * @property {string} value - Sets the <input type="checkbox"> element's HTML "value" attribute
 * @property {boolean} [required] - Whether the checkbox is a required field; sets the <input type="checkbox"> element's HTML "required" attribute and other accessible features
 * @property {boolean} [disabled] - Whether the checkbox is in the disabled state; Sets the <input type="checkbox"> element's HTML "disabled" attribute and other accessible features
 * @property {boolean} [error] - Whether the checkbox is in the error state; sets style classes and other accessible features
 * @property {string} [className] - Optional, custom user-defined CSS class(es) for the component's <input type="checkbox"> element: will be appended to the list of any other component classes
 * @property {string} [labelClassName] - Optional, custom user-defined CSS class(es) for the component's <label> element; will be appended to the list of any other component classes
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Optional, The React `{...rest}` prop allows all non-prop attributes added to the component markup to be rendered as attributes on the component's <input type="checkbox"> element.
 */
const LdsCheckbox = forwardRef(
  /**
   * LdsCheckbox component
   * @param {LdsCheckboxProps & React.InputHTMLAttributes<HTMLInputElement>} props
   * @returns {React.JSX.Element} - LdsCheckbox component
   */
  function LdsCheckbox(
    {
      id,
      label,
      name,
      value,
      required = false,
      disabled = false,
      error = false,
      className,
      labelClassName,
      ...rest
    },
    ref
  ) {
    // MARK: RENDER
    return (
    <label
      className={cn(
        'lds-check-label',
        {
          disabled,
        },
        labelClassName
      )}
    >
      <input
        className={cn(
          'lds-checkbox',
          {
            disabled,
            error,
          },
          className
        )}
        id={id}
        required={required}
        aria-required={required ? 'true' : null}
        type="checkbox"
        name={name}
        value={value}
        disabled={disabled}
        {...rest}
        ref={ref}
      />
      {label}
    </label>
    );
  }
);

// MARK: PROP VALIDATION
LdsCheckbox.propTypes = {
  id: PropTypes.string.isRequired,
  label: PropTypes.any.isRequired,
  name: PropTypes.string.isRequired,
  value: PropTypes.string.isRequired,
  required: PropTypes.bool,
  disabled: PropTypes.bool,
  error: PropTypes.bool,
  className: PropTypes.string,
  labelClassName: PropTypes.string,
  rest: PropTypes.any,
};

export default LdsCheckbox;
