import {
  forwardRef,
  useEffect,
  useRef,
  useState
} from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsButton from '../LdsButton/index.jsx';
import LdsIcon from '../LdsIcon/index.jsx';
import LdsLoadingSpinner from '../LdsLoadingSpinner/index.jsx';
import LdsTooltip from '../LdsTooltip/index.jsx';
import SearchInput from './SearchInput.jsx';
import useOutsideClick from '../../util/useOutsideClick.js';

import LdsSearchSuggestion from '../LdsHeader/Search/SearchSuggestion.jsx';

// JSDoc type definitions
/**
 * @typedef LdsSearchProps
 * @property {string} searchTerm - value for search input field
 * @property {boolean} [autofocus] - Autofocus search field on page load?
 * @property {string} [clearBtnAriaLabel] - Aria label attribute value for clear button.
 * @property {boolean} [disabled] - Controls whether or not the search field and buttons are disabled
 * @property {string} [id] - ID attribute value for search input. This value is also used as the ID for the search form with "Form" appended to the ID.
 * @property {string} [inputAriaDescription] - Text that populates the `#search-helper` element. This element "describes" the search input by its `aria-describedby` attribute.
 * @property {string} [inputAriaLabel] - Arial label attribute value for search input field. Set to an empty string if there is a `<label>` element with a `for` attribute associated to the search input.
 * @property {boolean} [isLoading] - If set to `true`, submit button is disabled loading spinner is displayed
 * @property {function} [setSearchTerm] - Custom handler for change event
 * @property {function} [onFocus] - Custom handler for focus event
 * @property {function} [onInput] - Custom handler for input event
 * @property {string} [loadingBtnAriaLabel] - Arial label attribute value for loading button
 * @property {string} [placeholder] - Placeholder attribute value for search input field
 * @property {function} [searchOnBtnClick] - Custom handler for search button click event. Receives the event and the input value as arguments.
 * @property {Object[]} [searchSuggestions] - Array of suggested search result objects if using auto-suggestion feature
 * @property {string} [submitBtnAriaLabel] - Arial label attribute value for submit button
 * @property {string} [suggestionsAriaLabel] - Arial label attribute value for the search suggestions. For accessibility it should notify users how many suggestions are available by using the `searchSuggestions.length` variable via a string literal.
 * @property {string} [className] - Optional custom user-defined CSS class(es) for the search field container form element, will be appended to the list of any other component classes
 * @property {string} [searchInputClassName] - Optional custom user-defined CSS class(es) for the search input element, will be appended to the list of any other component classes
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [searchInputAttributes] - An additional properties object to pass generic HTML attributes onto the search input element
 * @property {string} [searchClearBtnAriaLabel] - Aria label for the clear search button
 * @property {function} [searchCustomResult] - Custom render function for search results
 * @property {function} [searchOnSuggestionClick] - Handler for clicking a search suggestion
 */
const LdsSearch = forwardRef(
  /**
   * LdsSearch component
   * @param {LdsSearchProps & React.InputHTMLAttributes<HTMLInputElement>} props
   * @returns {React.JSX.Element}
   */
  function LdsSearch({
    autofocus = true,
    searchTerm = '',
    disabled = false,
    id,
    inputAriaDescription = 'Suggestions will update as you type',
    inputAriaLabel = 'Search the site',
    isLoading = false,
    setSearchTerm = () => {},
    onFocus = () => {},
    onInput = () => {},
    placeholder = 'Type search term...',
    searchSuggestions = [],
    submitBtnAriaLabel = 'Submit search',
    suggestionsAriaLabel = `Search suggestions. ${searchSuggestions.length} results. Use up and down arrows to review.`,
    className,
    searchInputClassName,
    searchInputAttributes,
    searchClearBtnAriaLabel = 'Clear search term',
    searchCustomResult,
    searchOnBtnClick = () => {},
    searchOnSuggestionClick = () => {},
    ...rest
  }, ref) {
    const [isOpen, setIsOpen] = useState(false);
    const [currentFocusPosition, setCurrentFocusPosition] = useState(-1);

    const inputRef = useRef();
    const listRef = useRef(null);

    const hasSearchSuggestions = searchSuggestions
      && Array.isArray(searchSuggestions)
      && searchSuggestions.length > 0;

    const clearSearchQuery = () => {
      setSearchTerm('');
      if (inputRef.current) inputRef.current.focus();
    };

    const resetSearchSuggestions = () => {
      setIsOpen(false);
      setCurrentFocusPosition(-1);
    };

    // Handle spacebar event for search suggestion click
    useEffect(() => {
      const handleSpaceKey = (e) => {
        if (e.key === ' ' && currentFocusPosition > -1) {
          e.preventDefault();
          searchOnSuggestionClick(searchSuggestions[currentFocusPosition]);
          setCurrentFocusPosition(-1); // clear focus position after we click an item
        }
      };
      window.addEventListener('keydown', handleSpaceKey);

      return () => window.removeEventListener('keydown', handleSpaceKey);
    }, [currentFocusPosition, searchOnSuggestionClick, searchSuggestions]);

    const handleNavigation = (e) => {
      // NOTE: Space key event is inside of a useEffect to avoid re-rendering issues

      if (e.key === 'Escape' && isOpen) {
        setIsOpen(false);
        setCurrentFocusPosition(-1);
      }

      if (e.key === 'ArrowUp') {
        const isFirstItemFocused = currentFocusPosition <= 0;

        if (isFirstItemFocused) {
          // On first item - go to last item
          setCurrentFocusPosition(searchSuggestions.length - 1);
        } else {
          // Move up to next item
          setCurrentFocusPosition(currentFocusPosition - 1);
        }
      }

      if (e.key === 'ArrowDown') {
        const isLastItemFocused = currentFocusPosition >= searchSuggestions.length - 1;

        if (isLastItemFocused) {
          // Last item is focused - go to first item
          setCurrentFocusPosition(0);
        } else {
          // Move down 1 item
          setCurrentFocusPosition(currentFocusPosition + 1);
        }
      }
    };

    const handleFocus = (e) => {
      setCurrentFocusPosition(-1);
      onFocus(e);
    };

    const handleInput = (e) => {
      onInput(e);
    };

    const handleInputTextChange = (e) => {
      // reenable autosuggest when input text is changed
      setSearchTerm(e.target.value);
    };

    useEffect(() => {
      if (typeof searchTerm !== 'string') {
        setSearchTerm('');
        return;
      }

      if (searchTerm) {
        setCurrentFocusPosition(-1);
        setIsOpen(true);
      } else {
        resetSearchSuggestions();
      }
    }, [searchTerm, setSearchTerm]);

    useOutsideClick(inputRef, () => {
      resetSearchSuggestions();
    });

    useEffect(() => {
      if (currentFocusPosition === null || currentFocusPosition === -1 || !listRef.current) return;

      // if using arrow keys to navigate we need to scroll to the suggestion if it is offscreen.
      // block: end will make this only scroll if it is not currently in view
      const results = listRef.current.querySelectorAll('.search-anchor');
      results[currentFocusPosition].scrollIntoView({ block: 'end' });
    }, [currentFocusPosition, listRef]);

    const RenderSearchResult = () => {
      if (!hasSearchSuggestions) return '';

      if (searchCustomResult) {
        return searchSuggestions.map((result, idx) => searchCustomResult(
          { ...result, currentFocusPosition, focusIndex: idx }
        ));
      }

      return searchSuggestions.map((result, idx) => (
        <LdsSearchSuggestion
          key={result.title}
          searchTerm={searchTerm}
          focusIndex={idx}
          currentFocusPosition={currentFocusPosition}
          onClick={searchOnSuggestionClick}
          suggestion={result}
        />
      ));
    };

    const handleInputKeyDown = (e) => {
      if (e.key === 'Enter') {
        if ((currentFocusPosition === -1 || currentFocusPosition === null)) {
          searchOnBtnClick(e, inputRef.current.value);
        } else if (currentFocusPosition > -1) {
          searchOnSuggestionClick(searchSuggestions[currentFocusPosition]);
          setCurrentFocusPosition(null); // clear focus position after we click an item
        }
      }
      handleNavigation(e);
    };

    return (
      <div
        className={cn(
          'lds-search',
          'lds-search-typeahead',
          className
        )}
        id={`${id}Form`}
        onKeyDown={handleNavigation}
        ref={ref}
        role="search"
        {...rest}
      >
        <SearchInput
          autofocus={autofocus}
          className={searchInputClassName}
          disabled={disabled}
          currentFocusPosition={currentFocusPosition}
          handleFocus={handleFocus}
          handleInput={handleInput}
          inputAriaLabel={inputAriaLabel}
          inputId={id}
          placeholder={placeholder}
          value={searchTerm}
          onChange={handleInputTextChange}
          onKeyDown={handleInputKeyDown}
          ref={inputRef}
          isOpen={isOpen}
          {...searchInputAttributes}
        />
        <LdsTooltip
          className="lds-search-clear-tooltip"
          hideIcon
          tooltipMode="link"
          openDelay={100}
          position="bottom"
        >
          <LdsTooltip.Text>
            <button
              className="lds-search-clear lds-button-base"
              aria-label={searchClearBtnAriaLabel}
              onClick={clearSearchQuery}
              disabled={disabled}
            >
              <LdsIcon decorative inline name="x" />
            </button>
          </LdsTooltip.Text>
          <LdsTooltip.Description>{searchClearBtnAriaLabel}</LdsTooltip.Description>
        </LdsTooltip>
        {isOpen && (hasSearchSuggestions || isLoading) && (
          <div
            aria-label={suggestionsAriaLabel}
            className="lds-search-suggestions lds-search-list"
            id="searchSuggestions"
            role="listbox"
            ref={listRef}
          >
            <RenderSearchResult />
            { isLoading && <div className="loading-container"><LdsLoadingSpinner size={72} /></div> }
          </div>
        )}
        <span id="search-helper" className="sr-only">{inputAriaDescription}</span>
        <LdsTooltip
          className="lds-search-button-tooltip"
          hideIcon
          tooltipMode="link"
          openDelay={100}
          position="bottom"
        >
          <LdsTooltip.Text>
            <LdsButton
              aria-label={submitBtnAriaLabel}
              classes="icon-button lds-search-button"
              type="submit"
              onClick={(e) => searchOnBtnClick(e, inputRef.current.value)}
              disabled={disabled}
            >
              <LdsIcon
                name="MagnifyingGlass"
                inline
                decorative
              />
            </LdsButton>
          </LdsTooltip.Text>
          <LdsTooltip.Description>{submitBtnAriaLabel}</LdsTooltip.Description>
        </LdsTooltip>
      </div>
    );
  }
);

LdsSearch.propTypes = {
  autofocus: PropTypes.bool,
  disabled: PropTypes.bool,
  id: PropTypes.string,
  inputAriaDescription: PropTypes.string,
  inputAriaLabel: PropTypes.string,
  isLoading: PropTypes.bool,
  loadingBtnAriaLabel: PropTypes.string,
  setSearchTerm: PropTypes.func,
  onFocus: PropTypes.func,
  onInput: PropTypes.func,
  placeholder: PropTypes.string,
  searchOnBtnClick: PropTypes.func,
  searchSuggestions: PropTypes.array,
  submitBtnAriaLabel: PropTypes.string,
  suggestionsAriaLabel: PropTypes.string,
  searchTerm: PropTypes.string.isRequired,
  className: PropTypes.string,
  searchInputClassName: PropTypes.string,
  searchInputAttributes: PropTypes.object,
  searchClearBtnAriaLabel: PropTypes.string,
  searchCustomResult: PropTypes.func,
  searchOnSuggestionClick: PropTypes.func,
};

export default LdsSearch;
