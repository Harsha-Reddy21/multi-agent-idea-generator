import { forwardRef } from 'react';
import cn from 'classnames';

export default forwardRef(function SearchInput({
  autofocus,
  disabled,
  currentFocusPosition,
  handleFocus,
  handleInput,
  onChange,
  inputAriaLabel,
  inputId,
  placeholder,
  value,
  isOpen,
  className,
  ...rest
}, ref) {
  const activeDescendantValue = () => {
    if (currentFocusPosition > -1) {
      return `suggestion-${currentFocusPosition}`;
    }
    return null;
  };

  return (
    <input
      aria-activedescendant={activeDescendantValue()}
      aria-autocomplete="both"
      aria-describedby="search-helper"
      aria-label={inputAriaLabel || null}
      aria-controls={isOpen ? 'searchSuggestions' : null }
      autoComplete="off"
      autoFocus={autofocus}
      className={cn(
        'lds-text-field',
        'lds-search-field',
        className
      )}
      disabled={disabled}
      id={inputId}
      name={inputId}
      onChange={onChange}
      onFocus={handleFocus}
      onInput={handleInput}
      placeholder={placeholder}
      ref={ref}
      type="search"
      value={value}
      {...rest}
    />
  );
});
