import { useErrorBoundary } from 'react-error-boundary';
import LdsButton from '../LdsButton/index.jsx';

// JSDoc comments to supply typscript compiler with the necessary types
/**
 * @typedef FallbackRenderProps
 * @property {boolean} [resetButton] - Whether to display a reset button
 * @property {string} [errorMessagePrefix] - Text to display before the error message
 * @property {string} [buttonText] - Text to display on the reset button
 * @property {Error} error - Error object to display
 */
/**
 * FallbackRender component
 * @param {FallbackRenderProps} props
 * @returns {React.JSX.Element} FallbackRender component
 */
export default function FallbackRender({
  resetButton,
  errorMessagePrefix,
  buttonText = 'Try again',
  error,
}) {
  const { resetBoundary } = useErrorBoundary();

  return (
    <div role="alert">
      <p>{errorMessagePrefix}</p>
      <pre style={{ color: 'red' }}>{error.message}</pre>
      {resetButton && (
        <LdsButton onClick={resetBoundary}>{buttonText}</LdsButton>
      )}
    </div>
  );
}
