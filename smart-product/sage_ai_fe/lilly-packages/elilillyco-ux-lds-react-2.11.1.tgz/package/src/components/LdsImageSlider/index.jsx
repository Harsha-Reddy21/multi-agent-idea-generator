import { createRef, useRef, useState } from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import LdsIcon from '../LdsIcon/index.jsx';

// JSDoc type definitions
/**
 * @typedef LdsImageSliderProps
 * @property {string} id - HTML id attribute to assign to Image Slider. Required for Image Slider to work.
 * @property {{src: string, alt?: string, caption?: string, style?: object}[]} images - An object which defines an array of images with valid src, alt, caption & style. src is required for image slider to work.
 * @property {number} [initialIndex] - Set an initial active image index value; defaults to the first image in the images object array
 * @property {boolean} [allowFullScreen] - Whether to allow full-screen mode.
 * @property {string} [ariaLabel] - A string value which sets the ARIA label attribute for Image Slider component
 * @property {string} [ariaRoledescription] - A string value which sets the ARIA role description attribute for Image Slider component
 * @property {string} [nextSlideButtonAriaLabel] - The ARIA label and title for the next slide button
 * @property {string} [previousSlideButtonAriaLabel] - The ARIA label and title for the previous slide button
 * @property {string} [fullscreenButtonExpandAriaLabel] - The ARIA label and title for the fullscreen toggle button when toggled off
 * @property {string} [fullscreenButtonCollapseAriaLabel] - The ARIA label and title for the fullscreen toggle button when toggled on
 * @property {string} [goToSlideTitle] - The title used for each individual slide button. The count of each slide is appended to the end of this value.
 * @property {string} [sliderDotsAriaLabel] - The ARIA label on the element containing all of the individual slide navigation buttons
 * @property {string} [slideAriaLabel] - The text used by the ARIA labels that describe each slide. The count of each slide is appended to the end of this value.
 * @property {number} [maxWidth] - Sets maxWidth for Image Slider
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [imageAttributes] - An additional properties object to pass generic HTML attributes onto the slide image IMG elements
 * @property {string} [ofText] - The text used to seperate the current slide count from the total slides count
 * @property {boolean} [showNumberIndicator] - Optional; Whether to show optional number indicator.
 * @property {string} [captionAlignStyleClass] - Optional; set one of the classes for the caption alignment; valid values are 'ta-center', 'ta-left' and 'ta-right'. default value is 'ta-center';
 * @property {string} [captionTypographyStyleClass] - Optional; set one of the classes for the caption typography; valid values are caption-text-bold', 'caption-text-heading' and 'caption-text-large' or leave undefined to use default
 * @property {string} [styleClass] - Optional; Set a string value for one of the variant component style classes; valid value is 'inverted' or leave undefined for the default style.
 * @property {string} [radiusClass] - Optional; set one of the border radius size classes for the component; valid values are 'radius-sm', 'radius-md' and 'radius-lg' or leave undefined to use the theme radius default
 * @property {string} [className] - Optional custom user-defined CSS class(es) to add to the component root container element; will be appended to the list of any other component classes
 */
/**
 * LdsImageSlider component
 * @param {LdsImageSliderProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
export default function LdsImageSlider({
  id,
  images = [],
  initialIndex = 0,
  allowFullScreen = true,
  ariaLabel,
  ariaRoledescription = 'image slides',
  nextSlideButtonAriaLabel = 'Next Slide',
  previousSlideButtonAriaLabel = 'Previous Slide',
  fullscreenButtonExpandAriaLabel = 'Expand image to full size',
  fullscreenButtonCollapseAriaLabel = 'Collapse image to fit',
  goToSlideTitle = 'Go to slide',
  sliderDotsAriaLabel = 'Slides',
  slideAriaLabel = 'Slide',
  maxWidth,
  imageAttributes,
  ofText = 'of',
  showNumberIndicator = false,
  captionTypographyStyleClass,
  captionAlignStyleClass = 'ta-center',
  styleClass,
  radiusClass,
  className,
  ...rest
}) {
  const imagesRef = useRef(images.map(() => createRef()));
  const captionsRef = useRef(images.map(() => createRef()));
  const dotsRef = useRef(images.map(() => createRef()));
  const imgSliderRef = useRef(null);
  const activeCountRef = useRef(null);
  const toggleBtnRef = useRef(null);
  let currentImgIdx = initialIndex;

  const [expanded, setExpanded] = useState(false);

  const setActiveIndex = (index) => {
    currentImgIdx = index;
    activeCountRef.current.textContent = index + 1;
    captionsRef.current.forEach(el => el.current.classList.remove('active'));
    dotsRef.current.forEach(el => {
      el.current.classList.remove('active');
      el.current.setAttribute('aria-selected', 'false');
    });
    captionsRef.current[index].current.classList.add('active');
    dotsRef.current[index].current.classList.add('active');
    dotsRef.current[index].current.setAttribute('aria-selected', 'true');
  };

  const scrollToSlide = (index, scrollBehavior = 'smooth') => {
    let slide = null;
    slide = imagesRef.current[index]?.current;
    slide.scrollIntoView({
      behavior: scrollBehavior,
      inline: 'start',
      block: 'nearest',
    });
    setActiveIndex(index);
  };

  const handleNavBtnClick = (next = 0) => {
    const totalSlides = images.length;
    let slideIndex = currentImgIdx;
    slideIndex += next;
    if (slideIndex >= totalSlides) { slideIndex = 0; }
    if (slideIndex < 0) { slideIndex = totalSlides - 1; }
    scrollToSlide(slideIndex);
  };

  const handleDotBtnClick = (index) => {
    scrollToSlide(index);
  };

  const toggleExpanded = () => {
    setExpanded(currentExpandedStatus => !currentExpandedStatus);
    scrollToSlide(currentImgIdx, 'instant');
  };

  const toggleButtonLabel = expanded ? fullscreenButtonCollapseAriaLabel : fullscreenButtonExpandAriaLabel;

  const imageSliderFullScreenToggle = (
    <div className="lds-image-slider-full-screen">
      <button
        className="lds-button-base lds-image-slider-full-screen-toggle"
        title={toggleButtonLabel}
        aria-label={toggleButtonLabel}
        ref={toggleBtnRef}
        onClick={toggleExpanded}
      >
        <LdsIcon
          name={expanded ? 'ArrowsInSimple' : 'ArrowsOutSimple'}
          label={toggleButtonLabel}
          decorative
          inline
        />
      </button>
    </div>
  );

  const imageSliderNavButtons = (
    <div className="lds-image-slider-navigation">
      <button
        className="lds-button-base lds-image-slider-prev"
        title={previousSlideButtonAriaLabel}
        aria-label={previousSlideButtonAriaLabel}
        onClick={() => handleNavBtnClick(-1)}
      >
        <LdsIcon
          name="CaretLeft"
          label={previousSlideButtonAriaLabel}
          decorative
          inline
        />
      </button>
      <button
        className="lds-button-base lds-image-slider-next"
        title={nextSlideButtonAriaLabel}
        aria-label={nextSlideButtonAriaLabel}
        onClick={() => handleNavBtnClick(1)}
      >
        <LdsIcon
          name="CaretRight"
          label={nextSlideButtonAriaLabel}
          decorative
          inline
        />
      </button>
    </div>
  );

  const imageSliderBottomNavButtons = (
    <div
      className={cn(
        'lds-image-slider-bottom-navigation',
        {
          counter: showNumberIndicator,
        }
      )}
    >
      <div className="lds-image-slider-counter">
        <span
          className="active-count"
          ref={activeCountRef}
        >
          {currentImgIdx + 1}
        </span>
        <span className="of-text">{ofText}</span>
        <span className="total-count">{images.length}</span>
      </div>
      <div
        className="lds-image-slider-dots"
        role="tablist"
        aria-label={sliderDotsAriaLabel}
      >
        {
          images.map((_, index) => (
            <button
              id={`image-slider-dots-${index + 1}`}
              ref={dotsRef.current[index]}
              key={`image-slider-dots-${index}`}
              className={cn(
                initialIndex === index ? 'active' : '',
                'lds-button-base'
              )}
              title={`${goToSlideTitle} ${index + 1}`}
              role="tab"
              aria-label={`${slideAriaLabel} ${index + 1}`}
              aria-selected={currentImgIdx === index}
              aria-controls={`image-slide-${index + 1}`}
              onClick={() => handleDotBtnClick(index)}
            >
              <span className="dot" />
            </button>
          ))
        }
      </div>
    </div>
  );

  const imageSliderCaptions = (
    <div
      className={cn(
        'lds-image-slider-captions',
        captionAlignStyleClass,
        captionTypographyStyleClass
      )}
      aria-live="polite"
    >
      {
        images.map((img, index) => (
          <p
            key={`image-slider-captions-${index}`}
            ref={captionsRef.current[index]}
            className={initialIndex === index ? 'active' : ''}
          >
            <span className="sr-only">
              {`${slideAriaLabel} ${index + 1} ${img.alt}`}
            </span>
            {img.caption ? img.caption : '\u00A0'}
          </p>
        ))
      }
    </div>
  );

  const imageSliderImages = (
    <div className="lds-image-slider-body">
      <div className="lds-image-slider-frame">
        {
          images.map((img, index) => (
            <div
              key={`image-slider-images-${index}`}
              ref={imagesRef.current[index]}
              className="lds-image-slider-frame-segment d-flex justify-content-center"
              id={`image-slide-${index + 1}`}
              aria-labelledby={`image-slider-dots-${index + 1}`}
              role="tabpanel"
            >
              <img
                className={cn({ 'w-100': !!maxWidth && !expanded })}
                src={img.src}
                alt={img.alt ? img.alt : `${slideAriaLabel} ${index + 1}`}
                {...imageAttributes}
                style={expanded ? null : { ...img.style, ...imageAttributes?.style }}
              />
            </div>
          ))
        }
      </div>
    </div>
  );

  return (
    <div
      className="lds-image-slider-container"
      style={{ maxWidth: maxWidth ? maxWidth + 'px' : '' }}
    >
      <div
        id={id}
        className={cn(
          {
            expanded,
          },
          'lds-image-slider',
          styleClass,
          radiusClass,
          className
        )}
        ref={imgSliderRef}
        role="region"
        aria-roledescription={ariaRoledescription}
        aria-label={ariaLabel}
        {...rest}
      >
        {imageSliderImages}
        {allowFullScreen && imageSliderFullScreenToggle}
        {imageSliderNavButtons}
        {imageSliderBottomNavButtons}
      </div>
      {imageSliderCaptions}
    </div>
  );
}

LdsImageSlider.propTypes = {
  id: PropTypes.string.isRequired,
  allowFullScreen: PropTypes.bool,
  ariaLabel: PropTypes.string,
  ariaRoledescription: PropTypes.string,
  initialIndex: PropTypes.number,
  images: PropTypes.arrayOf((propValue, key, componentName, propFullName) => { // eslint-disable-line
    if (!propValue[key].src) {
      return new Error(
        `Invalid prop ${propFullName} supplied to ${componentName} at index ${key}. Each Image object must contain a "src" property.`
      );
    }
  }).isRequired,
  showNumberIndicator: PropTypes.bool,
  ofText: PropTypes.string,
  nextSlideButtonAriaLabel: PropTypes.string,
  previousSlideButtonAriaLabel: PropTypes.string,
  fullscreenButtonExpandAriaLabel: PropTypes.string,
  fullscreenButtonCollapseAriaLabel: PropTypes.string,
  goToSlideTitle: PropTypes.string,
  sliderDotsAriaLabel: PropTypes.string,
  slideAriaLabel: PropTypes.string,
  captionAlignStyleClass: PropTypes.oneOf(['ta-center', 'ta-left', 'ta-right']),
  captionTypographyStyleClass: PropTypes.oneOf(['caption-text-bold', 'caption-text-heading', 'caption-text-large', undefined]),
  styleClass: PropTypes.oneOf(['inverted', undefined]),
  radiusClass: PropTypes.oneOf(['radius-sm', 'radius-md', 'radius-lg', undefined]),
  maxWidth: PropTypes.number,
};
