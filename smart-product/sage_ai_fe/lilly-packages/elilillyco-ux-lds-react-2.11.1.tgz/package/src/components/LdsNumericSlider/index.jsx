/* eslint-disable quote-props */
// MARK: IMPORTS
import {
  forwardRef,
  useEffect,
  useRef,
  useState
} from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

// MARK: Sub-Components
import NumericSliderRangeLabel from './private/RangeLabel.jsx';
import NumericSliderStepIndicators from './private/StepIndicators.jsx';

// MARK: Utilities
import {
  staticVars,
  propsDefault,
  elementIds,
  elementClasses,
  canShowRangeLabels,
  getRangeLabelPositions,
  canShowStepDotIndicators,
  canShowStepValueIndicators,
  getValidMin,
  getValidMax,
  getValidRange,
  getValidStepInRange,
  getValidSteps,
  getValidDecimalPrecision,
  getValidValueInRange,
  getValidValueDisplayDuration,
  validValueDisplayTypes,
  validRangeLabelPositions,
  validatePropTypeMax,
  validatePropTypeMin,
  validatePropTypeStep,
  validatePropTypeDecimalPrecision,
  validatePropTypeValue,
  getElementRefById,
  getUpdatedElementOffsetWidth
} from './util.js';

import { consoleWriter } from '../../util/consoleWriter.js';
// Enable local development only debugging; DO NOT COMMIT THIS SET TO TRUE
const enableDevDebug = false;

// MARK: COMPONENT DEF

// JSDoc type definitions
/**
 * @typedef LdsNumericSliderProps
 * @property {string} [id] - REQUIRED: Component `id`; must be unique for each table.
 * @property {number} [min=0] - The minimum selectable value
 * @property {number} [max=100] - The maximum selectable value
 * @property {number} [step=1] - The step increment to use between the min and max
 * @property {number} [decimalPrecision=0] - If using fractional values (decimal numbers) for the range or the step increment, an appropriate decimal place precision must be set. The default of zero (0) assumes integer step increments within an integer range.
 * @property {number} [value=0] - The selected value
 * @property {string} [valueDisplayType='never'] - Set a display type for whether and how to show the current value in a "bubble" above the slider handle. Accepts: `'never'`, `'always'`, or `'temporary'`
 * @property {number} [valueDisplayDuration='500'] - Set a numeric value for how long (in milliseconds) the temporary value bubble should be displayed`
 * @property {boolean} [showStepIndicators=false] - Whether to display the step increment dot indicators along the numeric slider's track at the step positions.
 * @property {boolean} [showStepValues] - Whether to display the step increment value indicators below the numeric slider's track at the step positions.
 * @property {boolean} [showRangeLabels=false] - Whether to show the range labels
 * @property {string} [rangeLabelPositions] - Set a positioning configuration for the range labels. Accepts: `'around'`, `'below'`, or `undefined`. When not set or falsy (which is the default) it uses "around" mode.
 * @property {React.ReactNode} [minLabel='0'] - The content for the minimum value label
 * @property {string} [minAriaLabel='minimum value'] - The accessible content for the minimum range label's `aria-label` attribute
 * @property {React.ReactNode} [midLabel='50'] - The content for the median value label
 * @property {string} [midAriaLabel='median value'] - The accessible content for the median range label's `aria-label` attribute
 * @property {React.ReactNode} [maxLabel='100'] - The content for the maximum value label
 * @property {string} [maxAriaLabel='maxiumm value'] - The accessible content for the maximum range label's `aria-label` attribute
 * @property {boolean} [disabled=false] - Whether the input should be in the disabled state
 * @property {string} [className] - Optional custom user-defined CSS class(es) for the component context, will be appended to the list of any other component classes on the component's root container element.
 * @property {object} [inputAttributes] - Optional additional properties object to pass generic HTML attributes onto component's `<input type="range">` element.
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Optional, define any additional non-prop attributes to be rendered on the component's root container element.
 * @property {boolean} [showSteps=null] - DEPRICATED Whether to display the step increment indicators on the slider track
 * @property {boolean} [showMinMax=null] - DEPRECATED Whether to show the range labels
 */
const LdsNumericSlider = forwardRef(
  /**
   * LdsNumericSlider component
   * @param {LdsNumericSliderProps & React.InputHTMLAttributes<HTMLInputElement>} props
   * @returns {React.JSX.Element}
   */
  function LdsNumericSlider(
    {
      id,
      min = propsDefault.min,
      max = propsDefault.max,
      step = propsDefault.setp,
      decimalPrecision = propsDefault.decimalPrecision,
      value = propsDefault.value,
      valueDisplayType = propsDefault.valueDisplayType,
      valueDisplayDuration = propsDefault.valueDisplayDuration,
      showStepIndicators = propsDefault.showStepIndicators,
      showStepValues = propsDefault.showStepValues,
      showRangeLabels = propsDefault.showRangeLabels,
      rangeLabelPositions = propsDefault.rangeLabelPositions,
      minLabel = propsDefault.minLabel,
      minAriaLabel = propsDefault.minAriaLabel,
      midLabel = propsDefault.midLabel,
      midAriaLabel = propsDefault.midAriaLabel,
      maxLabel = propsDefault.maxLabel,
      maxAriaLabel = propsDefault.maxAriaLabel,
      disabled = propsDefault.disabled,
      className = propsDefault.className,
      inputAttributes = propsDefault.inputAttributes,
      showMinMax = null, // TODO: Remove in the next minor version release
      showSteps = null, // TODO: Remove in the next minor version release
      ...rest
    },
    ref
  ) {
    // MARK: Variables
    const vars = staticVars();
    const ids = elementIds(id);
    const classes = elementClasses(id, 'lds-numeric-slider');

    const componentRef = useRef();
    const controlRef = useRef();

    const [rangeMin, setRangeMin] = useState(min);
    const [rangeMax, setRangeMax] = useState(max);
    const [stepIncrement, setStepIncrement] = useState(step);
    const [decimalPlaces, setDecimalPlaces] = useState(decimalPrecision);
    const [activeValue, setActiveValue] = useState(value);
    const [trackOffsetWidth, setTrackOffsetWidth] = useState(vars.controlTrackMinWidth);
    const [handleOffsetWidth, setHandleOffsetWidth] = useState(vars.controlHandleWidth);
    const [minLabelInnerOffsetWidth, setMinLabelInnerOffsetWidth] = useState(0);
    const [maxLabelInnerOffsetWidth, setMaxLabelInnerOffsetWidth] = useState(0);
    const [doShowRangeLabels, setDoShowRangeLabels] = useState(showRangeLabels);
    const [doPositionRangeLabelsBelow, setDoPositionRangeLabelsBelow] = useState(false);
    const [doShowStepIndicatorDots, setDoShowStepIndicatorDots] = useState(showStepIndicators);
    const [doShowStepIndicatorValues, setDoShowStepIndicatorValues] = useState(showStepValues);
    const [isFocused, setIsFocused] = useState(false);
    const [isMoving, setIsMoving] = useState(false);
    const [movingTimeout, setMovingTimeout] = useState(null);
    const [isDisabled, setIsDisabled] = useState(propsDefault.disabled);

    // MARK: Methods

    /**
     * Render a debug message to the console if debugging is enabled in this component locally
     * @param {string} message the debug message
     * @param {string} level the debug message type; `'log'`, `'warn'` or `'error'`; default is "log"
     * @param {boolean} useValue whether to send an output value
     * @param {*} value the value to output with `useValue`
     */
    const debug = (message, level = 'log', useValue = false, value = undefined) => {
      if (enableDevDebug) { consoleWriter(message, level, useValue, value); }
    };

    /**
     * Set the min value state
     * @param {number} newMin a new min value to set
     * @returns {number} the valid new min value that was set
     */
    const setMin = (newMin) => {
      try {
        const validMin = getValidMin(newMin);
        if (validMin === rangeMin) return rangeMin;
        setRangeMin(validMin);
        return validMin;
      } catch (ex) {
        debug(`>>> (×) ERROR: in subroutine setMin -> encountered unexpected exception: ${ex.message}`, 'error');
        return rangeMin;
      }
    };

    /**
     * Set the max value state
     * @param {number} curMin the current min state value
     * @param {number} newMax the new max value to set
     * @returns {number} the valid new max value that was set
     */
    const setMax = (curMin, newMax) => {
      try {
        const validMax = getValidMax(curMin, newMax);
        if (validMax === rangeMax) return rangeMax;
        setRangeMax(validMax);
        return validMax;
      } catch (ex) {
        debug(`>>> (×) ERROR: in subroutine setMax -> encountered unexpected exception in: ${ex.message}`, 'error');
        return rangeMax;
      }
    };

    /**
     * Set the decimalPrecision value state
     * @param {number} newDecimalPrecision the new decimal precision value to set
     * @returns {number} the valid new decimal precision value that was set
     */
    const setDecimalPrecision = (newDecimalPrecision) => {
      try {
        const validDecimalPrecision = getValidDecimalPrecision(newDecimalPrecision);
        if (validDecimalPrecision === decimalPlaces) return decimalPlaces;
        setDecimalPlaces(validDecimalPrecision);
        return validDecimalPrecision;
      } catch (ex) {
        debug(`>>> (×) ERROR: in subroutine setDecimalPrecision -> encountered unexpected exception in: ${ex.message}`, 'error');
        return decimalPlaces;
      }
    };

    /**
     * Set the step increment value state
     * @param {number} curMin the current min state
     * @param {number} curMax the current max state
     * @param {number} newStep the new step increment value to set
     * @param {number} curDecimalPrecision the current decimal prcision state
     * @returns {number} the valid new step increment with relation to the range that was set
     */
    const setStep = (curMin, curMax, newStep, curDecimalPrecision) => {
      try {
        const validStep = getValidStepInRange(curMin, curMax, newStep, curDecimalPrecision);
        if (validStep === stepIncrement) return stepIncrement;
        setStepIncrement(validStep);
        return validStep;
      } catch (ex) {
        debug(`>>> (×) ERROR: in subroutine setStep ->  encountered unexpected exception: ${ex.message}`, 'error');
        return stepIncrement;
      }
    };

    /**
     * Set the offsetWidth state of the numeric slider's track element
     * @param {HTMLElement} refTrack a reference to the track DOM element
     * @returns {number} the width of the track element in pixels
     */
    const setTrackOffsetWidthByRef = (refTrack) => {
      try {
        const newOffsetWidth = getUpdatedElementOffsetWidth(refTrack, trackOffsetWidth);
        if (newOffsetWidth !== trackOffsetWidth) setTrackOffsetWidth(newOffsetWidth);
        return newOffsetWidth;
      } catch (ex) {
        debug(`>>> (×) ERROR: in subroutine setTrackOffsetWidthByRef -> encountered unexpected exception: ${ex.message}\nReturning the current state of trackOffsetWidth: ${trackOffsetWidth}`, 'error');
        return trackOffsetWidth;
      }
    };

    /**
     * Set the offsetWidth state of the numeric slider's handle element
     * @param {HTMLElement} refHandle a reference to the handle DOM element
     * @returns {number} the width of the handle element in pixels
     */
    const setHandleOffsetWidthByRef = (refHandle) => {
      try {
        const newOffsetWidth = getUpdatedElementOffsetWidth(refHandle, handleOffsetWidth);
        if (newOffsetWidth !== handleOffsetWidth) setHandleOffsetWidth(newOffsetWidth);
        return newOffsetWidth;
      } catch (ex) {
        debug(`>>> (×) ERROR: in subroutine setHandleOffsetWidthByRef -> encountered unexpected exception: ${ex.message}\nReturning the current state of handleOffsetWidth: ${handleOffsetWidth}`, 'error');
        return handleOffsetWidth;
      }
    };

    /**
     * Set the offsetWidth state of the minimum range label element's inner container element
     * @param {boolean} curShowRangeLabels the current display state of the range labels
     * @param {HTMLElement} refRangeLabelMinInner a reference to the inner minimum range label DOM element
     * @returns {number} the width of the min range label
     */
    const setRangeLabelMinInnerOffsetWidthByRef = (curShowRangeLabels, refRangeLabelMinInner) => {
      if (!curShowRangeLabels) return minLabelInnerOffsetWidth;

      try {
        const newOffsetWidth = getUpdatedElementOffsetWidth(refRangeLabelMinInner, minLabelInnerOffsetWidth);
        if (newOffsetWidth !== minLabelInnerOffsetWidth) setMinLabelInnerOffsetWidth(newOffsetWidth);
        return newOffsetWidth;
      } catch (ex) {
        debug(`$>>> (×) ERROR: in subroutine setRangeLabelMinInnerOffsetWidthByRef -> encountered unexpected exception: ${ex.message}\nReturning the current state of minLabelInnerOffsetWidth: ${minLabelInnerOffsetWidth}`, 'error');
        return minLabelInnerOffsetWidth;
      }
    };

    /**
     * Set the offsetWidth state of the maximum range label element's inner container element
     * @param {boolean} curShowRangeLabels the current display state of the range labels
     * @param {HTMLElement} refRangeLabelMaxInner a reference to the inner maximum range label DOM element
     * @returns {number} the width of the max range label
     */
    const setRangeLabelMaxInnerOffsetWidthByRef = (curShowRangeLabels, refRangeLabelMaxInner) => {
      if (!curShowRangeLabels) return maxLabelInnerOffsetWidth;

      try {
        const newOffsetWidth = getUpdatedElementOffsetWidth(refRangeLabelMaxInner, maxLabelInnerOffsetWidth);
        if (newOffsetWidth !== maxLabelInnerOffsetWidth) setMaxLabelInnerOffsetWidth(newOffsetWidth);
        return newOffsetWidth;
      } catch (ex) {
        debug(`>>> (×) ERROR: in subroutine setRangeLabelMaxInnerOffsetWidthByRef -> encountered unexpected exception: ${ex.message}\nReturning the current state of maxLabelInnerOffsetWidth: ${maxLabelInnerOffsetWidth}`, 'error');
        return maxLabelInnerOffsetWidth;
      }
    };

    /**
     * Configures the overall display of the range labels
     * @param {boolean} curShowRangeLabels whether the range labels can be displayed
     * @param {string|undefined} curRangeLabelPositions the current range label configuration via the component prop; should be a string value of either `'around'` or `'below'`; if this is undefined the default "around" positioning will be used
     * @param {number} minLabelWidth the current width of the minimum range label
     * @param {number} maxLabelWidth the current width of the maximum range label
     */
    const setRangeLabelDisplay = (curShowRangeLabels, curRangeLabelPositions, minLabelWidth, maxLabelWidth) => {
      // Make sure there's an enable state update and then set the state value
      if (curShowRangeLabels !== doShowRangeLabels) setDoShowRangeLabels(curShowRangeLabels);

      // Check for the below positioning configuration setting
      let positionRangeLabelsBelow = false;
      if (curRangeLabelPositions === 'below') positionRangeLabelsBelow = true;

      // Make sure there's a position state update and then set the state value
      if (positionRangeLabelsBelow !== doPositionRangeLabelsBelow) setDoPositionRangeLabelsBelow(positionRangeLabelsBelow);

      // Adjust the median range label margins according to the position state
      const refMidLabel = getElementRefById(componentRef.current, ids.rangeLabel.mid.container);
      if (refMidLabel) {
        if (positionRangeLabelsBelow) {
          // When all three labels are below, they are evenly distributed using CSS flex-box
          refMidLabel.style.paddingInlineStart = '0';
          refMidLabel.style.paddingInlineEnd = '0';
        } else {
          // When only the range label is below, for it's content to appear centered below the slider track
          // it's inner width needs to be adjusted for the width of the min and max label widths (since the distribution may be asymetrical)
          // This also has the effect of ensuring the median label content is always within the width of the track
          if (minLabelWidth > 0) {
            refMidLabel.style.paddingInlineStart = `calc(var(--lds-spacing-numeric-slider-mid-label-padding-left) + ${minLabelWidth}px)`;
          }
          if (maxLabelWidth > 0) {
            refMidLabel.style.paddingInlineEnd = `calc(var(--lds-spacing-numeric-slider-mid-label-padding-right) + ${maxLabelWidth}px)`;
          }
        }
      }
    };

    /**
     * Sets the sliders handle to a new position on the slider track. Also updates the state of the selected values bar that displays to the left of the slider handle.
     * @param {number} newValue the new value within the slider's range to move the handle to
     * @param {HTMLElement} trackRef a reference to the slider's track DOM element
     * @param {HTMLElement} handleRef a reference to the slider's handle DOM element
     * @param {string} caller OPTIONAL - provide information about the function that called this function for debugging purposes
     */
    const setHandlePosition = (newValue, trackRef = null, handleRef = null, caller = '') => {
      const debugContext = `${caller ? `>>> ${caller}` : `LdsNumericSlider '${id}'`} => setHandlePosition`;
      const debugMessage = {
        newHandlePosition: undefined,
        xAborted: false,
        xAbortReason: undefined,
        xError: false,
        xErrorException: undefined,
      };

      try {
        const refInput = getElementRefById(componentRef.current, id, enableDevDebug);
        const refTrack = trackRef || getElementRefById(componentRef.current, ids.track, enableDevDebug);
        const refHandle = handleRef || getElementRefById(componentRef.current, ids.handle.base, enableDevDebug);
        const refStepBar = getElementRefById(componentRef.current, ids.steps.selectedBar, enableDevDebug);
        if (!refInput || !refTrack || !refHandle || !refStepBar) {
          if (!refInput) debug(`>>> WARNING: unexpected null element reference in => setHandlePosition: could not get an HTMLElement reference to the required custom input element id="${id}`, 'warn');
          if (!refTrack) debug(`>>> WARNING: unexpected null element reference in => setHandlePosition: could not get an HTMLElement reference to the required custom handle element id="${ids.track}`, 'warn');
          if (!refHandle) debug(`>>> WARNING: unexpected null element reference in => setHandlePosition: could not get an HTMLElement reference to the required custom handle element id="${ids.handle.base}`, 'warn');
          if (!refStepBar) debug(`>>> WARNING: unexpected null element reference in => setHandlePosition: could not get an HTMLElement reference to the required custom step bar element id="${ids.steps.selectedBar}`, 'warn');
          return;
        }

        const curMin = refInput.min;
        const curMax = refInput.max;

        const handle = {
          newValue: newValue,
          newValidValueWithinRange: getValidValueInRange(curMin, curMax, newValue),
          sliderMin: curMin,
          sliderMax: curMax,
          sliderValidRange: getValidRange(curMin, curMax),
          sliderRangeRatio: undefined, // percentage of the total slider track width
          sliderTrackOffsetWidth: setTrackOffsetWidthByRef(refTrack),
          sliderHandleOffsetWidth: setHandleOffsetWidthByRef(refHandle),
          sliderWidthOffset: undefined, // width offset computed from the track element offsets and the range ratio
          newPosition: undefined, // computed from the range ratio and width offset
          newPositionStyle: '',
          newPositionStyleBar: '',
        };
        handle.sliderRangeRatio = ((handle.newValidValueWithinRange - handle.sliderMin) / handle.sliderValidRange);
        handle.sliderWidthOffset = ((handle.sliderHandleOffsetWidth / handle.sliderTrackOffsetWidth) * handle.sliderRangeRatio);
        handle.newPosition = ((handle.sliderRangeRatio - handle.sliderWidthOffset) * 100);
        handle.newPositionStyle = `${handle.newPosition}%`;
        handle.newPositionStyleBar = `calc(${handle.newPosition}% + 10px)`;

        debugMessage.newHandlePosition = handle;

        // Update the handle position
        refHandle.style.insetInlineStart = handle.newPositionStyle;
        if (typeof refHandle.style.insetInlineStart === 'undefined') {
          refHandle.style.insetInlineStart = handle.newPositionStyle;
        }

        // Update the selected (active) steps track indicator overlay
        refStepBar.style.width = handle.newPositionStyleBar;

        // Update the active value state to be the new value of the handle
        setActiveValue(handle.newValidValueWithinRange);

        debug(`${debugContext} processed successfully!\n>>> RESULT:`, 'log', true, debugMessage);
      } catch (ex) {
        debugMessage.xError = true;
        debugMessage.xErrorException = ex;
        debug(`${debugContext} encountered an exception...\n>>> RESULT:`, 'error', true, debugMessage);
      }
    };

    /**
     * Computes the minimum total width required to display all of the step indicator value labels comfortably below the slider track
     * @param {number} curMin the current min state
     * @param {number} curMax the current max state
     * @param {number} curStep the current step increment state
     * @param {number} curDecimalPrecision the current decimal precision state
     * @returns {number} the minimum total width of the step increment value labels
     */
    const getStepValueIndicatorsMinTotalWidth = (curMin, curMax, curStep, curDecimalPrecision) => {
      const totalSteps = getValidSteps(curMin, curMax, curStep, curDecimalPrecision);
      const minimumTotalWidth = (totalSteps * vars.stepIndicatorValueMinHorzSize);

      // Try to get a node list of all the rendered step value items in DOM
      const refStepValueNodes = componentRef.current.querySelectorAll(`.${classes.base.stepValueInstance}`);

      // step value node list object is falsey!
      if (!refStepValueNodes) return minimumTotalWidth;

      // step value node list object is empty!
      if (refStepValueNodes.length <= 0) return minimumTotalWidth;

      // Compute the actual total width of all the rendered step value node objects
      // Also visually adjust them so that they are centered directly below their step location
      let newTotalWidth = 0;
      refStepValueNodes.forEach(stepValueNode => {
        const nodeWidth = stepValueNode.offsetWidth || vars.stepIndicatorValueMinHorzSize;

        const nodeLeft = `${-1 * ((nodeWidth / 2) - 2)}px`;
        stepValueNode.style.insetInlineStart = nodeLeft; // eslint-disable-line no-param-reassign

        const effectiveNodeWidth = nodeWidth + vars.stepIndicatorValueMargins;
        // debug(`>>> >>> Value node ${i} has width ${effectiveNodeWidth}px`);
        newTotalWidth += effectiveNodeWidth;
      });

      // The new total width is less than or equal to the minimum, so just use the minimum
      if (newTotalWidth <= minimumTotalWidth) return minimumTotalWidth;

      // Otherwise the new actual width value is greater than the minimum width value so return it
      return newTotalWidth;
    };

    /**
     * Sets the current state of the numeric slider
     *
     * @param {number} newMin the new `min` range value to use
     * @param {number} newMax the new `max` range value to use
     * @param {number} newStep the new `step` increment value to use
     * @param {number} newDecimalPrecision the new `decimalPrecision` value to use
     * @param {number} newValue the new selected value to set (also implies a new handle position)
     * @param {boolean} newShowRangelabels the new option of whether to show the range labels
     * @param {string|undefined} newRangeLabelPositions the new range label position configuration option
     * @param {boolean} newShowStepIndicators the new option of whether to show the step indicator dots
     * @param {boolean} newShowStepValues the new option of whehter to show the step indicator values
     * @param {number} newMinStepIndicatorValuesTrackWidth the potentially updated minimum track width which can allow step indicator values to be shown
     * @param {HTMLElement} refTrack OPTIONAL reference to the track element
     * @param {HTMLElement} refHandle OPTIONAL reference to the handle element
     * @param {HTMLElement} refRangeLabelMinInner OPTIONAL reference to the minimum range label's inner element
     * @param {HTMLElement} refRangeLabelMaxInner OPTIONAL reference to the maximum range label's inner element
     * @param {boolean} newShowMinMax DEPRECATED OPTIONAL prop value for whether to show the range labels
     * @param {boolean} newShowSteps DEPRECATED OPTIONAL prop value for whether to show the step indicator dots
     * @param {boolean} abortHandlePositionUpdate OPTIONAL whether to skip attempting to update the handle position state
     */
    const setState = (
      newMin,
      newMax,
      newStep,
      newDecimalPrecision,
      newValue,
      newShowRangeLabels,
      newRangeLabelPositions,
      newShowStepIndicators,
      newShowStepValues,
      newDisabledState,
      newComponentWidth,
      refTrack = null,
      refHandle = null,
      refRangeLabelMinInner = null,
      refRangeLabelMaxInner = null,
      deprecatedShowMinMax = null, // DEPRECATED PROP
      deprecatedShowSteps = null, // DEPRECATED PROP
      caller = ''
    ) => {
      const debugContext = `${caller ? `>>> ${caller}` : `LdsNumericSlider '${id}'`} => setState`;
      const debugMessage = {
        inputParams: undefined,
        initialStateVars: undefined,
        computedParams: undefined,
      };

      let thisCaller = 'setState';
      if (caller) thisCaller = `>>> ${caller} => setState`;

      try {
        if (enableDevDebug) {
          debugMessage.inputParams = {
            newMin: newMin,
            newMax: newMax,
            newStep: newStep,
            newDecimalPrecision: newDecimalPrecision,
            newValue: newValue,
            newShowRangeLabels: newShowRangeLabels,
            newRangeLabelPositions: newRangeLabelPositions,
            newShowStepIndicators: newShowStepIndicators,
            newShowStepValues: newShowStepValues,
            newDisabledState: newDisabledState,
            newComponentWidth: newComponentWidth,
            refTrack: refTrack,
            refHandle: refHandle,
            refRangeLabelMinInner: refRangeLabelMinInner,
            refRangeLabelMaxInner: refRangeLabelMaxInner,
            deprecatedShowMinMax: deprecatedShowMinMax,
            deprecatedShowSteps: deprecatedShowSteps,
          };
          debugMessage.initialStateVars = {
            vars: vars,
            ids: ids,
            classes: classes,
            componentRef: componentRef,
            controlRef: controlRef,
            rangeMin: rangeMin,
            rangeMax: rangeMax,
            stepIncrement: stepIncrement,
            decimalPlaces: decimalPlaces,
            activeValue: activeValue,
            trackOffsetWidth: trackOffsetWidth,
            handleOffsetWidth: handleOffsetWidth,
            minLabelInnerOffsetWidth: minLabelInnerOffsetWidth,
            maxLabelInnerOffsetWidth: maxLabelInnerOffsetWidth,
            doShowRangeLabels: doShowRangeLabels,
            doPositionRangeLabelsBelow: doPositionRangeLabelsBelow,
            doShowStepIndicatorDots: doShowStepIndicatorDots,
            doShowStepIndicatorValues: doShowStepIndicatorValues,
            isFocused: isFocused,
            isMoving: isMoving,
            movingTimeout: movingTimeout,
            isDisabled: isDisabled,
          };
        }

        debug(`${debugContext} processing...`);
        debug('>>> Current State:', 'log', true, debugMessage.initialStateVars);
        debug('>>> Input Params:', 'log', true, debugMessage.inputParams);

        const computedParams = {
          activeValue: newValue,
          inputDisabled: newDisabledState,
          rangeLabelDisplayEnabled: newShowRangeLabels,
          rangeLabelPositions: propsDefault.rangeLabelPositions,
          rangeLabelWidthMax: 0,
          rangeLabelWidthMin: 0,
          rangeMax: newMax,
          rangeMin: newMin,
          step: NaN,
          stepDecimalPrecision: newDecimalPrecision,
          stepIndicatorDotsEnabled: newShowStepIndicators,
          stepIndicatorValuesEnabled: newShowStepValues,
          stepIndicatorValuesMinTotalWidth: (newStep * vars.stepIndicatorValueMinHorzSize),
          widthTrack: NaN,
          widthHandle: NaN,
        };

        // Update range and step increment states
        computedParams.rangeMin = setMin(newMin);
        computedParams.rangeMax = setMax(computedParams.rangeMin, newMax);
        computedParams.stepDecimalPrecision = setDecimalPrecision(newDecimalPrecision);
        computedParams.step = setStep(computedParams.rangeMin, computedParams.rangeMax, newStep, computedParams.stepDecimalPrecision);

        // Update control element dimensions and positions
        computedParams.widthTrack = setTrackOffsetWidthByRef(refTrack);
        computedParams.widthHandle = setHandleOffsetWidthByRef(refHandle);
        setHandlePosition(computedParams.activeValue, refTrack, refHandle, thisCaller);

        // Configure range labels
        computedParams.rangeLabelDisplayEnabled = canShowRangeLabels(newShowRangeLabels, computedParams.widthTrack, enableDevDebug, deprecatedShowMinMax);
        setDoShowRangeLabels(computedParams.rangeLabelDisplayEnabled);
        computedParams.rangeLabelWidthMin = setRangeLabelMinInnerOffsetWidthByRef(computedParams.rangeLabelDisplayEnabled, refRangeLabelMinInner);
        computedParams.rangeLabelWidthMax = setRangeLabelMaxInnerOffsetWidthByRef(computedParams.rangeLabelDisplayEnabled, refRangeLabelMaxInner);
        computedParams.rangeLabelPositions = getRangeLabelPositions(newRangeLabelPositions, computedParams.rangeLabelWidthMin, computedParams.rangeLabelWidthMax, newComponentWidth, enableDevDebug);
        setRangeLabelDisplay(computedParams.rangeLabelDisplayEnabled, computedParams.rangeLabelPositions, computedParams.rangeLabelWidthMin, computedParams.rangeLabelWidthMax);

        // Configure step indicators
        computedParams.stepIndicatorDotsEnabled = canShowStepDotIndicators(newShowStepIndicators, computedParams.rangeMin, computedParams.rangeMax, computedParams.step, computedParams.stepDecimalPrecision, computedParams.widthTrack, enableDevDebug, deprecatedShowSteps);
        setDoShowStepIndicatorDots(computedParams.stepIndicatorDotsEnabled);
        computedParams.stepIndicatorValuesMinTotalWidth = getStepValueIndicatorsMinTotalWidth(computedParams.rangeMin, computedParams.rangeMax, computedParams.step, computedParams.stepDecimalPrecision);
        computedParams.stepIndicatorValuesEnabled = canShowStepValueIndicators(newShowStepValues, computedParams.rangeMin, computedParams.rangeMax, computedParams.step, computedParams.stepDecimalPrecision, computedParams.widthTrack, computedParams.stepIndicatorValuesMinTotalWidth, enableDevDebug);
        setDoShowStepIndicatorValues(computedParams.stepIndicatorValuesEnabled);

        // Update disabled state
        if (computedParams.inputDisabled !== isDisabled) setIsDisabled(computedParams.inputDisabled);

        debugMessage.computedParams = computedParams;

        debug(`${debugContext} processed successfully!\n>>> RESULT:`, 'log', true, debugMessage);
      } catch (ex) {
        debugMessage.xError = true;
        debugMessage.xErrorException = ex;
        debug(`${debugContext} encounted an exception...\n>>> RESULT:`, 'log', true, debugMessage);
      }
    };

    // MARK: Use Effects

    /**
     * INITIALIZATION EFFECT
     */
    useEffect(() => {
      debug(`<<< LdsNumericSlider '${id}' INITIALIZATION EFFECT >>>`, 'warn');
      const componentRefs = {
        componentOffsetWidth: 0,
        trackRef: null,
        handleRef: null,
        rangeLabelMinInnerRef: null,
        rangeLabelMaxInnerRef: null,
      };

      const initComponentRef = componentRef.current;
      if (initComponentRef) {
        componentRefs.componentOffsetWidth = initComponentRef.offsetWidth || 0;
        componentRefs.trackRef = getElementRefById(initComponentRef, ids.track, enableDevDebug);
        componentRefs.handleRef = getElementRefById(initComponentRef, ids.handle.base, enableDevDebug);
        componentRefs.rangeLabelMinInnerRef = getElementRefById(initComponentRef, ids.rangeLabel.min.inner, enableDevDebug);
        componentRefs.rangeLabelMaxInnerRef = getElementRefById(initComponentRef, ids.rangeLabel.max.inner, enableDevDebug);
      }

      try {
        setState(
          min,
          max,
          step,
          decimalPrecision,
          value,
          showRangeLabels,
          rangeLabelPositions,
          showStepIndicators,
          showStepValues,
          disabled,
          componentRefs.componentOffsetWidth,
          componentRefs.trackRef,
          componentRefs.handleRef,
          componentRefs.rangeLabelMinInnerRef,
          componentRefs.rangeLabelMaxInnerRef,
          showMinMax,
          showSteps,
          'INIT useEffect'
        );
      } catch (ex) {
        debug('> (×) ERROR: unexpected exception in INITALIZATION useEffect; exception:', 'error', true, ex.message);
      }
    }, [componentRef]); // eslint-disable-line react-hooks/exhaustive-deps

    /**
     * UPDATE EFFECT
     */
    useEffect(
      () => {
        debug(`<<< LdsNumericSlider '${id}' UPDATE EFFECT >>>`, 'warn');
        const componentRefs = {
          componentOffsetWidth: 0,
          trackRef: null,
          handleRef: null,
          rangeLabelMinInnerRef: null,
          rangeLabelMaxInnerRef: null,
        };

        const updateComponentRef = componentRef.current;
        if (updateComponentRef) {
          componentRefs.componentOffsetWidth = updateComponentRef.offsetWidth || 0;
          componentRefs.trackRef = getElementRefById(updateComponentRef, ids.track, enableDevDebug);
          componentRefs.handleRef = getElementRefById(updateComponentRef, ids.handle.base, enableDevDebug);
          componentRefs.rangeLabelMinInnerRef = getElementRefById(updateComponentRef, ids.rangeLabel.min.inner, enableDevDebug);
          componentRefs.rangeLabelMaxInnerRef = getElementRefById(updateComponentRef, ids.rangeLabel.max.inner, enableDevDebug);
        }

        try {
          setState(
            min,
            max,
            step,
            decimalPrecision,
            activeValue,
            showRangeLabels,
            rangeLabelPositions,
            showStepIndicators,
            showStepValues,
            disabled,
            componentRefs.componentOffsetWidth,
            componentRefs.trackRef,
            componentRefs.handleRef,
            componentRefs.rangeLabelMinInnerRef,
            componentRefs.rangeLabelMaxInnerRef,
            showMinMax,
            showSteps,
            'UPDATE useEffect'
          );
        } catch (ex) {
          debug('> (×) ERROR: unexpected exception in UPDATE useEffect; exception:', 'error', true, ex.message);
        }
      },
      /* eslint-disable react-hooks/exhaustive-deps */
      [
        min,
        max,
        step,
        decimalPrecision,
        value,
        valueDisplayType,
        valueDisplayDuration,
        showRangeLabels,
        showMinMax, // DEPRECATED
        doShowRangeLabels,
        rangeLabelPositions,
        doPositionRangeLabelsBelow,
        showStepIndicators,
        showSteps, // DEPRECATED
        doShowStepIndicatorDots,
        showStepValues,
        doShowStepIndicatorValues,
        disabled,
        isDisabled,
      ]
      /* eslint-enable react-hooks/exhaustive-deps */
    );

    /**
     * RESIZE OBSERVER EFFECT
     */
    useEffect(
      () => {
        debug(`<<< LdsNumericSlider '${id}' RESIZE EFFECT >>>`, 'warn');
        const roBindRef = componentRef.current;

        const resizeObserver = new ResizeObserver(() => {
          debug(`<<< LdsNumericSlider '${id}' RESIZE OBSERVER TRIGGERED >>>`, 'warn');

          const componentRefs = {
            componentOffsetWidth: 0,
            trackRef: null,
            handleRef: null,
            rangeLabelMinInnerRef: null,
            rangeLabelMaxInnerRef: null,
          };

          const roUpdateRef = componentRef.current;
          if (roUpdateRef) {
            componentRefs.componentOffsetWidth = roUpdateRef.offsetWidth || 0;
            componentRefs.inputRef = getElementRefById(roUpdateRef, id, enableDevDebug);
            componentRefs.trackRef = getElementRefById(roUpdateRef, ids.track, enableDevDebug);
            componentRefs.handleRef = getElementRefById(roUpdateRef, ids.handle.base, enableDevDebug);
            componentRefs.rangeLabelMinInnerRef = getElementRefById(roUpdateRef, ids.rangeLabel.min.inner, enableDevDebug);
            componentRefs.rangeLabelMaxInnerRef = getElementRefById(roUpdateRef, ids.rangeLabel.max.inner, enableDevDebug);
          }

          // The activeValue state value is always coming through with the initial prop value set
          // Even in one of the change handlers has fired which SHOULD update activeValue when the handle position updates
          // This tries to get the actual input element's value or failing that the activeValue state.
          const currentActiveValue = componentRefs.inputRef.value || activeValue;

          // Resize effect should have a little latentcy
          setTimeout(() => {
            setState(
              min,
              max,
              step,
              decimalPrecision,
              currentActiveValue, // this SHOULD be whatever the component input element's value attribute is...
              showRangeLabels,
              rangeLabelPositions,
              showStepIndicators,
              showStepValues,
              disabled,
              componentRefs.componentOffsetWidth,
              componentRefs.trackRef,
              componentRefs.handleRef,
              componentRefs.rangeLabelMinInnerRef,
              componentRefs.rangeLabelMaxInnerRef,
              showMinMax,
              showSteps,
              'resizeObserver'
            );
          }, 10); // timeout can be tweaked to improve performance at the risk of stuttering the resize effect
        });

        resizeObserver.observe(roBindRef);

        return () => {
          resizeObserver.unobserve(roBindRef);
        };
      },
      /* eslint-disable react-hooks/exhaustive-deps */
      [
        componentRef,
        min,
        max,
        step,
        decimalPrecision,
        value,
        valueDisplayType,
        valueDisplayDuration,
        showRangeLabels,
        rangeLabelPositions,
        showStepIndicators,
        showStepValues,
        disabled,
        showMinMax, // DEPRECATED
        showSteps, // DEPRECATED
      ]
    /* eslint-enable react-hooks/exhaustive-deps */
    );

    // MARK: Event Handlers

    /**
     * Handle the `<input type="range">` element event `onChange` when the user stops moving the handle
     *
     * _Sets the temporary `isMoving` state to false after a timeout of 'valueDisplayDuration' milliseconds._
     *
     * @param {Event} e event object
     */
    const handleOnChange = (e) => {
      try {
        const refInput = e.target;
        const timeoutDuration = getValidValueDisplayDuration(valueDisplayDuration);
        setActiveValue(refInput.value);
        clearTimeout(movingTimeout);
        setMovingTimeout(setTimeout(() => {
          setIsMoving(false);
        }, timeoutDuration));
      } catch (ex) {
        debug(`LdsNumericSlider '${id}' unexpected exception in => handleOnChange: ${ex.message}\n>>> event:`, 'error', true, e);
      }
    };

    /**
     * Handle the `<input type="range">` element event `onInput` when the user is actively moving the handle
     *
     * _Sets the temporary `isMoving` state to true._
     *
     * @param {Event} e event object
     */
    const handleOnInput = (e) => {
      try {
        const refInput = e.target;

        setIsMoving(true);
        setHandlePosition(refInput.value);
      } catch (ex) {
        debug(`LdsNumericSlider '${id}' unexpected exception in => handleOnInput: ${ex.message}\n>>> event:`, 'error', true, e);
      }
    };

    /**
     * Handle the `<input type="range">` element event `onFocus` when the input recieves browser focus
     *
     * _Sets the `isFocused` state to true which primarily applies accessible focus features to custom elements._
     */
    const handleOnFocus = () => {
      try {
        setIsFocused(true);
      } catch (ex) {
        debug(`LdsNumericSlider '${id}' unexpected exception in => handleOnFocus: ${ex.message}`, 'error');
      }
    };

    /**
     * Handle the `<input type="range">` element event `onBlur` when the input looses browser focus
     *
     * _Stes the `isFocused` state to false which primarily disables accessible focus features from custom elements._
     *
     * _Also disables the `isMoving` state because the slider's handle cannot be moving if the input is not focused._
     * _This is a failsafe to clean up any `isMoving` dependent animations._
     */
    const handleOnBlur = () => {
      try {
        setIsFocused(false);
        setIsMoving(false);
      } catch (ex) {
        debug(`LdsNumericSlider '${id}' unexpected exception in => handleOnBlur: ${ex.message}`, 'error');
      }
    };

    // MARK: Component Render
    return (
      <div
        ref={componentRef}
        id={ids.container}
        className={cn(
          classes.container,
          {
            [`${classes.states.rangeLabelsEnabled}`]: doShowRangeLabels,
            [`${classes.states.rangeLabelsBelow}`]: doPositionRangeLabelsBelow,
            [`${classes.states.stepIndicatorDotsEnabled}`]: doShowStepIndicatorDots,
            [`${classes.states.stepIndicatorValuesEnabled}`]: doShowStepIndicatorValues,
            'disabled': isDisabled,
          },
          className
        )}
        {...rest}
      >
        {/* Numeric Slider Control */}
        <span
          id={ids.control}
          className={classes.control}
          ref={controlRef}
        >
          <input
            ref={ref}
            id={id}
            type="range"
            min={rangeMin}
            max={rangeMax}
            step={stepIncrement}
            value={activeValue}
            disabled={isDisabled ? 'disabled' : null}
            onChange={handleOnChange}
            onInput={handleOnInput}
            onFocus={handleOnFocus}
            onBlur={handleOnBlur}
            {...inputAttributes}
          />
          <span
            id={ids.track}
            className={classes.track}
            aria-hidden="true"
          >
            <span
              id={ids.handle.base}
              className={cn(
                classes.handle.base,
                {
                  'moving': isMoving,
                  'focused': isFocused,
                }
              )}
            >
              <span className={classes.handle.overlay}></span>
              <span
                id={ids.handle.value.bubble}
                className={cn(
                  classes.handle.value.bubble,
                  valueDisplayType
                )}
              >
                <span id={ids.handle.value.inner}>
                  {/* When displaying the active value in the display bubble, it must be formatted to the correct decimal precision */}
                  {Number(activeValue).toFixed(decimalPrecision)}
                </span>
                <span className={classes.handle.value.indicator}></span>
              </span>
            </span>
            <span
              id={ids.steps.container}
              className={classes.steps.container}
            >
              {/* The selected steps bar overlays the track to the left of the handle's current position */}
              <span
                id={ids.steps.selectedBar}
                className={classes.steps.selectedBar}
                style={{ width: '9.66197%' }}
              ></span>

              {/* Renders the step indicators */}
              <NumericSliderStepIndicators
                showStepIndicators={doShowStepIndicatorDots}
                showStepValues={doShowStepIndicatorValues}
                ids={ids}
                classes={classes}
                min={rangeMin}
                max={rangeMax}
                step={stepIncrement}
                decimalPrecision={decimalPlaces}
                activeValue={activeValue}
                trackOffsetWidth={trackOffsetWidth}
                handleOffsetWidth={handleOffsetWidth}
                enableDevDebug={enableDevDebug}
              />
            </span>
          </span>

        </span>

        {/* Minimum Value Range Label */}
        <NumericSliderRangeLabel
          enabled={doShowRangeLabels}
          type="min"
          ids={ids}
          classes={classes}
          aria-label={minAriaLabel}
        >
          {minLabel}
        </NumericSliderRangeLabel>

        {/* Median Value Range Label */}
        <NumericSliderRangeLabel
          enabled={doShowRangeLabels}
          type="mid"
          ids={ids}
          classes={classes}
          aria-label={midAriaLabel}
        >
          {midLabel}
        </NumericSliderRangeLabel>

        {/* Maxium Value Range Label */}
        <NumericSliderRangeLabel
          enabled={doShowRangeLabels}
          type="max"
          ids={ids}
          classes={classes}
          aria-label={maxAriaLabel}
        >
          {maxLabel}
        </NumericSliderRangeLabel>
      </div>
    );
  }
);
export default LdsNumericSlider;

// MARK: Prop Type Validation
LdsNumericSlider.propTypes = {
  id: PropTypes.string.isRequired,
  min: (props, propName, componentName) => props[propName] && validatePropTypeMin(props.min, propName, componentName, 'min', props.max),
  max: (props, propName, componentName) => props[propName] && validatePropTypeMax(props.max, propName, componentName, 'max', props.min),
  step: (props, propName, componentName) => props[propName] && validatePropTypeStep(props.step, propName, componentName, 'step', props.min, props.max, props.decimalPrecision),
  decimalPrecision: (props, propName, componentName) => props[propName] && validatePropTypeDecimalPrecision(props.decimalPrecision, propName, componentName, 'decimalPrecision'),
  value: (props, propName, componentName) => props[propName] && validatePropTypeValue(props.value, propName, componentName, 'value', props.min, props.max),
  showRangeLabels: PropTypes.bool,
  rangeLabelPositions: PropTypes.oneOf(validRangeLabelPositions),
  showStepIndicators: PropTypes.bool,
  showStepValues: PropTypes.bool,
  minLabel: PropTypes.any,
  minAriaLabel: PropTypes.string,
  maxLabel: PropTypes.any,
  maxAriaLabel: PropTypes.string,
  valueDisplayType: PropTypes.oneOf(validValueDisplayTypes),
  valueDisplayDuration: PropTypes.number,
  className: PropTypes.string,
  inputAttributes: PropTypes.any,
  rest: PropTypes.any,
};
