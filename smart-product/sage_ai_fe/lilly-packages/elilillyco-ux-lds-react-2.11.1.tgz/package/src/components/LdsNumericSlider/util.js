import { consoleWriter } from '../../util/consoleWriter.js';

// MARK: Component Defaults

/**
 * Static hardcoded component variables
 */
export const staticVars = () => {
  // Design element sizes
  const stepIndicatorDotWidth = 6;
  const stepIndicatorDotMargins = 4;
  const stepIndicatorValueWidthMin = 16;
  const stepIndicatorValueMargins = 4;

  return {
    // The hard minimum width of the slider control per UX design requirements
    controlTrackMinWidth: 288,
    // The fixed width of the slider handle per UX design requirements
    controlHandleWidth: 24,
    // The maximum number of step indicator items that can be displayed
    stepIndicatorItemsMax: 100,
    // The ABSOLUTE horizontal size of a step indicator dot
    stepIndicatorDotHorzSize: (stepIndicatorDotWidth + stepIndicatorDotMargins),
    // The MINIMUM horizontal size of a step indicator value
    stepIndicatorValueMargins: stepIndicatorValueMargins,
    stepIndicatorValueMinHorzSize: (stepIndicatorValueWidthMin + stepIndicatorValueMargins),
    // Value bubble display duration timeout clamps
    displayDurationMin: 250,
    displayDurationMax: 2500,
  };
};

/**
 * Component input prop default values
 */
export const propsDefault = {
  id: undefined,
  min: 0,
  max: 100,
  minLabel: '0',
  minAriaLabel: 'minimum value',
  midLabel: '50',
  midAriaLabel: 'median value',
  maxLabel: '100',
  maxAriaLabel: 'maximum value',
  showRangeLabels: false,
  rangeLabelPositions: undefined,
  step: 1,
  decimalPrecision: 0,
  showStepIndicators: false,
  showStepValues: false,
  value: 0,
  valueDisplayType: 'never',
  valueDisplayDuration: 500,
  disabled: false,
  className: undefined,
  inputAttributes: undefined,
};

// MARK: Element Attributes

/**
 * `LdsNumericSlider` utility: Create and return an object of the expected id attribute values for the Numeric Slider component elements
 *
 * @param {string} componentId the component's unique id
 */
export const elementIds = (componentId) => {
  return {
    container: `${componentId}_container`,
    rangeLabel: {
      min: {
        container: `${componentId}_min-label`,
        inner: `${componentId}_min-label-inner`,
      },
      mid: {
        container: `${componentId}_mid-label`,
        inner: `${componentId}_mid-label-inner`,
      },
      max: {
        container: `${componentId}_max-label`,
        inner: `${componentId}_max-label-inner`,
      },
    },
    control: `${componentId}_control`,
    input: `${componentId}`,
    track: `${componentId}_track`,
    handle: {
      base: `${componentId}_handle`,
      value: {
        bubble: `${componentId}_value-bubble`,
        inner: `${componentId}_value-bubble-value`,
      },
    },
    steps: {
      container: `${componentId}_steps`,
      selectedBar: `${componentId}_step-bar`,
      indicatorsItemsPrefix: `${componentId}-step-`,
    },
  };
};

/**
 * `LdsNumericSlider` utility: Create and return and object of the expected class names for the Numeric Slider component elements
 *
 * @param {string} componentId the component's unique id
 * @param {string} baseClass the component's unique CSS base context class name
 */
export const elementClasses = (componentId, baseClass) => {
  const valueBubble = '-value-bubble';
  const stepItem = '-step-item';
  const stepIndicator = 'step-indicator';
  const stepValue = 'step-value';

  const base = {
    labelRange: `${baseClass}-range-label`,
    handle: `${baseClass}-handle`,
    valueBubble: `${baseClass}${valueBubble}`,
    valueBubbleIndicator: `${baseClass}${valueBubble}-indicator`,
    valueBubbleTooltip: 'lds-tooltip-description tooltip-description top lds-tooltip-enter-to ta-center',
    valueBubbleTooltipArrow: 'lds-tooltip-arrow',
    step: `${baseClass}-step`,
    stepItem: `${baseClass}${stepItem}`,
    stepItemInstance: `${componentId}${stepItem}`,
    stepIndicator: stepIndicator,
    stepIndicatorInstance: `${componentId}-${stepIndicator}`,
    stepValue: stepValue,
    stepValueInstance: `${componentId}-${stepValue}`,
  };

  return {
    container: `${baseClass}`,
    rangeLabel: {
      min: `${base.labelRange} min`,
      mid: `${base.labelRange} mid`,
      max: `${base.labelRange} max`,
      inner: 'range-label-inner',
    },
    control: `${baseClass}-control`,
    input: `${baseClass}-input`,
    track: `${baseClass}-track`,
    handle: {
      base: base.handle,
      overlay: `${base.handle}-overlay`,
      value: {
        bubble: `${base.valueBubble} ${base.valueBubbleTooltip}`,
        indicator: `${base.valueBubbleIndicator} ${base.valueBubbleTooltipArrow}`,
      },
    },
    steps: {
      container: `${base.step}s`,
      selectedBar: `${base.step}-bar`,
      indicators: {
        item: `${base.stepItem} ${base.stepItemInstance}`,
        trackDot: `${base.stepIndicator} ${base.stepIndicatorInstance}`,
        value: `${base.stepValue} ${base.stepValueInstance}`,
      },
    },
    states: {
      minSelected: 'min-selected',
      maxSelected: 'max-selected',
      rangeLabelsEnabled: 'show-range-labels',
      rangeLabelsBelow: 'range-labels-below',
      stepIndicatorDotsEnabled: 'show-step-indicators',
      stepIndicatorValuesEnabled: 'show-step-values',
    },
    base: base,
  };
};

// MARK: Computed Vars

/**
 * `LdsNumericSlider` utility: Gets the MINIMUM width of the slider control's track which can display the DOT step indicators responsively
 *
 * @param {number} min the desired `min` range value to use; is validated in this context using `getValidRange`
 * @param {number} max the desired `max` range value to use; is validated in this context using `getValidRange`
 * @param {number} step the desired `step` increment value to use; is validated in this context using `getValidStepInRange`
 * @param {number} decimalPrecision the desired `decimalPrecision` value to use; is validated in this context using `getValidStepInRange`
 *
 * @returns {number} an number value of pixels which defines the minimum width _or_ `NaN` if the input parameters are not number types or `NaN`
 */
export const getMinStepIndicatorDotsTrackWidth = (min, max, step, decimalPrecision) => {
  const vars = staticVars();
  const totalSteps = getValidSteps(min, max, step, decimalPrecision);

  return Number(totalSteps * vars.stepIndicatorDotHorzSize);
};

/**
 * `LdsNumericSlider` utility: Gets the MINIMUM width of the slider control's track which can display the VALUE step indicators responsively
 *
 * @param {number} min the desired `min` range value to use; is validated in this context using `getValidRange`
 * @param {number} max the desired `max` range value to use; is validated in this context using `getValidRange`
 * @param {number} step the desired `step` increment value to use; is validated in this context using `getValidStepInRange`
 * @param {number} decimalPrecision the desired `decimalPrecision` value to use; is validated in this context using `getValidStepInRange`
 *
 * @returns {number} an number value of pixels which defines the minimum width _or_ `NaN` if the input parameters are not number types or `NaN`
 */
export const getMinStepIndicatorValuesTrackWidth = (min, max, step, decimalPrecision) => {
  const vars = staticVars();
  const totalSteps = getValidSteps(min, max, step, decimalPrecision);

  return Number(totalSteps * vars.stepIndicatorValueMinHorzSize);
};

/**
 * `LdsNumericSlider` utility: Gets whether the range labels can be displayed
 *
 * _This function will be called recursively and will always print a console warning message if the `deprecatedShowMinMax` parameter is not `null`; when set it overrides the value of the `showRangeLabels` param_
 *
 * @param {boolean} showRangeLabels whether the component was configured by prop to show range labels
 * @param {number} trackOffsetWidth the current width of the component's track element in pixels
 * @param {boolean} debug OPTIONAL - whether to print debugging messages to the browser console
 * @param {boolean|null} deprecatedShowMinMax OPTIONAL - if not null, this will be set to a deprecated component prop that was used to configure whether to show the range labels
 *
 * @returns {boolean} the computed range label display state
 */
export const canShowRangeLabels = (showRangeLabels, trackOffsetWidth, debug = false, deprecatedShowMinMax = null) => {
  // DEPRECATED PROP OVERRIDE
  if (deprecatedShowMinMax !== null) {
    if (debug) {
      consoleWriter(`>>> [!] WARNING: THE DEPRECATED COMPONENT PROP 'showMinMax' was set to ${deprecatedShowMinMax}!\n>>> This prop will be removed in a future version of React LDS; please update the component implementation to use the 'showRangeLabels' prop instead\n>>> The value of this prop will override the function of the 'showRangeLabels' prop\n>>> recursively calling the canShowRangeLabels function =>`, 'warn');
    } else {
      consoleWriter(`LdsNumericSlider WARNING: THE COMPONENT PROP 'showMinMax' IS DEPRECATED; it is set to ${deprecatedShowMinMax}!\n>>> This prop will be removed in a future version of React LDS; please update the component implementation to use the 'showRangeLabels' prop instead\n>>> When set, the value of this prop will override the function of the 'showRangeLabels' prop`, 'warn');
    }
    // Default to using the deprecated prop by recursively calling this function using the deprecated prop as the current equivalent prop
    return canShowRangeLabels(deprecatedShowMinMax, trackOffsetWidth, debug, null);
  }

  // Not configured to show range labels
  if (!showRangeLabels) return false;

  // Control width (and likely viewport width) is too narrow to display range labels comfortably
  const vars = staticVars();
  if (trackOffsetWidth < vars.controlTrackMinWidth) {
    if (debug) consoleWriter(`>>> (!) RANGE LABELS dispaly DISABLED RESPONSIVELY\n>>> >>> component trackWidth of ${trackOffsetWidth}px is less than the allowed minimum track width of ${vars.controlTrackMinWidth}`);
    return false;
  }

  // Otherwise, can show the range values
  return true;
};

/**
 * `LdsNumericSlider` utility: Gets both a valid and responsively correct range label positions state
 *
 * @param {string|undefined} rangeLabelPositions the component's range label positions prop configuration; when undefined the default positioning state of "around" is assumed
 * @param {number} minLabelWidth the current computed widthOffset for the minimum range label in pixels (min range label inner `offsetWidth`)
 * @param {number} maxLabelWidth the current computed widthOffset for the maximum range label in pixels (max range label inner `offsetWidth`)
 * @param {number} componentWidth the current computed total width of the component (component container element `offsetWidth`)
 * @param {boolean} debug OPTIONAL - whether to print debugging messages to the browser console
 *
 * @returns {string} the processed range label position value; currently it will be either `'below'` or `'around'`
 */
export const getRangeLabelPositions = (rangeLabelPositions, minLabelWidth, maxLabelWidth, componentWidth, debug = false) => {
  // Default a falsey value to the "around" positioning variant
  let curPositions;
  if (!rangeLabelPositions) {
    curPositions = 'around';
  } else {
    curPositions = String(rangeLabelPositions).toLowerCase();
  }

  // Check for valid rangeLabelPositions prop and param input
  if (!validRangeLabelPositions.includes(curPositions)) {
    consoleWriter('>>> [!] WARNING: Invalid input for rangeLabelPositions prop detected!\n>>> when setting the prop the input must be a string value of \'around\' or \'below\'\n>>> >>> the default "around" setting will be used\n>>> >>> Invalid Input Value:', 'warn', true, rangeLabelPositions);
    curPositions = 'around';
  }

  // Range labels are configured by prop to use the "below" positions variant
  if (curPositions === 'below') return curPositions;

  // Otherwise, try to use the default "around" positions variant

  // Compute the MINIMUM possible width the range labels at their current widths can be displayed "around" the track
  // If the component width is less than that minimum around width, force the usage of "below" positioning
  const vars = staticVars();
  const minAroundWidth = (minLabelWidth + maxLabelWidth + vars.controlTrackMinWidth);
  if (componentWidth < minAroundWidth) {
    if (debug) consoleWriter(`>>> (!) Using RESPONSIVE OVERRIDE range label positions 'below'\n>>> >>> the component width of ${componentWidth}px is less than the MINIMUM possible width the range labels at their current widths can be displayed "around" the track which is ${minAroundWidth}px`);
    return 'below';
  }

  return curPositions;
};

/**
 * `LdsNumericSlider` utility: Determines whether the "dot" step indicators can be displayed on the numeric slider's track
 *
 * _This function will be called recursively and will always print a console warning message if the `deprecatedShowMinMax` parameter is not `null`; it overrides the value of the `showStepIndicators` param_
 *
 * @param {boolean} showStepIndidcators whether the component was configured by prop to show the dot step indicators
 * @param {number} min the current minimum range value
 * @param {number} max the current maximum range value
 * @param {number} step the currernt step increment value
 * @param {number} decimalPrecision the current number of decimal places to use
 * @param {number} trackOffsetWidth the current width of the component's track element in pixels
 * @param {boolean} debug OPTIONAL - whether to print debugging messages to the browser console
 * @param {boolean|null} deprecatedShowMinMax OPTIONAL - if not null, this will be set to a deprecated component prop that was used to configure whether to show the equivalent of the dot step indicators
 *
 * @returns {boolean} the computed dot step indicators display state
 */
export const canShowStepDotIndicators = (showStepIndicators, min, max, step, decimalPrecision, trackOffsetWidth, debug = false, deprecatedShowSteps = null) => {
  // DEPRECATED PROP OVERRIDE
  if (deprecatedShowSteps !== null) {
    if (debug) {
      consoleWriter(`>>> [!] WARNING: THE DEPRECATED COMPONENT PROP 'showSteps' was set to ${deprecatedShowSteps}!\n>>> This prop will be removed in a future version of React LDS; please update the component implementation to use the 'showStepIndicators' prop instead\n>>> The value of this prop will override the function of the 'showStepIndicators' prop\n>>> recursively calling the canShowStepDotIndicators function =>`, 'warn');
    } else {
      consoleWriter(`LdsNumericSlider WARNING: THE COMPONENT PROP 'showSteps' IS DEPRECATED; it was set to ${deprecatedShowSteps}!\n>>> This prop will be removed in a future version of React LDS; please update the component implementation to use the 'showStepIndicators' prop instead\n>>> When set, the value of this prop will override the function of the 'showStepIndicators' prop`, 'warn');
    }
    // Default to using the deprecated prop by recursively calling this function using the deprecated prop as the current equivalent prop
    return canShowStepDotIndicators(deprecatedShowSteps, min, max, step, decimalPrecision, trackOffsetWidth, debug, null);
  }

  // Not configured to show step (dot) indicators
  if (!showStepIndicators) return false;

  // More total indicator items than can be displayed
  const vars = staticVars();
  const totalSteps = getValidSteps(min, max, step, decimalPrecision);
  if (totalSteps > vars.stepIndicatorItemsMax) {
    if (debug) consoleWriter(`>>> (!) DOT indicators DISABLED via OVERRIDE\n>>> >>> the total number of steps within the control range ${totalSteps} is greater than the hard-coded maximum allowed step indicator items of ${vars.stepIndicatorItemsMax}`);
    return false;
  }

  // More dots than can be comfortably displayed on the track
  const minStepDotsTrackWidth = (totalSteps * vars.stepIndicatorDotHorzSize);
  if (trackOffsetWidth < minStepDotsTrackWidth) {
    if (debug) consoleWriter(`>>> (!) DOT indicators DISABLED via OVERRIDE\n>>> >>> the total width of all dot indicator elements is ${minStepDotsTrackWidth}px which will not fit within the track width of ${trackOffsetWidth}`);
    return false;
  }

  // Otherwise, can show the dot indicators
  return true;
};

/**
 * `LdsNumericSlider` utility: Determines whether the step value indicators can be displayed below the numeric slider's track
 *
 * @param {boolean} showStepValues whether the component was configured by prop to show the dot step indicators
 * @param {number} min the current minimum range value
 * @param {number} max the current maximum range value
 * @param {number} step the currernt step increment value
 * @param {number} decimalPrecision the current number of decimal places to use
 * @param {number} trackOffsetWidth the current width of the component's track element in pixels
 * @param {number} minStepValuesTotalWidth the current computed required minimum width for ALL the value to be displayed "comfortably" below the slider track
 * @param {boolean} debug OPTIONAL - whether to print debugging messages to the browser console
 *
 * @returns {boolean} the computed step value indicators display state
 */
export const canShowStepValueIndicators = (showStepValues, min, max, step, decimalPrecision, trackOffsetWidth, minStepValuesTotalWidth, debug = false) => {
  // Not showing step (dot) indicators
  if (!showStepValues) return false;

  // More values than can be comfortably displayed below the track
  if (trackOffsetWidth < minStepValuesTotalWidth) {
    if (debug) consoleWriter(`>>> (!) VALUE indicators DISABLED via OVERRIDE\n>>> >>> the total width of all VALUE indicator elements is ${minStepValuesTotalWidth}px which will not fit within the track width of ${trackOffsetWidth}`);
    return false;
  }

  // More total indicator items than can be displayed
  const vars = staticVars();
  const totalSteps = getValidSteps(min, max, step, decimalPrecision);
  if (totalSteps > vars.stepIndicatorItemsMax) {
    if (debug) consoleWriter(`>>> [×] VALUE indicators DISABLED via OVERRIDE\n>>> >>> the total number of steps within the control range ${totalSteps} is greater than the hard-coded maximum allowed step indicator items of ${vars.stepIndicatorItemsMax}`);
    return false;
  }

  // Otherwise, can show the value indicators
  return true;
};

// MARK: Computed Props

/**
 * `LdsNumericSlider` utility: Gets a valid, logical min range value
 *
 * @param {number} min the desired `min` range value to use
 * @param {boolean} debug OPTIONAL - whether to print debugging messages to the browser console
 * @param {boolean} nested OPTIONAL - whether this function is nested within another function, only used for debugging purposes
 *
 * @returns {number} a floating point typeof `number` which is a valid minimum range value _or_ the default componen min parameter value if the input parameters are not number types or `NaN`
 */
export function getValidMin(min, debug = false, nested = false) {
  if (debug) {
    const params = { min: min };
    consoleWriter(`${nested ? '>>> ' : 'LdsNumericSlider utility'} => getValidMin processing...`, 'log', true, params);
  }

  // Coerce the min value to a number
  let validMin = Number(min);

  // If min is falsey but not zero, it's probably NaN if the coercion failed
  // ...fallback to the default min
  if (!validMin && validMin !== 0) {
    if (debug) consoleWriter(`>>> [!] WARNING: min was a falsy value of ${validMin}; using the component prop default value...`, 'warn');
    validMin = propsDefault.min;
  }

  if (debug) consoleWriter(`>>> validMin: ${validMin}`);
  return validMin;
}

/**
 * `LdsNumericSlider` utility: Gets a valid, logical max range value in relation to the min range value
 *
 * @param {number} min the desired `min` range value to use; is validated in this context using `getValidMin`
 * @param {number} max the desired `max` range value to use
 * @param {boolean} debug OPTIONAL - whether to print debugging messages to the browser console
 * @param {boolean} nested OPTIONAL - whether this function is nested within another function, only used for debugging purposes
 *
 * @returns {number} a floating point typeof `number` which is a valid maximum range value _or_ `NaN` if the input parameters are not number types or `NaN`
 */
export function getValidMax(min, max, debug = false, nested = false) {
  if (debug) {
    const params = { min: min, max: max };
    consoleWriter(`${nested ? '>>> ' : 'LdsNumericSlider utility'} => getValidMax processing...`, 'log', true, params);
  }

  // Validate min
  const validMin = getValidMin(min, debug, true);

  // Create a fallback default max relative to the valid min
  const fallbackMax = Number(validMin + propsDefault.max);

  // Coerce the max value to a number
  let validMax = Number(max);

  // If max is falsey but not zero, it's probably NaN if the coercion failed
  // ...use the fallback default max
  if (!validMax && validMax !== 0) {
    if (debug) consoleWriter(`>>> [!] WARNING: max was a falsy value of ${validMax}; using the computed safe fallback...`, 'warn');
    validMax = fallbackMax;
  }

  // Check if max is less than or equal to min; range cannot be nothing (0) or illogical (negative)
  // ...use the fallback default max
  if (validMax <= validMin) {
    if (debug) consoleWriter(`>>> [!] WARNING: illogical range detected! -> max(${validMax}) <= min(${validMin}); using the computed safe fallback...`, 'warn');
    validMax = fallbackMax;
  }

  if (debug) consoleWriter(`>>> validMax: ${validMax}`);
  return validMax;
}

/**
 * `LdsNumericSlider` utility: Gets a valid, logical range from the min and max range values
 *
 * @param {number} min the desired `min` range value to use; is validated in this context using `getValidMin`
 * @param {number} max the desired `max` range value to use; is validated in this context using `getValidMax`
 * @param {boolean} debug OPTIONAL - whether to print debugging messages to the browser console
 * @param {boolean} nested OPTIONAL - whether this function is nested within another function, only used for debugging purposes
 *
 * @returns {number} a floating point typeof `number` which is a positive valid numeric slider range _or_ `NaN` if the input parameters are not number types or `NaN`
 */
export function getValidRange(min, max, debug = false, nested = false) {
  if (debug) {
    const params = { min: min, max: max };
    consoleWriter(`${nested ? '>>> ' : 'LdsNumericSlider utility'} => getValidRange processing...`, 'log', true, params);
  }
  const validMin = getValidMin(min, debug, true);
  const validMax = getValidMax(min, max, debug, true);

  const validRange = Math.abs(validMax - validMin);
  if (debug) consoleWriter(`>>> computed validRange: ${validRange}`);
  return validRange;
}

/**
 * `LdsNumericSlider` utility: Gets a valid, logical decimal precision (places) value
 *
 * @param {number} decimalPrecision the desired `decimalPrecision` value to use
 * @param {boolean} debug OPTIONAL - whether to print debugging messages to the browser console
 * @param {boolean} nested OPTIONAL - whether this function is nested within another function, only used for debugging purposes
 *
 * @returns {number} an integer typeof `number` value representing the decimal places (precision) _or_ `NaN` if the input parameters are not number types or any are `NaN`
 */
export function getValidDecimalPrecision(decimalPrecision, debug = false, nested = false) {
  if (debug) {
    const params = { decimalPrecision: decimalPrecision };
    consoleWriter(`${nested ? '>>> ' : 'LdsNumericSlider utility'} =>getValidDecimalPrecision processing...`, 'log', true, params);
  }

  let vdp = propsDefault.decimalPrecision;
  const ndp = Number(decimalPrecision);

  // If the coercion failed and the value is falsey OR...
  // The value is a negative number, use the component default
  if ((!ndp || ndp < 0) && ndp !== 0) {
    if (debug) {
      consoleWriter(`>>> [!] WARNING: Invalid decimalPrecision value returned from '${decimalPrecision}' when coerced to Number as:`, 'warn', true, ndp);
      consoleWriter(`>>> using default decimalPrecision: ${vdp}`);
    }
    return vdp;
  }

  // A valid decimal precision must be an integer value
  vdp = parseInt(ndp, 10);
  if (debug) consoleWriter(`>>> computed validDecimalPrecision: ${vdp}`);
  return vdp;
}

/**
 * `LdsNumericSlider` utility: Gets a valid decimal precision factor to work with the numeric slider range values in whole numbers
 *
 * @param {number} decimalPrecsision the desired `decimalPrecision` value to use; is validated in this context using `getValidDecimalPrecision
 * @param {boolean} debug OPTIONAL - whether to print debugging messages to the browser console
 * @param {boolean} nested OPTIONAL - whether this function is nested within another function, only used for debugging purposes
 *
 * @returns {number} a floating point typeof `number` which should be either 1 or a factor of 10 _or_ `NaN` if the input parameters are not number types or any are `NaN`
 */
export function getValidDecimalPrecisionFactor(decimalPrecision, debug = false, nested = false) {
  if (debug) {
    const params = {
      decimalPrecision: decimalPrecision,
    };
    consoleWriter(`${nested ? '>>> ' : 'LdsNumericSlider utility'} => getValidDecimalPrecisionFactor processing...`, 'log', true, params);
  }

  const validDecimalPrecision = getValidDecimalPrecision(decimalPrecision, debug, true);

  // The default decimal precision factor is 1
  let dpf = 1;

  // Integer precision (0) is the default; use default DPF
  if (validDecimalPrecision <= 0) {
    if (debug) consoleWriter(`>>> Default zero decimal places (integer values) detected; decimalPrecisionFactor: ${dpf}`);
    return dpf;
  }

  // Otherwise DPF is an exponential factor of 10
  dpf = Number(10 ** validDecimalPrecision);
  if (debug) consoleWriter(`>>> computed decimalPrecisionFactor: ${dpf}`);
  return dpf;
}

/**
 * `LdsNumericSlider` utility: Gets an initially valid numeric step increment with relation to the numeric slider range
 *
 * _This function DOES NOT TEST if the step is valid within the range!_
 *
 * @param {number} min the desired `min` range value to use; is validated in this context using 'getValidMax`
 * @param {number} max the desired `max` range value to use; is validated in this context using `getValidMax`
 * @param {number} step the desired `step` increment value to use
 *
 * @returns {number} a floating point typeof `number` which is a valid numeric slider step _or_ `NaN` if the input parameters are not number types or `NaN`
 */
export function getValidStep(min, max, step, debug, nested) {
  if (debug) {
    const params = { min: min, max: max, step: step };
    consoleWriter(`${nested ? '>>> ' : 'LdsNumericSlider utility'} => getValidStep processing...`, 'log', true, params);
  }

  // Validate max (and implicitly min)
  const validMax = getValidMax(min, max, debug, true);

  // Coerce the min value to a number
  let validStep = Number(step);

  // Range must be a non-zero positive number
  // ...if invalid fallback to default
  if (validStep <= 0) {
    if (debug) consoleWriter(`>>> [!] WARNING: Invalid step value of '${validStep}' is either zero or negative; falling back to the the component default step increment...`, 'warn');
    validStep = propsDefault.step;
  }

  // Range must not be greater than the max range value
  // ...if invalid fallback to default
  if (validStep > validMax) {
    if (debug) consoleWriter(`>>> [!] WARNING: Invalid step value of '${validStep}' is greater than the max range of '${validMax}'; falling back to the the component default step increment...`, 'warn');
    validStep = propsDefault.step;
  }

  if (debug) consoleWriter(`>>> computed validStep: ${validStep}`);
  return Number(validStep);
}

/**
 * `LdsNumericSlider` utility: Tests whether the step increment is valid within the desired numeric slider range
 * defined as whether the range is divisble by step which is verified by calculating whether the modulus of range versus step is zero (valid) or not (invalid)
 *
 * @param {number} min the desired `min` range value to use; is validated in this contedt using `getValidRange`
 * @param {number} max the desired `max` range value to use; is validated in this context using `getValidRange`
 * @param {number} step the desired `step` increment value to use; is initially validated in this context using `getValidStep`
 * @param {number} decimalPrecision the desired `decimalPrecision` value to use; is validated in this context using `getValidDecimalPrecisionFactor`
 * @param {boolean} debug OPTIONAL - whether to print debugging messages to the browser console
 * @param {boolean} nested OPTIONAL - whether this function is nested within another function, only used for debugging purposes
 *
 * @returns {boolean} a boolean value of true if valid and false if not
 */
export function isValidStepWithinRange(min, max, step, decimalPrecision, debug = false, nested = false) {
  if (debug) {
    const params = {
      min: min,
      max: max,
      step: step,
      decimalPrecision: decimalPrecision,
    };
    consoleWriter(`${nested ? '>>> ' : 'LdsNumericSlider utility'} => isValidStepWithinRange processing...`, 'log', true, params);
  }

  /* ***
   * When working with modulus, it's better to work with whole numbers
   * To do this we'll factor the decimal precision as either 1 or a factor of 10
   * Then we'll factor the range and step values by that "decimal precision factor" so that they are whole numbers
   */

  const validRange = getValidRange(min, max, debug, true);
  const dpf = getValidDecimalPrecisionFactor(decimalPrecision, debug, true);
  const factoredRange = (validRange * dpf); // Independant var
  if (debug) consoleWriter(`>>> computed factoredRange: ${factoredRange}`);

  const validStep = getValidStep(min, max, step, debug, true);
  const factoredStep = (validStep * dpf); // Dependent var
  if (debug) consoleWriter(`>>> computed factoredStep: ${factoredStep}`);

  // Compute the modulus of the factoredRange vs factoredStep
  // If modulus is not zero the range is NOT divisible by the step increment
  const modulusStepVsRange = (factoredRange % factoredStep);
  if (modulusStepVsRange !== 0) {
    if (debug) consoleWriter(`>>> [!] WARNING: INVALID STEP INCREMENT IN RANGE DETECTED! - the factoredRange was not divisible by the factoredStep; modulusStepVsRange = ${modulusStepVsRange}`, 'warn');
    return false;
  }

  if (debug) consoleWriter('>>> [√] VALID step invrement in range!');
  return true;
}

/**
 * `LdsNumericSlider` utility: Gets a valid numeric step increment with relation to the numeric slider range
 *
 * _This function DOES TEST that the step is valid within the range using the `isValidStepWithinRange` function_
 *
 * @param {number} min the desired `min` range value to use; is validated in this context using `getValidStep`
 * @param {number} max the desired `max` range value to use; is validated in this context using `getValidStep`
 * @param {number} step the desired `step` increment value to use; is initially validated in this context using `getValidStep`
 * @param {number} decimalPrecision the desired `decimalPrecision` value to use; is validated in this context using `getValidDecimalPrecisionFactor`
 * @param {boolean} debug OPTIONAL - whether to print debugging messages to the browser console
 * @param {boolean} nested OPTIONAL - whether this function is nested within another function, only used for debugging purposes
 *
 * @returns {number} a floating point typeof `number` which is a valid numeric slider step within the range _or_ `NaN` if the input parameters are not number types or `NaN`
 */
export function getValidStepInRange(min, max, step, decimalPrecision, debug = false, nested = false) {
  if (debug) {
    const params = {
      min: min,
      max: max,
      step: step,
      decimalPrecision: decimalPrecision,
    };
    consoleWriter(`${nested ? '>>> ' : 'LdsNumericSlider utility'} => getValidStepInRange processing...`, 'log', true, params);
  }

  // Get an initially validated step value
  let validStepInRange = getValidStep(min, max, step, debug, true);

  // THIS DOES NOT WORK AS EXPECTED...
  /*
  // If the step is valid within the range
  // ...fallback to a valid step computed the decimal precision factor
  if (!isValidStepWithinRange(min, max, step, decimalPrecision, debug, true)) {
    const dpf = getValidDecimalPrecisionFactor(decimalPrecision, debug, true);
    validStepInRange = (1 / dpf);
  }
  */

  if (debug) consoleWriter(`>>> computed valdStepInRange: ${validStepInRange}`);
  return validStepInRange;
}

/**
 * `LdsNumericSlider` utility: Gets the total number of steps based on the step increment and slider range
 *
 * @param {number} min the desired `min` range value to use; is validated in this context using `getValidRange`
 * @param {number} max the desired `max` range value to use; is validated in this context using `getValidRange`
 * @param {number} step the desired `step` increment value to use; is validated in this context using `getValidStepInRange`
 * @param {number} decimalPrecision the desired `decimalPrecision` value to use; is validated in this context using `getValidStepInRange`
 * @param {boolean} debug OPTIONAL - whether to print debugging messages to the browser console
 * @param {boolean} nested OPTIONAL - whether this function is nested within another function, only used for debugging purposes
 *
 * @returns {number} a floating point typeof `number` which is the total steps _or_ `NaN` if the input parameters are not number types or `NaN`
 */
export function getValidSteps(min, max, step, decimalPrecision, debug = false, nested = false) {
  if (debug) {
    const params = {
      min: min,
      max: max,
      step: step,
      decimalPrecision: decimalPrecision,
    };
    consoleWriter(`${nested ? '>>> ' : 'LdsNumericSlider utility'} => getValidSteps processing...`, 'log', true, params);
  }

  const validRange = getValidRange(min, max, debug, true);

  const validStepInRange = getValidStepInRange(min, max, step, decimalPrecision, debug, true);

  let validSteps = Number(validRange / validStepInRange);

  // If the step isn't valid within the range, the "validSteps" would be computed as a fraction
  // Steps need to be an integer value, so parse it as necessary...
  if (!isValidStepWithinRange(min, max, step, decimalPrecision, debug, true)) {
    if (debug) consoleWriter(`>>> [!] WARNING: the validSteps was initially computed as non-integer value: ${validSteps}; it will be parsed to an integer...`, 'warn');
    validSteps = parseInt(validSteps, 10);
  }

  if (debug) consoleWriter(`>>> computed validSteps: ${validSteps}`);

  return validSteps;
}

/**
 * `LdsNumericSlider` utility: Gets a valid selected value that is at least within the range of the slider
 *
 * _This only prevents out-of-range values; it does not prevent an invalid value within range (not a multiple of step) from being set._
 *
 * @param {number} min the desired `min` range value to use; is validated in this context using `getValidMin`
 * @param {number} max the desired `max` range value to use; is validated in this context using `getValidMax`
 * @param {number} value the desired selected `value` to use
 * @param {boolean} debug OPTIONAL - whether to print debugging messages to the browser console
 * @param {boolean} nested OPTIONAL - whether this function is nested within another function, only used for debugging purposes
 *
 * @returns {number} a floating point typeof `number` which is a valid selected value within range _or_ `NaN` if the input parameters are not number types or `NaN`
 */
export function getValidValueInRange(min, max, value, debug = false, nested = false) {
  if (debug) {
    const params = { min: min, max: max, value: value };
    consoleWriter(`${nested ? '>>> ' : 'LdsNumericSlider utility'} => getValidValueInRange processing...`, 'log', true, params);
  }

  const validMin = getValidMin(min, debug, true);
  const validMax = getValidMax(validMin, max, debug, true);

  let validValue = value;

  if (validValue < validMin) {
    if (debug) consoleWriter(`>>> [!] WARNING: Invalid out-of-range value of '${value}' is less than the minimum range value; using the minimum range value....`, 'warn');
    validValue = validMin;
  }

  if (validValue > validMax) {
    if (debug) consoleWriter(`>>> [!] WARNING: Invalid out-of-range value of '${value}' is greater than the maximum range value; using the maximum range value...`, 'warn');
    validValue = validMax;
  }

  if (debug) consoleWriter(`>>> validValueInRange: ${validValue}`);
  return validValue;
}

/**
 * `LdsNumericSlider` utility: Gets a valid value display duration that is neither too short (less than 0.25s) nor too long (greater than 2.5s)
 *
 * @param {number} valueDisplayDuration the desired `valueDisplayDuration` number of milliseconds to use
 * @param {boolean} debug OPTIONAL - whether to print debugging messages to the browser console
 * @param {boolean} nested OPTIONAL - whether this function is nested within another function, only used for debugging purposes
 *
 * @returns {number} an integer typeof `number` which defines a number of milliseconds to use for the timeout; if the input parameter is falsey the default value of 500 is returned or if it is out of range either the min or max duration will be returned
 */
export function getValidValueDisplayDuration(valueDisplayDuration = propsDefault.valueDisplayDuration, debug = false, nested = false) {
  if (debug) {
    const params = { valueDisplayDuration: valueDisplayDuration };
    consoleWriter(`${nested ? '>>> ' : 'LdsNumericSlider utility'} => getValidValueDisplayDuration processing...`, 'log', true, params);
  }
  let validValueDisplayDuration = Number(valueDisplayDuration);

  // if the input prop is falsy return the default
  if (!valueDisplayDuration && (valueDisplayDuration !== 0)) {
    if (debug) consoleWriter(`>>> [!] WARNING: the valueDisplayDuration input returned a falsey numeric value of ${validValueDisplayDuration}; using the default duration...`, 'warn');
    return propsDefault.valueDisplayDuration;
  }

  const vars = staticVars();

  // the duration must not be too short
  if (validValueDisplayDuration < vars.displayDurationMin) {
    if (debug) consoleWriter(`>>> [!] WARNING: the requested valueDisplayDuration of ${validValueDisplayDuration} IS TOO SHORT; using the default minimum duration...`, 'warn');
    validValueDisplayDuration = vars.displayDurationMin;
  }

  // the duration must not be too long
  if (validValueDisplayDuration > vars.displayDurationMax) {
    if (debug) consoleWriter(`>>> [!] WARNING: the requested valueDisplayDuration of ${validValueDisplayDuration} IS TOO LONG; using the default maximum duration...`, 'warn');
    validValueDisplayDuration = vars.displayDurationMax;
  }

  if (debug) consoleWriter(`>>> validValueDisplayDuration: ${validValueDisplayDuration}`);
  return validValueDisplayDuration;
}

// MARK: PropType Validators

/**
 * `LdsNumericSlider` utility: Valid string input values for the `valueDisplayType` prop
 */
export const validValueDisplayTypes = [
  'never',
  'temporary',
  'always',
];

/**
 * `LdsNumericSlider` utility: Valid string input values for the `valueDisplayType` prop
 */
export const validRangeLabelPositions = [
  undefined,
  'around',
  'below',
];

/**
 * `LdsNumericSlider` utility `PropType` validation function: Determines if the user input to prop `min` is valid
 *
 * _Returns an error if invalid, otherwise returns null_
 *
 * @returns {Error|null}
 */
export function validatePropTypeMin(propValue, key, componentName, propFullName, maxValue) {
  if (typeof propValue !== 'number') {
    return new Error(`Invalid value of ${propValue} supplied to the prop '${propFullName}' of an ${componentName}. The '${propFullName}' must be supplied a value of type 'number'`);
  }
  if (propValue >= maxValue) {
    return new Error(`Illogical ${componentName} range detected; the value ${propValue} supplied to the prop '${propFullName}' is GREATER THAN OR EQUAL TO the prop 'max' value of ${maxValue}. The '${propFullName}' must a logical value that is LESS THAN 'max'`);
  }

  return null;
}

/**
 * `LdsNumericSlider` utility `PropType` validation function: Determines if the user input to prop `max` is valid
 *
 * _Returns an `Error` if invalid, otherwise returns `null`_
 *
 * @returns {Error|null}
 */
export function validatePropTypeMax(propValue, key, componentName, propFullName, minValue) {
  if (typeof propValue !== 'number') {
    return new Error(`Invalid value of ${propValue} supplied to the prop '${propFullName}' of an ${componentName}. The '${propFullName}' must be supplied a value of type 'number'`);
  }
  if (propValue <= minValue) {
    return new Error(`Illogical ${componentName} range detected; the value ${propValue} supplied to the prop '${propFullName}' is LESS THAN OR EQUAL TO the prop 'min' value of ${minValue}. The '${propFullName}' must a logical value that is GREATER THAN 'min'`);
  }

  return null;
}

/**
 * `LdsNumericSlider` utility `PropType` validation function: Determines if the user input to prop `step` is valid
 *
 * _Returns an `Error` if invalid, otherwise returns `null`_
 *
 * @returns {Error|null}
 */
export function validatePropTypeStep(propValue, key, componentName, propFullName, minValue, maxValue, decimalPrecisionValue) {
  if (typeof propValue !== 'number') {
    return new Error(`Invalid value of ${propValue} supplied to the prop '${propFullName}' of an ${componentName}. The '${propFullName}' must be supplied a value of type 'number'`);
  }
  if (propValue <= 0) {
    return new Error(`Invalid value of ${propValue} supplied to the prop '${propFullName}' of an ${componentName}. The '${propFullName}' must be a non-zero positive number`);
  }
  if (!isValidStepWithinRange(minValue, maxValue, propValue, decimalPrecisionValue)) {
    return new Error(`Invalid value of ${propValue} supplied to the prop '${propFullName}' of an ${componentName}. The ${componentName} range of ${maxValue - minValue} is not divisible by the '${propFullName}' using a decimalPrecsision of ${decimalPrecisionValue}; this will prevent the user from selecting the 'max' value and must be corrected by updating the value of 'step' and/or the value of 'decimalPrecision'`);
  }

  return null;
}

/**
 * `LdsNumericSlider` utility `PropType` validation function: Determines if the user input to prop `decimalPrecision` is valid
 *
 * _Returns an `Error` if invalid, otherwise returns `null`_
 *
 * @returns {Error|null}
 */
export function validatePropTypeDecimalPrecision(propValue, key, componentName, propFullName) {
  if (typeof propValue !== 'number') {
    return new Error(`Invalid value of ${propValue} supplied to the prop '${propFullName}' of an ${componentName}. The '${propFullName}' must be supplied a value of type 'number'`);
  }
  if (propValue < 0) {
    return new Error(`Illogical value of ${propValue} supplied to the prop '${propFullName}' of an ${componentName}. The '${propFullName}' represents "decimal places" needed for the numeric precision and MUST be a positive integer value (fractional values will not be used; the value will be processed using the parseInt function)`);
  }

  return null;
}

/**
 * `LdsNumericSlider` utility `PropType` validation function: Determines if the user input to prop `value` is valid
 *
 * _Returns an `Error` if invalid, otherwise returns `null`_
 *
 * @returns {Error|null}
 */
export function validatePropTypeValue(propValue, key, componentName, propFullName, minValue, maxValue) {
  if (typeof propValue !== 'number') {
    return new Error(`Invalid value of ${propValue} supplied to the prop '${propFullName}' of an ${componentName}. The '${propFullName}' must be supplied a value of type 'number'`);
  }
  if (minValue > propValue || propValue > maxValue) {
    return new Error(`Invalid out-of-range value of ${propValue} supplied to the prop '${propFullName}' of an ${componentName}. The '${propFullName}' value must be within the min/max range: min(${minValue}) ≥ 'value' ≤ max(${maxValue})`);
  }

  return null;
}

// MARK: Utilities

/**
 * `LdsNumericSlider` utility: Gets an element from within the component context by ID using the `querySelector` method.
 *
 * @param {React.MutableRefObject<undefined>.current} currentContextRef a valid React `useRef` to a component element, usually the component's root container element.
 * @param {string} elementId the id attribute of the component element to get
 * @param {boolean} debug whether to print development debug messages to the console
 *
 * @returns {HTMLElement|null} a reference to the `HTMLElement` object if found, or the `null` primitive if the `querySelector` function fails or an exception occurs
 */
export const getElementRefById = (currentContextRef, elementId, debug = false) => {
  if (currentContextRef) {
    try {
      const element = currentContextRef.querySelector(`#${elementId}`);
      if (!element) {
        if (debug) consoleWriter(`LdsNumericSlider utility => getElementRefById >>> [×] Element ID '${elementId}' NOT found, this many not be a problem if the component has not finished rendering; returning:`, 'warn', true, element);
        return null;
      }

      // Verbose DEBUG -- Enable to make sure you're getting the DOM element you think you are; Disable in production
      // console.log(`LdsNumericSlider utility => getElementRefById >>> [√] Element ID '${elementId}' found:`, element);

      return element;
    } catch (ex) {
      // DEBUG
      if (debug) consoleWriter(`LdsNUmericSlider utility => getElementRefById >>> A fatal exception occurred attempting to get the Element ID '${elementId}': ${ex.message}`, 'error');
      return null;
    }
  }

  return null;
};

/**
 * `LdsNumericSlider` utility: Gets the offsetWidth property of an `HTMLElement`
 *
 * @param {HTMLElement} elementRef a valid HTML DOM element reference
 *
 * @returns {number} either the `offsetWidth` property value of the element or the `NaN` primitive if the processing fails or throws an exception
 */
export function getElementOffsetWidth(elementRef) {
  try {
    // If the element reference is falsy, return NaN
    if (!elementRef) return NaN;

    // Return the element's offsetWidth explicitly coerced to typeof Number
    return Number(elementRef.offsetWidth);
  } catch (ex) {
    // Shouldn't happen...
    consoleWriter('LdsNumericSlider utility => getElementOffsetWidth handled unexpected exception:', 'error', true, ex.message);
    return NaN;
  }
}

/**
 * `LdsNumericSlider` utility: Gets the NEW offsetWidth property of an `HTMLElement` if it has changed from a previously known value
 *
 * @param {HTMLElement} elementRef a valid HTML DOM element reference
 * @param {number} currentOffsetWidth the known current/previous offset width of the same element passed into `elementRef`
 *
 * @returns {number} either the NEW `offsetWidth` property value of the element or else it returns the value of `currentOffsetWidth` if the processing fails or throws an exception
 */
export function getUpdatedElementOffsetWidth(elementRef, currentOffsetWidth) {
  try {
    const newOffsetWidth = getElementOffsetWidth(elementRef);

    // If the returned new value is falsy, return the current value
    if (!newOffsetWidth) return currentOffsetWidth;

    // If the returned new value is identical to the current, return the current
    if (newOffsetWidth === currentOffsetWidth) return currentOffsetWidth;

    // The new value is an update, return it
    return newOffsetWidth;
  } catch (ex) {
    // Shouldn't happen...
    consoleWriter('LdsNumericSlider utility => tryUpdatingElementOffsetWidth handled unexpected exception:', 'error', true, ex.message);
    return currentOffsetWidth;
  }
}
