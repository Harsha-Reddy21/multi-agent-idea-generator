// MARK: IMPORTS
import cn from 'classnames';

import {
  getValidRange,
  getValidSteps,
  getValidDecimalPrecisionFactor
} from '../util.js';

import { consoleWriter } from '../../../util/consoleWriter.js';

/**
 * Private Sub-Component slider min or max label
 */
export default function NumericSliderStepIndicators({
  ids,
  classes,
  min,
  max,
  step,
  decimalPrecision,
  activeValue,
  trackOffsetWidth,
  handleOffsetWidth,
  enableDevDebug,
}) {
  // Enable a verbose debugging option for this sub-component? (NEVER LEAVE THIS ENABLED IN PRODUCTION!)
  const enableVerboseDebug = false;

  // Verbose debugging will only apply if the component debugging is also enabled (safety)
  let useVerboseDebug = false;
  if (enableVerboseDebug && enableDevDebug) useVerboseDebug = true;

  let props;
  if (enableDevDebug) {
    props = {
      ids: ids,
      classes: classes,
      min: min,
      max: max,
      step: step,
      decimalPrecision: decimalPrecision,
      activeValue: activeValue,
      trackOffsetWidth: trackOffsetWidth,
      handleOffsetWidth: handleOffsetWidth,
    };
  }

  const debugMessage = {
    componentProps: props,
    computedRange: NaN,
    computedIndicatorSteps: NaN,
    computedDecimalPrecisionFactor: NaN,
    renderedStepItemCount: 0,
    renderedStepItems: [],
    xError: false,
    xErrorMessage: undefined,
  };

  try {
    const range = getValidRange(min, max, useVerboseDebug);
    const decimalPrecisionFactor = getValidDecimalPrecisionFactor(decimalPrecision, useVerboseDebug);
    // LDS Design wants the step indicators to include the min and max step
    // Indicator steps will be the total valid steps within the range PLUS ONE
    const indicatorSteps = (getValidSteps(min, max, step, decimalPrecision, useVerboseDebug) + 1);

    if (enableDevDebug) {
      debugMessage.computedRange = range;
      debugMessage.computedIndicatorSteps = indicatorSteps;
      debugMessage.computedDecimalPrecisionFactor = decimalPrecisionFactor;
    }

    // Array to hold the JSX mark-up for each step as an array element
    const stepsJSX = [];
    // Create a step JSX element for the min, max and each step within that range on the track
    // Note we're looping through an absolute number of steps to render as indicators
    for (let i = 0; i < (indicatorSteps); i += 1) {
      const thisStep = {
        value: NaN,
        valueLabel: NaN,
        activeClass: '',
        ratio: NaN,
        offset: NaN,
        position: NaN,
        jsxItemId: '!STEP_ITEM_ID',
        jsxItemClass: '!STEP_ITEM_CLASS',
        jsxItemStyle: null,
        jsxItem: undefined,
        jsxDotId: '!STEP_DOT_ID',
        jsxDotClass: '!STEP_DOT_CLASS',
        jsxDot: null,
        jsxValueId: '!STEP_VALUE_ID',
        jsxValueClass: '!STEP_VALUE_CLASS',
        jsxValue: null,
      };
      // Compute the actual step value
      thisStep.value = (((i) * step) + min);
      // Get the step value as a whole number for the element id
      thisStep.valueLabel = Math.trunc(thisStep.value * decimalPrecisionFactor);
      // Determine whether the step is in the active state
      thisStep.activeClass = (activeValue > thisStep.value) ? 'in-selected-range' : '';

      // Calculate this step's position on the track
      thisStep.ratio = ((thisStep.value - min) / range);
      thisStep.offset = (handleOffsetWidth / trackOffsetWidth) * thisStep.ratio;
      thisStep.position = ((thisStep.ratio - thisStep.offset) * 100);

      // Compose this step element's opening container element attributes
      thisStep.jsxItemId = `${ids.steps.indicatorsItemsPrefix}${thisStep.valueLabel}`;
      thisStep.jsxItemClass = cn(classes.steps.indicators.item, thisStep.activeClass);
      thisStep.jsxItemStyle = { insetInlineStart: `calc(${thisStep.position}% + 10px)` };

      thisStep.jsxDotId = `${thisStep.jsxItemId}-indicator`;
      thisStep.jsxDotClass = `${classes.steps.indicators.trackDot}`;
      thisStep.dotJSX = <span id={thisStep.jsxDotId} className={thisStep.jsxDotClass} data-value={thisStep.value}></span>;

      thisStep.jsxValueId = `${thisStep.jsxItemId}-value`;
      thisStep.jsxValueClass = `${classes.steps.indicators.value}`;
      thisStep.valueJSX = <span id={thisStep.jsxValueId} className={thisStep.jsxValueClass}>{thisStep.valueLabel}</span>;

      // Create this step's JSX element mark-up
      thisStep.itemJSX = <span key={i} id={thisStep.jsxItemId} className={thisStep.jsxItemClass} style={thisStep.jsxItemStyle}>{thisStep.dotJSX || ''}{thisStep.valueJSX || ''}</span>;

      // Add this step's JSX to the steps JSX mark-up array.
      stepsJSX.push(thisStep.itemJSX);

      if (enableDevDebug) {
        debugMessage.renderedStepItemCount = (i + 1);
        debugMessage.renderedStepItems.push(thisStep);
      }
    }

    if (enableDevDebug) consoleWriter(`LdsNumericSlider '${ids.input}' private sub-component <NumericSliderStepIndicators> rendered successfully!\n>>> RESULT:`, 'log', true, debugMessage);

    return stepsJSX;
  } catch (ex) {
    if (enableDevDebug) {
      debugMessage.xError = true;
      debugMessage.xErrorMessage = ex.message;
      consoleWriter(`LdsNumericSlider '${ids.input}' private sub-component <NumericSliderStepIndicators> rendered with errors...\n>>> RESULT:`, 'error', true, debugMessage);
    }
  }
}
