import cn from 'classnames';
import PropTypes from 'prop-types';

/**
 * Private Sub-Component slider range label
 */
export default function NumericSliderRangeLabel({
  enabled = false,
  type,
  ids,
  classes,
  children = 'UNDEFINED!',
  className,
  ...rest
}) {
  try {
    if (!enabled) return null;

    const label = {
      id: 'UNDEFINED',
      class: 'UNDEFINED',
      innerId: 'UNDEFINED',
    };

    switch (type.toLowerCase()) {
      case 'min':
        label.id = ids.rangeLabel.min.container;
        label.class = classes.rangeLabel.min;
        label.innerId = ids.rangeLabel.min.inner;
        break;
      case 'mid':
        label.id = ids.rangeLabel.mid.container;
        label.class = classes.rangeLabel.mid;
        label.innerId = ids.rangeLabel.mid.inner;
        break;
      case 'max':
        label.id = ids.rangeLabel.max.container;
        label.class = classes.rangeLabel.max;
        label.innerId = ids.rangeLabel.max.inner;
        break;
      default:
        break;
    }

    return (
      <span
        id={label.id}
        className={cn(
          label.class,
          className
        )}
        aria-hidden={!children}
        {...rest}
      >
        <span
          id={label.innerId}
          className={classes.rangeLabel.inner}
        >
          {children}
        </span>
      </span>
    );
  } catch (ex) {
    throw new Error(`LdsNumericSlider handled an unexpected exception in private sub-component <NumericSliderRangeLabel>; EXCEPTION: ${ex.message}`);
  }
}

NumericSliderRangeLabel.propTypes = {
  type: PropTypes.oneOf(['min', 'mid', 'max']).isRequired,
  ids: PropTypes.any.isRequired,
  classes: PropTypes.any.isRequired,
};
