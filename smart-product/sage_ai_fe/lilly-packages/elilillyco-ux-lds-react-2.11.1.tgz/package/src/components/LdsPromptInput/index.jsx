import {
  forwardRef,
  useEffect,
  useRef,
  useState
} from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import useResizeObserver from '../../hooks/useResizeObserver.js';

// JSDoc type definitions
/**
 * @typedef LdsPromptInputProps
 * @property {string} [borderRadius] - The border radius of the input area. Default is "small"
 * @property {React.ReactNode} [children] - The children of the component
 * @property {string} [className] - The class name of the component
 * @property {string} [inputAriaDescribedBy] - The ID of the element that describes the input area
 * @property {string} [inputAriaLabel] - The aria-label attribute for the input area
 * @property {string} [inputId] - The ID of the input area
 * @property {string} [inputLabel] - The label for the input area
 * @property {string} [inputPlaceholder] - The placeholder text for the input area
 * @property {boolean} [isDisabled] - Whether the input area is disabled
 * @property {boolean} [isRequired] - Whether the input area is required
 * @property {string} [layout] - The layout of the input area. Default is "dynamic"
 * @property {boolean} [showDivider] - Whether to show a divider. Default is "true"
 * @property {string} [textValue] - The value of the input area
 * @property {function} [setTextValue] - The setter function for the value of the input area
 * @property {function} [onChange] - The event handler for the "change" event
 * @property {function} [onFocus] - The event handler for the "focus" event
 * @property {function} [onInput] - The event handler for the "input" event
 * @property {function} [onKeyDown] - The event handler for the "keydown" event
 * @property {function} [onSubmit] - The event handler for the "submit" event
 * @property {React.HTMLAttributes<HTMLDivElement>} [rest] - The rest of the props
 */
/**
 * LdsPromptInput component
 * @param {LdsPromptInputProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */

const LdsPromptInput = forwardRef(
  function LdsPromptInput({
    borderRadius,
    children,
    className,
    inputAriaDescribedBy,
    inputAriaLabel,
    inputId,
    inputLabel,
    inputPlaceholder,
    isDisabled = false,
    isRequired = false,
    layout,
    showDivider = true,
    /* state */
    textValue,
    setTextValue,
    /* event handlers */
    onChange = () => {},
    onFocus = () => {},
    onInput = () => {},
    onKeyDown = () => {},
    onSubmit = () => {},
    /* */
    ...rest
  }, ref) {
    const [isMultiLine, setIsMultiLine] = useState(false);
    const promptInputRef = useRef();
    const inputWrapRef = useRef();

    // need two refs because the textarea width varies
    // use the whole component's width as a reference for the textarea width
    const [promptInputWidth, setPromptInputWidth] = useState(null);

    // use the textarea height to determine if it's multiline
    const [inputWrapHeight, setInputWrapHeight] = useState(null);
    const [inputWrapRect, inputLabelRef] = useResizeObserver();

    const handleChange = (e) => {
      setTextValue(e.target.value);
      onChange(e);
    };

    const handleInput = (e) => {
      // "field-sizing: content" is not widely supported yet
      if (!(CSS.supports('field-sizing', 'content'))) {
      // https://css-tricks.com/the-cleanest-trick-for-autogrowing-textareas/
        inputWrapRef.current.dataset.replicatedValue = e.target.value;
      }
      onInput(e);
    };

    const handleKeyDown = (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        onSubmit(promptInputRef);
      }
      onKeyDown(e);
    };

    // determine if input area has gone full width or multiline
    useEffect(() => {
      // only necessary if layout is dynamic or multiline-focus
      if (layout === 'dynamic' || layout === 'multiline-focus') {
        if (!inputWrapRect || !promptInputRef) return;

        // get initial measurements
        if (!inputWrapHeight || !promptInputWidth) {
          setInputWrapHeight(inputWrapRect.height);

          // get the width of the Prompt Input minus borders
          const promptInputRefStyle = window.getComputedStyle(promptInputRef.current);
          setPromptInputWidth(promptInputRef.current.offsetWidth
            - parseFloat(promptInputRefStyle.borderLeftWidth)
            - parseFloat(promptInputRefStyle.borderRightWidth));
        }

        // input area is shorter or narrower
        if (inputWrapRect.height <= inputWrapHeight || inputWrapRect.width < promptInputWidth) {
          setIsMultiLine(false);
        }
        // input area is taller or wider
        if (inputWrapRect.height > inputWrapHeight || inputWrapRect.width >= promptInputWidth) {
          setIsMultiLine(true);
        }
      }
    }, [
      layout,
      inputWrapHeight,
      inputWrapRect,
      promptInputWidth,
    ]);

    return (
      <div
        className={cn(
          'lds-prompt-input',
          `radius-${borderRadius || 'small'}`,
          layout || 'dynamic',
          {
            'has-divider': showDivider && layout !== 'singleline',
          },
          {
            'has-label': inputLabel,
          },
          {
            'is-multiline': isMultiLine || (layout === 'multiline'),
          },
          className
        )}
        ref={promptInputRef}
        {...rest}
      >
        <div className="textarea-wrap">
          {layout === 'singleline' ? (
            <div
              className="input-wrap"
              ref={inputWrapRef}
              >
              <input
                type="text"
                aria-describedby={inputAriaDescribedBy}
                aria-label={inputAriaLabel || inputLabel}
                disabled={isDisabled}
                id={inputId}
                name={inputId}
                onChange={handleChange}
                onFocus={onFocus}
                onInput={(e) => handleInput(e)}
                onKeyDown={handleKeyDown}
                placeholder={inputPlaceholder}
                ref={ref}
                required={isRequired}
                value={textValue}
              />
            </div>
          ) : (
            <>
              <label
                ref={inputLabelRef}
              >
                {inputLabel && (
                  <span className="input-label-wrap">
                    <span className="input-label">{inputLabel}</span>
                  </span>
                )}
                <div
                  className="input-wrap"
                  ref={inputWrapRef}
                >
                  <textarea
                    aria-describedby={inputAriaDescribedBy}
                    aria-label={inputAriaLabel || inputLabel}
                    disabled={isDisabled}
                    id={inputId}
                    name={inputId}
                    onChange={handleChange}
                    onFocus={onFocus}
                    onInput={handleInput}
                    onKeyDown={handleKeyDown}
                    placeholder={inputPlaceholder || inputLabel}
                    ref={ref}
                    required={isRequired}
                    rows={1}
                    value={textValue}
                  />
                </div>
              </label>
            </>
          )}
        </div>
        <div className="button-area">
          {children}
        </div>
      </div>
    );
  }
);

export default LdsPromptInput;

LdsPromptInput.propTypes = {
  borderRadius: PropTypes.string,
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
  inputAriaDescribedBy: PropTypes.string,
  inputAriaLabel: PropTypes.string,
  inputId: PropTypes.string,
  inputLabel: PropTypes.string,
  inputPlaceholder: PropTypes.string,
  isDisabled: PropTypes.bool,
  isRequired: PropTypes.bool,
  layout: PropTypes.string,
  showDivider: PropTypes.bool,
  textValue: PropTypes.string.isRequired,
  setTextValue: PropTypes.func.isRequired,
  onChange: PropTypes.func,
  onFocus: PropTypes.func,
  onInput: PropTypes.func,
  onKeyDown: PropTypes.func,
  onSubmit: PropTypes.func.isRequired,
};
