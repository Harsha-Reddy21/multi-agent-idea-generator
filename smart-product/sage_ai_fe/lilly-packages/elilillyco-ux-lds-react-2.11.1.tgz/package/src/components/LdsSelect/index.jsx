import {
  createRef,
  useEffect,
  useRef,
  useState
} from 'react';
import cn from 'classnames';
import PropTypes from 'prop-types';

import LdsDropdown from '../LdsDropdown/index.jsx';
import LdsValidationError from '../LdsValidationError/index.jsx';

import SelectOption from './private/SelectOption.jsx';
import { flattenOptions } from './util.js';

// JSDoc type definitions
/**
 * @typedef LdsSelectProps
 * @property {string} id - HTML input element ID
 * @property {string} name - HTML input name
 * @property {string} [label] - Label to display above the select
 * @property {{value: any, label: string}[]} options - Array of options. Each option must contain a value and a label
 * @property {any} [value] - The value of the selected option
 * @property {boolean} [required] - Sets the input as required
 * @property {boolean} [error] - Sets the select input to error state
 * @property {string} [errorMessage] - Optional error message to display below select when error is true.
 * @property {boolean} [disabled] - Sets the select input to disabled state
 * @property {Function} [onChange] - Event that will be fired after selected option changes
 * @property {object} [inputProps] - Optional object of properties to apply to the hidden input
 * @property {object} [buttonProps] - Optional additional button properties
 * @property {string} [className] - Optional custom user-defined CSS class names, will be appended to the list of any other component classes
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Optional, define any additional non-prop attributes to be rendered on the component's root container element.
 */
/**
 * LdsSelect component
 * @param {LdsSelectProps & React.InputHTMLAttributes<HTMLInputElement>} props
 * @returns {React.JSX.Element}
 */
function LdsSelect({
  id,
  name,
  label = '',
  options = [],
  value,
  required = false,
  error = false,
  errorMessage,
  disabled = false,
  onChange = () => {},
  inputProps,
  buttonProps,
  className,
  ...rest
}) {
  // MARK: Component Methods
  const flattenedOptions = flattenOptions(id, options);

  const selectRef = useRef(null);
  const optionsRef = useRef(flattenedOptions.map(() => createRef()));

  const validationMessageId = `${id}_select-validation-message`;

  /**
   * Gets the currently selected item based on the current selected value
   */
  const getSelectItemByValue = () => {
    // console.log('Getting the selected option by the selected value...');
    if (!flattenedOptions || !Array.isArray(flattenedOptions) || flattenedOptions.length < 1) {
      // console.log('>>> NO OPTIONS! Returning an option object with undefiend properties.');
      return { id: undefined, value: undefined, label: undefined };
    }

    if (value === undefined || value === null) {
      // console.log(`>>> value = ${value}; we need to default to the first selectable option in the flattened array as selected`);
      if (flattenedOptions[0].value === undefined || flattenedOptions[0].value === null) {
        // console.log('>>> the value of the first option object in the flattened options list was a option group header, selecting the first option group\'s selectable option:', flattenedOptions[1]);
        return flattenedOptions[1];
      }
      // console.log('>>> selecting the first option by default; option:', flattenedOptions[0]);
      return flattenedOptions[0];
    }

    // console.log(`>>> value = ${value}; we need to find the selected option in the flattened array to set as selected`);
    const foundItem = flattenedOptions.find((option) => option.value === value);
    if (!foundItem) {
      // eslint-disable-next-line no-console
      console.error(`
        LdsSelect - no corresponding option provided for value: ${value}
        type: ${typeof value}
      `);
    }
    // console.log('>>> found it! setting the selecting the option:', foundItem);
    return foundItem;
  };

  const [isOpen, setIsOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState(getSelectItemByValue());
  const [focusedOption, setFocusedOption] = useState(getSelectItemByValue());

  /**
   * Gets which option and/or validation message is currently describing the select
   * when there is a selected option or an active validation message
   */
  const getAriaDescribedBy = () => {
    let desc = '';
    // id of the validation error
    if (error && errorMessage) desc += ` ${validationMessageId}`;

    // id of the selected option
    if (selectedItem !== undefined && selectedItem !== null) {
      desc += ` ${selectedItem.id}`;
    }

    return desc.trim();
  };

  const [ariaDescribedBy, setAriaDescribedBy] = useState(getAriaDescribedBy());

  /**
   * Watches the selected value and updates the selected option and gives it focus
   */
  useEffect(() => {
    const selectedItem = getSelectItemByValue();
    setSelectedItem(selectedItem);
    setFocusedOption(selectedItem);
  }, [value]); // eslint-disable-line react-hooks/exhaustive-deps

  /**
   * Watches the selected item and the validation message to update the select's ARIA described by attribute
   */
  useEffect(() => {
    setAriaDescribedBy(getAriaDescribedBy());
  }, [selectedItem, error, errorMessage]); // eslint-disable-line react-hooks/exhaustive-deps

  /**
   * Watches isOpen and causes focus to move to selected/active item when the select dropdown is opened
   */
  useEffect(() => {
    if (isOpen) {
      const activeIdx = flattenedOptions.findIndex((option) => option.value === selectedItem.value);
      optionsRef.current[activeIdx].current.focus();
    }
  }, [isOpen]); // eslint-disable-line react-hooks/exhaustive-deps

  /**
   * Handles setting the select open state of the select options list
   */
  const handleOpen = () => {
    setIsOpen(true);
    setFocusedOption(selectedItem);
  };

  /**
   * Handles creating a custom keyboard UX when interacting with the select
   *
   * @param {Event} e the standard event object
   */
  const handleSelectKeyDown = (e) => {
    const code = e.code;

    // open the dropdown and switch the focus to the selected item
    if (code === 'Space') {
      handleOpen();
    }

    // Tab away from the select
    if (code === 'Tab') {
      setIsOpen(false);
    }
  };

  /**
   * Handles creating a custom keyboard UX when interacting with the options list elements
   *
   * @param {Event} e the standard event object
   */
  const handleOptionKeyDown = (e) => {
    const isUp = e.key === 'ArrowUp';
    const isDown = e.key === 'ArrowDown';
    const isTab = e.key === 'Tab';
    const isEscape = e.key === 'Escape';

    if (isEscape) {
      setIsOpen(false);
      selectRef.current.focus();
    }

    if (isTab) {
      setIsOpen(false);
    }

    if (isUp) {
      const activeIdx = flattenedOptions.findIndex((option) => option.value === focusedOption.value);
      if (activeIdx === 0) return;

      let newIdx = activeIdx - 1;
      const nextOption = optionsRef.current[newIdx].current;
      // See if Next option up is a group label
      if (nextOption.classList.contains('select-group-label')) {
        if (newIdx === 0) return;
        newIdx -= 1;
      }
      optionsRef.current[newIdx].current.focus();
      setFocusedOption(flattenedOptions[newIdx]);
    }

    if (isDown) {
      const activeIdx = flattenedOptions.findIndex((option) => option.value === focusedOption.value);
      if (activeIdx === flattenedOptions.length - 1) return;

      let newIdx = activeIdx + 1;
      const nextOption = optionsRef.current[newIdx].current;
      // See if Next option down is a group label
      if (nextOption.classList.contains('select-group-label')) {
        if (newIdx === flattenedOptions.length - 1) return;
        newIdx += 1;
      }

      optionsRef.current[newIdx].current.focus();
      setFocusedOption(flattenedOptions[newIdx]);
    }
  };

  /**
   * Handles setting the selected option
   * @param option an instance of an option object
   */
  const handleSelectOption = (option) => {
    setSelectedItem(option);
    setIsOpen(false);
    selectRef.current.focus();

    // Call passed in onChange event
    onChange(option);
  };

  // MARK: Component Render
  return (
    <div
      id={`${id}_wrapper`}
      className={cn(
        'lds-select-wrapper',
        className
      )}
      {...rest}
    >
      { label
        && <label
          id={`${id}_label`}
          className={cn(
            'lds-form-label',
            {
              disabled: disabled,
            }
          )}
          htmlFor={`${id}_button`}
        >
          {label}
        </label>
      }

      <div
        id={`${id}_input-wrapper`}
        className={cn(
          'lds-select-input-wrapper',
          {
            open: isOpen,
          }
        )}
      >
        <input
          id={id}
          name={name || id}
          type="hidden"
          value={selectedItem?.value}
          required={required}
          {...inputProps}
        />
        <LdsDropdown
          isOpen={isOpen}
          setIsOpen={setIsOpen}
          autoFocusFirstItem={false}
          label={selectedItem?.label}
          buttonProps={{
            className: cn(
              'lds-select',
              {
                error,
              }
            ),
            id: `${id}_button`,
            onKeyDown: handleSelectKeyDown,
            disabled,
            ref: selectRef,
            'aria-label': selectedItem?.ariaLabel,
            'aria-describedby': ariaDescribedBy,
            'aria-required': required,
            'aria-invalid': error,
            ...buttonProps,
          }}
          dropdownProps={{}}
        >
          <div
            id={`${id}_options`}
            role="listbox"
            aria-hidden={!isOpen}
          >
            { flattenedOptions && Array.isArray(flattenedOptions) && flattenedOptions.map((flattenedOption, idx) => (
              <SelectOption
                key={idx}
                option={flattenedOption}
                idx={idx}
                optionsRef={optionsRef}
                selectId={id}
                handleSelectOption={handleSelectOption}
                handleOptionKeyDown={handleOptionKeyDown}
                selectedItem={selectedItem}
              />
            ))}
          </div>
        </LdsDropdown>
      </div>
      {
        error && errorMessage
        && <LdsValidationError id={validationMessageId}>{errorMessage}</LdsValidationError>
      }
    </div>
  );
}

// MARK: Props Validation
LdsSelect.propTypes = {
  id: PropTypes.string.isRequired,
  name: PropTypes.string,
  label: PropTypes.string,
  options: PropTypes.arrayOf((propValue, key, componentName, propFullName) => { // eslint-disable-line
    const isGroup = !!propValue[key].options;
    if (isGroup && !Array.isArray(propValue[key].options)) {
      return new Error(
        `Invalid prop ${propFullName} supplied to ${componentName} at index ${key}. Grouped options must have an "options" array.`
      );
    }

    if (propValue[key].value === undefined && !isGroup) {
      return new Error(
        `Invalid prop ${propFullName} supplied to ${componentName} at index ${key}. Each option must contain a "value" property.`
      );
    }
    if (propValue[key].label === undefined && !isGroup) {
      return new Error(
        `Invalid prop ${propFullName} supplied to ${componentName} at index ${key}. Each option must contain a "label" property.`
      );
    }
  }),
  required: PropTypes.bool,
  error: PropTypes.bool,
  errorMessage: PropTypes.string,
  disabled: PropTypes.bool,
  onChange: PropTypes.any,
  inputProps: PropTypes.object,
  buttonProps: PropTypes.object,
  className: PropTypes.string,
  rest: PropTypes.any,
};

export default LdsSelect;
