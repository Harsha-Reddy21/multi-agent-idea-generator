/**
 * Creates an identifier string value from a label value
 *
 * @param {string|number|boolean} label a value to use as a label
 *
 * @returns {string} a formatted id value
 *
 * Note: If the parameter is provided a value which tests as falsey it will be handled as undefined
 * and a "loud" uppercase value will be returned to help identify problematic logic;
 * make sure you are passing a truthy value into the parameter
 */
export const createLabelId = (label) => {
  let labelId = 'FALSEY-LABEL-ID-VALUE';
  if (label) {
    labelId = label.toString();
    labelId = labelId.toLowerCase();
    labelId = labelId.replaceAll(' ', '-');
  }
  return labelId;
};

/**
 * Creates an option element id
 *
 * @param {string} selectId the unique select instance id value
 * @param {string|number|boolean} elementId a value to use as a logical identifier for the type of option
 * @param {string|number|boolean} optionId a value to use as a unique logical indentifier value for the option
 *
 * @returns {string} a formatted id value for the option element
 *
 * Note: If any parameter is provided a value which tests as falsey it will be handled as undefined
 * and a "loud" uppercase value will be returned to help identify problematic logic;
 * make sure you are passing truthy values into the parameters
 */
export const createOptionId = (selectId, elementId, optionId) => {
  let parsedSelectId = 'FALSEY-SELECT-ID-VALUE';
  if (selectId) parsedSelectId = selectId.toString();

  let parsedElementId = 'FALSEY-ELEMENT-ID-VALUE';
  if (elementId) parsedElementId = elementId.toString();

  let parsedOptionId = 'FALSEY-OPTION-ID-VALUE';
  if (optionId) parsedOptionId = createLabelId(optionId);

  return `${parsedSelectId}_${parsedElementId}_${parsedOptionId}`;
};

/**
 * Flatten the select options objects array and pre-process it to streamline building the options list, particularly when using option groups
 * @param {string} selectId `string` the unique select instance ID
 * @param {Array.<Object>} options `Array.<Object>` the user-defined options object array that was input into the select component options prop
 *
 * @returns {Array.<Object>[]} `Array.<Object>` the flattened array of options list objects
 */
export const flattenOptions = (selectId, options) => {
  try {
    const flatOptions = options.flatMap((option) => {
      if (option.options) {
        // Handle an option group and its options
        const groupId = createOptionId(selectId, 'option-group', option.label);
        const groupOptionId = `${createLabelId(option.label)}-option`;
        return [
          {
            id: groupId,
            label: option.label,
          },
          ...option.options.map((groupOption) => ({
            groupId: groupId,
            id: createOptionId(selectId, groupOptionId, (groupOption.value === '' ? 'empty' : groupOption.value.toString())),
            label: groupOption.label,
            ariaLabel: groupOption.ariaLabel || null,
            value: groupOption.value,
          })),
        ];
      }

      // Handle a single flat option
      return [
        {
          id: createOptionId(selectId, 'option', (option.value === '' ? 'empty' : option.value)),
          label: option.label,
          ariaLabel: option.ariaLabel || null,
          value: option.value,
        },
      ];
    });
    // UNCOMMENT TO DEBUG
    // console.log('LdsSelect processed flattened options array => flatOptions:', flatOptions);
    return flatOptions;
  } catch (err) {
    // eslint-disable-next-line
    console.error(`LdsSelect id='${selectId}' encountered an unhandled exception in the flattenOptions helper function; Error ${err}\noptions:`, options)
    return options;
  }
};
/* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  The "flattenOptions" function parses the options objects array to preprocess the
  options and to flatten grouped options if they are being used
  this makes displaying the list and working with refs easier
  it also adds:
    - select instance unique ID attribute values to set on the options list items
    - creates a group id for options groups which is used to set ARIA attributes

  Given a select with id='mySelect', the following options objects array:
  [
    {
      label: '',
      value: '',
    },
    {
      label: 'Group A',
      options: [
        {
          label: 'Group A - 1'
          value: 1,
        },
        {
          label: 'Group A - 2'
          value: 2,
        }
      ],
    {
      label: 'Group B',
      options: [
        {
          label: 'Group B - 1'
          value: 3,
        },
        {
          label: 'Group B - 2'
          value: 4,
        }
      ],
    }
  ]

  Is transformed into the flattened options objects array:

  [
    {
        "id": "mySelect_option_empty",
        "label": "",
        "value": ""
    },
    {
        "id": "mySelect_option-group_group-a",
        "label": "Group A"
    },
    {
        "id": "mySelect_group-a-option_1",
        "groupId": "mySelect_option-group_group-a",
        "value": 1,
        "label": "Group A - 1"
    },
    {
        "id": "mySelect_group-a-option_2",
        "groupId": "mySelect_option-group_group-a",
        "value": 2,
        "label": "Group A - 2"
    },
    {
        "id": "mySelect_option-group_group-b",
        "label": "Group B"
    },
    {
        "id": "mySelect_group-b-option_3",
        "groupId": "mySelect_option-group_group-b",
        "value": 3,
        "label": "Group B - 1"
    },
    {
        "id": "mySelect_group-b-option_4",
        "groupId": "mySelect_option-group_group-b",
        "value": 4,
        "label": "Group B - 2"
    }
  ]
*/
