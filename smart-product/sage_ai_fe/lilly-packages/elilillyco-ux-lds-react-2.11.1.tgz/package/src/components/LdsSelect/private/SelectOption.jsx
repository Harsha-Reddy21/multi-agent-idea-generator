import cn from 'classnames';

/**
 * Private Sub-Component to return an option list element
 */
export default function SelectOption({
  selectId, // eslint-disable-line no-unused-vars
  idx,
  option,
  optionsRef,
  handleOptionKeyDown,
  handleSelectOption,
  selectedItem,
  className,
  ...rest
}) {
  if (option.value === undefined) {
    return (
      <div
        ref={optionsRef.current[idx]}
        id={option.id}
        className={cn(
          'select-group-label',
          className
        )}
        tabIndex="-1"
        aria-label=''
        aria-hidden="true"
        {...rest}
      >
        {option.label}
      </div>
    );
  }

  return (
    <button
      id={option.id}
      role="option"
      type="button"
      ref={optionsRef.current[idx]}
      tabIndex="-1"
      // In Safari non-text input elements do not gain focus on click.
      // Here we prevent the default mousedown behavior, which allows
      // the button element to gain focus
      onMouseDown={(event) => event.preventDefault()}
      onClick={() => handleSelectOption(option)}
      onKeyDown={handleOptionKeyDown}
      data-option={option.id}
      data-value={option.value}
      aria-label={option.ariaLabel}
      aria-describedby={option.groupId || null}
      className={cn(
        'lds-button-clear-style',
        'lds-select-option',
        {
          selected: selectedItem.value === option.value,
          grouped: option.groupId,
        },
        className
      )}
      {...rest}
    >
      {option.label}
    </button>
  );
}
