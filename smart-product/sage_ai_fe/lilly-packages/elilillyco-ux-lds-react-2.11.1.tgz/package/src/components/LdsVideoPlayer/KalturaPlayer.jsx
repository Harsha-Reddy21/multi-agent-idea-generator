import cn from 'classnames';
import PropTypes from 'prop-types';

import useAddKalturaScript from '../../hooks/useAddKalturaScript.js';

// JSDoc type definitions
/**
 * @typedef LdsKalturaPlayerProps
 * @property {string} [videoId] - Rquired; A unique identifier for an individual Kaltura video (Kaltura also referrs to this as the "Entry ID"); this should be provided by a Lilly Kaltura account administrator
 * @property {string} [partnerId] - Required; A unique identifier for a Kaltura user account; this should be provided by a Lilly Kaltura account administrator
 * @property {string} [uiConfId] - Required; A Kaltura "UI Configuration ID" which references a Video Player UI Configuration set in the KMC (Kaltura Management Console); this should be provided by a Lilly Kaltura account administrator
 * @property {boolean} [autoplay=false] - Optional; Whether the video should start playing as soon it is loaded on the page
 * @property {string} [startTime='00:00:00'] - Optional: Input an absolute time string in the format 'h:mm:ss' that is within the duration of the video being embedded at which the video should default its playback start at
 * @property {boolean} [chromeless=false] - Optional; Whether to apply the Kaltura "chromeless" class to the targetDiv element
 * @property {object} [plugins] - Optional; The Kaltura player's plugins configuration object; used to add custom plugins which extend player functionality
 * @property {string} [className] - Optional; Custom user-defined CSS class(es) for the component context, will be appended to the list of any other component classes on the component's root container element.
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Optional; Define any additional non-prop attributes to be rendered on the component's root container element.
 */
/**
 * LdsVideoPlayer component
 * @param {LdsKalturaPlayerProps} props
 * @returns {React.JSX.Element}
 */
export default function LdsKalturaPlayer({
  videoId,
  partnerId,
  uiConfId,
  autoplay = false,
  startTime = '0:00:00',
  chromeless = false,
  plugins,
  className,
  ...rest
}) {
  const targetDiv = `kaltura_player_for_video_${videoId}`;

  // Creating an error callback is recommended when instantiating the embed script
  const {
    hasError: {
      errorDetected, errorMessage,
    },
    seekToPositionKaltura,
  } = useAddKalturaScript({
    videoId: videoId,
    partnerId,
    uiConfId,
    targetDiv,
    chromeless,
    plugins,
  });

  // if there is an error loading the script, throw an error, which will be caught by an ErrorBoundary
  if (errorDetected) {
    throw new Error(errorMessage);
  }

  // Use the seek to postion function to dynamically set the start time
  // and whether to auto play when these props are updated.
  seekToPositionKaltura(startTime, autoplay);

  // Returns a div element that embeds the player
  return (
    <div
      id={targetDiv}
      className={cn(
        'kaltura_player',
        className
      )}
      {...rest}
    >
    </div>
  );
}

LdsKalturaPlayer.propTypes = {
  videoId: PropTypes.string.isRequired,
  partnerId: PropTypes.string.isRequired,
  uiConfId: PropTypes.string.isRequired,
  autoplay: PropTypes.bool,
  startTime: PropTypes.string,
  chromeless: PropTypes.bool,
  plugins: PropTypes.any,
  className: PropTypes.string,
};
