import PropTypes from 'prop-types';

import timeToSeconds from '../../util/timeToSeconds.js';

// JSDoc type definitions
/**
 * @typedef LdsYoutubePlayerProps
 * @property {string} [videoId] - Rquired; A unique identifier for an individual Kaltura video (Kaltura also referrs to this as the "Entry ID"); this should be provided by a Lilly Kaltura account administrator
 * @property {number} [width=560] - Optional; the width attribute of the iframe in pixels; default is 560; assumes a 16/9 aspect ratio.
 * @property {height} [height=315] - Optional; the height attribute of the iframe in pixels; default is 315; assumes a 16/9 aspect ratio.
 * @property {boolean} [autoplay=false] - Optional; Whether the video should start playing as soon it is loaded on the page
 * @property {string} [startTime='00:00:00'] - Optional; Input an absolute time string in the format 'h:mm:ss' that is within the duration of the video being embedded at which the video should default its playback start at
 * @property {string} [id] - Optional; set a user-defined id attribute override on the rendered <iframe> element; when not set a default value is generated based on the unique videoId
 * @property {string} [title] - Optional; set a user-defined title attribute override value on the rendered <iframe> element; default is 'YouTube Video Player'; this has accessibile context and should describe the embedded player NOT the unique embedded video.
 * @property {string} [src] - Optional; set a user-defined src attribute override value on the rendered <iframe> element; default is a well-formed YouTube video embed URL based on the videoId, autoplay and startTime props. This is provided if explicit control over the embedded video URL is necessary.
 * @property {string} [allow] - Optional; set a user-defined YouTube allow attribute configuration value on the rendered <iframe> element; default config string is 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share'
 * @property {string} [referrerPolicy] - Optional; set a user-defined referrerPolicy attribute value on the rendered <iframe> element; default is 'strict-origin-when-cross-origin'
 * @property {boolean} [allowFullScreen=true] - Optional; Whether to allow the player to use full-screen mode.
 * @property {string} [className] - Optional; Custom user-defined CSS class(es) for the component context, will be appended to the list of any other component classes on the component's root container element.
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Optional; Define any additional non-prop attributes to be rendered on the component's root container element.
 */
/**
 * LdsYoutubePlayer component
 * @param {LdsYoutubePlayerProps} props
 * @returns {React.JSX.Element}
 */
export default function LdsYoutubePlayer({
  videoId,
  autoplay = false,
  startTime = '0:00:00',
  width = 560,
  height = 315,
  id = undefined,
  title = undefined,
  src = undefined,
  allow = undefined,
  referrerPolicy = undefined,
  allowFullScreen = true,
  className,
  ...rest
}) {
  // Use a user-defined src attribute for the iframe or create the default based on the props input
  let iFrameSrc = src;
  if (!src) {
    const srcDefaultPath = 'https://www.youtube.com/embed/';

    const srcAutoPlay = `?autoplay=${autoplay ? '1' : '0'}`;

    const startTimeInSeconds = timeToSeconds(startTime);
    const srcStart = startTimeInSeconds ? `&start=${startTimeInSeconds}` : '';

    iFrameSrc = `${srcDefaultPath}${videoId}${srcAutoPlay}${srcStart}`;
  }

  // Returns a div element that embeds the player
  return (
    <iframe
      id={id || `lds-youtube-video_${videoId}`}
      src={iFrameSrc}
      title={title || 'YouTube Video Player'}
      width={width}
      height={height}
      allow={allow || 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share'}
      referrerPolicy={referrerPolicy || 'strict-origin-when-cross-origin'}
      allowFullScreen={allowFullScreen || null}
      className={className}
      {...rest}
    >
    </iframe>
  );
}

LdsYoutubePlayer.propTypes = {
  videoId: PropTypes.string.isRequired,
  autoplay: PropTypes.bool,
  startTime: PropTypes.string,
  width: PropTypes.number,
  height: PropTypes.number,
  id: PropTypes.string,
  title: PropTypes.string,
  src: PropTypes.string,
  allow: PropTypes.string,
  referrerPolicy: PropTypes.string,
  allowFullScreen: PropTypes.bool,
  className: PropTypes.string,
  rest: PropTypes.any,
};
