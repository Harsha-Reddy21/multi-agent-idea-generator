import useLdsCookieConsent from '../../hooks/useLdsCookieConsent.js';
import LdsLillyLogo from '../LdsLillyLogo/index.jsx';

// JSDoc type definitions
/**
 * @typedef VideoContainerProps
 * @property {string} [backgroundImageUrl] - The background image URL
 * @property {string} [buttonText='Continue'] - The button text
 * @property {boolean} [interstitial=false] - Whether the video is an interstitial
 * @property {React.ReactNode} [interstitialContent] - The interstitial content
 * @property {React.ReactNode} [children] - The children of the component
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Additional props
 */
/**
 * VideoContainer component
 * @param {VideoContainerProps} props
 * @returns {React.JSX.Element}
 */

export default function VideoContainer({
  // Interstitial props
  backgroundImageUrl,
  buttonText = 'Continue',
  interstitial = false,
  interstitialContent = <>
    <p>This video is hosted on YouTube, a platform which Lilly USA, LLC does not control, influence, or endorse. Lilly is not responsible for any content on this third-party site, including the privacy policy.</p>
    <p>Click &ldquo;continue&rdquo; to watch this video hosted on YouTube.</p>
  </>,

  // VideoContainer props
  children,
  ...rest
}) {
  const { acceptCookies, cookieConsentStatus } = useLdsCookieConsent('lds_youtube_affirm');

  return (
    <div
      className="lds-video-container"
      {...rest}
    >
      {(interstitial && !cookieConsentStatus)
        ? <div
          className={'lds-youtube-video-player-interstitial active'}
          style={{ backgroundImage: backgroundImageUrl ? `url('${backgroundImageUrl}')` : 'none' }}
        >
          <div className="lds-youtube-video-player-interstitial-content mx-0">
            <LdsLillyLogo sizeClass="lg" colorClass="white" />
            {interstitialContent}
            <button
              className="lds-button lds-interstitial-button"
              onClick={acceptCookies}
            >
              {buttonText}
            </button>
          </div>
        </div>
        : children
      }
    </div>
  );
}
