import cn from 'classnames';
import { useId } from 'react';

// VideoPlayer sub components for export
import VideoContainer from './VideoContainer.jsx';

// JSDoc type definitions
/**
 * @typedef LdsVideoPlayerProps
 * @property {React.ReactNode} [children] - React Child Node elements "slot"; this should contain the desired video embed method markup
 * @property {string} [aspectRatio='16/9'] - The aspect ratio of the video and embedded player; default is 16:9
 * @property {boolean} [brandBorder] - Optional, adds a thick bottom border to the video player which uses the LDS theme's primary brand color by default
 * @property {string} [heading] - Optional, when set displays a heading or title for the video below the embedded player
 * @property {string} [time] - Optional, when set displays a time duration for the video below the embedded player
 * @property {boolean} [interstitial=false] - If required by legal or regulatory, use to enable a third-party video platform notification interstitial.
 * @property {string} [backgroundImageUrl] - When using the third-party video platform notification instersitial, this prop sets a URI to an image to display in the background; most commonly used with YouTube video thumbnail URI's
 * @property {React.ReactNode} [interstitialContent] - When using the third-party video platform notification instersitial, this prop defines the text content displayed to the user. The default is a typical U.S. English message for use with YouTube videos.
 * @property {string} [buttonText='Continue'] - When using the third-party video platform notification instersitial, this prop defines the text label on the button which dismisses the interstital.
 * @property {string} [className] - Optional custom user-defined CSS class(es) for the component context, will be appended to the list of any other component classes on the component's root container element.
 * @property {React.InputHTMLAttributes<HTMLInputElement>} [rest] - Optional, define any additional non-prop attributes to be rendered on the component's root container element.
 */
/**
 * LdsVideoPlayer component
 * @param {LdsVideoPlayerProps} props
 * @returns {React.JSX.Element}
 */
export default function LdsVideoPlayer({
  children,
  aspectRatio = '16/9',
  brandBorder,
  heading,
  time,
  // Interstitial props
  interstitial = false,
  backgroundImageUrl,
  interstitialContent = <>
    <p>This video is hosted on YouTube, a platform which Lilly USA, LLC does not control, influence, or endorse. Lilly is not responsible for any content on this third-party site, including the privacy policy.</p>
    <p>Click &ldquo;continue&rdquo; to watch this video hosted on YouTube.</p>
  </>,
  buttonText = 'Continue',
  // Default props
  className,
  ...rest
}) {
  // id will be used to generate unique CSS for each video player instance
  const id = useId();
  const cssId = `lds-video-player-${id.slice(1, -1)}`; // remove colons

  return (
    <>
      <style>
        {`
          #${cssId} .lds-video-container,
          #${cssId} .kaltura_player,
          #${cssId} .lds-video-container iframe,
          #${cssId} .lds-video-container video {
            aspect-ratio: ${aspectRatio};
          }
        `}
      </style>
      <div
      className={cn(
        'lds-video-player',
        {
          'has-brand-border': brandBorder,
        },
        className
      )}
        id={cssId}
        {...rest}
      >
        <VideoContainer
          backgroundImageUrl={backgroundImageUrl}
          buttonText={buttonText}
          interstitial={interstitial}
          interstitialContent={interstitialContent}
        >
          {children}
        </VideoContainer>
        {heading && <div className="lds-video-meta">
          <h4 className="lds-video-heading">{heading}</h4>
          {time && <p className="lds-video-time">{time}</p>}
        </div>}
      </div>
    </>
  );
}
