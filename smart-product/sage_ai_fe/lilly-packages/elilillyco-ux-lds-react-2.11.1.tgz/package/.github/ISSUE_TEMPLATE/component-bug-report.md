---
name: Component Bug/Issue Report
about: Track LDS component bugs/issues.
title: 'COMPONENT: BUG/ISSUE'
labels: Potential Issue, Bug
---

**Describe the bug or issue you are experiencing.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the solution you'd like**
A clear and concise description of what you want to happen.

**Describe alternatives you've considered**
A clear and concise description of any alternative solutions or features you've considered.

**Additional context**
Add any other context or screenshots about the feature request here.
