---
name: Component Feature Request
about: Track LDS component feature requests.
title: 'COMPONENT: FEATURE'
labels: Potential Enhancement
---

**Describe the feature you would like to request.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Additional context**
Add any other context or screenshots about the feature request here.
