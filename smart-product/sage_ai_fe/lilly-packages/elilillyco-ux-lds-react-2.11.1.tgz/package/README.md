# Lilly Design System Enterprise — React v2

Lilly UX Design System Repository for the React Component Library

Implements the LDS 2.0 Design Theme

## Overview

The React Lilly Design System (React LDS) package in `UX-LDS-REACT` is a collection of bespoke React components that can be used to facilitate the development of Lilly websites.

## Documentation

This repository uses a [Storybook](https://storybook.js.org/) app used to document the usage of the components, which is located at the following url: [https://ux-lds-react-v2-11edd5d7d7fb.herokuapp.com/](https://ux-lds-react-v2-11edd5d7d7fb.herokuapp.com/)

The React components are built upon the [Base LDS](https://github.com/EliLillyCo/ux-lds) `ux-lds` CSS & web components package. For documentation on that package, please reference it's storybook at the following URL: [https://ux-lds-v2-dd02c86f08ed.herokuapp.com/](https://ux-lds-v2-dd02c86f08ed.herokuapp.com/)

## Usage

### Prerequisites

NodeJS and ReactJS are required.

- The minimum Node version supported is 18; 20+ is recommended.
- The minimum React version supported is 18.

_Older versions than the minimums specified, or initially supported versions which reach end-of-life will not be supported._

### Installation and Usage

The most up-to-date developer guide to installing this code package as a project dependency will be in the included Storybook application's Developer's Guide.

Please see the [React LDS Developer's Guide Quick Start Job Aid](https://ux-lds-react-v2-11edd5d7d7fb.herokuapp.com/?path=/docs/developer-guide-quick-start--docs) for installation instructions.

### Development

This repository contains two web apps used to demonstrate our components. Storybook is used to document and show the API properties of our components. Vite is used to demonstrate our components in an actual web app page - similar to the old LDS kitchen sink.

When deploying the app `npm run build` will build both storybook and vite and serve them on the same app. Storybook will be the default app under the index `/` route. All vite pages routes will be prefixed with `/vite/`

#### Storybook

The Storybook source files are located in this repository under `./stories`

It is hosted for internal Lilly use here: [https://ux-lds-react-v2-11edd5d7d7fb.herokuapp.com/](https://ux-lds-react-v2-11edd5d7d7fb.herokuapp.com/)

It is also possible for developers to run the storybook locally.
Use the command `npm run dev`.
Storybook will run on port 5007; it should automatically open up in the system default browser (or manually navigate to http://localhost:5007).

#### Vite

The Vite source files are located in this repository under `./example-lds-app`

It is hosted for internal Lilly use here: [https://ux-lds-react-v2-11edd5d7d7fb.herokuapp.com/vite/](https://ux-lds-react-v2-11edd5d7d7fb.herokuapp.com/vite/)

It is also possible for developers to run the Vite app locally.
Use the command `npm run dev:vite`.
Vite will run on port 6007; manually navigate to http://localhost:6007 to open it in a browser.

## APPENDIX A - EULA

Third party end user license agreements (EULA).

LDS uses a few third-party features such as fonts, icons and other copyrighted works which are subject to user license agreements.

The relevant EULA information is stored in individual files in the root of this code repository.

These may need to be copied into LDS-dependant project repositories as directed by Lilly legal stakeholders.

### Functionality

- Bootstrap 5: `eula_bootstrap.md`

### Icons

- Phosphor: `eula_phosphor-icons.md`

### Fonts


- IBM Plex Sans: `eula_fonts_ibm-plex-sans.md`
- IBM Plex Mono: `eula_fonts_ibm-plex-mono.md`
- Noto Sans: `eula_fonts_noto-sans.md`
- Noto Sans Mono: `eula_fonts_noto-sans-mono.md`
- Noto Sans Arabic: `eula_fonts_noto-sans-arabic.md`
- Noto Sans Hebrew: `eula_fonts_noto-sans-hebrew.md`
- Noto Sans Japanese: `eula_fonts_noto-sans-japanese.md`
- Noto Sans Korean: `eula_fonts_noto-sans-korean.md`
- Roboto: `eula_fonts_roboto.md`
